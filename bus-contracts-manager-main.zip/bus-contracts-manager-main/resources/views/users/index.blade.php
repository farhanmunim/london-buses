<x-app-layout :crumb="'Manage users'">
    @php
        $isSuperadmin = auth()->user()->isSuperadmin();
        $hasCreateErrors = $errors->hasAny(['name', 'email', 'role', 'password']);
    @endphp
    <div x-data="{
        editing: null,
        viewing: null,
        creating: {{ $hasCreateErrors ? 'true' : 'false' }},
        /*
         * Shared inline password-confirm dialog for every mutation
         * (Add / Edit / Delete user). Mirrors the Settings > Data
         * control pattern: capture the operator's password, write it
         * into the originating form's hidden `confirm_password` field,
         * then submit programmatically. Server-side this is checked
         * via App\Support\PasswordConfirm::check($request,
         * 'confirm_password'); a different field name from the new
         * user's `password` so the two can coexist in one POST.
         */
        passwordPrompt: { form: null, password: '', label: '' },
        queueForPassword(event, label) {
            event.preventDefault();
            this.passwordPrompt = {
                form: event.target,
                password: '',
                label: label || 'this action',
            };
            this.$nextTick(() => this.$refs.passwordInput?.focus());
        },
        cancelPasswordPrompt() {
            this.passwordPrompt = { form: null, password: '', label: '' };
        },
        submitWithPassword() {
            if (! this.passwordPrompt.password) return;
            const form = this.passwordPrompt.form;
            const hidden = form?.querySelector('input[name=confirm_password]');
            if (hidden) hidden.value = this.passwordPrompt.password;
            const formToSubmit = form;
            this.cancelPasswordPrompt();
            formToSubmit?.submit();
        },
    }"
         @keydown.escape.window="editing = null; viewing = null; creating = false; cancelPasswordPrompt()">
        <div class="page__header">
            <div>
                <h1 class="page__title">
                    @if ($showArchived)
                        Archived users
                    @else
                        Manage users
                    @endif
                </h1>
                <div class="page__subtitle">
                    @if ($showArchived)
                        {{ $users->count() }} archived {{ \Illuminate\Support\Str::plural('account', $users->count()) }}. Restore from here to bring an account back into the active list.
                    @else
                        {{ $users->count() }} active {{ \Illuminate\Support\Str::plural('account', $users->count()) }}. Roles: superadmin (singleton), admin (elevated), user (default).
                    @endif
                </div>
            </div>
            <div class="page__actions">
                @if ($showArchived)
                    <a href="{{ route('users.index') }}" class="btn btn--secondary">← Back to active</a>
                @else
                    @if ($archivedCount > 0)
                        <a href="{{ route('users.index', ['archived' => 1]) }}" class="btn btn--secondary">
                            Archived <span class="chip__count">{{ $archivedCount }}</span>
                        </a>
                    @endif
                    @if ($isSuperadmin)
                        <button type="button" class="btn btn--default" @click="creating = true">
                            <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                            Add user
                        </button>
                    @endif
                @endif
            </div>
        </div>

        @if (session('status'))
            <div class="alert alert--success" role="status">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5"/></svg>
                {{ session('status') }}
            </div>
        @endif

        @if (session('updateError'))
            <div class="alert alert--destructive" role="alert">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                {{ session('updateError') }}
            </div>
        @endif

        <div class="table-wrap">
            <div class="table-scroll">
                <table class="table">
                    <thead>
                        <tr class="table__header-row">
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Role</th>
                            <th scope="col">Status</th>
                            <th scope="col">Last login</th>
                            <th scope="col" class="num"><span class="sr-only">Actions</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $user)
                            @php
                                $lastLogin = $lastLoginIps->get($user->id);
                                [$roleLabel, $roleBadge] = match ($user->role) {
                                    \App\Models\User::ROLE_SUPERADMIN => ['Superadmin', 'badge--info'],
                                    \App\Models\User::ROLE_ADMIN => ['Admin', 'badge--warning'],
                                    default => ['User', 'badge--neutral'],
                                };
                                $logins = $loginsByUser->get($user->id, collect());
                                $isCurrent = $user->id === auth()->id();
                                $frozen = $user->isFrozen();
                            @endphp
                            <tr class="{{ $frozen ? 'is-frozen' : '' }}">
                                <td>
                                    <span class="is-medium">{{ $user->name }}</span>
                                    @if ($isCurrent)
                                        <span class="id-token">you</span>
                                    @endif
                                </td>
                                <td><span class="is-mono">{{ $user->email }}</span></td>
                                <td>
                                    <span class="badge {{ $roleBadge }} badge--with-dot">{{ $roleLabel }}</span>
                                </td>
                                <td>
                                    @if ($frozen)
                                        <span class="badge badge--destructive badge--with-dot" title="Frozen on {{ $user->frozen_at->format('d/m/Y H:i:s') }}">Frozen</span>
                                    @else
                                        <span class="badge badge--success badge--with-dot">Active</span>
                                    @endif
                                </td>
                                <td>
                                    @if ($lastLogin)
                                        <span class="is-medium">{{ $lastLogin->logged_in_at->format('d/m/Y H:i:s') }}</span>
                                        <span class="id-token">{{ $lastLogin->ip_address ?? '—' }}</span>
                                    @else
                                        <span class="text-soft">Never</span>
                                    @endif
                                </td>
                                <td class="num">
                                    <div class="audit-row-actions">
                                        @if (auth()->user()->canViewLoginLogs())
                                            <button type="button" class="row-action"
                                                    :class="{ 'is-active': viewing === {{ $user->id }} }"
                                                    :aria-expanded="viewing === {{ $user->id }}"
                                                    aria-label="Login history for {{ $user->name }}"
                                                    data-tooltip="Login history"
                                                    @click="viewing = (viewing === {{ $user->id }} ? null : {{ $user->id }})">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                            </button>
                                        @endif

                                        <button type="button" class="row-action"
                                                aria-label="{{ $showArchived ? 'View' : 'Edit' }} {{ $user->name }}"
                                                data-tooltip="{{ $showArchived ? 'View' : 'Edit' }}"
                                                data-id="{{ $user->id }}"
                                                data-name="{{ $user->name }}"
                                                data-email="{{ $user->email }}"
                                                data-role="{{ $user->role }}"
                                                data-is-superadmin="{{ $user->isSuperadmin() ? '1' : '0' }}"
                                                data-is-current="{{ $isCurrent ? '1' : '0' }}"
                                                data-frozen="{{ $frozen ? '1' : '0' }}"
                                                @click="editing = {
                                                    id: $el.dataset.id,
                                                    name: $el.dataset.name,
                                                    email: $el.dataset.email,
                                                    role: $el.dataset.role,
                                                    isSuperadmin: $el.dataset.isSuperadmin === '1',
                                                    isCurrent: $el.dataset.isCurrent === '1',
                                                    frozen: $el.dataset.frozen === '1',
                                                    setPassword: false,
                                                }">
                                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                        </button>

                                        @if (! $user->isSuperadmin() && ! $isCurrent)
                                            @if ($showArchived)
                                                <form method="POST" action="{{ route('users.restore', $user) }}" class="form--inline"
                                                      @submit="if (! confirm('Restore {{ $user->name }}? Account stays frozen — unfreeze separately to allow sign-in.')) { $event.preventDefault(); return; } queueForPassword($event, 'restoring {{ $user->name }}');">
                                                    @csrf
                                                    @method('PATCH')
                                                    <input type="hidden" name="confirm_password" value="">
                                                    <button type="submit" class="row-action" aria-label="Restore {{ $user->name }}" data-tooltip="Restore">
                                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
                                                    </button>
                                                </form>
                                            @else
                                                <form method="POST" action="{{ route('users.destroy', $user) }}" class="form--inline"
                                                      @submit="if (! confirm('Archive {{ $user->name }} ({{ $user->email }})? Account is hidden from this list and cannot sign in. Audit history is preserved. Restore from the Archived view if needed.')) { $event.preventDefault(); return; } queueForPassword($event, 'archiving {{ $user->name }}');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <input type="hidden" name="confirm_password" value="">

                                                    <button type="submit" class="row-action text-destructive" aria-label="Archive {{ $user->name }}" data-tooltip="Archive">
                                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/></svg>
                                                    </button>
                                                </form>
                                            @endif
                                        @endif
                                    </div>
                                </td>
                            </tr>

                            <tr x-show="viewing === {{ $user->id }}" x-cloak class="audit-detail-row">
                                <td colspan="6">
                                    <div class="audit-detail">
                                        <div class="audit-detail__heading">
                                            Login history
                                            @if ($logins->isNotEmpty())
                                                · last {{ $logins->count() }}
                                            @endif
                                        </div>
                                        @if ($logins->isEmpty())
                                            <div class="audit-detail__empty field--gap-top">
                                                {{ $user->name }} has not signed in yet. Login events are recorded automatically the first time they sign in.
                                            </div>
                                        @else
                                            <table class="audit-mini field--gap-top">
                                                <thead>
                                                    <tr>
                                                        <th>When</th>
                                                        <th>IP address</th>
                                                        <th>User agent</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($logins as $login)
                                                        <tr>
                                                            <td>{{ $login->logged_in_at->format('d/m/Y H:i:s') }}</td>
                                                            <td>{{ $login->ip_address ?? '—' }}</td>
                                                            <td title="{{ $login->user_agent }}">{{ \Illuminate\Support\Str::limit($login->user_agent, 80) }}</td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="table-footer">
                <div>{{ $users->count() }} {{ \Illuminate\Support\Str::plural('account', $users->count()) }} · {{ $users->where('role', \App\Models\User::ROLE_SUPERADMIN)->count() }} superadmin · {{ $users->where('role', \App\Models\User::ROLE_ADMIN)->count() }} admin · {{ $users->where('role', \App\Models\User::ROLE_USER)->count() }} user</div>
            </div>
        </div>

        <!-- Edit user -->
        @php
            // Mirror the contracts pattern: archived users are immutable.
            // The Edit dialog still opens (so admins can SEE the record),
            // but every input is read-only and the only footer action is
            // Restore. This is enforced UI-side here AND server-side via
            // abort_if($user->isArchived(), 404) in UsersController.
            $editCanWrite = ! $showArchived;
        @endphp
        <div x-show="editing !== null" x-cloak @keydown.escape.window="editing = null" role="dialog" aria-modal="true" aria-labelledby="edit-user-title">
            <div class="dialog__overlay" @click="editing = null" aria-hidden="true"></div>
            <template x-if="editing !== null">
                <div class="dialog__content dialog__content--lg">
                    <h2 class="dialog__title" id="edit-user-title">{{ $editCanWrite ? 'Edit user' : 'View user' }}</h2>
                    <p class="dialog__description" x-text="editing.email"></p>

                    <form method="POST" :action="`/users/${editing.id}`"
                          @submit="if (! confirm(`Save changes to ${editing.name}?`)) { $event.preventDefault(); return; } queueForPassword($event, `editing ${editing.name}`);">
                        @csrf
                        @method('PATCH')
                        <input type="hidden" name="confirm_password" value="">

                        <div class="dialog__body">
                            <div class="field">
                                <label class="label" for="edit-user-name">Name</label>
                                <input id="edit-user-name" type="text" class="input" name="name" :value="editing.name" @required($editCanWrite) @readonly(! $editCanWrite)>
                            </div>
                            <div class="field">
                                <label class="label" for="edit-user-email">Email</label>
                                <input id="edit-user-email" type="email" class="input" name="email" :value="editing.email" @required($editCanWrite) @readonly(! $editCanWrite) autocomplete="off">
                            </div>
                            <div class="field">
                                <label class="label" for="edit-user-role">Role</label>
                                <select id="edit-user-role" name="role" class="input" :disabled="editing.isSuperadmin || ! {{ $editCanWrite ? 'true' : 'false' }}">
                                    @foreach ($roleOptions as $role)
                                        <option value="{{ $role }}" x-bind:selected="editing.role === '{{ $role }}'">
                                            {{ ucfirst($role) }}
                                        </option>
                                    @endforeach
                                </select>
                                <span class="field__hint" x-show="editing.isSuperadmin">The superadmin slot is fixed.</span>
                            </div>

                            {{-- Freeze toggle --}}
                            <div class="field">
                                <label class="label">Access</label>
                                <label class="toggle-row">
                                    <input type="hidden" name="frozen" value="0">
                                    <input type="checkbox" name="frozen" value="1" x-model="editing.frozen" :disabled="editing.isSuperadmin || editing.isCurrent || ! {{ $editCanWrite ? 'true' : 'false' }}">
                                    <span class="toggle-row__body">
                                        <span class="toggle-row__title">Freeze account</span>
                                        <span class="toggle-row__hint">
                                            Frozen users cannot sign in but all of their data is preserved. Reverse anytime.
                                            <template x-if="editing.isSuperadmin"><span> The superadmin cannot be frozen.</span></template>
                                            <template x-if="editing.isCurrent"><span> You cannot freeze your own account.</span></template>
                                        </span>
                                    </span>
                                </label>
                            </div>

                            @if ($isSuperadmin && $editCanWrite)
                                <div class="field">
                                    <label class="label">Password</label>
                                    <label class="toggle-row">
                                        <input type="checkbox" x-model="editing.setPassword">
                                        <span class="toggle-row__body">
                                            <span class="toggle-row__title">Set a new password</span>
                                            <span class="toggle-row__hint">Leave unchecked to keep the current password. Communicate the new password out-of-band.</span>
                                        </span>
                                    </label>
                                </div>

                                <div class="field" x-show="editing.setPassword" x-cloak>
                                    <label class="label" for="edit-user-password">New password</label>
                                    <input id="edit-user-password" type="password" class="input" name="password" autocomplete="new-password" minlength="8" :required="editing.setPassword" :disabled="! editing.setPassword">
                                    <span class="field__hint">Minimum 8 characters. The password is never logged.</span>
                                    <x-input-error :messages="$errors->get('password')" />
                                </div>
                                <div class="field" x-show="editing.setPassword" x-cloak>
                                    <label class="label" for="edit-user-password-confirmation">Confirm new password</label>
                                    <input id="edit-user-password-confirmation" type="password" class="input" name="password_confirmation" autocomplete="new-password" minlength="8" :required="editing.setPassword" :disabled="! editing.setPassword">
                                </div>
                            @endif
                        </div>
                        <div class="dialog__footer dialog__footer--split">
                            @if ($showArchived)
                                {{-- The Save action is disabled on the
                                     archived view; the only meaningful
                                     action is Restore (handled by the
                                     row-level form, not this dialog). --}}
                                <span></span>
                            @else
                                <span></span>
                            @endif
                            <div class="dialog__actions">
                                <button type="button" class="btn btn--secondary" @click="editing = null">{{ $editCanWrite ? 'Cancel' : 'Close' }}</button>
                                @if ($editCanWrite)
                                    <button type="submit" class="btn btn--default">Save</button>
                                @endif
                            </div>
                        </div>
                    </form>
                </div>
            </template>
        </div>

        @if ($isSuperadmin)
            <!-- Add user (superadmin only) -->
            <div x-show="creating" x-cloak @keydown.escape.window="creating = false" role="dialog" aria-modal="true" aria-labelledby="add-user-title">
                <div class="dialog__overlay" @click="creating = false" aria-hidden="true"></div>
                <div class="dialog__content dialog__content--lg" x-show="creating" x-cloak>
                    <h2 class="dialog__title" id="add-user-title">Add user</h2>
                    <p class="dialog__description">Create an account. The user will sign in with the email and password you set here.</p>

                    <form method="POST" action="{{ route('users.store') }}"
                          @submit="if (! confirm('Create this user account?')) { $event.preventDefault(); return; } queueForPassword($event, 'creating this user');">
                        @csrf
                        <input type="hidden" name="confirm_password" value="">

                        <div class="dialog__body">
                            <div class="field">
                                <label class="label" for="new-user-name">Name</label>
                                <input id="new-user-name" type="text" class="input" name="name" value="{{ old('name') }}" required autofocus>
                                <x-input-error :messages="$errors->get('name')" />
                            </div>
                            <div class="field">
                                <label class="label" for="new-user-email">Email</label>
                                <input id="new-user-email" type="email" class="input" name="email" value="{{ old('email') }}" required autocomplete="off">
                                <x-input-error :messages="$errors->get('email')" />
                            </div>
                            <div class="field">
                                <label class="label" for="new-user-role">Role</label>
                                <select id="new-user-role" name="role" class="input">
                                    <option value="{{ \App\Models\User::ROLE_USER }}" {{ old('role', 'user') === 'user' ? 'selected' : '' }}>User</option>
                                    <option value="{{ \App\Models\User::ROLE_ADMIN }}" {{ old('role') === 'admin' ? 'selected' : '' }}>Admin</option>
                                </select>
                                <span class="field__hint">Superadmin is a singleton role and cannot be assigned here.</span>
                                <x-input-error :messages="$errors->get('role')" />
                            </div>
                            <div class="field">
                                <label class="label" for="new-user-password">Password</label>
                                <input id="new-user-password" type="password" class="input" name="password" required autocomplete="new-password" minlength="8">
                                <span class="field__hint">Minimum 8 characters. Communicate it to the user out-of-band — it is never logged.</span>
                                <x-input-error :messages="$errors->get('password')" />
                            </div>
                            <div class="field">
                                <label class="label" for="new-user-password-confirmation">Confirm password</label>
                                <input id="new-user-password-confirmation" type="password" class="input" name="password_confirmation" required autocomplete="new-password" minlength="8">
                            </div>
                        </div>
                        <div class="dialog__footer">
                            <button type="button" class="btn btn--secondary" @click="creating = false">Cancel</button>
                            <button type="submit" class="btn btn--default">Create user</button>
                        </div>
                    </form>
                </div>
            </div>
        @endif

        {{-- Shared password-confirm dialog. Opened by every Add / Edit /
             Delete form's @submit handler via queueForPassword(). On
             Confirm we paste the typed password into the form's hidden
             `confirm_password` field and submit programmatically — the
             server then validates via PasswordConfirm::check(). --}}
        <div x-show="passwordPrompt.form !== null" x-cloak role="dialog" aria-modal="true" aria-labelledby="users-password-confirm-title">
            <div class="dialog__overlay" @click="cancelPasswordPrompt()" aria-hidden="true"></div>
            <div class="dialog__content" x-show="passwordPrompt.form !== null" x-cloak>
                <h2 class="dialog__title" id="users-password-confirm-title">Confirm with your password</h2>
                <p class="dialog__description">Re-enter your own password to authorise this user-management action.</p>

                <form @submit.prevent="submitWithPassword()">
                    <div class="dialog__body">
                        <div class="field">
                            <label class="label" for="users-password-confirm-input">Your password</label>
                            <input id="users-password-confirm-input"
                                   type="password"
                                   class="input"
                                   autocomplete="current-password"
                                   x-ref="passwordInput"
                                   x-model="passwordPrompt.password"
                                   required>
                            @if ($errors->has('confirm_password'))
                                <span class="field__hint text-destructive">{{ $errors->first('confirm_password') }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="dialog__footer">
                        <button type="button" class="btn btn--secondary" @click="cancelPasswordPrompt()">Cancel</button>
                        <button type="submit" class="btn btn--default" :disabled="! passwordPrompt.password">Confirm</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>
