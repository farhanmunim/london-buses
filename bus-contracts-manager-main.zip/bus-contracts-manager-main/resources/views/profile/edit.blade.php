<x-app-layout :crumb="'Profile'">
    <div class="page__header">
        <div>
            <h1 class="page__title">Profile</h1>
            <p class="page__subtitle">Manage your account details and security.</p>
        </div>
    </div>

    <div class="stack stack--lg stack--narrow">
        <section class="card" aria-labelledby="profile-info-title">
            <header class="card__header">
                <div>
                    <h2 class="card__title" id="profile-info-title">Profile information</h2>
                    <p class="card__subtitle">Update your name and email address.</p>
                </div>
            </header>
            <div class="card__body">
                @include('profile.partials.update-profile-information-form')
            </div>
        </section>

        <section class="card" aria-labelledby="profile-pwd-title">
            <header class="card__header">
                <div>
                    <h2 class="card__title" id="profile-pwd-title">Password</h2>
                    <p class="card__subtitle">Use a long, random password to stay secure.</p>
                </div>
            </header>
            <div class="card__body">
                @include('profile.partials.update-password-form')
            </div>
        </section>

        <section class="card" aria-labelledby="profile-delete-title">
            <header class="card__header">
                <div>
                    <h2 class="card__title" id="profile-delete-title">Delete account</h2>
                    <p class="card__subtitle">Permanently delete your account and all associated data.</p>
                </div>
            </header>
            <div class="card__body">
                @include('profile.partials.delete-user-form')
            </div>
        </section>
    </div>
</x-app-layout>
