<form id="send-verification" method="post" action="{{ route('verification.send') }}">
    @csrf
</form>

<form method="post" action="{{ route('profile.update') }}" class="space-y-4"
      x-data
      @submit="if (! confirm('Update your profile information?')) $event.preventDefault();">
    @csrf
    @method('patch')

    <div class="field">
        <x-input-label for="name" :value="__('Name')" />
        <x-text-input id="name" name="name" type="text" :value="old('name', $user->name)" required autofocus autocomplete="name" />
        <x-input-error :messages="$errors->get('name')" />
    </div>

    <div class="field">
        <x-input-label for="email" :value="__('Email')" />
        <x-text-input id="email" name="email" type="email" :value="old('email', $user->email)" required autocomplete="username" />
        <x-input-error :messages="$errors->get('email')" />

        @if ($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail())
            <p class="field__hint">
                {{ __('Your email address is unverified.') }}
                <button form="send-verification" class="btn btn--link">{{ __('Resend verification.') }}</button>
            </p>

            @if (session('status') === 'verification-link-sent')
                <p class="field__hint field__hint--success" role="status">{{ __('A new verification link has been sent.') }}</p>
            @endif
        @endif
    </div>

    @php
        $roleMeta = match ($user->role) {
            \App\Models\User::ROLE_SUPERADMIN => [
                'label' => 'Superadmin',
                'tier' => 'superadmin',
                'description' => 'Full access. Singleton role — cannot be changed.',
            ],
            \App\Models\User::ROLE_ADMIN => [
                'label' => 'Admin',
                'tier' => 'admin',
                'description' => 'Elevated access — may manage other users and data.',
            ],
            default => [
                'label' => 'User',
                'tier' => 'user',
                'description' => 'Standard access — read and edit your own work.',
            ],
        };
    @endphp
    <div class="field">
        <x-input-label :value="__('Account type')" />
        <div class="role-display role-display--{{ $roleMeta['tier'] }}" role="group" aria-label="Account type">
            <span class="role-display__icon" aria-hidden="true">
                @if ($roleMeta['tier'] === 'superadmin')
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M12 2 4 5v6c0 5 3.4 9.5 8 11 4.6-1.5 8-6 8-11V5l-8-3Z"/><path d="m9 12 2 2 4-4"/></svg>
                @elseif ($roleMeta['tier'] === 'admin')
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M12 2 4 5v6c0 5 3.4 9.5 8 11 4.6-1.5 8-6 8-11V5l-8-3Z"/></svg>
                @else
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>
                @endif
            </span>
            <div class="role-display__body">
                <div class="role-display__name">
                    {{ $roleMeta['label'] }}
                    <span class="role-display__lock" data-tooltip="Read-only" aria-label="Read-only">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>
                    </span>
                </div>
                <p class="role-display__description">{{ $roleMeta['description'] }}</p>
            </div>
        </div>
    </div>

    <div class="cluster cluster--gap-top">
        <x-primary-button>{{ __('Save') }}</x-primary-button>

        @if (session('status') === 'profile-updated')
            <span x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 2000)" class="text-muted text-sm" role="status">{{ __('Saved.') }}</span>
        @endif
    </div>
</form>
