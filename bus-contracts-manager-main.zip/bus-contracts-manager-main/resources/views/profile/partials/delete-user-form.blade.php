<div x-data="{ confirmOpen: {{ $errors->userDeletion->isNotEmpty() ? 'true' : 'false' }} }">
    <p class="text-sm text-muted text-bottom-gap">{{ __('This action cannot be undone. All of your data will be permanently removed.') }}</p>

    <x-danger-button x-on:click.prevent="confirmOpen = true">{{ __('Delete account') }}</x-danger-button>

    <div x-show="confirmOpen" x-cloak @keydown.escape.window="confirmOpen = false" role="dialog" aria-modal="true" aria-labelledby="delete-account-title">
        <div class="dialog__overlay" @click="confirmOpen = false" aria-hidden="true"></div>
        <div class="dialog__content">
            <form method="post" action="{{ route('profile.destroy') }}">
                @csrf
                @method('delete')

                <h2 class="dialog__title" id="delete-account-title">{{ __('Delete account?') }}</h2>
                <p class="dialog__description">{{ __('All of your data will be permanently removed. Enter your password to confirm.') }}</p>

                <div class="dialog__body">
                    <div class="field">
                        <x-input-label for="password" value="{{ __('Password') }}" />
                        <x-text-input id="password" name="password" type="password" placeholder="{{ __('Password') }}" />
                        <x-input-error :messages="$errors->userDeletion->get('password')" />
                    </div>
                </div>

                <div class="dialog__footer">
                    <button type="button" class="btn btn--secondary" @click="confirmOpen = false">{{ __('Cancel') }}</button>
                    <x-danger-button>{{ __('Delete account') }}</x-danger-button>
                </div>
            </form>
        </div>
    </div>
</div>
