<form method="post" action="{{ route('password.update') }}" class="space-y-4"
      x-data
      @submit="if (! confirm('Change your password? You will continue to be signed in on this device.')) $event.preventDefault();">
    @csrf
    @method('put')

    <div class="field">
        <x-input-label for="update_password_current_password" :value="__('Current password')" />
        <x-text-input id="update_password_current_password" name="current_password" type="password" autocomplete="current-password" />
        <x-input-error :messages="$errors->updatePassword->get('current_password')" />
    </div>

    <div class="field">
        <x-input-label for="update_password_password" :value="__('New password')" />
        <x-text-input id="update_password_password" name="password" type="password" autocomplete="new-password" />
        <x-input-error :messages="$errors->updatePassword->get('password')" />
    </div>

    <div class="field">
        <x-input-label for="update_password_password_confirmation" :value="__('Confirm password')" />
        <x-text-input id="update_password_password_confirmation" name="password_confirmation" type="password" autocomplete="new-password" />
        <x-input-error :messages="$errors->updatePassword->get('password_confirmation')" />
    </div>

    <div class="cluster cluster--gap-top">
        <x-primary-button>{{ __('Save') }}</x-primary-button>

        @if (session('status') === 'password-updated')
            <span x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 2000)" class="text-muted text-sm" role="status">{{ __('Saved.') }}</span>
        @endif
    </div>
</form>
