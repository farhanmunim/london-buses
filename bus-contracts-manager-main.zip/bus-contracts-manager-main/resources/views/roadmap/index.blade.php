<x-app-layout :crumb="'Roadmap'">
    <div class="page__header">
        <div>
            <h1 class="page__title">Roadmap</h1>
            <div class="page__subtitle">
                What's shipped, what's coming, and what's on the wishlist.
            </div>
        </div>
    </div>

    @if ($totalCount === 0)
        <div class="card">No roadmap items yet.</div>
    @else
        @php
            $progressStats = collect($sectionOrder)
                ->filter(fn ($k) => count($grouped[$k]) > 0)
                ->map(fn ($k) => [
                    'label' => $statuses[$k]['label'] ?? ucfirst($k),
                    'count' => count($grouped[$k]),
                    'badge' => $statuses[$k]['badge'] ?? 'badge--neutral',
                ])
                ->values();
        @endphp

        <div class="roadmap__totals">
            @foreach ($progressStats as $stat)
                <div class="roadmap__total">
                    <div class="roadmap__total-num">{{ $stat['count'] }}</div>
                    <div class="roadmap__total-label">{{ $stat['label'] }}</div>
                </div>
            @endforeach
            <div class="roadmap__total roadmap__total--all">
                <div class="roadmap__total-num">{{ $totalCount }}</div>
                <div class="roadmap__total-label">Total</div>
            </div>
        </div>

        @foreach ($sectionOrder as $statusKey)
            @php
                $items = $grouped[$statusKey] ?? [];
                if (count($items) === 0) {
                    continue;
                }
                $status = $statuses[$statusKey] ?? ['label' => ucfirst($statusKey), 'badge' => 'badge--neutral'];
            @endphp

            <section class="roadmap__section roadmap__section--{{ $statusKey }}">
                <header class="roadmap__section-head">
                    <span class="badge {{ $status['badge'] }}">{{ $status['label'] }}</span>
                    <span class="roadmap__section-count">{{ count($items) }}</span>
                </header>

                <div class="roadmap__grid">
                    @foreach ($items as $item)
                        <article class="roadmap__card roadmap__card--{{ $statusKey }}">
                            <h3 class="roadmap__card-title">{{ $item['title'] }}</h3>
                            <p class="roadmap__card-description">{{ $item['description'] }}</p>
                            @if (! empty($item['area']))
                                <div class="roadmap__card-area">{{ $item['area'] }}</div>
                            @endif
                        </article>
                    @endforeach
                </div>
            </section>
        @endforeach
    @endif
</x-app-layout>
