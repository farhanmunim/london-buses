@php
    /** @var string $title */
    /** @var ?string $description */
    $slug = strtolower($title);
@endphp
<x-app-layout :crumb="'Indices / '.$title">
    <div class="page__header">
        <div>
            <h1 class="page__title">{{ $title }}</h1>
            <p class="page__subtitle">{{ $description ?? 'This index series is coming soon.' }}</p>
        </div>
    </div>

    {{-- Match the tab nav used by CPI / CPA / RPI so navigation stays consistent. --}}
    <nav class="tabs" aria-label="Indices views">
        <a href="{{ route('indices.cpi') }}" class="tabs__item">CPI</a>
        <a href="{{ route('indices.cpa') }}" class="tabs__item">CPA</a>
        <a href="{{ route('indices.rpi') }}" class="tabs__item">RPI</a>
        <a href="{{ route('indices.cebr') }}" class="tabs__item {{ $slug === 'cebr' ? 'is-active' : '' }}" @if ($slug === 'cebr') aria-current="page" @endif>CEBR</a>
        <a href="{{ route('indices.derv') }}" class="tabs__item {{ $slug === 'derv' ? 'is-active' : '' }}" @if ($slug === 'derv') aria-current="page" @endif>DERV</a>
    </nav>

    <x-coming-soon :title="$title" :description="($description ?? '').' This view is being built.'" />
</x-app-layout>
