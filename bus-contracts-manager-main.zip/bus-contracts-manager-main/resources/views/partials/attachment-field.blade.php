@php
    /**
     * Attachment upload field — used inside the five contract dialogs:
     * Edit contract, CPA confirmation, Extension, Notice served, Tender
     * award. Reuses the dropzone styling that the bulk-import modal
     * uses so the visual language is consistent across the app.
     *
     * Args:
     *   fieldId — unique DOM id for the input.
     *
     * The form this lives in MUST declare `enctype="multipart/form-data"`.
     *
     * Duplicate-detection workflow:
     *   1. On file selection, the component fires a pre-flight XHR to
     *      /contracts/check-attachment-duplicate.
     *   2. If existing attachments share the sanitised filename, the
     *      panel below the dropzone shows four options:
     *        - Link existing (recommended, only shown when at least
     *                         one active copy exists): server skips
     *                         writing bytes and just creates an
     *                         attachment_link pointing at the existing
     *                         file. Saves storage and sidesteps "which
     *                         copy is canonical?" ambiguity.
     *        - Replace existing: server updates bytes everywhere this
     *                            filename is used; new audit row also
     *                            attaches the same bytes.
     *        - Keep both: server appends a timestamp to the filename
     *                     and saves independently.
     *        - Cancel: handled client-side; never reaches the server.
     *   3. The chosen action lands in a hidden `dupe_action` field; the
     *      Save button is disabled until either no dupe exists or an
     *      action has been picked.
     */
    $fieldId = $fieldId ?? 'attachment';

    // Read the live limits so the picker filter and hint text reflect
    // whatever the superadmin configured under Settings > Upload limits.
    $allowedExtensions = \App\Models\Attachment::allowedExtensions();
    $maxKb = \App\Models\Attachment::maxUploadKb();
    $maxLabel = $maxKb >= 1024 ? round($maxKb / 1024, 1).' MB' : $maxKb.' KB';
    $extLabel = collect($allowedExtensions)->map(fn ($e) => strtoupper($e))->implode(' · ');
    $acceptAttr = collect($allowedExtensions)->map(fn ($e) => '.'.$e)->implode(',');
@endphp

<div class="field field--full"
     x-data="{
        attachmentName: '',
        duplicates: [],
        dupeAction: '',
        sanitised: '',
        checking: false,
        async onPick(event) {
            this.attachmentName = event.target.files[0]?.name ?? '';
            this.duplicates = [];
            this.dupeAction = '';
            this.sanitised = '';
            if (! this.attachmentName) return;
            this.checking = true;
            try {
                const resp = await fetch('{{ route('contracts.check-attachment-duplicate') }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]')?.content ?? '',
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({ filename: this.attachmentName }),
                });
                if (! resp.ok) throw new Error('check failed');
                const body = await resp.json();
                this.duplicates = body.duplicates ?? [];
                this.sanitised = body.sanitised_filename ?? this.attachmentName;
            } catch (e) {
                /* swallow — server-side guard will catch the dupe on submit */
            } finally {
                this.checking = false;
            }
        },
        clearFile(event) {
            const input = event.target.closest('.field').querySelector('input[type=file]');
            if (input) input.value = '';
            this.attachmentName = '';
            this.duplicates = [];
            this.dupeAction = '';
            this.sanitised = '';
        },
     }">
    <label for="{{ $fieldId }}" class="label">Attachment <span class="is-soft">(optional)</span></label>
    <label for="{{ $fieldId }}" class="dropzone" :class="attachmentName && 'dropzone--has-file'">
        <input id="{{ $fieldId }}" name="attachment" type="file"
               accept="{{ $acceptAttr }}"
               class="sr-only"
               @change="onPick($event)">
        <svg class="dropzone__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true">
            <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66L9.41 17.41a2 2 0 0 1-2.83-2.83L15.41 5.75"/>
        </svg>
        <span class="dropzone__text" x-text="attachmentName || 'Click to attach a file'"></span>
        <span class="dropzone__hint">{{ $extLabel }} · up to {{ $maxLabel }}</span>
    </label>
    <input type="hidden" name="dupe_action" :value="dupeAction">
    <x-input-error :messages="$errors->get('attachment')" />

    {{-- Inline loading hint while the dupe-check XHR is in flight.
         Without it, picking a file looks frozen until the response
         lands and the dupe panel pops into view. --}}
    <span class="field__hint" x-show="checking" x-cloak>Checking for duplicates…</span>

    {{-- Pre-flight result. Shown only when the chosen filename clashes
         with at least one existing attachment. --}}
    <div class="dupe-warning" x-show="duplicates.length > 0" x-cloak>
        <div class="dupe-warning__head">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>
            <div>
                <strong x-text="`A file named “${sanitised}” already exists`"></strong>
                <span class="dupe-warning__sub" x-text="duplicates.length === 1 ? '1 record uses it.' : `${duplicates.length} records use it.`"></span>
            </div>
        </div>

        <div class="dupe-warning__list">
            <template x-for="d in duplicates.slice(0, 3)" :key="d.id">
                <div class="dupe-warning__item">
                    <span x-text="d.context || 'Audit entry'"></span>
                    <span class="dupe-warning__meta" x-text="`${d.uploader || 'unknown'} · ${d.when}`"></span>
                </div>
            </template>
            <div class="dupe-warning__item is-soft" x-show="duplicates.length > 3" x-text="`…${duplicates.length - 3} more`"></div>
        </div>

        <div class="dupe-warning__actions">
            {{-- Link existing — first option, recommended whenever at
                 least one ACTIVE copy of the file exists. Skips the
                 byte upload entirely and points this slot at the
                 already-stored file. --}}
            <label class="kind-row__option"
                   :class="{ 'is-selected': dupeAction === 'link' }"
                   x-show="duplicates.some(d => d.is_active)" x-cloak>
                <input type="radio" x-model="dupeAction" value="link">
                <span class="kind-row__body">
                    <span class="kind-row__title">Link existing file <span class="is-soft">(recommended)</span></span>
                    <span class="kind-row__hint">Reuse the file already in the system — no new upload, no duplicated bytes. Detaching this slot later won't affect the other records still using the file.</span>
                </span>
            </label>
            <label class="kind-row__option" :class="{ 'is-selected': dupeAction === 'replace' }">
                <input type="radio" x-model="dupeAction" value="replace">
                <span class="kind-row__body">
                    <span class="kind-row__title">Replace existing</span>
                    <span class="kind-row__hint">Update the file bytes everywhere this filename appears in the audit trail. The new upload becomes the canonical version.</span>
                </span>
            </label>
            <label class="kind-row__option" :class="{ 'is-selected': dupeAction === 'keep' }">
                <input type="radio" x-model="dupeAction" value="keep">
                <span class="kind-row__body">
                    <span class="kind-row__title">Keep both</span>
                    <span class="kind-row__hint">Save the new upload alongside the existing — its filename gets a timestamp suffix to disambiguate.</span>
                </span>
            </label>
            <button type="button" class="btn btn--ghost btn--sm" @click="clearFile($event)">Cancel upload</button>
        </div>
    </div>
</div>
