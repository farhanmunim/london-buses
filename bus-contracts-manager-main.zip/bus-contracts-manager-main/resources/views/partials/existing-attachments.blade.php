@php
    /**
     * Renders the list of currently-attached files for a
     * record-item, with download + soft-detach controls. Driven entirely
     * by Alpine state (no server-side data) so the list can update
     * in-place after a successful detach without a page reload.
     *
     * Args (from @include):
     *   stateVar — Alpine path to the array, e.g. 'confirmingCpa.attachments'
     *
     * The state array is mutated in place by the inline `detachAttachment`
     * helper: on confirm + 200 response we splice the row out so the
     * dialog stays open and consistent.
     */
    $stateVar = $stateVar ?? 'attachments';
@endphp

<div class="field field--full" x-show="{{ $stateVar }}.length > 0" x-cloak>
    <span class="label">Attachments</span>
    <ul class="attachment-list" role="list">
        <template x-for="att in {{ $stateVar }}" :key="att.link_id ?? att.id">
            <li class="attachment-list__item">
                <a :href="`/attachments/${att.id}/download`"
                   :download="att.filename"
                   class="attachment-list__link"
                   :title="`Download ${att.filename} (${att.size_kb} KB)`">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66L9.41 17.41a2 2 0 0 1-2.83-2.83L15.41 5.75"/></svg>
                    <span class="attachment-list__name" x-text="att.filename"></span>
                    <span class="attachment-list__meta" x-text="`${att.size_kb} KB · ${att.when}`"></span>
                </a>
                @if (auth()->user()?->canWrite())
                    <button type="button"
                            class="attachment-list__delete"
                            data-tooltip="Detach"
                            :aria-label="`Detach ${att.filename}`"
                            @click="detachAttachment(att, {{ $stateVar }})">
                        {{-- Broken-link icon — semantic match for "detach". --}}
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 17H7A5 5 0 0 1 7 7h2"/><path d="M15 7h2a5 5 0 0 1 4 8"/><line x1="2" y1="2" x2="22" y2="22"/></svg>
                    </button>
                @endif
            </li>
        </template>
    </ul>
</div>
