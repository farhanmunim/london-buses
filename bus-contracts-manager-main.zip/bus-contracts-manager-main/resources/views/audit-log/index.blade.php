@use('App\Support\AuditActions')
@use('App\Support\AuditDiffer')
@use('Illuminate\Support\Str')

<x-app-layout :crumb="'Audit log'">
    @php
        $f = $filters;
        $hasAnyFilter = ! empty($f['actions']) || ! empty($f['users']) || $f['from'] !== null || $f['to'] !== null || $f['q'] !== null;

        // Three statuses for the record column. Verbs from the
        // AuditActions catalogue collapse to one of these.
        $recordStatuses = [
            'create' => ['label' => 'Added', 'badge' => 'badge--success'],
            'update' => ['label' => 'Modified', 'badge' => 'badge--info'],
            'delete' => ['label' => 'Deleted', 'badge' => 'badge--destructive'],
            'import' => ['label' => 'Modified', 'badge' => 'badge--info'],
        ];

        // Attachment tag labels. Same colour mapping as before; only the
        // labels changed to match the record-status vocabulary.
        $attachmentEventBadges = [
            'added' => ['label' => 'Attached', 'class' => 'audit-log-attach--added'],
            'replaced' => ['label' => 'Modified', 'class' => 'audit-log-attach--replaced'],
            'removed' => ['label' => 'Detached', 'class' => 'audit-log-attach--removed'],
        ];

        $auditActionMeta = AuditActions::all();
    @endphp

    <div x-data="{ open: null, openId: null, actionsSel: @js($f['actions']), usersSel: @js(array_map('strval', $f['users'])) }"
         @keydown.escape.window="open = null">
        <div class="page__header">
            <div>
                <h1 class="page__title">Audit log</h1>
                <div class="page__subtitle">
                    @if ($filteredContract)
                        Every change to <strong>#{{ $filteredContract->id }} · {{ $filteredContract->contract_number }} · Route {{ $filteredContract->route }} · {{ $filteredContract->company }}</strong>.
                        <a href="{{ route('audit-log.index', request()->except('contract')) }}" class="audit-log__link">Show all events →</a>
                    @elseif ($contractFilter)
                        Filtered to contract id #{{ $contractFilter }} <em>(this contract no longer exists)</em>.
                        <a href="{{ route('audit-log.index', request()->except('contract')) }}" class="audit-log__link">Show all events →</a>
                    @else
                        Filter the table, then click any row to see the before / after diff inline.
                    @endif
                </div>
            </div>
        </div>

        @if (session('status'))
            <div class="alert alert--success" role="status">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5"/></svg>
                {{ session('status') }}
            </div>
        @endif

        {{-- Filter toolbar (mirrors v1's exactly, routes pointed at v4) --}}
        <div class="toolbar">
            <div class="toolbar__group">
                <a href="{{ route('audit-log.index', $contractFilter ? ['contract' => $contractFilter] : []) }}" class="chip {{ ! $hasAnyFilter ? 'is-active' : '' }}">
                    All <span class="chip__count">{{ $totalCount }}</span>
                </a>
            </div>

            <div class="toolbar__group toolbar__group--offset">
                {{-- Action popover --}}
                <div class="filter-pop" @click.outside="if (open === 'action') open = null">
                    <button type="button"
                            class="chip chip--outline {{ ! empty($f['actions']) ? 'is-active' : '' }}"
                            aria-haspopup="true"
                            :aria-expanded="open === 'action'"
                            @click="open = open === 'action' ? null : 'action'">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h10"/></svg>
                        Action
                        @if (! empty($f['actions']))
                            <span class="chip__value">
                                {{ count($f['actions']) === 1 ? $f['actions'][0] : count($f['actions']).' actions' }}
                            </span>
                        @endif
                        <svg class="chip__chev" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>

                    <form x-show="open === 'action'" x-cloak x-transition.opacity.duration.100ms
                          method="GET" action="{{ route('audit-log.index') }}"
                          class="filter-pop__menu">
                        @foreach (request()->except(['actions', 'page']) as $key => $val)
                            @if (is_array($val))
                                @foreach ($val as $v)
                                    <input type="hidden" name="{{ $key }}[]" value="{{ $v }}">
                                @endforeach
                            @else
                                <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                            @endif
                        @endforeach
                        <input type="hidden" :name="actionsSel.length ? 'actions' : null" :value="actionsSel.join(',')">

                        <div class="filter-pop__title">Filter by action</div>

                        @forelse ($actionGroups as $group)
                            <label class="filter-pop__option">
                                <input type="checkbox" value="{{ $group['label'] }}" x-model="actionsSel">
                                <span class="filter-pop__option-label">
                                    <span class="badge {{ $group['badge'] }} badge--with-dot">{{ $group['label'] }}</span>
                                </span>
                                <span class="filter-pop__option-count">{{ $group['count'] }}</span>
                            </label>
                        @empty
                            <div class="filter-pop__empty">No actions logged yet.</div>
                        @endforelse

                        <div class="filter-pop__footer">
                            @if (! empty($f['actions']))
                                <a href="{{ route('audit-log.index', request()->except(['actions', 'page'])) }}" class="btn btn--ghost btn--sm">Clear</a>
                            @else
                                <span></span>
                            @endif
                            <button type="submit" class="btn btn--default btn--sm">Apply</button>
                        </div>
                    </form>
                </div>

                {{-- User popover --}}
                @if ($users->count() > 1)
                    <div class="filter-pop" @click.outside="if (open === 'user') open = null">
                        <button type="button"
                                class="chip chip--outline {{ ! empty($f['users']) ? 'is-active' : '' }}"
                                aria-haspopup="true"
                                :aria-expanded="open === 'user'"
                                @click="open = open === 'user' ? null : 'user'">
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            User
                            @if (! empty($f['users']))
                                <span class="chip__value">
                                    {{ count($f['users']) === 1 ? ($users->firstWhere('id', $f['users'][0])->name ?? 'User') : count($f['users']).' users' }}
                                </span>
                            @endif
                            <svg class="chip__chev" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
                        </button>

                        <form x-show="open === 'user'" x-cloak x-transition.opacity.duration.100ms
                              method="GET" action="{{ route('audit-log.index') }}"
                              class="filter-pop__menu">
                            @foreach (request()->except(['users', 'page']) as $key => $val)
                                @if (is_array($val))
                                    @foreach ($val as $v)
                                        <input type="hidden" name="{{ $key }}[]" value="{{ $v }}">
                                    @endforeach
                                @else
                                    <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                                @endif
                            @endforeach
                            <input type="hidden" :name="usersSel.length ? 'users' : null" :value="usersSel.join(',')">

                            <div class="filter-pop__title">Filter by user</div>

                            @foreach ($users as $user)
                                <label class="filter-pop__option">
                                    <input type="checkbox" value="{{ $user->id }}" x-model="usersSel">
                                    <span class="filter-pop__option-label">{{ $user->name }}</span>
                                </label>
                            @endforeach

                            <div class="filter-pop__footer">
                                @if (! empty($f['users']))
                                    <a href="{{ route('audit-log.index', request()->except(['users', 'page'])) }}" class="btn btn--ghost btn--sm">Clear</a>
                                @else
                                    <span></span>
                                @endif
                                <button type="submit" class="btn btn--default btn--sm">Apply</button>
                            </div>
                        </form>
                    </div>
                @endif

                {{-- Date range popover --}}
                <div class="filter-pop" @click.outside="if (open === 'date') open = null">
                    <button type="button"
                            class="chip chip--outline {{ $f['from'] !== null || $f['to'] !== null ? 'is-active' : '' }}"
                            aria-haspopup="true"
                            :aria-expanded="open === 'date'"
                            @click="open = open === 'date' ? null : 'date'">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        Date range
                        @if ($f['from'] !== null || $f['to'] !== null)
                            <span class="chip__value">
                                {{ $f['from'] ? \Carbon\Carbon::createFromFormat('Y-m', $f['from'])->format('M Y') : '…' }} →
                                {{ $f['to'] ? \Carbon\Carbon::createFromFormat('Y-m', $f['to'])->format('M Y') : '…' }}
                            </span>
                        @endif
                        <svg class="chip__chev" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>

                    <form x-show="open === 'date'" x-cloak x-transition.opacity.duration.100ms
                          method="GET" action="{{ route('audit-log.index') }}"
                          class="filter-pop__menu filter-pop__menu--date">
                        @foreach (request()->except(['from', 'to', 'page']) as $key => $val)
                            @if (is_array($val))
                                @foreach ($val as $v)
                                    <input type="hidden" name="{{ $key }}[]" value="{{ $v }}">
                                @endforeach
                            @else
                                <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                            @endif
                        @endforeach

                        <div class="filter-pop__title">Filter by date</div>
                        <div class="filter-pop__row">
                            <div class="field">
                                <label class="label">From</label>
                                <x-month-picker name="from" :value="$f['from']" placeholder="Any" />
                            </div>
                            <div class="field">
                                <label class="label">To</label>
                                <x-month-picker name="to" :value="$f['to']" placeholder="Any" />
                            </div>
                        </div>
                        <div class="filter-pop__footer">
                            @if ($f['from'] !== null || $f['to'] !== null)
                                <a href="{{ route('audit-log.index', request()->except(['from', 'to', 'page'])) }}" class="btn btn--ghost btn--sm">Clear</a>
                            @else
                                <span></span>
                            @endif
                            <button type="submit" class="btn btn--default btn--sm">Apply</button>
                        </div>
                    </form>
                </div>

                @if ($hasAnyFilter)
                    <a href="{{ route('audit-log.index', $contractFilter ? ['contract' => $contractFilter] : []) }}" class="chip chip--ghost" data-tooltip="Clear all filters">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                        Reset
                    </a>
                @endif
            </div>

            <div class="toolbar__spacer"></div>

            <form method="GET" action="{{ route('audit-log.index') }}" class="audit-search">
                @foreach (request()->except(['q', 'page']) as $key => $val)
                    @if (is_array($val))
                        @foreach ($val as $v)
                            <input type="hidden" name="{{ $key }}[]" value="{{ $v }}">
                        @endforeach
                    @else
                        <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                    @endif
                @endforeach
                <svg class="audit-search__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input type="search" name="q" value="{{ $f['q'] }}" placeholder="Search id, contract no., route, user, action, note…" aria-label="Search audit log" class="audit-search__input" autocomplete="off">
            </form>
        </div>

        <div class="audit-v4">
            @if ($logs->isEmpty())
                <div class="card audit-log__empty">
                    <div class="audit-log__empty-title">No matching audit entries.</div>
                    <div class="audit-log__empty-body">
                        @if ($hasAnyFilter || $contractFilter)
                            Try widening the filters or
                            <a href="{{ route('audit-log.index') }}" class="audit-log__link">clear all</a>.
                        @else
                            Add, edit, or override anything and the activity appears here.
                        @endif
                    </div>
                </div>
            @else
                <div class="table-wrap">
                    <table class="table audit-log-list">
                        <colgroup>
                            <col class="audit-log-list__col audit-log-list__col--time">
                            <col class="audit-log-list__col audit-log-list__col--status">
                            <col class="audit-log-list__col audit-log-list__col--area">
                            <col class="audit-log-list__col audit-log-list__col--record">
                            <col class="audit-log-list__col audit-log-list__col--user">
                            <col class="audit-log-list__col audit-log-list__col--note">
                            <col class="audit-log-list__col audit-log-list__col--chev">
                        </colgroup>
                        <thead>
                            <tr>
                                <th scope="col">Time</th>
                                <th scope="col">Status</th>
                                <th scope="col">Area</th>
                                <th scope="col">Record</th>
                                <th scope="col">User</th>
                                <th scope="col">Note</th>
                                <th scope="col" aria-label="Expand row"></th>
                            </tr>
                        </thead>
                        <tbody>
                    @php
                        $areaMap = [
                            'contracts' => 'Contracts',
                            'cpi_index_entries' => 'CPI',
                            'cpa_rates' => 'CPA',
                            'rpi_index_entries' => 'RPI',
                            'users' => 'Users',
                            'app_settings' => 'Settings',
                            'audit_logs' => 'Audit',
                            'login_logs' => 'Logins',
                        ];
                    @endphp
                    @foreach ($logs as $log)
                        @if (in_array($log->id, $suppressedDetachLogIds, true))
                            @continue
                        @endif
                        @php
                            $diff = AuditDiffer::diff($log->old_values, $log->new_values);
                            $contract = $log->entity_type === 'contracts'
                                ? $contractLookup->get($log->entity_id)
                                : null;
                            $attachState = $attachmentEvents[$log->id] ?? null;
                            $attachBadge = $attachState ? $attachmentEventBadges[$attachState] : null;

                            // Recognise both the current `contract_attachment_*`
                            // keys and the legacy `contract_evidence_*` keys —
                            // historical rows from before the rename still use
                            // the old key (audit log is append-only per §10).
                            $isAttachmentOnly = in_array($log->action, [
                                'contract_attachment_attached',
                                'contract_attachment_detached',
                                'contract_evidence_attached',
                                'contract_evidence_detached',
                            ], true);
                            $isBulkAction = in_array($log->action, ['contracts_imported', 'all_overrides_cleared', 'all_imports_cleared'], true);
                            // Replace pair: this attach row carries the
                            // OLD attachment too (the suppressed detach
                            // row's reference) so before+after can render
                            // side by side.
                            $replacePairBefore = $replaceBeforeAttachments[$log->id] ?? null;
                            $attachmentForRow = $log->attachment
                                ?? $replacePairBefore
                                ?? ($detachedAttachments[$log->id] ?? null);

                            // ── Row metadata: area, ref, key, cleaned note ──
                            $area = $areaMap[$log->entity_type] ?? ucfirst(str_replace('_', ' ', (string) ($log->entity_type ?? '—')));

                            // Resolve a meaningful record label. When the
                            // entity row is gone (deleted), fall back to
                            // the snapshot stored in old_values so the
                            // historical identifier still surfaces — e.g.
                            // "Paul Tran (deleted)" instead of just
                            // "(deleted)".
                            $recordIsDeleted = false;
                            if ($log->entity_type === 'contracts') {
                                if ($contract) {
                                    $record = $contract->contract_number;
                                } else {
                                    $record = $log->old_values['contract_number']
                                        ?? $log->new_values['contract_number']
                                        ?? null;
                                    $recordIsDeleted = $record !== null;
                                    $record = $record ?? '—';
                                }
                            } elseif (in_array($log->entity_type, ['cpi_index_entries', 'cpa_rates', 'rpi_index_entries'], true)) {
                                $month = $monthLookup[$log->entity_type.':'.$log->entity_id] ?? null;
                                $record = $month ? \Carbon\Carbon::parse($month)->format('M Y') : '—';
                            } elseif ($log->entity_type === 'users') {
                                $entityUser = $userLookup->get($log->entity_id);
                                if ($entityUser) {
                                    $record = $entityUser->name;
                                } else {
                                    // Fall back to whichever side carries the name —
                                    // old_values for updates/deletes, new_values for
                                    // creates whose user has since been deleted.
                                    $record = $log->old_values['name']
                                        ?? $log->new_values['name']
                                        ?? $log->old_values['email']
                                        ?? $log->new_values['email']
                                        ?? null;
                                    $recordIsDeleted = $record !== null;
                                    $record = $record ?? '—';
                                }
                            } else {
                                $record = '—';
                            }

                            $entityKey = $log->entity_id > 0 ? '#'.$log->entity_id : null;

                            // Strip the [#id contract · route] prefix written
                            // by contractRef() — area + ref + key already
                            // carry that information.
                            $rawNote = (string) ($log->note ?? '');
                            $noteClean = trim((string) preg_replace('/^\[#[^\]]+\]\s*/', '', $rawNote));
                        @endphp

                        <tr class="audit-log-event-row"
                            :class="{ 'audit-log-event-row--open': openId === {{ $log->id }} }"
                            @click="openId = openId === {{ $log->id }} ? null : {{ $log->id }}"
                            :aria-expanded="openId === {{ $log->id }}"
                            aria-controls="audit-log-detail-{{ $log->id }}">
                            <td class="audit-log-event__time" title="{{ optional($log->created_at)->format('Y-m-d H:i:s') }}">
                                {{ optional($log->created_at)->format('d/m H:i') }}
                            </td>
                            <td class="audit-log-event__status">
                                @php
                                    $verb = $auditActionMeta[$log->action]['verb'] ?? 'update';
                                    $recordStatus = $recordStatuses[$verb] ?? $recordStatuses['update'];
                                @endphp
                                @unless ($isAttachmentOnly)
                                    <span class="badge {{ $recordStatus['badge'] }}">{{ $recordStatus['label'] }}</span>
                                @endunless
                                @if ($attachBadge)
                                    <span class="audit-log-attach {{ $attachBadge['class'] }}">
                                        <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                                        {{ $attachBadge['label'] }}
                                    </span>
                                @endif
                            </td>
                            <td class="audit-log-event__area">
                                <span class="audit-log-area-pill audit-log-area-pill--{{ \Illuminate\Support\Str::slug($area) }}">{{ $area }}</span>
                            </td>
                            <td class="audit-log-event__record">
                                <span class="audit-log-event__record-value">{{ $record }}</span>
                                @if ($recordIsDeleted)
                                    <span class="audit-log-event__record-deleted" title="This record has since been deleted">(deleted)</span>
                                @endif
                                @if ($entityKey)
                                    <span class="audit-log-event__record-key">[{{ $entityKey }}]</span>
                                @endif
                            </td>
                            <td class="audit-log-event__user">{{ $log->user?->name ?? 'System' }}</td>
                            <td class="audit-log-event__note">{{ $noteClean !== '' ? Str::limit($noteClean, 70) : '—' }}</td>
                            <td class="audit-log-event__chev">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
                            </td>
                        </tr>
                        <tr class="audit-log-event-detail"
                            id="audit-log-detail-{{ $log->id }}"
                            x-show="openId === {{ $log->id }}"
                            x-cloak>
                            <td colspan="7">
                              <div class="audit-log-event__detail">

                                @php
                                    // Skip the AuditDiffer rows for attachment-only
                                    // actions — those rows are pure attachment
                                    // metadata noise. The dedicated Attachment
                                    // row below carries the meaningful info.
                                    $diffToShow = ($isAttachmentOnly || $isBulkAction) ? [] : $diff;
                                    // Before-side attachment: either this
                                    // row IS a standalone detach (look up
                                    // by log id), or it's a merged replace
                                    // attach row carrying its partner's
                                    // old file in $replacePairBefore.
                                    $beforeAttach = ($detachedAttachments[$log->id] ?? null) ?? $replacePairBefore;
                                    $afterAttach = $log->attachment;
                                    $hasAttachmentRow = $attachmentForRow !== null;
                                    $hasTable = count($diffToShow) > 0 || $hasAttachmentRow;

                                    $attachPillLabels = [
                                        'added' => 'Added',
                                        'replaced' => 'Replaced',
                                        'removed' => 'Removed',
                                    ];
                                    $attachPillLabel = $attachPillLabels[$attachState] ?? null;
                                @endphp

                                @if ($hasTable)
                                    <div class="audit-log-table">
                                        <div class="audit-log-table__head">
                                            <div class="audit-log-table__cell audit-log-table__cell--field">Field</div>
                                            <div class="audit-log-table__cell audit-log-table__cell--before">Before</div>
                                            <div class="audit-log-table__cell audit-log-table__cell--after">After</div>
                                        </div>

                                        @foreach ($diffToShow as $row)
                                            <div class="audit-log-table__row audit-log-table__row--{{ $row['status'] }}">
                                                <div class="audit-log-table__cell audit-log-table__cell--field">{{ $row['label'] }}</div>
                                                <div class="audit-log-table__cell audit-log-table__cell--before">
                                                    @if ($row['status'] === 'added')
                                                        <span class="audit-log-table__empty">—</span>
                                                    @else
                                                        <span class="audit-log-table__value audit-log-table__value--old">{{ $row['oldFormatted'] }}</span>
                                                    @endif
                                                </div>
                                                <div class="audit-log-table__cell audit-log-table__cell--after">
                                                    @if ($row['status'] === 'removed')
                                                        <span class="audit-log-table__empty">—</span>
                                                    @else
                                                        <span class="audit-log-table__value audit-log-table__value--new">{{ $row['newFormatted'] }}</span>
                                                    @endif
                                                </div>
                                            </div>
                                        @endforeach

                                        @if ($hasAttachmentRow)
                                            <div class="audit-log-table__row audit-log-table__row--attachment audit-log-table__row--{{ $attachState ?? 'added' }}">
                                                <div class="audit-log-table__cell audit-log-table__cell--field">Attachment</div>
                                                <div class="audit-log-table__cell audit-log-table__cell--before">
                                                    @if ($beforeAttach)
                                                        @php
                                                            $bDeleted = isset($beforeAttach->_deleted);
                                                            $bDownload = ! $bDeleted && ! empty($beforeAttach->id);
                                                        @endphp
                                                        <div class="audit-log-att">
                                                            @if ($attachPillLabel)
                                                                <span class="audit-log-att__pill audit-log-att__pill--{{ $attachState }}">{{ $attachPillLabel }}</span>
                                                            @endif
                                                            @if ($bDownload)
                                                                <a href="{{ route('attachments.download', $beforeAttach) }}" class="audit-log-att__name">{{ $beforeAttach->original_filename }}</a>
                                                            @else
                                                                <span class="audit-log-att__name audit-log-att__name--gone">{{ $beforeAttach->original_filename }} <em>(deleted)</em></span>
                                                            @endif
                                                            @if (! empty($beforeAttach->size_bytes))
                                                                <span class="audit-log-att__meta">{{ number_format($beforeAttach->size_bytes / 1024, 1) }} KB</span>
                                                            @endif
                                                        </div>
                                                    @else
                                                        <span class="audit-log-table__empty">—</span>
                                                    @endif
                                                </div>
                                                <div class="audit-log-table__cell audit-log-table__cell--after">
                                                    @if ($afterAttach)
                                                        <div class="audit-log-att">
                                                            @if ($attachPillLabel)
                                                                <span class="audit-log-att__pill audit-log-att__pill--{{ $attachState }}">{{ $attachPillLabel }}</span>
                                                            @endif
                                                            <a href="{{ route('attachments.download', $afterAttach) }}" class="audit-log-att__name">{{ $afterAttach->original_filename }}</a>
                                                            @if (! empty($afterAttach->size_bytes))
                                                                <span class="audit-log-att__meta">{{ number_format($afterAttach->size_bytes / 1024, 1) }} KB</span>
                                                            @endif
                                                        </div>
                                                    @else
                                                        <span class="audit-log-table__empty">—</span>
                                                    @endif
                                                </div>
                                            </div>
                                        @endif
                                    </div>
                                @else
                                    <div class="audit-log-event__empty">
                                        No field-level changes recorded — this entry is a marker (e.g. status flip with no diff).
                                    </div>
                                @endif

                                <footer class="audit-log-event__foot">
                                    <div class="audit-log-event__meta">
                                        from <code>{{ $log->ip_address ?? '—' }}</code>
                                        @if ($contract && ! $contractFilter)
                                            · <a href="{{ route('audit-log.index', ['contract' => $contract->id]) }}" class="audit-log__link">Show only this contract's history</a>
                                        @endif
                                    </div>
                                    @if ($hasTable)
                                        <button type="button"
                                                class="btn btn--ghost btn--sm"
                                                disabled
                                                title="Revert the entire change — coming soon">
                                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
                                            Revert entire change
                                        </button>
                                    @endif
                                </footer>
                              </div>
                            </td>
                        </tr>
                    @endforeach
                        </tbody>
                    </table>
                </div>

                @if ($logs->hasPages())
                    <div class="audit-log__pagination">
                        {{ $logs->links() }}
                    </div>
                @endif
            @endif
        </div>
    </div>
</x-app-layout>
