<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>{{ config('app.name', 'Bus Contracts Manager') }}</title>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&family=Geist+Mono:wght@400;500&display=swap" rel="stylesheet">

        {{-- Pre-paint theme — match app.blade.php so the auth pages
             render in the chosen theme without a flash. --}}
        <script>
            (function () {
                try {
                    var t = localStorage.getItem('theme');
                    if (t === 'dark' || t === 'light') {
                        document.documentElement.setAttribute('data-theme', t);
                    }
                } catch (e) {}
            })();
        </script>

        @vite(['resources/css/app.css', 'resources/js/app.js'])

        {{-- Cloudflare Turnstile widget script. Loaded once on the guest
             layout so all auth forms (login / register / forgot-password /
             reset-password / confirm-password) can drop in the widget
             partial without re-loading the script per page. `defer` so the
             form HTML parses first and the widget activates after. --}}
        <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
    </head>
    <body>
        <main class="auth-shell">
            <section class="auth-shell__panel">
                <div class="card auth-card">
                    {{ $slot }}
                </div>
            </section>
        </main>
    </body>
</html>
