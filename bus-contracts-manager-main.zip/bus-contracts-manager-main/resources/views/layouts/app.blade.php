<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Bus Contracts Manager') }}</title>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&family=Geist+Mono:wght@400;500&display=swap" rel="stylesheet">

        {{-- Pre-paint theme application. Runs synchronously before <body>
             paints so there's no flash-of-light when the user has pinned
             dark mode. localStorage `theme` of "light" | "dark" wins; if
             unset, we leave `data-theme` off and the @media
             (prefers-color-scheme) fallback in app.css takes over. --}}
        <script>
            (function () {
                try {
                    var t = localStorage.getItem('theme');
                    if (t === 'dark' || t === 'light') {
                        document.documentElement.setAttribute('data-theme', t);
                    }
                } catch (e) { /* private mode / disabled storage — fall through to system pref */ }
            })();
        </script>

        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body>
        <div class="app">
            @include('layouts.sidebar')

            <div class="main">
                <header class="topbar">
                    <nav class="breadcrumb" aria-label="Breadcrumb">
                        <span>Bus Contracts Manager</span>
                        <span class="breadcrumb__separator" aria-hidden="true">/</span>
                        <span class="breadcrumb__current" aria-current="page">{{ $crumb ?? ($title ?? '') }}</span>
                    </nav>

                    <div class="topbar__spacer"></div>

                    @if (! empty($topbarContractsMeta))
                        <div class="release-meta release-meta--topbar" aria-label="Contracts last update">
                            <span class="dot dot--success" aria-hidden="true"></span>
                            <span class="release-meta__item" title="When a contract was last added or changed">
                                Updated <span class="release-meta__value">{{ $topbarContractsMeta['updated_at'] ?? '—' }}</span>
                            </span>
                        </div>
                    @endif

                    @if (! empty($topbarOnsMeta))
                        <div class="release-meta release-meta--topbar" aria-label="ONS CPI release schedule">
                            @if (auth()->user()?->canWrite())
                                <form method="POST" action="{{ route('indices.refresh') }}" class="form--inline"
                                      @submit="if (! confirm('Force-refresh CPI + RPI from ONS now? Manual overrides preserved; ONS-feed and manual-import rows aligned to live ONS. Takes 5-10s.')) $event.preventDefault();">
                                    @csrf
                                    <button type="submit"
                                            class="release-meta__refresh"
                                            aria-label="Force refresh ONS data"
                                            data-tooltip="Force refresh from ONS"
                                            data-tooltip-side="bottom">
                                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 12a9 9 0 0 1 15.5-6.36L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.36L3 16"/><path d="M3 21v-5h5"/></svg>
                                    </button>
                                </form>
                            @else
                                <span class="dot dot--success" aria-hidden="true"></span>
                            @endif
                            <span class="release-meta__item" title="When the local refresh last ran">
                                Updated <span class="release-meta__value">{{ $topbarOnsMeta['updated_at'] ?? '—' }}</span>
                            </span>
                            <span class="release-meta__sep" aria-hidden="true">·</span>
                            <span class="release-meta__item" title="Latest CPI month held locally">
                                Through <span class="release-meta__value">{{ $topbarOnsMeta['data_through'] ?? '—' }}</span>
                            </span>
                            <span class="release-meta__sep" aria-hidden="true">·</span>
                            <span class="release-meta__item" title="Next scheduled ONS release">
                                Next <span class="release-meta__value">{{ $topbarOnsMeta['next_release'] ?? '—' }}</span>
                            </span>
                        </div>
                    @endif
                </header>

                <main class="page">
                    {{ $slot }}
                </main>

                <footer class="site-footer" x-data="{ aboutOpen: false }">
                    <nav class="site-footer__nav" aria-label="About this app">
                        <button type="button" class="site-footer__link" @click="aboutOpen = true">About</button>
                        <span class="site-footer__sep" aria-hidden="true">·</span>
                        <span class="site-footer__built">
                            Built by <a href="https://farhan.app" target="_blank" rel="noopener noreferrer">Farhan</a>
                        </span>
                        <span class="site-footer__sep" aria-hidden="true">·</span>
                        <a class="site-footer__coffee" href="https://buymeacoffee.com/farhan.app" target="_blank" rel="noopener noreferrer">
                            <span aria-hidden="true">☕</span> Buy me a coffee
                        </a>
                    </nav>

                    {{-- About dialog --}}
                    <div x-show="aboutOpen" x-cloak class="dialog" @keydown.escape.window="aboutOpen = false"
                         role="dialog" aria-modal="true" aria-labelledby="about-title">
                        <div class="dialog__overlay" @click="aboutOpen = false" aria-hidden="true"></div>
                        <div class="dialog__content">
                            <div class="about__head">
                                <div>
                                    <h2 class="dialog__title" id="about-title">{{ config('app.name', 'Contract Manager') }}</h2>
                                    <p class="dialog__description">Bus contract rate & revenue management</p>
                                </div>
                                <button type="button" class="dialog__close" @click="aboutOpen = false" aria-label="Close">✕</button>
                            </div>

                            <div class="dialog__body about__body">
                                <p>
                                    A Laravel application for tracking bus operating contracts, CPI/RPI-indexed
                                    CPA rate calculations, period revenue, and a full audit trail. Built around the
                                    UK ONS inflation feeds with manual override support.
                                </p>

                                <h3 class="about__label">Source</h3>
                                <p class="about__row">
                                    <a href="https://github.com/farhanmunim/bus-contracts-manager" target="_blank" rel="noopener noreferrer">github.com/farhanmunim/bus-contracts-manager</a>
                                    <span class="is-soft">open source · MIT</span>
                                </p>

                                <h3 class="about__label">Developer</h3>
                                <p class="about__row">
                                    <a href="https://farhan.app" target="_blank" rel="noopener noreferrer">Farhan</a>
                                    <span class="is-soft">farhan.app</span>
                                </p>

                                <div class="about__support">
                                    <h3 class="about__label">Support</h3>
                                    <p>Support the development of this free tool.</p>
                                    <a class="btn btn--default btn--sm" href="https://buymeacoffee.com/farhan.app" target="_blank" rel="noopener noreferrer">
                                        ☕ Buy me a coffee
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </body>
</html>
