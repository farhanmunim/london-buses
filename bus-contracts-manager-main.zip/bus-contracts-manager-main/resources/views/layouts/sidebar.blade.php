<aside class="sidebar" aria-label="Primary">
    <a href="{{ route('contracts.index') }}" class="sidebar__brand">
        <span class="sidebar__brand-mark" aria-hidden="true">BCM</span>
        <span class="sidebar__brand-name">Bus Contracts Manager</span>
    </a>

    <nav class="sidebar__section" aria-label="Workspace">
        <a href="{{ route('contracts.index') }}" class="sidebar__nav-item {{ request()->routeIs('contracts.*') ? 'is-active' : '' }}" @if(request()->routeIs('contracts.*')) aria-current="page" @endif>
            <svg class="sidebar__nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="13" y2="17"/></svg>
            Contracts
        </a>
        <div class="sidebar__group">
            <a href="{{ route('indices.cpa') }}" class="sidebar__nav-item {{ request()->routeIs('indices.*') ? 'is-active' : '' }}" @if(request()->routeIs('indices.*')) aria-current="page" @endif>
                <svg class="sidebar__nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 5-5"/></svg>
                Indices
            </a>
            <div class="sidebar__sub-nav" role="group" aria-label="Indices sections">
                <a href="{{ route('indices.cpi') }}" class="sidebar__sub-item {{ request()->routeIs('indices.cpi*') ? 'is-active' : '' }}">CPI</a>
                <a href="{{ route('indices.cpa') }}" class="sidebar__sub-item {{ request()->routeIs('indices.cpa*') ? 'is-active' : '' }}">CPA</a>
                <a href="{{ route('indices.rpi') }}" class="sidebar__sub-item {{ request()->routeIs('indices.rpi*') ? 'is-active' : '' }}">RPI</a>
                <a href="{{ route('indices.cebr') }}" class="sidebar__sub-item {{ request()->routeIs('indices.cebr*') ? 'is-active' : '' }}">CEBR</a>
                <a href="{{ route('indices.derv') }}" class="sidebar__sub-item {{ request()->routeIs('indices.derv*') ? 'is-active' : '' }}">DERV</a>
            </div>
        </div>

        <div class="sidebar__group">
            <a href="{{ route('reports.index') }}" class="sidebar__nav-item {{ request()->routeIs('reports.*') ? 'is-active' : '' }}" @if(request()->routeIs('reports.*')) aria-current="page" @endif>
                {{-- Pie-chart icon (Lucide). Distinct from Contracts
                     (file-with-text) and Indices (line chart) so the
                     three workspace items don't read as the same. --}}
                <svg class="sidebar__nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>
                Reports
            </a>
            <div class="sidebar__sub-nav" role="group" aria-label="Reports">
                @foreach (\App\Http\Controllers\ReportsController::REPORTS as $slug => $meta)
                    <a href="{{ route('reports.show', $slug) }}" class="sidebar__sub-item {{ request()->routeIs('reports.show') && request()->route('report') === $slug ? 'is-active' : '' }}">{{ $meta['label'] }}</a>
                @endforeach
            </div>
        </div>

        <div class="sidebar__group">
            <a href="{{ route('documents.attachments') }}" class="sidebar__nav-item {{ request()->routeIs('documents.*') ? 'is-active' : '' }}" @if(request()->routeIs('documents.*')) aria-current="page" @endif>
                {{-- Folder icon (Lucide). Documents is the canonical
                     "where files live" workspace section, so a folder
                     reads more naturally than the previous paperclip. --}}
                <svg class="sidebar__nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg>
                Documents
            </a>
            <div class="sidebar__sub-nav" role="group" aria-label="Documents sections">
                <a href="{{ route('documents.attachments') }}" class="sidebar__sub-item {{ request()->routeIs('documents.attachments') ? 'is-active' : '' }}">Attachments</a>
                <a href="{{ route('documents.settlements') }}" class="sidebar__sub-item {{ request()->routeIs('documents.settlements') ? 'is-active' : '' }}">Settlements</a>
            </div>
        </div>
    </nav>

    @php $authUser = auth()->user(); @endphp
    @if ($authUser?->isAdmin())
        <nav class="sidebar__section" aria-label="Tools">
            <div class="sidebar__section-label">Tools</div>
            @if ($authUser->canViewAuditLog())
                <a href="{{ route('audit-log.index') }}" class="sidebar__nav-item {{ request()->routeIs('audit-log.*') ? 'is-active' : '' }}" @if(request()->routeIs('audit-log.*')) aria-current="page" @endif>
                    <svg class="sidebar__nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    Audit log
                </a>
            @endif
            @if ($authUser->canManageUsers())
                <a href="{{ route('users.index') }}" class="sidebar__nav-item {{ request()->routeIs('users.*') ? 'is-active' : '' }}" @if(request()->routeIs('users.*')) aria-current="page" @endif>
                    <svg class="sidebar__nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    Manage users
                </a>
            @endif
            @if ($authUser->canViewSettings())
                <a href="{{ route('settings.index') }}" class="sidebar__nav-item {{ request()->routeIs('settings.*') ? 'is-active' : '' }}" @if(request()->routeIs('settings.*')) aria-current="page" @endif>
                    <svg class="sidebar__nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                    Settings
                </a>
            @endif
        </nav>

        <nav class="sidebar__section" aria-label="Planning">
            <div class="sidebar__section-label">Planning</div>
            <a href="{{ route('roadmap.index') }}" class="sidebar__nav-item {{ request()->routeIs('roadmap.*') ? 'is-active' : '' }}" @if(request()->routeIs('roadmap.*')) aria-current="page" @endif>
                <svg class="sidebar__nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg>
                Roadmap
            </a>
        </nav>
    @endif

    <div class="sidebar__footer" x-data="{ open: false }" @click.outside="open = false">
        <div x-show="open" x-cloak x-transition.opacity class="dropdown__menu dropdown__menu--up dropdown__menu--full" role="menu">
            <a href="{{ route('profile.edit') }}" class="dropdown__item" role="menuitem">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true"><path d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z"/></svg>
                Profile
            </a>
            {{-- Theme toggle. Two states: light ↔ dark. The icon and label
                 swap via CSS sibling selectors keyed on data-theme-effective. --}}
            <button type="button" class="dropdown__item theme-toggle" role="menuitem" data-theme-toggle>
                <svg class="theme-toggle__icon theme-toggle__icon--light" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>
                <svg class="theme-toggle__icon theme-toggle__icon--dark" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
                <span class="theme-toggle__label">
                    <span class="theme-toggle__label--light">Switch to dark</span>
                    <span class="theme-toggle__label--dark">Switch to light</span>
                </span>
            </button>
            <div class="dropdown__separator" role="separator"></div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="dropdown__item" role="menuitem">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true"><path d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15M12 9l-3 3m0 0 3 3m-3-3h12.75"/></svg>
                    Log out
                </button>
            </form>
        </div>

        <button type="button" class="user-card" @click="open = !open" :aria-expanded="open" aria-haspopup="menu" aria-label="Open account menu">
            @php
                $userName = trim(auth()->user()->name ?? '');
                $parts = preg_split('/\s+/', $userName, -1, PREG_SPLIT_NO_EMPTY) ?: [];
                if (count($parts) >= 2) {
                    $initials = mb_substr($parts[0], 0, 1).mb_substr(end($parts), 0, 1);
                } else {
                    $initials = mb_substr($userName ?: 'User', 0, 2);
                }
            @endphp
            <span class="user-card__avatar" aria-hidden="true">{{ strtoupper($initials) }}</span>
            <span class="user-card__info">
                <span class="user-card__name">{{ auth()->user()->name ?? 'Guest' }}</span>
                <span class="user-card__email">{{ auth()->user()->email ?? '' }}</span>
            </span>
            <svg class="user-card__chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </button>
    </div>
</aside>
