<x-app-layout :crumb="'Reports'">
    <div class="page__header">
        <div>
            <h1 class="page__title">Reports</h1>
            <div class="page__subtitle">Pre-defined views over contract cash, accruals, and claim cycles.</div>
        </div>
    </div>

    <div class="report-grid">
        @foreach ($reports as $slug => $meta)
            <a href="{{ route('reports.show', $slug) }}" class="report-card">
                <div class="report-card__head">
                    <span class="report-card__label">{{ $meta['label'] }}</span>
                    <svg class="report-card__chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <polyline points="9 18 15 12 9 6"/>
                    </svg>
                </div>
                <p class="report-card__summary">{{ $meta['summary'] }}</p>
                <span class="report-card__status">
                    <span class="dot dot--muted" aria-hidden="true"></span>
                    Coming soon
                </span>
            </a>
        @endforeach
    </div>
</x-app-layout>
