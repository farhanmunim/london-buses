<x-app-layout :crumb="'Reports / '.$meta['label']">
    <div class="page__header">
        <div>
            <h1 class="page__title">{{ $meta['label'] }}</h1>
            <div class="page__subtitle">{{ $meta['description'] }}</div>
        </div>
        <div class="page__actions">
            <a href="{{ route('reports.index') }}" class="btn btn--secondary">
                <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="15 18 9 12 15 6"/></svg>
                All reports
            </a>
        </div>
    </div>

    <x-coming-soon :title="$meta['label']" :description="$meta['description'].' This view is being built.'" />
</x-app-layout>
