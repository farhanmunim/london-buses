@props(['messages'])

@if ($messages)
    <ul {{ $attributes->merge(['class' => 'field__error']) }}>
        @foreach ((array) $messages as $message)
            <li>{{ $message }}</li>
        @endforeach
    </ul>
@endif
