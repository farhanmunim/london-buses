{{--
    Cloudflare Turnstile widget. Drop into any auth form *inside* the
    <form> element so the rendered <input name="cf-turnstile-response">
    is submitted alongside the rest of the form. The Turnstile JS is
    loaded once at the layout level (resources/views/layouts/guest.blade.php).

    Default site key (config/services.php) is Cloudflare's "always-pass"
    dev key — locally and in tests the challenge always succeeds without
    the user seeing a real puzzle.

    Sized via Cloudflare's official `data-size="flexible"` — that's the
    only way to widen the widget because Cloudflare renders the actual
    challenge inside a *closed* shadow root, which our CSS cannot
    penetrate. Flexible mode tells Turnstile to render at the parent
    container's width (clamped to ≥300px and ≤100%).

    Reference: https://developers.cloudflare.com/turnstile/get-started/client-side-rendering/#widget-size
--}}
<div class="field">
    <div class="turnstile-host">
        <div class="cf-turnstile"
             data-sitekey="{{ config('services.turnstile.site_key') }}"
             data-theme="light"
             data-size="flexible"></div>
    </div>
    {{-- Cloudflare reads `data-theme` synchronously when its `defer` script
         runs. We bump the attribute here, in document order before that
         script executes, so the widget picks up the saved theme on first
         render — no flash, no remount. --}}
    <script>
        (function () {
            try {
                var t = localStorage.getItem('theme');
                if (t === 'dark') {
                    document.currentScript.previousElementSibling
                        .querySelector('.cf-turnstile')
                        .setAttribute('data-theme', 'dark');
                }
            } catch (e) {}
        })();
    </script>
    <x-input-error :messages="$errors->get('cf-turnstile-response')" />
</div>
