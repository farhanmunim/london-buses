@props(['title', 'description' => null])

<div class="empty-state">
    <svg class="empty-state__icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"/>
    </svg>
    <div class="empty-state__title">{{ $title }}</div>
    <p class="empty-state__description">{{ $description ?? 'This section is coming soon.' }}</p>
</div>
