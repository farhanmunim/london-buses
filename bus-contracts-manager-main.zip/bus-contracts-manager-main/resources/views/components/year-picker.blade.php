@props([
    'name',
    'id' => null,
    'value' => null,
    'required' => false,
    'placeholder' => 'Select year',
    'minYear' => 1990,
    'maxYear' => 2100,
])

@php
    $id = $id ?? 'year-picker-'.uniqid();
    $value = old($name, $value);
@endphp

<div class="date-picker"
     x-data="yearPicker({
        initial: @js($value),
        minYear: {{ (int) $minYear }},
        maxYear: {{ (int) $maxYear }},
     })"
     x-modelable="value"
     {{ $attributes->whereStartsWith(['x-model', 'wire:model']) }}
     @keydown.escape.window="open = false"
     @click.outside="if (! $refs.panel || ! $refs.panel.contains($event.target)) open = false">
    <input type="hidden" name="{{ $name }}" :value="value" {{ $required ? 'required' : '' }}>

    <button type="button"
            x-ref="trigger"
            id="{{ $id }}"
            class="date-picker__trigger input"
            :class="{ 'date-picker__trigger--empty': ! value, 'is-open': open }"
            aria-haspopup="dialog"
            :aria-expanded="open"
            @click="open = !open">
        <span class="date-picker__value" x-text="display || '{{ $placeholder }}'"></span>
        <svg class="date-picker__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
            <rect x="3" y="4" width="18" height="18" rx="2"/>
            <line x1="16" y1="2" x2="16" y2="6"/>
            <line x1="8" y1="2" x2="8" y2="6"/>
            <line x1="3" y1="10" x2="21" y2="10"/>
        </svg>
    </button>

    <template x-teleport="body">
        <div x-show="open"
             x-ref="panel"
             x-cloak
             x-transition.opacity.duration.100ms
             class="date-picker__panel"
             :style="`top: ${panelTop}px; left: ${panelLeft}px;`"
             role="dialog"
             aria-label="Choose year">
            <div class="date-picker__nav">
                <button type="button" class="date-picker__nav-btn" aria-label="Previous decade" :disabled="windowStart <= minYear" @click="prevWindow()">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <span class="date-picker__heading" x-text="heading"></span>
                <button type="button" class="date-picker__nav-btn" aria-label="Next decade" :disabled="windowStart + 11 >= maxYear" @click="nextWindow()">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
            </div>

            <div class="date-picker__year-grid">
                <template x-for="year in years" :key="year">
                    <button type="button"
                            class="date-picker__year-cell"
                            :class="{ 'is-selected': isSelected(year), 'is-today': isCurrent(year) }"
                            @click="select(year)">
                        <span x-text="year"></span>
                    </button>
                </template>
            </div>

            <div class="date-picker__footer">
                <button type="button" class="btn btn--ghost btn--sm" @click="clear()" x-show="value">Clear</button>
                <button type="button" class="btn btn--ghost btn--sm" @click="goToday()">Today</button>
            </div>
        </div>
    </template>
</div>
