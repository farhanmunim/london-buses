<x-app-layout :crumb="'Documents / Settlements'">
    <div class="page__header">
        <div>
            <h1 class="page__title">Settlements</h1>
            <p class="page__subtitle">
                Future home of TfL settlement statement PDFs.
                Once live, the per-period figures parsed out of these will feed the Final and Intermediate claim reports.
            </p>
        </div>
    </div>

    {{-- Same tab nav as the Attachments page so navigation stays
         consistent across the Documents sub-section. --}}
    <nav class="tabs" aria-label="Documents views">
        <a href="{{ route('documents.attachments') }}" class="tabs__item">Attachments</a>
        <a href="{{ route('documents.settlements') }}" class="tabs__item is-active" aria-current="page">Settlements</a>
    </nav>

    <x-coming-soon
        title="Settlements"
        description="Drop in TfL settlement statement PDFs here. Parsed per-period figures will feed the Final and Intermediate claim reports." />
</x-app-layout>
