<x-app-layout :crumb="'Documents / Attachments'">
    @php
        $f = $filters;
        $hasAnyFilter = $f['q'] !== null || ! empty($f['extensions']) || ! empty($f['uploaders']);

        $formatBytes = function (?int $bytes): string {
            if ($bytes === null) {
                return '—';
            }
            if ($bytes < 1024) {
                return $bytes.' B';
            }
            if ($bytes < 1024 * 1024) {
                return round($bytes / 1024, 1).' KB';
            }

            return round($bytes / 1024 / 1024, 1).' MB';
        };

        // Highlight a small set of "interesting" extensions in the table
        // chip; everything else falls back to a neutral pill.
        $extBadge = function (string $filename): array {
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

            return [$ext, match ($ext) {
                'pdf' => 'badge--destructive',
                'doc', 'docx' => 'badge--info',
                'xls', 'xlsx', 'csv' => 'badge--success',
                'eml', 'msg' => 'badge--warning',
                default => 'badge--neutral',
            }];
        };
    @endphp

    <div x-data="{
            open: null,
            // viewing = { filename, contracts: [{contract_number, route, archived, slots: ['CPA confirmation 2024', ...]}, ...], total }
            viewing: null,
            linkFilter: '',
            // Contracts whose contract_number / route matches the current filter,
            // case-insensitive, ignoring whitespace. Empty filter = show everything.
            visibleContracts() {
                if (! this.viewing) return [];
                const q = this.linkFilter.trim().toLowerCase();
                if (q === '') return this.viewing.contracts;
                return this.viewing.contracts.filter(c =>
                    (c.contract_number || '').toLowerCase().includes(q)
                    || (c.route || '').toString().toLowerCase().includes(q)
                    || c.slots.some(s => s.toLowerCase().includes(q)),
                );
            },
         }"
         @keydown.escape.window="open = null; viewing = null; linkFilter = '';">
        <div class="page__header">
            <div>
                <h1 class="page__title">
                    @if ($showDetached)
                        Detached attachments
                    @else
                        Attachments
                    @endif
                </h1>
                <p class="page__subtitle">
                    @if ($showDetached)
                        {{ $attachments->total() }} detached {{ \Illuminate\Support\Str::plural('file', $attachments->total()) }}.
                        Audit history continues to resolve these — re-attach is not currently supported via this view.
                    @else
                        Browse every contract attachment in the system.
                        Mutating actions (detach, replace) live inside the contract dialogs that own the slot.
                    @endif
                </p>
            </div>
            <div class="page__actions">
                @if ($showDetached)
                    <a href="{{ route('documents.attachments') }}" class="btn btn--secondary">← Back to active</a>
                @elseif ($detachedCount > 0)
                    <a href="{{ route('documents.attachments', ['detached' => 1]) }}" class="btn btn--secondary" data-tooltip="View detached" data-tooltip-side="bottom">
                        Detached <span class="chip__count">{{ $detachedCount }}</span>
                    </a>
                @endif
            </div>
        </div>

        {{-- Sub-section tabs (Attachments + Settlements). Same shape as
             the indices CPI / CPA / RPI tab nav so the visual language
             stays consistent. --}}
        <nav class="tabs" aria-label="Documents views">
            <a href="{{ route('documents.attachments') }}" class="tabs__item {{ request()->routeIs('documents.attachments') ? 'is-active' : '' }}" @if (request()->routeIs('documents.attachments')) aria-current="page" @endif>Attachments</a>
            <a href="{{ route('documents.settlements') }}" class="tabs__item {{ request()->routeIs('documents.settlements') ? 'is-active' : '' }}" @if (request()->routeIs('documents.settlements')) aria-current="page" @endif>Settlements</a>
        </nav>

        {{-- Filter toolbar — search left, dropdowns right --}}
        <form method="GET" action="{{ route('documents.attachments') }}" class="toolbar" role="search">
            @if ($showDetached)
                <input type="hidden" name="detached" value="1">
            @endif

            <div class="toolbar__group">
                <a href="{{ route('documents.attachments', $showDetached ? ['detached' => 1] : []) }}"
                   class="chip {{ ! $hasAnyFilter ? 'is-active' : '' }}">
                    All <span class="chip__count">{{ $totalCount }}</span>
                </a>
            </div>

            <div class="toolbar__group toolbar__group--offset">
                {{-- Extension filter --}}
                <div class="filter-pop" @click.outside="if (open === 'ext') open = null">
                    <button type="button"
                            class="chip chip--outline {{ ! empty($f['extensions']) ? 'is-active' : '' }}"
                            aria-haspopup="true"
                            :aria-expanded="open === 'ext'"
                            @click="open = open === 'ext' ? null : 'ext'">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                        Type
                        @if (! empty($f['extensions']))
                            <span class="chip__value">
                                {{ count($f['extensions']) === 1 ? '.'.$f['extensions'][0] : count($f['extensions']).' types' }}
                            </span>
                        @endif
                        <svg class="chip__chev" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>

                    <div x-show="open === 'ext'" x-cloak x-transition.opacity.duration.100ms class="filter-pop__menu">
                        <div class="filter-pop__title">Filter by file type</div>
                        @foreach ($extensionOptions as $ext)
                            <label class="filter-pop__option">
                                <input type="checkbox" name="extensions[]" value="{{ $ext }}"
                                       {{ in_array($ext, $f['extensions'], true) ? 'checked' : '' }}>
                                <span class="filter-pop__option-label">.{{ $ext }}</span>
                            </label>
                        @endforeach

                        <div class="filter-pop__footer">
                            @if (! empty($f['extensions']))
                                <a href="{{ route('documents.attachments', collect(request()->all())->except('extensions')->all()) }}" class="btn btn--ghost btn--sm">Clear</a>
                            @else
                                <span></span>
                            @endif
                            <button type="submit" class="btn btn--default btn--sm">Apply</button>
                        </div>
                    </div>
                </div>

                {{-- Uploader filter --}}
                <div class="filter-pop" @click.outside="if (open === 'uploader') open = null">
                    <button type="button"
                            class="chip chip--outline {{ ! empty($f['uploaders']) ? 'is-active' : '' }}"
                            aria-haspopup="true"
                            :aria-expanded="open === 'uploader'"
                            @click="open = open === 'uploader' ? null : 'uploader'">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="7" r="4"/><path d="M5 21v-2a4 4 0 0 1 4-4h6a4 4 0 0 1 4 4v2"/></svg>
                        Uploader
                        @if (! empty($f['uploaders']))
                            <span class="chip__value">
                                {{ count($f['uploaders']) === 1
                                    ? ($uploaderOptions->firstWhere('id', $f['uploaders'][0])->name ?? 'unknown')
                                    : count($f['uploaders']).' people' }}
                            </span>
                        @endif
                        <svg class="chip__chev" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>

                    <div x-show="open === 'uploader'" x-cloak x-transition.opacity.duration.100ms class="filter-pop__menu">
                        <div class="filter-pop__title">Filter by uploader</div>
                        @foreach ($uploaderOptions as $u)
                            <label class="filter-pop__option">
                                <input type="checkbox" name="uploaders[]" value="{{ $u->id }}"
                                       {{ in_array($u->id, $f['uploaders'], true) ? 'checked' : '' }}>
                                <span class="filter-pop__option-label">{{ $u->name }}</span>
                            </label>
                        @endforeach

                        <div class="filter-pop__footer">
                            @if (! empty($f['uploaders']))
                                <a href="{{ route('documents.attachments', collect(request()->all())->except('uploaders')->all()) }}" class="btn btn--ghost btn--sm">Clear</a>
                            @else
                                <span></span>
                            @endif
                            <button type="submit" class="btn btn--default btn--sm">Apply</button>
                        </div>
                    </div>
                </div>

                @if ($hasAnyFilter)
                    <a href="{{ route('documents.attachments', $showDetached ? ['detached' => 1] : []) }}" class="chip chip--ghost">
                        Clear all
                    </a>
                @endif
            </div>

            <div class="toolbar__group toolbar__group--right">
                {{-- Reuses the audit-search BEM pair (icon + bordered
                     input). Wrapped in a div, not its own form, since
                     the toolbar is already a single GET form. --}}
                <div class="audit-search">
                    <svg class="audit-search__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    <input type="search" name="q" value="{{ $f['q'] ?? '' }}" placeholder="Search filename" aria-label="Search documents" class="audit-search__input" autocomplete="off">
                </div>
            </div>
        </form>

        @if ($attachments->isEmpty())
            <div class="card">
                <div class="card__body table-empty">
                    No documents match these filters.
                </div>
            </div>
        @else
            <div class="table-wrap">
                <table class="table">
                    <colgroup>
                        <col>
                        <col>
                        <col>
                        <col style="width: 1%; white-space: nowrap;">
                        <col style="width: 1%; white-space: nowrap;">
                        <col style="width: 1%; white-space: nowrap;">
                        <col style="width: 1%; white-space: nowrap;">
                    </colgroup>
                    <thead>
                        <tr>
                            <th scope="col">File</th>
                            <th scope="col">Linked to</th>
                            <th scope="col">Uploader</th>
                            <th scope="col">Type</th>
                            <th scope="col" class="num">Size</th>
                            <th scope="col">Uploaded</th>
                            <th scope="col" class="num"></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($attachments as $att)
                            @php
                                [$ext, $extBadgeClass] = $extBadge($att->original_filename);
                                $links = $linkLookup->get($att->id, []);
                                $primaryLink = $links[0] ?? null;
                                $extraLinks = max(0, count($links) - 1);

                                // Group every active link by contract so a file
                                // attached to N slots on M contracts (very
                                // common: one CPA-confirmation email applies
                                // to many contracts) collapses cleanly.
                                $byContract = [];
                                foreach ($links as $link) {
                                    $cid = $link['contract_id'];
                                    if ($cid === null) continue;
                                    $byContract[$cid] ??= [
                                        'contract_id' => $cid,
                                        'contract_number' => null,
                                        'route' => null,
                                        'archived' => false,
                                        'slots' => [],
                                    ];
                                    $byContract[$cid]['slots'][] = $link['slot_label'];
                                }
                                foreach ($byContract as $cid => &$row) {
                                    $c = $contractLookup->get($cid);
                                    if ($c) {
                                        $row['contract_number'] = $c->contract_number;
                                        $row['route'] = (string) $c->route;
                                        $row['archived'] = $c->archived_at !== null;
                                    }
                                }
                                unset($row);
                                $contractGroups = array_values($byContract);
                                $contractCount = count($contractGroups);
                                $extraContracts = max(0, $contractCount - 1);
                            @endphp
                            <tr>
                                <td>
                                    <div class="doc-filename">
                                        <svg class="doc-filename__icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                                        <span class="doc-filename__name" title="{{ $att->original_filename }}">{{ $att->original_filename }}</span>
                                    </div>
                                </td>
                                <td>
                                    @if (empty($contractGroups))
                                        <span class="text-soft">— no active link</span>
                                    @else
                                        @php $first = $contractGroups[0]; @endphp
                                        <div class="doc-link">
                                            <a href="{{ route('contracts.index', ['q' => '#'.$first['contract_id']]) }}" class="doc-link__contract">
                                                {{ $first['contract_number'] }}
                                                <span class="text-soft">· route {{ $first['route'] }}</span>
                                            </a>
                                            <span class="doc-link__slot">
                                                {{ $first['slots'][0] }}
                                                @if (count($first['slots']) > 1)
                                                    <span class="text-soft">+ {{ count($first['slots']) - 1 }} more on this contract</span>
                                                @endif
                                            </span>
                                            @if ($first['archived'])
                                                <span class="badge badge--neutral badge--sm">Archived contract</span>
                                            @endif
                                        </div>
                                        @if ($extraContracts > 0)
                                            {{-- Open a modal listing every contract this file is
                                                 attached to. Common case: one CPA-confirmation
                                                 email applies to 50 contracts. --}}
                                            <button type="button"
                                                    class="doc-link__more-btn"
                                                    @click="viewing = {
                                                        filename: @js($att->original_filename),
                                                        total: {{ count($links) }},
                                                        contracts: @js($contractGroups),
                                                    }; linkFilter = '';">
                                                + {{ $extraContracts }} other {{ \Illuminate\Support\Str::plural('contract', $extraContracts) }}
                                            </button>
                                        @endif
                                    @endif
                                </td>
                                <td>
                                    @if ($att->uploader)
                                        {{ $att->uploader->name }}
                                    @else
                                        <span class="text-soft">—</span>
                                    @endif
                                </td>
                                <td>
                                    @if ($ext !== '')
                                        <span class="badge {{ $extBadgeClass }}">.{{ $ext }}</span>
                                    @else
                                        <span class="text-soft">—</span>
                                    @endif
                                </td>
                                <td class="num is-mono">{{ $formatBytes($att->size_bytes) }}</td>
                                <td>
                                    <time datetime="{{ optional($att->created_at)->toIso8601String() }}" title="{{ optional($att->created_at)->format('Y-m-d H:i') }}">
                                        {{ optional($att->created_at)->format('d M Y') }}
                                    </time>
                                </td>
                                <td class="num">
                                    <a href="{{ route('attachments.download', $att) }}"
                                       class="row-action"
                                       aria-label="Download {{ $att->original_filename }}"
                                       data-tooltip="Download">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            @if ($attachments->hasPages())
                <div class="pagination">
                    {{ $attachments->links() }}
                </div>
            @endif
        @endif

        {{-- Linked-records dialog. Lists every contract a single file is
             attached to, with a quick filter for the 50+ case. Driven
             entirely client-side from the data already shipped with the
             page — no extra round-trip. --}}
        <div x-show="viewing !== null" x-cloak role="dialog" aria-modal="true" aria-labelledby="linked-records-title">
            <div class="dialog__overlay" @click="viewing = null; linkFilter = '';" aria-hidden="true"></div>
            <template x-if="viewing !== null">
                <div class="dialog__content dialog__content--lg">
                    <h2 class="dialog__title" id="linked-records-title">Linked records</h2>
                    <p class="dialog__description">
                        <span class="is-mono" x-text="viewing.filename"></span>
                        is attached to <strong x-text="viewing.contracts.length"></strong>
                        <span x-text="viewing.contracts.length === 1 ? 'contract' : 'contracts'"></span>
                        (<span x-text="viewing.total"></span>
                        <span x-text="viewing.total === 1 ? 'slot' : 'slots'"></span> total).
                    </p>

                    <div class="dialog__body">
                        <div class="audit-search" style="margin-bottom: var(--space-3);">
                            <svg class="audit-search__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                            <input type="search" x-model="linkFilter" placeholder="Filter contract no., route, slot…" aria-label="Filter linked records" class="audit-search__input" autocomplete="off">
                        </div>

                        <div class="linked-records">
                            <table class="table linked-records__table">
                                <thead>
                                    <tr>
                                        <th scope="col">Contract</th>
                                        <th scope="col">Route</th>
                                        <th scope="col">Slot</th>
                                        <th scope="col" class="num"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <template x-for="c in visibleContracts()" :key="c.contract_id">
                                        <tr>
                                            <td>
                                                <span class="is-mono" x-text="c.contract_number"></span>
                                                <template x-if="c.archived">
                                                    <span class="badge badge--neutral badge--sm" style="margin-left: 6px;">Archived</span>
                                                </template>
                                            </td>
                                            <td x-text="c.route"></td>
                                            <td>
                                                <template x-if="c.slots.length === 1">
                                                    <span x-text="c.slots[0]"></span>
                                                </template>
                                                <template x-if="c.slots.length > 1">
                                                    <ul class="linked-records__slots">
                                                        <template x-for="slot in c.slots" :key="slot">
                                                            <li x-text="slot"></li>
                                                        </template>
                                                    </ul>
                                                </template>
                                            </td>
                                            <td class="num">
                                                {{-- `%23` is `#` URL-encoded — using a raw
                                                     `#` here would make the rest of the value
                                                     a URL fragment, leaving q= empty server-
                                                     side. The PHP route() helper already
                                                     handles this for the inline link above. --}}
                                                <a :href="`/contracts?q=%23${c.contract_id}`" class="row-action" data-tooltip="Open contract" aria-label="Open contract">
                                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M7 17L17 7"/><polyline points="7 7 17 7 17 17"/></svg>
                                                </a>
                                            </td>
                                        </tr>
                                    </template>
                                    <template x-if="visibleContracts().length === 0">
                                        <tr>
                                            <td colspan="4" class="table-empty">No contracts match this filter.</td>
                                        </tr>
                                    </template>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="dialog__footer">
                        <button type="button" class="btn btn--secondary" @click="viewing = null; linkFilter = '';">Close</button>
                    </div>
                </div>
            </template>
        </div>
    </div>
</x-app-layout>
