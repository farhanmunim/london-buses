@include('errors.layout', [
    'code' => 503,
    'title' => 'Maintenance in progress',
    'description' => 'Bus Contracts Manager is briefly down for maintenance. Try again in a few minutes.',
])
