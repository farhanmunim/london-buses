{{-- Shared layout for HTTP error pages (404, 419, 429, 500, ...).
     Reuses the guest layout's typography + theme handling so the
     page is on-brand even when the user isn't authenticated. --}}
<x-guest-layout>
    <header class="auth-card__header">
        <h1 class="auth-card__title">{{ $title ?? __('Something went wrong') }}</h1>
        @if (isset($code))
            <p class="auth-card__description">
                <span class="is-mono is-soft">HTTP {{ $code }}</span>
                @isset($description)
                    · {{ $description }}
                @endisset
            </p>
        @elseif (isset($description))
            <p class="auth-card__description">{{ $description }}</p>
        @endif
    </header>

    <div class="auth-card__body">
        @isset($body)
            {{ $body }}
        @endisset

        <div class="dialog__actions dialog__actions--center">
            @auth
                <a href="{{ url('/') }}" class="btn btn--default">Back to dashboard</a>
            @else
                <a href="{{ route('login') }}" class="btn btn--default">Sign in</a>
            @endauth
        </div>
    </div>
</x-guest-layout>
