@include('errors.layout', [
    'code' => 403,
    'title' => 'Access denied',
    'description' => $exception->getMessage() !== ''
        ? $exception->getMessage()
        : 'You don\'t have permission to view that page.',
])
