@include('errors.layout', [
    'code' => 500,
    'title' => 'Something broke on our side',
    'description' => 'An unexpected error happened while handling that request. The team has been notified.',
])
