@include('errors.layout', [
    'code' => 404,
    'title' => 'Page not found',
    'description' => 'That page doesn\'t exist — or you don\'t have access to it.',
])
