@include('errors.layout', [
    'code' => 419,
    'title' => 'Page expired',
    'description' => 'Your session timed out before that form was submitted. Sign in again and retry the action — nothing was saved.',
])
