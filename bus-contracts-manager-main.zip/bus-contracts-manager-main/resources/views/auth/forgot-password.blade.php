<x-guest-layout>
    <header class="auth-card__header">
        <h1 class="auth-card__title">Forgot password</h1>
        <p class="auth-card__description">{{ __('Enter your email and we\'ll send you a reset link.') }}</p>
    </header>

    <form method="POST" action="{{ route('password.email') }}" class="auth-card__body">
        @csrf

        <x-auth-session-status :status="session('status')" />

        <div class="field">
            <label for="email" class="label">Email</label>
            <x-text-input id="email" type="email" name="email" :value="old('email')" required autofocus placeholder="you@example.com" />
            <x-input-error :messages="$errors->get('email')" />
        </div>

        <x-turnstile />

        <button type="submit" class="btn btn--default btn--block">Send reset link</button>
    </form>

    <footer class="auth-card__footer">
        Remembered it? <a href="{{ route('login') }}">Sign in</a>
    </footer>
</x-guest-layout>
