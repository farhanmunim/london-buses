<x-guest-layout>
    <header class="auth-card__header">
        <h1 class="auth-card__title">Confirm password</h1>
        <p class="auth-card__description">{{ __('This is a secure area. Please confirm your password before continuing.') }}</p>
    </header>

    <form method="POST" action="{{ route('password.confirm') }}" class="auth-card__body">
        @csrf

        <div class="field">
            <x-input-label for="password" :value="__('Password')" />
            <x-text-input id="password" type="password" name="password" required autocomplete="current-password" />
            <x-input-error :messages="$errors->get('password')" />
        </div>

        <button type="submit" class="btn btn--default btn--block">{{ __('Confirm') }}</button>
    </form>
</x-guest-layout>
