<x-guest-layout>
    <header class="auth-card__header">
        <h1 class="auth-card__title">Create account</h1>
        <p class="auth-card__description">Sign up to get started with Bus Contracts Manager.</p>
    </header>

    <form method="POST" action="{{ route('register') }}" class="auth-card__body">
        @csrf

        <div class="field">
            <label for="name" class="label">Name</label>
            <x-text-input id="name" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" placeholder="Jane Doe" />
            <x-input-error :messages="$errors->get('name')" />
        </div>

        <div class="field">
            <label for="email" class="label">Email</label>
            <x-text-input id="email" type="email" name="email" :value="old('email')" required autocomplete="username" placeholder="you@example.com" />
            <x-input-error :messages="$errors->get('email')" />
        </div>

        <div class="field">
            <label for="password" class="label">Password</label>
            <x-text-input id="password" type="password" name="password" required autocomplete="new-password" />
            <x-input-error :messages="$errors->get('password')" />
        </div>

        <div class="field">
            <label for="password_confirmation" class="label">Confirm password</label>
            <x-text-input id="password_confirmation" type="password" name="password_confirmation" required autocomplete="new-password" />
            <x-input-error :messages="$errors->get('password_confirmation')" />
        </div>

        <x-turnstile />

        <button type="submit" class="btn btn--default btn--block">Create account</button>
    </form>

    <footer class="auth-card__footer">
        Already have an account? <a href="{{ route('login') }}">Sign in</a>
    </footer>
</x-guest-layout>
