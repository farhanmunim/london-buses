<x-guest-layout>
    <header class="auth-card__header">
        <h1 class="auth-card__title">Reset password</h1>
        <p class="auth-card__description">Choose a new password for your account.</p>
    </header>

    <form method="POST" action="{{ route('password.store') }}" class="auth-card__body">
        @csrf
        <input type="hidden" name="token" value="{{ $request->route('token') }}">

        <div class="field">
            <x-input-label for="email" :value="__('Email')" />
            <x-text-input id="email" type="email" name="email" :value="old('email', $request->email)" required autofocus autocomplete="username" />
            <x-input-error :messages="$errors->get('email')" />
        </div>

        <div class="field">
            <x-input-label for="password" :value="__('Password')" />
            <x-text-input id="password" type="password" name="password" required autocomplete="new-password" />
            <x-input-error :messages="$errors->get('password')" />
        </div>

        <div class="field">
            <x-input-label for="password_confirmation" :value="__('Confirm Password')" />
            <x-text-input id="password_confirmation" type="password" name="password_confirmation" required autocomplete="new-password" />
            <x-input-error :messages="$errors->get('password_confirmation')" />
        </div>

        <x-turnstile />

        <button type="submit" class="btn btn--default btn--block">{{ __('Reset password') }}</button>
    </form>
</x-guest-layout>
