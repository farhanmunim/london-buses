<x-guest-layout>
    <header class="auth-card__header">
        <h1 class="auth-card__title">Verify email</h1>
        <p class="auth-card__description">{{ __('We sent you a verification link. Click it to activate your account.') }}</p>
    </header>

    <div class="auth-card__body">
        @if (session('status') == 'verification-link-sent')
            <div class="alert alert--success" role="status">{{ __('A new verification link has been sent.') }}</div>
        @endif

        <div class="cluster cluster--split">
            <form method="POST" action="{{ route('verification.send') }}">
                @csrf
                <button type="submit" class="btn btn--default">{{ __('Resend verification') }}</button>
            </form>

            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="btn btn--link">{{ __('Log out') }}</button>
            </form>
        </div>
    </div>
</x-guest-layout>
