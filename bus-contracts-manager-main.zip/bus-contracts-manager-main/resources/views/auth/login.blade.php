<x-guest-layout>
    <header class="auth-card__header">
        <h1 class="auth-card__title">Sign in</h1>
        <p class="auth-card__description">Enter your email and password to access Bus Contracts Manager.</p>
    </header>

    <form method="POST" action="{{ route('login') }}" class="auth-card__body">
        @csrf

        <x-auth-session-status :status="session('status')" />

        <div class="field">
            <label for="email" class="label">Email</label>
            <x-text-input id="email" type="email" name="email" :value="old('email')" required autofocus autocomplete="username" placeholder="you@example.com" />
            <x-input-error :messages="$errors->get('email')" />
        </div>

        <div class="field">
            <div class="field__label-row">
                <label for="password" class="label">Password</label>
                @if (Route::has('password.request'))
                    <a class="btn btn--link text-xs" href="{{ route('password.request') }}">Forgot password?</a>
                @endif
            </div>
            <x-text-input id="password" type="password" name="password" required autocomplete="current-password" />
            <x-input-error :messages="$errors->get('password')" />
        </div>

        <label class="checkbox-row">
            <input id="remember_me" type="checkbox" name="remember">
            Remember me
        </label>

        <x-turnstile />

        <button type="submit" class="btn btn--default btn--block">Sign in</button>
    </form>

    {{-- Public registration is disabled — accounts are created by a
         superadmin via Manage users. The footer "Sign up" link is
         intentionally removed; the route still exists but 404s. --}}
</x-guest-layout>
