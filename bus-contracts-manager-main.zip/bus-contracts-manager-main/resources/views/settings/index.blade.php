<x-app-layout :crumb="'Settings'">
    @php
        $isSuperadmin = auth()->user()->isSuperadmin();
    @endphp

    <div x-data="{
        /*
         * Shared password-confirm dialog for every Data-control action.
         * Forms call queueForPassword($event) from their @submit handler
         * — that captures a reference to the form, blocks the submit,
         * and opens the dialog. On confirm we write the password into
         * the form's hidden field and submit it programmatically. The
         * server still hashes-and-compares; this is a UI nudge, not the
         * security boundary.
         */
        passwordPrompt: { form: null, password: '', label: '' },
        queueForPassword(event, label) {
            event.preventDefault();
            this.passwordPrompt = {
                form: event.target,
                password: '',
                label: label || 'this action',
            };
            this.$nextTick(() => this.$refs.passwordInput?.focus());
        },
        cancelPasswordPrompt() {
            this.passwordPrompt = { form: null, password: '', label: '' };
        },
        submitWithPassword() {
            if (! this.passwordPrompt.password) return;
            const form = this.passwordPrompt.form;
            const hidden = form?.querySelector('input[name=password]');
            if (hidden) hidden.value = this.passwordPrompt.password;
            // Submit programmatically — calling .submit() bypasses the
            // form's @submit handler so we don't re-enter this dialog.
            const formToSubmit = form;
            this.cancelPasswordPrompt();
            formToSubmit?.submit();
        },
    }"
         @keydown.escape.window="cancelPasswordPrompt()">
    <div class="page__header">
        <div>
            <h1 class="page__title">Settings</h1>
            <p class="page__subtitle">App-wide preferences and data control.</p>
        </div>
    </div>

    @if (session('status'))
        <div class="alert alert--success" role="status">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5"/></svg>
            {{ session('status') }}
        </div>
    @endif

    @php
        $formatBytes = function (?int $bytes): string {
            if ($bytes === null) return '—';
            if ($bytes < 1024) return $bytes.' B';
            if ($bytes < 1024 * 1024) return round($bytes / 1024, 1).' KB';
            return round($bytes / 1024 / 1024, 1).' MB';
        };
    @endphp

    @php
        $indexCount = $cpiCount + $cpaCount + $rpiCount;
        $totalCount = $contractCount + $indexCount + $auditLogCount + $attachmentCount;
    @endphp

    <div class="stack stack--lg stack--medium">
        @if ($isSuperadmin)
            {{-- Group label sits above the three Data-control cards so the
                 framing ("these are all data-control actions") is preserved
                 even though each action is its own card below. --}}
            <div class="settings-group__heading">
                <h2 class="settings-group__title">Data control</h2>
                <p class="settings-group__subtitle">Superadmin-only data operations — backups and destructive actions. Not audit-logged.</p>
            </div>

            {{-- Upload limits — sits first because it's the system-wide
                 policy knob every other data-control action depends on
                 (template imports, evidence attachments). --}}
            <section class="card" aria-labelledby="upload-limits-title">
                <header class="card__header">
                    <div>
                        <h3 class="card__title" id="upload-limits-title">Upload limits</h3>
                        <p class="card__subtitle">Cap file size and restrict extensions across the system.</p>
                    </div>
                </header>
                <form method="POST" action="{{ route('settings.upload-limits.update') }}"
                      @submit="
                          if ($event.submitter && $event.submitter.dataset.action === 'reset') {
                              if (! confirm('Reset attachment and template upload limits to their built-in defaults?')) { $event.preventDefault(); return; }
                          }
                          queueForPassword($event, 'this action');
                      ">
                    @csrf
                    <input type="hidden" name="password" value="">
                    <div class="card__body">
                        <p class="card__hint">
                            Attachment limits apply in the contract dialogs (CPA confirm, Extension, Notice served, Tender award, Edit contract).
                            Template limits apply to every bulk Import button (Contracts, CPI, CPA, RPI).
                        </p>
                        <div class="contract-form-grid field--gap-top">
                            <div class="field">
                                <label class="label" for="attachment-max-kb">Attachment max size (KB)</label>
                                <input id="attachment-max-kb" type="number" class="input" name="attachment_max_kb" value="{{ old('attachment_max_kb', $attachmentMaxKb) }}" min="64" max="51200" required>
                                <span class="field__hint">{{ $formatBytes($attachmentMaxKb * 1024) }} currently · 64 KB min · 50 MB max.</span>
                                <x-input-error :messages="$errors->get('attachment_max_kb')" />
                            </div>
                            <div class="field">
                                <label class="label" for="attachment-extensions">Attachment allowed extensions</label>
                                <input id="attachment-extensions" type="text" class="input" name="attachment_extensions" value="{{ old('attachment_extensions', $attachmentExtensions) }}" required pattern="[A-Za-z0-9, ]+">
                                <span class="field__hint">Comma-separated, no dots. Example: <span class="is-mono">pdf,docx,csv</span>.</span>
                                <x-input-error :messages="$errors->get('attachment_extensions')" />
                            </div>
                            <div class="field">
                                <label class="label" for="template-max-kb">Template max size (KB)</label>
                                <input id="template-max-kb" type="number" class="input" name="template_max_kb" value="{{ old('template_max_kb', $templateMaxKb) }}" min="64" max="51200" required>
                                <span class="field__hint">{{ $formatBytes($templateMaxKb * 1024) }} currently · default 2 MB.</span>
                                <x-input-error :messages="$errors->get('template_max_kb')" />
                            </div>
                            <div class="field">
                                <label class="label" for="template-extensions">Template allowed extensions</label>
                                <input id="template-extensions" type="text" class="input" name="template_extensions" value="{{ old('template_extensions', $templateExtensions) }}" required pattern="[A-Za-z0-9, ]+">
                                <span class="field__hint">CSV by default. Example: <span class="is-mono">csv</span>.</span>
                                <x-input-error :messages="$errors->get('template_extensions')" />
                            </div>
                        </div>
                    </div>
                    <footer class="card__footer card__footer--split">
                        {{-- formaction overrides the form's main action so
                             Reset hits the reset endpoint without nesting
                             a second <form> (which HTML doesn't allow). --}}
                        <button type="submit"
                                data-action="reset"
                                formaction="{{ route('settings.upload-limits.reset') }}"
                                class="btn btn--ghost btn--sm">
                            <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 12a9 9 0 0 1 15.5-6.36L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.36L3 16"/><path d="M3 21v-5h5"/></svg>
                            Reset to defaults
                        </button>
                        <button type="submit" class="btn btn--default btn--sm">Save limits</button>
                    </footer>
                </form>
            </section>

            {{-- Database snapshot --}}
            <section class="card" aria-labelledby="snapshot-title">
                <header class="card__header">
                    <div>
                        <h3 class="card__title" id="snapshot-title">Database snapshot</h3>
                        <p class="card__subtitle">Single-file backup of every table plus the full audit history.</p>
                    </div>
                </header>
                <div class="card__body">
                    <p class="card__hint">
                        @if ($snapshotDriver === 'sqlite')
                            @if ($snapshotAvailable)
                                Currently <span class="is-mono">{{ $formatBytes($snapshotSize) }}</span>.
                            @else
                                Local SQLite file not found.
                            @endif
                            Save this somewhere safe; restore by replacing <span class="is-mono">database/database.sqlite</span>.
                        @elseif ($snapshotDriver === 'pgsql')
                            Streamed live via <span class="is-mono">pg_dump | gzip</span> as a portable <span class="is-mono">.sql.gz</span> file. Save this somewhere safe; restore from the app container's Terminal with
                            <span class="is-mono">gunzip -c snapshot.sql.gz | psql -h $DB_HOST -U $DB_USERNAME $DB_DATABASE</span>.
                        @else
                            Driver <span class="is-mono">{{ $snapshotDriver }}</span> is not currently supported for snapshots.
                        @endif
                    </p>
                </div>
                <footer class="card__footer card__footer--end">
                    @if ($snapshotAvailable)
                        <form method="POST" action="{{ route('settings.database-snapshot') }}"
                              @submit="queueForPassword($event, 'this action');">
                            @csrf
                            <input type="hidden" name="password" value="">
                            <button type="submit" class="btn btn--secondary btn--sm">
                                <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                                Download snapshot
                            </button>
                        </form>
                    @else
                        <button type="button" class="btn btn--secondary btn--sm" disabled aria-label="Snapshot unavailable on this driver">
                            <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                            Download snapshot
                        </button>
                    @endif
                </footer>
            </section>

            {{-- Targeted data delete — single destructive entry point.
                 Pick WHAT to wipe; users, login history, and app settings always survive.
                 Per project policy these actions are NOT audit-logged. --}}
            <section class="card card--destructive" aria-labelledby="delete-data-title" x-data="{ deleteType: '' }">
                <header class="card__header">
                    <div>
                        <h3 class="card__title" id="delete-data-title">Delete data</h3>
                        <p class="card__subtitle">Irreversible — take a snapshot above first. Users, login history, and app settings always survive.</p>
                    </div>
                </header>
                <div class="card__body">
                    <dl class="data-counts">
                        <div class="data-counts__row">
                            <dt class="data-counts__label">Audit log</dt>
                            <dd class="data-counts__value"><span class="is-mono">{{ number_format($auditLogCount) }}</span> {{ \Illuminate\Support\Str::plural('entry', $auditLogCount) }}</dd>
                        </div>
                        <div class="data-counts__row">
                            <dt class="data-counts__label">Contracts</dt>
                            <dd class="data-counts__value"><span class="is-mono">{{ number_format($contractCount) }}</span></dd>
                        </div>
                        <div class="data-counts__row">
                            <dt class="data-counts__label">Indices <span class="text-soft">(CPI · CPA · RPI)</span></dt>
                            <dd class="data-counts__value"><span class="is-mono">{{ number_format($indexCount) }}</span> {{ \Illuminate\Support\Str::plural('row', $indexCount) }}</dd>
                        </div>
                        <div class="data-counts__row">
                            <dt class="data-counts__label">Attachments</dt>
                            <dd class="data-counts__value"><span class="is-mono">{{ number_format($attachmentCount) }}</span> · <span class="is-mono">{{ $formatBytes($attachmentBytes) }}</span></dd>
                        </div>
                    </dl>
                </div>
                <footer class="card__footer card__footer--split">
                    <form method="POST" action="{{ route('settings.delete-data') }}"
                          class="card__footer-form"
                          @submit="
                              if (! deleteType) { $event.preventDefault(); return; }
                              var labels = {
                                  audit_log: 'all {{ $auditLogCount }} audit log entries (cascades attachments)',
                                  contracts: 'all {{ $contractCount }} contracts (audit history preserved)',
                                  indices: 'all {{ $indexCount }} CPI / CPA / RPI rows',
                                  attachments: 'all {{ $attachmentCount }} attachments ({{ $formatBytes($attachmentBytes) }})',
                                  all: 'EVERYTHING ({{ $totalCount }} rows: contracts, indices, audit log, attachments). Users, login history, and app settings will be preserved.'
                              };
                              var msg = labels[deleteType];
                              if (! confirm('Step 1 of 2: Permanently delete ' + msg + '?')) { $event.preventDefault(); return; }
                              if (! confirm('Step 2 of 2: Are you absolutely sure? This cannot be undone. Continue?')) { $event.preventDefault(); return; }
                              queueForPassword($event, 'this action');
                          ">
                        @csrf
                        <input type="hidden" name="password" value="">
                        <select name="type" x-model="deleteType" class="input" required aria-label="Pick what to delete">
                            <option value="" disabled>— Pick what to delete —</option>
                            <option value="audit_log">Audit log only ({{ number_format($auditLogCount) }} entries)</option>
                            <option value="contracts">Contracts only ({{ number_format($contractCount) }})</option>
                            <option value="indices">Indices only — CPI · CPA · RPI ({{ number_format($indexCount) }})</option>
                            <option value="attachments">Attachments only ({{ number_format($attachmentCount) }})</option>
                            <option value="all">All data ({{ number_format($totalCount) }})</option>
                        </select>
                        <button type="submit" class="btn btn--destructive btn--sm" :disabled="! deleteType">
                            <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
                            Delete
                        </button>
                    </form>
                </footer>
            </section>
        @else
            <section class="card">
                <div class="card__body">
                    <p class="text-soft">App-wide settings will live here. For account profile changes use the user menu in the sidebar.</p>
                </div>
            </section>
        @endif
    </div>

    {{-- Password-confirm dialog. Opened by every Data-control form's
         @submit handler via queueForPassword(). The form is held in
         passwordPrompt.form; on Confirm we paste the typed password into
         the form's hidden field and submit it programmatically. --}}
    <div x-show="passwordPrompt.form !== null" x-cloak role="dialog" aria-modal="true" aria-labelledby="password-confirm-title">
        <div class="dialog__overlay" @click="cancelPasswordPrompt()" aria-hidden="true"></div>
        <div class="dialog__content" x-show="passwordPrompt.form !== null" x-cloak>
            <h2 class="dialog__title" id="password-confirm-title">Confirm with your password</h2>
            <p class="dialog__description">Re-enter your password to authorise this action. This is logged and applies to every data-control operation.</p>

            <form @submit.prevent="submitWithPassword()">
                <div class="dialog__body">
                    <div class="field">
                        <label class="label" for="password-confirm-input">Your password</label>
                        <input id="password-confirm-input"
                               type="password"
                               class="input"
                               autocomplete="current-password"
                               x-ref="passwordInput"
                               x-model="passwordPrompt.password"
                               required>
                        @if ($errors->has('password'))
                            <span class="field__hint text-destructive">{{ $errors->first('password') }}</span>
                        @endif
                    </div>
                </div>
                <div class="dialog__footer">
                    <button type="button" class="btn btn--secondary" @click="cancelPasswordPrompt()">Cancel</button>
                    <button type="submit" class="btn btn--default" :disabled="! passwordPrompt.password">Confirm</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</x-app-layout>
