<x-app-layout :crumb="'Contracts'">
    @php
        $f = $filters;
        $hasAnyFilter = ! empty($f['companies']) || ! empty($f['depots']) || ! empty($f['statuses']) || $f['q'] !== null;
        $hasAddErrors = $errors->hasAny(['company', 'depot', 'route', 'contract_number', 'tender_date', 'start_date', 'end_date', 'contract_value']);
    @endphp

    <div x-data="{
            open: null,
            editing: null,
            creating: {{ $hasAddErrors && ! request('contract_id') ? 'true' : 'false' }},
            settingsOpen: {{ $errors->hasAny(['anchor_year', 'p2p_ra_cutoff']) ? 'true' : 'false' }},
            importOpen: {{ $errors->has('csv') ? 'true' : 'false' }},
            confirmingCpa: null,
            confirmingExtension: null,
            confirmingNotice: null,
            confirmingTender: null,
            moreInfo: false,
            companies: @js($f['companies']),
            depots: @js($f['depots']),
            statuses: @js($f['statuses']),
            async detachAttachment(att, list) {
                if (! confirm(`Detach “${att.filename}” from this record? The file stays in the audit history but is removed from the active list.`)) return;
                // Detach now operates on the attachment LINK (the per-slot
                // binding), not the attachment itself — so detaching one
                // slot doesn't unhook the file from any other slot that
                // links to it (Stage 2 of link-existing rollout).
                const linkId = att.link_id ?? att.id;
                try {
                    const resp = await fetch(`/contracts/attachment-links/${linkId}/detach`, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]')?.content ?? '',
                            'Accept': 'application/json',
                        },
                    });
                    if (! resp.ok && resp.status !== 302) throw new Error('detach failed');
                    const idx = list.findIndex(x => (x.link_id ?? x.id) === linkId);
                    if (idx >= 0) list.splice(idx, 1);
                } catch (e) {
                    alert('Could not detach the file. Please refresh and try again.');
                }
            },
         }"
         @keydown.escape.window="open = null; editing = null; creating = false; settingsOpen = false; importOpen = false; confirmingCpa = null; confirmingExtension = null; confirmingNotice = null; confirmingTender = null">
        <div class="page__header">
            <div>
                <h1 class="page__title">
                    @if ($showArchived)
                        Archived contracts
                    @else
                        Contracts
                    @endif
                </h1>
                <div class="page__subtitle">
                    @if ($showArchived)
                        {{ $contracts->count() }} archived {{ \Illuminate\Support\Str::plural('contract', $contracts->count()) }}. Restore from here to bring a contract back into the active list.
                    @elseif ($anchorYear && $p2pRaCutoff)
                        Values anchored at <strong>{{ $anchorYear }}</strong>;
                        tenders on or before <strong>{{ \Carbon\Carbon::parse($p2pRaCutoff)->format('d/m/Y') }}</strong> use P2P, later tenders use RA.
                    @else
                        <span class="text-soft">Set the anchor year and P2P/RA cutoff via the settings cog so contract values can be indexed correctly.</span>
                    @endif
                </div>
            </div>
            <div class="page__actions">
                @if ($showArchived)
                    <a href="{{ route('contracts.index') }}" class="btn btn--secondary">← Back to active</a>
                @else
                @if ($archivedCount > 0)
                    <a href="{{ route('contracts.index', ['archived' => 1]) }}" class="btn btn--secondary" data-tooltip="View archived" data-tooltip-side="bottom">
                        Archived <span class="chip__count">{{ $archivedCount }}</span>
                    </a>
                @endif
                @if (auth()->user()->canWrite())
                <button type="button" class="btn btn--secondary" @click="settingsOpen = true" aria-label="Contract settings" data-tooltip="Settings" data-tooltip-side="bottom">
                    <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                </button>
                <a href="{{ route('contracts.export') }}" class="btn btn--secondary" data-tooltip="Download as CSV" data-tooltip-side="bottom">
                    <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    Export
                </a>
                <button type="button" class="btn btn--secondary" @click="importOpen = true" data-tooltip="Bulk import from CSV" data-tooltip-side="bottom">
                    <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    Import
                </button>
                <button type="button" class="btn btn--default" @click="creating = true">
                    <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    Add contract
                </button>
                @endif
                @endif
            </div>
        </div>

        @if (session('status'))
            <div class="alert alert--success" role="status">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5"/></svg>
                {{ session('status') }}
            </div>
        @endif

        @if (session('updateError'))
            <div class="alert alert--destructive" role="alert">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                {{ session('updateError') }}
            </div>
        @endif

        {{-- Filter toolbar --}}
        <div class="toolbar">
            <div class="toolbar__group">
                <a href="{{ route('contracts.index') }}" class="chip {{ ! $hasAnyFilter ? 'is-active' : '' }}">
                    All <span class="chip__count">{{ $totalCount }}</span>
                </a>
            </div>

            <div class="toolbar__group toolbar__group--offset">
                {{-- Company filter --}}
                <div class="filter-pop" @click.outside="if (open === 'company') open = null">
                    <button type="button"
                            class="chip chip--outline {{ ! empty($f['companies']) ? 'is-active' : '' }}"
                            aria-haspopup="true"
                            :aria-expanded="open === 'company'"
                            @click="open = open === 'company' ? null : 'company'">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 21h18"/><path d="M5 21V7l8-4v18"/><path d="M19 21V11l-6-4"/></svg>
                        Company
                        @if (! empty($f['companies']))
                            <span class="chip__value">
                                {{ count($f['companies']) === 1 ? $f['companies'][0] : count($f['companies']).' companies' }}
                            </span>
                        @endif
                        <svg class="chip__chev" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>

                    <form x-show="open === 'company'" x-cloak x-transition.opacity.duration.100ms
                          method="GET" action="{{ route('contracts.index') }}"
                          class="filter-pop__menu">
                        @foreach (request()->except(['companies']) as $key => $val)
                            @if (is_array($val))
                                @foreach ($val as $v)
                                    <input type="hidden" name="{{ $key }}[]" value="{{ $v }}">
                                @endforeach
                            @else
                                <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                            @endif
                        @endforeach
                        <input type="hidden" :name="companies.length ? 'companies' : null" :value="companies.join(',')">

                        <div class="filter-pop__title">Filter by company</div>

                        @foreach ($companyCounts as $code => $count)
                            <label class="filter-pop__option">
                                <input type="checkbox" value="{{ $code }}" x-model="companies">
                                <span class="filter-pop__option-label">{{ $code }}</span>
                                <span class="filter-pop__option-count">{{ $count }}</span>
                            </label>
                        @endforeach

                        <div class="filter-pop__footer">
                            @if (! empty($f['companies']))
                                <a href="{{ route('contracts.index', request()->except(['companies'])) }}" class="btn btn--ghost btn--sm">Clear</a>
                            @else
                                <span></span>
                            @endif
                            <button type="submit" class="btn btn--default btn--sm">Apply</button>
                        </div>
                    </form>
                </div>

                {{-- Depot filter --}}
                <div class="filter-pop" @click.outside="if (open === 'depot') open = null">
                    <button type="button"
                            class="chip chip--outline {{ ! empty($f['depots']) ? 'is-active' : '' }}"
                            aria-haspopup="true"
                            :aria-expanded="open === 'depot'"
                            @click="open = open === 'depot' ? null : 'depot'">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                        Depot
                        @if (! empty($f['depots']))
                            <span class="chip__value">
                                {{ count($f['depots']) === 1 ? $f['depots'][0] : count($f['depots']).' depots' }}
                            </span>
                        @endif
                        <svg class="chip__chev" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>

                    <form x-show="open === 'depot'" x-cloak x-transition.opacity.duration.100ms
                          method="GET" action="{{ route('contracts.index') }}"
                          class="filter-pop__menu">
                        @foreach (request()->except(['depots']) as $key => $val)
                            @if (is_array($val))
                                @foreach ($val as $v)
                                    <input type="hidden" name="{{ $key }}[]" value="{{ $v }}">
                                @endforeach
                            @else
                                <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                            @endif
                        @endforeach
                        <input type="hidden" :name="depots.length ? 'depots' : null" :value="depots.join(',')">

                        <div class="filter-pop__title">Filter by depot</div>

                        @foreach ($depotCounts as $code => $count)
                            <label class="filter-pop__option">
                                <input type="checkbox" value="{{ $code }}" x-model="depots">
                                <span class="filter-pop__option-label">{{ $code }}</span>
                                <span class="filter-pop__option-count">{{ $count }}</span>
                            </label>
                        @endforeach

                        <div class="filter-pop__footer">
                            @if (! empty($f['depots']))
                                <a href="{{ route('contracts.index', request()->except(['depots'])) }}" class="btn btn--ghost btn--sm">Clear</a>
                            @else
                                <span></span>
                            @endif
                            <button type="submit" class="btn btn--default btn--sm">Apply</button>
                        </div>
                    </form>
                </div>

                {{-- Status filter --}}
                <div class="filter-pop" @click.outside="if (open === 'status') open = null">
                    <button type="button"
                            class="chip chip--outline {{ ! empty($f['statuses']) ? 'is-active' : '' }}"
                            aria-haspopup="true"
                            :aria-expanded="open === 'status'"
                            @click="open = open === 'status' ? null : 'status'">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        Status
                        @if (! empty($f['statuses']))
                            <span class="chip__value">
                                {{ count($f['statuses']) === 1 ? ucfirst($f['statuses'][0]) : count($f['statuses']).' statuses' }}
                            </span>
                        @endif
                        <svg class="chip__chev" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>

                    <form x-show="open === 'status'" x-cloak x-transition.opacity.duration.100ms
                          method="GET" action="{{ route('contracts.index') }}"
                          class="filter-pop__menu">
                        @foreach (request()->except(['statuses']) as $key => $val)
                            @if (is_array($val))
                                @foreach ($val as $v)
                                    <input type="hidden" name="{{ $key }}[]" value="{{ $v }}">
                                @endforeach
                            @else
                                <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                            @endif
                        @endforeach
                        <input type="hidden" :name="statuses.length ? 'statuses' : null" :value="statuses.join(',')">

                        <div class="filter-pop__title">Filter by status</div>

                        @foreach (['active', 'expired', 'upcoming'] as $statusKey)
                            <label class="filter-pop__option">
                                <input type="checkbox" value="{{ $statusKey }}" x-model="statuses">
                                <span class="filter-pop__option-label">{{ ucfirst($statusKey) }}</span>
                                <span class="filter-pop__option-count">{{ $statusCounts[$statusKey] ?? 0 }}</span>
                            </label>
                        @endforeach

                        <div class="filter-pop__footer">
                            @if (! empty($f['statuses']))
                                <a href="{{ route('contracts.index', request()->except(['statuses'])) }}" class="btn btn--ghost btn--sm">Clear</a>
                            @else
                                <span></span>
                            @endif
                            <button type="submit" class="btn btn--default btn--sm">Apply</button>
                        </div>
                    </form>
                </div>

                @if ($hasAnyFilter)
                    <a href="{{ route('contracts.index') }}" class="chip chip--ghost" data-tooltip="Clear all filters">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                        Reset
                    </a>
                @endif

                <button type="button"
                        class="chip chip--outline"
                        :class="{ 'is-active': moreInfo }"
                        @click="moreInfo = !moreInfo"
                        :aria-pressed="moreInfo"
                        data-tooltip="Toggle operational columns">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
                    <span x-text="moreInfo ? 'Less info' : 'More info'">More info</span>
                </button>
            </div>

            <div class="toolbar__spacer"></div>

            <form method="GET" action="{{ route('contracts.index') }}" class="audit-search">
                @foreach (request()->except(['q', 'page']) as $key => $val)
                    @if (is_array($val))
                        @foreach ($val as $v)
                            <input type="hidden" name="{{ $key }}[]" value="{{ $v }}">
                        @endforeach
                    @else
                        <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                    @endif
                @endforeach
                <svg class="audit-search__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input type="search" name="q" value="{{ $f['q'] }}" placeholder="Search contract no., route, company, or depot" aria-label="Search contracts" title="Searches contract no., route, company, and depot." class="audit-search__input" autocomplete="off">
            </form>
        </div>

        <div class="table-wrap">
            <div class="table-scroll table-scroll--tall" :class="{ 'is-expanded': moreInfo }">
                <table class="table table--wide">
                    <thead>
                        <tr class="table__header-row">
                            <th scope="col" class="table-frozen table-frozen--1" title="Internal record id — use this when overriding or varying via CSV import.">ID</th>
                            <th scope="col" class="table-frozen table-frozen--2" title="Active if today falls between start and end dates; Expired if end date has passed; Upcoming if it hasn't started yet.">Status</th>
                            <th scope="col" class="table-frozen table-frozen--3">Company</th>
                            <th scope="col" class="table-frozen table-frozen--4">Depot</th>
                            <th scope="col" class="table-frozen table-frozen--5">Route</th>
                            <th scope="col" class="table-frozen table-frozen--6">Contract no.</th>
                            <th scope="col">Tender</th>
                            <th scope="col">Start</th>
                            <th scope="col">End</th>
                            <th scope="col" class="num" title="Whole years between start and end date — round((end − start) / 365).">Length</th>
                            <th scope="col" class="num">Value (£)</th>
                            <th scope="col" class="num" title="Year that the contract value is anchored to. Equals the global anchor year for contracts tendered on or before it; otherwise the tender year.">Anchor</th>
                            <th scope="col" class="num" title="Annual contracted operational mileage.">Contracted miles</th>
                            <th scope="col" title="P2P for tenders on or before the configured cutoff; RA for later tenders.">CPA type</th>
                            @foreach ($cpaYears as $year)
                                <th scope="col" title="Tender anniversary in {{ $year }}. Shown when the contract is still running on or after the anniversary date.">CPA Anv {{ $year }}</th>
                            @endforeach
                            @foreach ($cpaYears as $year)
                                <th scope="col" class="num" title="CPA rate for {{ $year }} — looked up by the contract's tender month against the {{ $year }} row in the CPA table.">CPA % {{ $year }}</th>
                            @endforeach
                            @foreach ($cpaYears as $year)
                                <th scope="col" title="CPA confirmed for {{ $year }}. Years before the anchor are locked to Yes; anchor onwards are editable per contract.">CPA confirmed {{ $year }}</th>
                            @endforeach
                            <th scope="col" class="table-extra" title="Date the contract was awarded to the operator following the tender process.">Tender award</th>
                            <th scope="col" class="num table-extra" title="Peak vehicle requirement.">PVR</th>
                            <th scope="col" class="num table-extra" title="Total vehicle requirement.">TVR</th>
                            <th scope="col" class="table-extra" title="Vehicle propulsion type — Diesel, Hybrid, Electric, or a mix.">Propulsion</th>
                            <th scope="col" class="table-extra" title="Vehicle deck configuration — SD (single-deck), DD (double-deck), or mixed.">Decks</th>
                            <th scope="col" class="table-extra" title="Whether the contract was re-let / extended. Drives the ET-date formula on contracts longer than 5 years.">Extension</th>
                            <th scope="col" class="table-extra" title="Computed earliest break date — derived from start date, contract length, extension flag, and tender year.">ET date</th>
                            <th scope="col" class="table-extra" title="Computed notice date — ET date − 10 months (or end date − 10 months for sub-5-year contracts).">Notice date</th>
                            <th scope="col" class="table-extra" title="Has notice been served? Yes/No flag — note required.">Notice served</th>
                            <th scope="col" class="table-extra" title="Derived from notice served + dates: Served, Passed, or Ongoing.">ET status</th>
                            <th scope="col" class="num"><span class="sr-only">Actions</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($contracts as $contract)
                            <tr id="contract-{{ $contract->id }}">
                                <td class="table-frozen table-frozen--1"><span class="is-mono text-soft">{{ $contract->id }}</span></td>
                                <td class="table-frozen table-frozen--2">
                                    @php
                                        $status = $contract->status();
                                        $statusBadge = match ($status) {
                                            'active' => 'badge--success',
                                            'expired' => 'badge--destructive',
                                            'upcoming' => 'badge--info',
                                        };
                                    @endphp
                                    <span class="badge {{ $statusBadge }} badge--with-dot">{{ ucfirst($status) }}</span>
                                </td>
                                <td class="table-frozen table-frozen--3"><span class="badge badge--neutral badge--with-dot">{{ $contract->company }}</span></td>
                                <td class="table-frozen table-frozen--4"><span class="is-mono">{{ $contract->depot }}</span></td>
                                <td class="table-frozen table-frozen--5"><span class="is-medium">{{ $contract->route }}</span></td>
                                <td class="table-frozen table-frozen--6"><span class="is-mono">{{ $contract->contract_number }}</span></td>
                                <td>{{ $contract->formatTenderDate() }}</td>
                                <td>{{ $contract->formatStartDate() }}</td>
                                <td>{{ $contract->formatEndDate() }}</td>
                                <td class="num">
                                    @php $lengthYears = $contract->contractLengthYears(); @endphp
                                    @if ($lengthYears !== null)
                                        <span class="is-mono">{{ $lengthYears }}</span>
                                    @else
                                        <span class="text-soft">—</span>
                                    @endif
                                </td>
                                <td class="num">{{ number_format((float) $contract->contract_value, 2, '.', ',') }}</td>
                                <td class="num">
                                    @php $contractAnchor = $contract->anchorYear($anchorYear !== null ? (int) $anchorYear : null); @endphp
                                    @if ($contractAnchor !== null)
                                        <span class="is-mono">{{ $contractAnchor }}</span>
                                    @else
                                        <span class="text-soft">—</span>
                                    @endif
                                </td>
                                <td class="num">
                                    @if ($contract->contracted_miles !== null)
                                        {{ number_format((float) $contract->contracted_miles, 2, '.', ',') }}
                                    @else
                                        <span class="text-soft">—</span>
                                    @endif
                                </td>
                                <td>
                                    @php $contractCpaType = $contract->cpaType($p2pRaCutoff); @endphp
                                    @if ($contractCpaType !== null)
                                        <span class="badge {{ $contractCpaType === 'P2P' ? 'badge--info' : 'badge--neutral' }} badge--with-dot">{{ $contractCpaType }}</span>
                                    @else
                                        <span class="text-soft">—</span>
                                    @endif
                                </td>
                                @php
                                    $tenderCarbon = \Carbon\Carbon::parse($contract->tender_date);
                                    $tenderMonth = (int) $tenderCarbon->format('m');
                                    $tenderDay = (int) $tenderCarbon->format('d');
                                    $tenderYear = (int) $tenderCarbon->format('Y');
                                    $startCarbon = \Carbon\Carbon::parse($contract->start_date)->startOfDay();
                                    $endCarbon = \Carbon\Carbon::parse($contract->end_date)->startOfDay();

                                    // Reusable applicability closure — same three-rule check used
                                    // by the CPA % cells. Returns the applicability flag plus the
                                    // anniversary Carbon so both column groups stay in sync.
                                    $cpaApplicability = function (int $year) use ($tenderMonth, $tenderDay, $tenderYear, $startCarbon, $endCarbon) {
                                        try {
                                            $anniversary = \Carbon\Carbon::create($year, $tenderMonth, $tenderDay)->startOfDay();
                                        } catch (\Throwable $e) {
                                            $anniversary = \Carbon\Carbon::create($year, $tenderMonth, 1)->endOfMonth()->startOfDay();
                                        }
                                        $columnYearStart = \Carbon\Carbon::create($year, 1, 1)->startOfDay();
                                        $columnYearEnd = \Carbon\Carbon::create($year, 12, 31)->endOfDay();
                                        $beforeFirstAnniversary = $year <= $tenderYear;
                                        $contractLiveInYear = $startCarbon->lessThanOrEqualTo($columnYearEnd) && $endCarbon->greaterThanOrEqualTo($columnYearStart);
                                        $anniversaryReachedByEnd = $anniversary->lessThanOrEqualTo($endCarbon);

                                        return [
                                            'anniversary' => $anniversary,
                                            'notApplicable' => $beforeFirstAnniversary || ! $contractLiveInYear || ! $anniversaryReachedByEnd,
                                        ];
                                    };
                                @endphp
                                @foreach ($cpaYears as $year)
                                    @php
                                        $a = $cpaApplicability($year);
                                    @endphp
                                    <td>
                                        @if ($a['notApplicable'])
                                            <span class="text-soft" title="Anniversary falls outside the contract's life or before the first anniversary.">N/A</span>
                                        @else
                                            <span class="is-mono">{{ $a['anniversary']->format('d/m/Y') }}</span>
                                        @endif
                                    </td>
                                @endforeach
                                @foreach ($cpaYears as $year)
                                    @php
                                        $a = $cpaApplicability($year);
                                        $notApplicable = $a['notApplicable'];

                                        $key = sprintf('%04d-%02d-01', $year, $tenderMonth);
                                        $rateRow = $cpaRatesByMonth[$key] ?? null;
                                        $effectiveRate = null;
                                        if (! $notApplicable && $rateRow && $contractCpaType !== null) {
                                            $effectiveRate = $contractCpaType === 'P2P'
                                                ? ($rateRow->p2p_override ?? $rateRow->p2p_rate)
                                                : ($rateRow->ra_override ?? $rateRow->ra_rate);
                                        }
                                    @endphp
                                    <td class="num">
                                        @if ($notApplicable)
                                            <span class="text-soft" title="CPA is not applicable for this year — anniversary falls outside the contract's life or before the first anniversary.">N/A</span>
                                        @elseif ($effectiveRate !== null)
                                            {{ number_format((float) $effectiveRate * 100, 4) }}%
                                        @else
                                            <span class="text-soft" title="Applicable, but ONS hasn't published CPI for {{ \Carbon\Carbon::createFromFormat('!Y-m', sprintf('%04d-%02d', $year, $tenderMonth))->format('F Y') }} yet.">Pending</span>
                                        @endif
                                    </td>
                                @endforeach
                                @php
                                    $globalAnchorInt = $anchorYear !== null ? (int) $anchorYear : null;
                                @endphp
                                @foreach ($cpaYears as $year)
                                    @php
                                        $confirmStatus = $contract->cpaConfirmation($year, $globalAnchorInt);
                                        $confirmEditable = $contract->isCpaConfirmationEditable($year, $globalAnchorInt);
                                    @endphp
                                    <td>
                                        @if ($confirmEditable)
                                            <button type="button"
                                                    class="cpa-confirm-trigger cpa-confirm-trigger--{{ $confirmStatus }}"
                                                    aria-label="Set CPA confirmation for {{ $year }}"
                                                    @click="confirmingCpa = {
                                                        contract_id: {{ $contract->id }},
                                                        contract_number: @js($contract->contract_number),
                                                        route: @js($contract->route),
                                                        year: {{ $year }},
                                                        status: '{{ $confirmStatus === 'blank' ? '' : $confirmStatus }}',
                                                        note: @js($contract->cpaConfirmationNote($year) ?? ''),
                                                        attachments: @js($attachmentsByKey['contract:'.$contract->id.':cpa:'.$year] ?? []),
                                                    }">
                                                @if ($confirmStatus === 'yes')
                                                    Yes
                                                @elseif ($confirmStatus === 'no')
                                                    No
                                                @else
                                                    <span class="cpa-confirm-trigger__placeholder" aria-hidden="true">—</span>
                                                @endif
                                            </button>
                                        @else
                                            <span class="badge badge--success badge--with-dot" title="Pre-anchor years are locked to Yes.">Yes</span>
                                        @endif
                                    </td>
                                @endforeach
                                {{-- Tender award — click opens a dialog to set the
                                     free-text label (e.g. "Option 1") + attachment. --}}
                                <td class="table-extra">
                                    @php
                                        $tenderAwardNote = $contract->tenderAwardNoteValue();
                                    @endphp
                                    <button type="button"
                                            class="cpa-confirm-trigger {{ $tenderAwardNote ? 'cpa-confirm-trigger--yes' : '' }}"
                                            aria-label="{{ auth()->user()->canWrite() ? 'Set' : 'View' }} tender award for {{ $contract->contract_number }}"
                                            @click="confirmingTender = {
                                                contract_id: {{ $contract->id }},
                                                contract_number: @js($contract->contract_number),
                                                route: @js($contract->route),
                                                note: @js($tenderAwardNote ?? ''),
                                                attachments: @js($attachmentsByKey['contract:'.$contract->id.':tender_award'] ?? []),
                                            }">
                                        @if ($tenderAwardNote)
                                            {{ $tenderAwardNote }}
                                        @else
                                            <span class="cpa-confirm-trigger__placeholder" aria-hidden="true">—</span>
                                        @endif
                                    </button>
                                </td>
                                <td class="num table-extra">{{ $contract->pvr ?? '—' }}</td>
                                <td class="num table-extra">{{ $contract->tvr ?? '—' }}</td>
                                <td class="table-extra">{{ $contract->propulsion ?? '—' }}</td>
                                <td class="table-extra">{{ $contract->decks ?? '—' }}</td>
                                {{-- Extension flag — Yes/No with mandatory note. Drives ET-date formula. --}}
                                <td class="table-extra">
                                    @php $extState = $contract->extensionStatus(); @endphp
                                    <button type="button"
                                            class="cpa-confirm-trigger cpa-confirm-trigger--{{ $extState }}"
                                            aria-label="{{ auth()->user()->canWrite() ? 'Set' : 'View' }} extension flag for {{ $contract->contract_number }}"
                                            @click="confirmingExtension = {
                                                contract_id: {{ $contract->id }},
                                                contract_number: @js($contract->contract_number),
                                                route: @js($contract->route),
                                                status: '{{ $extState === 'blank' ? '' : $extState }}',
                                                note: @js($contract->extensionNote() ?? ''),
                                                attachments: @js($attachmentsByKey['contract:'.$contract->id.':extension'] ?? []),
                                            }">
                                        @if ($extState === 'yes') Yes
                                        @elseif ($extState === 'no') No
                                        @else <span class="cpa-confirm-trigger__placeholder" aria-hidden="true">—</span>
                                        @endif
                                    </button>
                                </td>
                                {{-- ET date — computed; dash when no tender date, blank when length < 5. --}}
                                <td class="table-extra">
                                    @if ($contract->showsDateDash())
                                        <span class="text-soft">—</span>
                                    @else
                                        @php $etDate = $contract->earlyTerminationDate(); @endphp
                                        @if ($etDate)
                                            {{ $etDate->format('d/m/Y') }}
                                        @else
                                            <span class="text-soft" aria-hidden="true"></span>
                                        @endif
                                    @endif
                                </td>
                                {{-- Notice date — computed; dash when no tender date. --}}
                                <td class="table-extra">
                                    @if ($contract->showsDateDash())
                                        <span class="text-soft">—</span>
                                    @else
                                        @php $noticeDate = $contract->noticeDate(); @endphp
                                        @if ($noticeDate)
                                            {{ $noticeDate->format('d/m/Y') }}
                                        @else
                                            <span class="text-soft" aria-hidden="true"></span>
                                        @endif
                                    @endif
                                </td>
                                {{-- Notice served — Yes/No with mandatory note. --}}
                                <td class="table-extra">
                                    @php $nsState = $contract->noticeServedStatus(); @endphp
                                    <button type="button"
                                            class="cpa-confirm-trigger cpa-confirm-trigger--{{ $nsState }}"
                                            aria-label="{{ auth()->user()->canWrite() ? 'Set' : 'View' }} notice-served flag for {{ $contract->contract_number }}"
                                            @click="confirmingNotice = {
                                                contract_id: {{ $contract->id }},
                                                contract_number: @js($contract->contract_number),
                                                route: @js($contract->route),
                                                status: '{{ $nsState === 'blank' ? '' : $nsState }}',
                                                note: @js($contract->noticeServedNoteValue() ?? ''),
                                                attachments: @js($attachmentsByKey['contract:'.$contract->id.':notice_served'] ?? []),
                                            }">
                                        @if ($nsState === 'yes') Yes
                                        @elseif ($nsState === 'no') No
                                        @else <span class="cpa-confirm-trigger__placeholder" aria-hidden="true">—</span>
                                        @endif
                                    </button>
                                </td>
                                {{-- ET status — derived: Served (notice_served = yes), Passed (today > notice date), Ongoing. --}}
                                <td class="table-extra">
                                    @php
                                        $etStatus = null;
                                        $today = \Carbon\Carbon::today()->startOfDay();
                                        if (! $contract->showsDateDash() && ($contract->contractLengthYears() ?? 0) >= 5) {
                                            $etStatus = $nsState === 'yes' ? 'served' : 'ongoing';
                                            $nd = $contract->noticeDate();
                                            if ($etStatus === 'ongoing' && $nd !== null && $today->greaterThan($nd)) {
                                                $etStatus = 'passed';
                                            }
                                        }
                                    @endphp
                                    @if ($etStatus !== null)
                                        @php
                                            $etBadge = match ($etStatus) {
                                                'served' => 'badge--info',
                                                'passed' => 'badge--neutral',
                                                'ongoing' => 'badge--success',
                                            };
                                        @endphp
                                        <span class="badge {{ $etBadge }} badge--with-dot">{{ ucfirst($etStatus) }}</span>
                                    @else
                                        <span class="text-soft">—</span>
                                    @endif
                                </td>
                                <td class="num">
                                    <div class="audit-row-actions">
                                        @if (auth()->user()->canViewAuditLog())
                                            <a href="{{ route('audit-log.index', ['q' => '#'.$contract->id]) }}"
                                               class="row-action"
                                               aria-label="View history for {{ $contract->contract_number }}"
                                               data-tooltip="History">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                            </a>
                                        @endif
                                    @php $rowCanEdit = auth()->user()->canWrite() && ! $showArchived; @endphp
                                    <button type="button" class="row-action"
                                            aria-label="{{ $rowCanEdit ? 'Edit' : 'View' }} {{ $contract->contract_number }}"
                                            data-tooltip="{{ $rowCanEdit ? 'Edit' : 'View' }}"
                                            data-id="{{ $contract->id }}"
                                            data-company="{{ $contract->company }}"
                                            data-depot="{{ $contract->depot }}"
                                            data-route="{{ $contract->route }}"
                                            data-contract-number="{{ $contract->contract_number }}"
                                            data-tender-date="{{ \Carbon\Carbon::parse($contract->tender_date)->format('Y-m-d') }}"
                                            data-start-date="{{ \Carbon\Carbon::parse($contract->start_date)->format('Y-m-d') }}"
                                            data-end-date="{{ \Carbon\Carbon::parse($contract->end_date)->format('Y-m-d') }}"
                                            data-contract-value="{{ number_format((float) $contract->contract_value, 4, '.', '') }}"
                                            data-contracted-miles="{{ $contract->contracted_miles !== null ? number_format((float) $contract->contracted_miles, 2, '.', '') : '' }}"
                                            data-tender-award-note="{{ $contract->tenderAwardNoteValue() ?? '' }}"
                                            data-pvr="{{ $contract->pvr ?? '' }}"
                                            data-tvr="{{ $contract->tvr ?? '' }}"
                                            data-propulsion="{{ $contract->propulsion ?? '' }}"
                                            data-decks="{{ $contract->decks ?? '' }}"
                                            data-latest-change-note="{{ $contract->latest_change_note ?? '' }}"
                                            @click="editing = {
                                                id: $el.dataset.id,
                                                company: $el.dataset.company,
                                                depot: $el.dataset.depot,
                                                route: $el.dataset.route,
                                                contract_number: $el.dataset.contractNumber,
                                                tender_date: $el.dataset.tenderDate,
                                                start_date: $el.dataset.startDate,
                                                end_date: $el.dataset.endDate,
                                                contract_value: $el.dataset.contractValue,
                                                contracted_miles: $el.dataset.contractedMiles,
                                                tender_award_note: $el.dataset.tenderAwardNote,
                                                pvr: $el.dataset.pvr,
                                                tvr: $el.dataset.tvr,
                                                propulsion: $el.dataset.propulsion,
                                                decks: $el.dataset.decks,
                                                change_kind: '',
                                                change_note: $el.dataset.latestChangeNote,
                                                attachments: @js($attachmentsByKey['contract:'.$contract->id] ?? []),
                                            }">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                    </button>

                                    @if ($showArchived && auth()->user()->canWrite())
                                        <form method="POST" action="{{ route('contracts.restore', $contract) }}" class="form--inline"
                                              @submit="if (! confirm(`Restore contract {{ $contract->contract_number }}? It will reappear in the active list.`)) $event.preventDefault();">
                                            @csrf
                                            @method('PATCH')
                                            <button type="submit" class="row-action" aria-label="Restore {{ $contract->contract_number }}" data-tooltip="Restore">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
                                            </button>
                                        </form>
                                    @endif
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="{{ 25 + (3 * count($cpaYears)) }}" class="table-empty">No contracts match these filters.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        {{-- Add contract --}}
        <div x-show="creating" x-cloak @keydown.escape.window="creating = false" role="dialog" aria-modal="true" aria-labelledby="add-contract-title">
            <div class="dialog__overlay" @click="creating = false" aria-hidden="true"></div>
            <div class="dialog__content dialog__content--lg" x-show="creating" x-cloak>
                <h2 class="dialog__title" id="add-contract-title">Add contract</h2>
                <p class="dialog__description">Record a new contract line item.</p>

                <form method="POST" action="{{ route('contracts.store') }}"
                      @submit="if (! confirm('Add this contract?')) $event.preventDefault();">
                    @csrf
                    <div class="dialog__body">
                        <div class="contract-form-grid">
                            <div class="field">
                                <label class="label" for="add-company">Company</label>
                                <input id="add-company" type="text" class="input" name="company" value="{{ old('company') }}" required maxlength="8" placeholder="e.g. AB">
                                <x-input-error :messages="$errors->get('company')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-depot">Depot</label>
                                <input id="add-depot" type="text" class="input" name="depot" value="{{ old('depot') }}" required maxlength="8" placeholder="e.g. CD">
                                <x-input-error :messages="$errors->get('depot')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-route">Route</label>
                                <input id="add-route" type="text" class="input" name="route" value="{{ old('route') }}" required maxlength="32" placeholder="e.g. 100">
                                <x-input-error :messages="$errors->get('route')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-contract-number">Contract no.</label>
                                <input id="add-contract-number" type="text" class="input" name="contract_number" value="{{ old('contract_number') }}" required maxlength="32" placeholder="e.g. QC12345">
                                <x-input-error :messages="$errors->get('contract_number')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-tender-date">Tender date</label>
                                <x-date-picker id="add-tender-date" name="tender_date" :value="old('tender_date')" required placeholder="dd/mm/yyyy" />
                                <x-input-error :messages="$errors->get('tender_date')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-start-date">Start date</label>
                                <x-date-picker id="add-start-date" name="start_date" :value="old('start_date')" required placeholder="dd/mm/yyyy" />
                                <x-input-error :messages="$errors->get('start_date')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-end-date">End date</label>
                                <x-date-picker id="add-end-date" name="end_date" :value="old('end_date')" required placeholder="dd/mm/yyyy" />
                                <x-input-error :messages="$errors->get('end_date')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-contract-value">Contract value (£)</label>
                                <input id="add-contract-value" type="number" step="0.0001" class="input" name="contract_value" value="{{ old('contract_value') }}" required placeholder="e.g. 1000000.0000">
                                <x-input-error :messages="$errors->get('contract_value')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-contracted-miles">Contracted miles</label>
                                <input id="add-contracted-miles" type="number" step="0.01" min="0" class="input" name="contracted_miles" value="{{ old('contracted_miles') }}" required placeholder="e.g. 100000.00">
                                <x-input-error :messages="$errors->get('contracted_miles')" />
                            </div>
                            {{-- Optional operational fields — mirror the Edit dialog
                                 so PVR / TVR / Propulsion / Decks / Tender award can
                                 be captured at creation time. None are required. --}}
                            <div class="field">
                                <label class="label" for="add-tender-award">Tender award <span class="is-soft">(optional)</span></label>
                                <input id="add-tender-award" type="text" class="input" name="tender_award_note" maxlength="500" value="{{ old('tender_award_note') }}" placeholder="e.g. Option A">
                                <x-input-error :messages="$errors->get('tender_award_note')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-pvr">PVR <span class="is-soft">(optional)</span></label>
                                <input id="add-pvr" type="number" step="1" min="0" max="9999" class="input" name="pvr" value="{{ old('pvr') }}">
                                <x-input-error :messages="$errors->get('pvr')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-tvr">TVR <span class="is-soft">(optional)</span></label>
                                <input id="add-tvr" type="number" step="1" min="0" max="9999" class="input" name="tvr" value="{{ old('tvr') }}">
                                <x-input-error :messages="$errors->get('tvr')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-propulsion">Propulsion <span class="is-soft">(optional)</span></label>
                                <select id="add-propulsion" class="input" name="propulsion">
                                    <option value="" {{ old('propulsion') ? '' : 'selected' }}>—</option>
                                    <option value="Diesel" {{ old('propulsion') === 'Diesel' ? 'selected' : '' }}>Diesel</option>
                                    <option value="Hybrid" {{ old('propulsion') === 'Hybrid' ? 'selected' : '' }}>Hybrid</option>
                                    <option value="Electric" {{ old('propulsion') === 'Electric' ? 'selected' : '' }}>Electric</option>
                                    <option value="Mix - Hybrid/EV" {{ old('propulsion') === 'Mix - Hybrid/EV' ? 'selected' : '' }}>Mix - Hybrid/EV</option>
                                </select>
                                <x-input-error :messages="$errors->get('propulsion')" />
                            </div>
                            <div class="field">
                                <label class="label" for="add-decks">Decks <span class="is-soft">(optional)</span></label>
                                <select id="add-decks" class="input" name="decks">
                                    <option value="" {{ old('decks') ? '' : 'selected' }}>—</option>
                                    <option value="SD" {{ old('decks') === 'SD' ? 'selected' : '' }}>SD</option>
                                    <option value="DD" {{ old('decks') === 'DD' ? 'selected' : '' }}>DD</option>
                                    <option value="SD/DD" {{ old('decks') === 'SD/DD' ? 'selected' : '' }}>SD/DD</option>
                                </select>
                                <x-input-error :messages="$errors->get('decks')" />
                            </div>
                        </div>
                    </div>
                    <div class="dialog__footer">
                        <button type="button" class="btn btn--secondary" @click="creating = false">Cancel</button>
                        <button type="submit" class="btn btn--default">Save contract</button>
                    </div>
                </form>
            </div>
        </div>

        {{-- Edit contract --}}
        <div x-show="editing !== null" x-cloak @keydown.escape.window="editing = null" role="dialog" aria-modal="true" aria-labelledby="edit-contract-title">
            <div class="dialog__overlay" @click="editing = null" aria-hidden="true"></div>
            <template x-if="editing !== null">
                <div class="dialog__content dialog__content--lg">
                    @php
                        // Archived contracts are immutable. Even an admin
                        // viewing the archived list gets the read-only
                        // dialog — the only action available is Restore.
                        $canWrite = auth()->user()->canWrite() && ! $showArchived;
                    @endphp
                    <h2 class="dialog__title" id="edit-contract-title">{{ $canWrite ? 'Edit contract' : 'View contract' }}</h2>
                    <p class="dialog__description" x-text="`${editing.contract_number} — ${editing.company} / ${editing.depot} / ${editing.route}`"></p>

                    <form id="edit-contract-form" method="POST" :action="`/contracts/${editing.id}`"
                          enctype="multipart/form-data"
                          @submit="if (! confirm(`Save changes to ${editing.contract_number}? Logged as a ${editing.change_kind}.`)) $event.preventDefault();">
                        @csrf
                        @method('PATCH')
                        <div class="dialog__body">
                            <div class="contract-form-grid">
                                <div class="field">
                                    <label class="label" for="edit-company">Company</label>
                                    <input id="edit-company" type="text" class="input" name="company" :value="editing.company" maxlength="8" @required($canWrite) @readonly(! $canWrite)>
                                </div>
                                <div class="field">
                                    <label class="label" for="edit-depot">Depot</label>
                                    <input id="edit-depot" type="text" class="input" name="depot" :value="editing.depot" maxlength="8" @required($canWrite) @readonly(! $canWrite)>
                                </div>
                                <div class="field">
                                    <label class="label" for="edit-route">Route</label>
                                    <input id="edit-route" type="text" class="input" name="route" :value="editing.route" maxlength="32" @required($canWrite) @readonly(! $canWrite)>
                                </div>
                                <div class="field">
                                    <label class="label" for="edit-contract-number">Contract no.</label>
                                    <input id="edit-contract-number" type="text" class="input" name="contract_number" :value="editing.contract_number" maxlength="32" @required($canWrite) @readonly(! $canWrite)>
                                </div>
                                <div class="field">
                                    <label class="label">Tender date</label>
                                    @if ($canWrite)
                                        <x-date-picker name="tender_date" :value="null" required placeholder="dd/mm/yyyy" x-model="editing.tender_date" />
                                    @else
                                        <input type="text" class="input" :value="editing.tender_date" readonly>
                                    @endif
                                </div>
                                <div class="field">
                                    <label class="label">Start date</label>
                                    @if ($canWrite)
                                        <x-date-picker name="start_date" :value="null" required placeholder="dd/mm/yyyy" x-model="editing.start_date" />
                                    @else
                                        <input type="text" class="input" :value="editing.start_date" readonly>
                                    @endif
                                </div>
                                <div class="field">
                                    <label class="label">End date</label>
                                    @if ($canWrite)
                                        <x-date-picker name="end_date" :value="null" required placeholder="dd/mm/yyyy" x-model="editing.end_date" />
                                    @else
                                        <input type="text" class="input" :value="editing.end_date" readonly>
                                    @endif
                                </div>
                                <div class="field">
                                    <label class="label" for="edit-contract-value">Contract value (£)</label>
                                    <input id="edit-contract-value" type="number" step="0.0001" class="input" name="contract_value" :value="editing.contract_value" @required($canWrite) @readonly(! $canWrite)>
                                </div>
                                <div class="field">
                                    <label class="label" for="edit-contracted-miles">Contracted miles</label>
                                    <input id="edit-contracted-miles" type="number" step="0.01" min="0" class="input" name="contracted_miles" :value="editing.contracted_miles" @required($canWrite) @readonly(! $canWrite)>
                                </div>
                                <div class="field">
                                    <label class="label" for="edit-tender-award">Tender award</label>
                                    <input id="edit-tender-award" type="text" class="input" name="tender_award_note" maxlength="500" placeholder="e.g. Option A" x-model="editing.tender_award_note" @readonly(! $canWrite)>
                                </div>
                                <div class="field">
                                    <label class="label" for="edit-pvr">PVR</label>
                                    <input id="edit-pvr" type="number" step="1" min="0" max="9999" class="input" name="pvr" :value="editing.pvr" @readonly(! $canWrite)>
                                </div>
                                <div class="field">
                                    <label class="label" for="edit-tvr">TVR</label>
                                    <input id="edit-tvr" type="number" step="1" min="0" max="9999" class="input" name="tvr" :value="editing.tvr" @readonly(! $canWrite)>
                                </div>
                                <div class="field">
                                    <label class="label" for="edit-propulsion">Propulsion</label>
                                    <select id="edit-propulsion" class="input" name="propulsion" x-model="editing.propulsion" @disabled(! $canWrite)>
                                        <option value="">—</option>
                                        <option value="Diesel">Diesel</option>
                                        <option value="Hybrid">Hybrid</option>
                                        <option value="Electric">Electric</option>
                                        <option value="Mix - Hybrid/EV">Mix - Hybrid/EV</option>
                                    </select>
                                </div>
                                <div class="field">
                                    <label class="label" for="edit-decks">Decks</label>
                                    <select id="edit-decks" class="input" name="decks" x-model="editing.decks" @disabled(! $canWrite)>
                                        <option value="">—</option>
                                        <option value="SD">SD</option>
                                        <option value="DD">DD</option>
                                        <option value="SD/DD">SD/DD</option>
                                    </select>
                                </div>
                            </div>

                            @if ($canWrite)
                                <div class="field field--full field--gap-top">
                                    <label class="label" for="edit-change-kind">Change kind</label>
                                    <select id="edit-change-kind" class="input" name="change_kind" x-model="editing.change_kind" required>
                                        <option value="" disabled>Select one</option>
                                        <option value="confirmation">Confirmation</option>
                                        <option value="override">Override</option>
                                        <option value="variation">Variation</option>
                                    </select>
                                    <span class="field__hint">
                                        Confirmation: re-affirming an existing value. ·
                                        Override: correcting bad data (typo, mis-key). ·
                                        Variation: a legitimate contract amendment.
                                    </span>
                                </div>

                                <div class="field field--full">
                                    <label class="label" for="edit-change-note">Note <span class="is-soft">(optional)</span></label>
                                    <textarea id="edit-change-note" name="change_note" rows="2" maxlength="500" class="textarea" placeholder="Reason or supporting reference (e.g. variation order number)" x-model="editing.change_note"></textarea>
                                    <span class="field__hint">Saved with the contract; the next edit pre-fills this field with whatever was written here.</span>
                                </div>
                            @endif

                            @include('partials.existing-attachments', ['stateVar' => 'editing.attachments'])
                            @if ($canWrite)
                                @include('partials.attachment-field', ['fieldId' => 'edit-attachment'])
                            @endif
                        </div>
                    </form>

                    <div class="dialog__footer dialog__footer--split">
                        @if ($showArchived && auth()->user()->canWrite())
                            <form method="POST" :action="`/contracts/${editing.id}/restore`" @submit="if (! confirm(`Restore contract ${editing.contract_number}? It will reappear in the active list.`)) $event.preventDefault();">
                                @csrf
                                @method('PATCH')
                                <button type="submit" class="btn btn--ghost btn--sm">
                                    <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
                                    Restore
                                </button>
                            </form>
                        @elseif ($canWrite)
                            <form method="POST" :action="`/contracts/${editing.id}`" @submit="if (! confirm(`Archive contract ${editing.contract_number}? Audit history preserved; restore from the Archived view if needed.`)) $event.preventDefault();">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn--ghost btn--sm text-destructive">
                                    <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/></svg>
                                    Archive
                                </button>
                            </form>
                        @else
                            <span></span>
                        @endif
                        <div class="dialog__actions">
                            <button type="button" class="btn btn--secondary" @click="editing = null">{{ $canWrite ? 'Cancel' : 'Close' }}</button>
                            @if ($canWrite)
                                <button type="submit" form="edit-contract-form" class="btn btn--default" :disabled="! editing.change_kind" :title="editing.change_kind ? '' : 'Pick a Change kind first'">Save</button>
                            @endif
                        </div>
                    </div>
                </div>
            </template>
        </div>

        {{-- Contract settings --}}
        <div x-show="settingsOpen" x-cloak @keydown.escape.window="settingsOpen = false" role="dialog" aria-modal="true" aria-labelledby="settings-title">
            <div class="dialog__overlay" @click="settingsOpen = false" aria-hidden="true"></div>
            <div class="dialog__content" x-show="settingsOpen" x-cloak>
                <h2 class="dialog__title" id="settings-title">Contract settings</h2>
                <p class="dialog__description">Tune how contract values are interpreted across the page.</p>

                <form method="POST" action="{{ route('contracts.settings.update') }}"
                      @submit="if (! confirm('Save contract settings?')) $event.preventDefault();">
                    @csrf
                    <div class="dialog__body">
                        <div class="field">
                            <label class="label" for="anchor-year">Anchor year</label>
                            <x-year-picker id="anchor-year" name="anchor_year" :value="$anchorYear" required placeholder="e.g. 2024" />
                            <span class="field__hint">The year contract values are quoted at. Indexation (CPA) compounds from each contract's tender anniversary forward, anchored to this year.</span>
                            <x-input-error :messages="$errors->get('anchor_year')" />
                        </div>
                        <div class="field">
                            <label class="label" for="p2p-ra-cutoff">P2P / RA cutoff</label>
                            <x-date-picker id="p2p-ra-cutoff" name="p2p_ra_cutoff" :value="$p2pRaCutoff" required placeholder="e.g. 01/08/2020" />
                            <span class="field__hint">Tender date that splits the two CPA regimes. Tenders on or before this date use P2P; later tenders use RA. Default: 01/08/2020.</span>
                            <x-input-error :messages="$errors->get('p2p_ra_cutoff')" />
                        </div>
                    </div>
                    <div class="dialog__footer">
                        <button type="button" class="btn btn--secondary" @click="settingsOpen = false">Cancel</button>
                        <button type="submit" class="btn btn--destructive">Save settings</button>
                    </div>
                </form>
            </div>
        </div>

        {{-- Import contracts --}}
        <div x-show="importOpen" x-cloak @keydown.escape.window="importOpen = false" role="dialog" aria-modal="true" aria-labelledby="import-contracts-title">
            <div class="dialog__overlay" @click="importOpen = false" aria-hidden="true"></div>
            <div class="dialog__content" x-data="{ filename: '' }" x-show="importOpen" x-cloak>
                <h2 class="dialog__title" id="import-contracts-title">Import contracts</h2>
                <p class="dialog__description">
                    Upload a CSV. Each row must set <span class="is-mono">import_type</span> to one of
                    <strong class="is-mono is-emphasis">new</strong>,
                    <strong class="is-mono is-emphasis">override</strong>, or
                    <strong class="is-mono is-emphasis">variation</strong>.
                    Override and variation rows also need the contract <span class="is-mono">id</span>.
                    <a href="{{ route('contracts.import-template') }}" download class="link">Download template</a>.
                </p>

                <form method="POST" action="{{ route('contracts.import') }}" enctype="multipart/form-data">
                    @csrf
                    <div class="dialog__body">
                        <label for="contracts-csv" class="dropzone" :class="filename && 'dropzone--has-file'">
                            <input id="contracts-csv" name="csv" type="file" accept=".csv,text/csv" required class="sr-only" @change="filename = $event.target.files[0]?.name ?? ''">
                            <svg class="dropzone__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true">
                                <path d="M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4"/>
                                <polyline points="17 8 12 3 7 8"/>
                                <line x1="12" y1="3" x2="12" y2="15"/>
                            </svg>
                            <span class="dropzone__text" x-text="filename || 'Click to choose a CSV file'"></span>
                            <span class="dropzone__hint">Up to 2 MB · 5,000 rows max</span>
                        </label>
                        <x-input-error :messages="$errors->get('csv')" />

                        @if (session('importErrors') && count(session('importErrors')) > 0)
                            <div class="alert alert--destructive alert--flush" role="alert">
                                <span>
                                    <strong>{{ count(session('importErrors')) }} rows rejected:</strong>
                                    <ul class="list--inline">
                                        @foreach (array_slice(session('importErrors'), 0, 10) as $err)
                                            <li>Row {{ $err['row'] }}: {{ $err['message'] }}</li>
                                        @endforeach
                                        @if (count(session('importErrors')) > 10)
                                            <li>… and {{ count(session('importErrors')) - 10 }} more.</li>
                                        @endif
                                    </ul>
                                </span>
                            </div>
                        @endif
                    </div>
                    <div class="dialog__footer">
                        <button type="button" class="btn btn--secondary" @click="importOpen = false">Cancel</button>
                        <button type="submit" class="btn btn--default">Import</button>
                    </div>
                </form>
            </div>
        </div>

        {{-- Import confirmation — opens automatically when the previous
             POST staged a pre-flight result. Shows the summary, lets the
             operator pick a default for any rows missing import_type,
             and surfaces in-file duplicate contract_numbers as a warning. --}}
        @if (session('importConfirmation'))
            @php
                $importConf = session('importConfirmation');
                $confAnalysis = $importConf['analysis'];
                $needsDefault = count($confAnalysis['missing_type_rows']) > 0;
                $hasDuplicates = count($confAnalysis['duplicate_contract_numbers']) > 0;
            @endphp
            <div x-data="{ confirmOpen: true }"
                 x-show="confirmOpen"
                 x-cloak
                 @keydown.escape.window="confirmOpen = false"
                 role="dialog"
                 aria-modal="true"
                 aria-labelledby="import-confirm-title">
                <div class="dialog__overlay" aria-hidden="true"></div>
                <div class="dialog__content" x-show="confirmOpen" x-cloak>
                    <h2 class="dialog__title" id="import-confirm-title">Confirm import</h2>
                    <p class="dialog__description">
                        Review the pre-flight before committing. Nothing has been written to the database yet.
                    </p>

                    <div class="import-summary">
                        <div class="import-summary__counts">
                            <div class="import-summary__count">
                                <div class="import-summary__count-num">{{ $confAnalysis['type_counts']['new'] }}</div>
                                <div class="import-summary__count-label">new</div>
                            </div>
                            <div class="import-summary__count">
                                <div class="import-summary__count-num">{{ $confAnalysis['type_counts']['override'] }}</div>
                                <div class="import-summary__count-label">override</div>
                            </div>
                            <div class="import-summary__count">
                                <div class="import-summary__count-num">{{ $confAnalysis['type_counts']['variation'] }}</div>
                                <div class="import-summary__count-label">variation</div>
                            </div>
                            @if ($needsDefault)
                                <div class="import-summary__count import-summary__count--warn">
                                    <div class="import-summary__count-num">{{ count($confAnalysis['missing_type_rows']) }}</div>
                                    <div class="import-summary__count-label">missing type</div>
                                </div>
                            @endif
                        </div>
                        <div class="import-summary__total">
                            {{ $confAnalysis['total_rows'] }} total {{ $confAnalysis['total_rows'] === 1 ? 'row' : 'rows' }}.
                        </div>
                    </div>

                    <form method="POST" action="{{ route('contracts.import-confirm') }}">
                        @csrf
                        <input type="hidden" name="uuid" value="{{ $importConf['uuid'] }}">

                        <div class="dialog__body">
                            @if ($needsDefault)
                                <div class="alert alert--warning alert--flush" role="alert">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                    <span>
                                        <strong>{{ count($confAnalysis['missing_type_rows']) }} {{ count($confAnalysis['missing_type_rows']) === 1 ? 'row is' : 'rows are' }} missing import_type.</strong>
                                        Pick a default to apply to {{ count($confAnalysis['missing_type_rows']) === 1 ? 'that row' : 'those rows' }}, or cancel and edit your CSV manually.
                                    </span>
                                </div>
                                <div class="field">
                                    <label class="label" for="default-import-type">Apply this import_type to missing rows</label>
                                    <select id="default-import-type" name="default_import_type" class="input" required>
                                        <option value="" disabled selected>— Pick one —</option>
                                        <option value="new">new</option>
                                        <option value="override">override</option>
                                        <option value="variation">variation</option>
                                    </select>
                                </div>
                            @endif

                            @if ($hasDuplicates)
                                <div class="alert alert--warning alert--flush" role="note">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                                    <span>
                                        <strong>Duplicate contract_numbers in this file.</strong>
                                        This is allowed (you may be varying the same contract twice), but worth checking.
                                        <ul class="import-summary__duplicates">
                                            @foreach (array_slice($confAnalysis['duplicate_contract_numbers'], 0, 8, true) as $cn => $rows)
                                                <li><span class="is-mono">{{ $cn }}</span> in rows {{ implode(', ', $rows) }}</li>
                                            @endforeach
                                            @if (count($confAnalysis['duplicate_contract_numbers']) > 8)
                                                <li>… and {{ count($confAnalysis['duplicate_contract_numbers']) - 8 }} more.</li>
                                            @endif
                                        </ul>
                                    </span>
                                </div>
                            @endif
                        </div>

                        <div class="dialog__footer">
                            <button type="button"
                                    class="btn btn--secondary"
                                    @click="$refs.cancelForm.submit()">Cancel</button>
                            <button type="submit" class="btn btn--default">Confirm import</button>
                        </div>
                    </form>

                    <form method="POST" action="{{ route('contracts.import-cancel') }}" x-ref="cancelForm" class="is-hidden">
                        @csrf
                        <input type="hidden" name="uuid" value="{{ $importConf['uuid'] }}">
                    </form>
                </div>
            </div>
        @endif

        {{-- CPA confirmation --}}
        <div x-show="confirmingCpa !== null" x-cloak @keydown.escape.window="confirmingCpa = null" role="dialog" aria-modal="true" aria-labelledby="confirm-cpa-title">
            <div class="dialog__overlay" @click="confirmingCpa = null" aria-hidden="true"></div>
            <div class="dialog__content" x-show="confirmingCpa !== null" x-cloak>
                <template x-if="confirmingCpa">
                    <div>
                        <h2 class="dialog__title" id="confirm-cpa-title">
                            Confirm CPA <span x-text="confirmingCpa.year"></span>
                        </h2>
                        <p class="dialog__description">
                            <span x-text="confirmingCpa.contract_number"></span>
                            ·
                            <span x-text="confirmingCpa.route"></span>
                        </p>

                        @php $canWrite = auth()->user()->canWrite() && ! $showArchived; @endphp
                        <form method="POST"
                              :action="`{{ url('contracts') }}/${confirmingCpa.contract_id}/cpa-confirmation`"
                              enctype="multipart/form-data"
                              @submit="if (! confirmingCpa.status) { $event.preventDefault(); }">
                            @csrf
                            @method('PATCH')
                            <input type="hidden" name="year" :value="confirmingCpa.year">

                            <div class="dialog__body">
                                <div class="field">
                                    <span class="label">Confirmation</span>
                                    <div class="kind-row">
                                        <label class="kind-row__option" :class="{ 'is-selected': confirmingCpa.status === 'yes' }">
                                            <input type="radio" name="status" value="yes" x-model="confirmingCpa.status" @required($canWrite) @disabled(! $canWrite)>
                                            <span class="kind-row__body">
                                                <span class="kind-row__title">Yes</span>
                                                <span class="kind-row__hint">CPA was applied for this anniversary.</span>
                                            </span>
                                        </label>
                                        <label class="kind-row__option" :class="{ 'is-selected': confirmingCpa.status === 'no' }">
                                            <input type="radio" name="status" value="no" x-model="confirmingCpa.status" @required($canWrite) @disabled(! $canWrite)>
                                            <span class="kind-row__body">
                                                <span class="kind-row__title">No</span>
                                                <span class="kind-row__hint">CPA was not applied for this anniversary.</span>
                                            </span>
                                        </label>
                                    </div>
                                    @if ($canWrite)
                                        <span class="field__hint" x-show="! confirmingCpa.status">Pick Yes or No before saving.</span>
                                    @endif
                                </div>

                                <div class="field">
                                    <label class="label" for="cpa-confirm-note">Note <span class="is-soft">(optional)</span></label>
                                    <textarea id="cpa-confirm-note" name="note" rows="3" maxlength="500" class="textarea" x-model="confirmingCpa.note" placeholder="Why is this being confirmed (or not)? Saved with the contract and recorded in the audit log." @readonly(! $canWrite)></textarea>
                                </div>

                                @include('partials.existing-attachments', ['stateVar' => 'confirmingCpa.attachments'])
                                @if ($canWrite)
                                    @include('partials.attachment-field', ['fieldId' => 'cpa-confirm-attachment'])
                                @endif
                            </div>

                            <div class="dialog__footer">
                                <button type="button" class="btn btn--secondary" @click="confirmingCpa = null">{{ $canWrite ? 'Cancel' : 'Close' }}</button>
                                @if ($canWrite)
                                    <button type="submit" class="btn btn--default" :disabled="! confirmingCpa.status">Save</button>
                                @endif
                            </div>
                        </form>
                    </div>
                </template>
            </div>
        </div>

        {{-- Extension flag dialog. Mirrors the CPA-confirmation dialog —
             same Yes/No radio + note pattern. Note is mandatory (`required`
             on the textarea + server-side validation), unlike the CPA
             dialog where notes are optional. --}}
        <div x-show="confirmingExtension !== null" x-cloak role="dialog" aria-modal="true" aria-labelledby="confirm-ext-title">
            <div class="dialog__overlay" @click="confirmingExtension = null" aria-hidden="true"></div>
            <template x-if="confirmingExtension !== null">
                <div class="dialog__content">
                    <div>
                        <h2 class="dialog__title" id="confirm-ext-title">Extension flag</h2>
                        <p class="dialog__description">
                            <span x-text="confirmingExtension.contract_number"></span>
                            ·
                            <span x-text="confirmingExtension.route"></span>
                        </p>

                        @php $canWrite = auth()->user()->canWrite() && ! $showArchived; @endphp
                        <form method="POST"
                              :action="`{{ url('contracts') }}/${confirmingExtension.contract_id}/extension`"
                              enctype="multipart/form-data"
                              @submit="if (! confirmingExtension.status || ! confirmingExtension.note.trim()) { $event.preventDefault(); }">
                            @csrf
                            @method('PATCH')

                            <div class="dialog__body">
                                <div class="field">
                                    <span class="label">Was the contract re-let / extended?</span>
                                    <div class="kind-row">
                                        <label class="kind-row__option" :class="{ 'is-selected': confirmingExtension.status === 'yes' }">
                                            <input type="radio" name="status" value="yes" x-model="confirmingExtension.status" @required($canWrite) @disabled(! $canWrite)>
                                            <span class="kind-row__body">
                                                <span class="kind-row__title">Yes</span>
                                                <span class="kind-row__hint">Contract was re-let. ET formula uses the 3-year branch.</span>
                                            </span>
                                        </label>
                                        <label class="kind-row__option" :class="{ 'is-selected': confirmingExtension.status === 'no' }">
                                            <input type="radio" name="status" value="no" x-model="confirmingExtension.status" @required($canWrite) @disabled(! $canWrite)>
                                            <span class="kind-row__body">
                                                <span class="kind-row__title">No</span>
                                                <span class="kind-row__hint">Original contract. ET formula uses the 4-year branch (length &gt; 5).</span>
                                            </span>
                                        </label>
                                    </div>
                                </div>

                                <div class="field">
                                    <label class="label" for="confirm-ext-note">Note</label>
                                    <textarea id="confirm-ext-note" name="note" rows="3" maxlength="500" class="textarea" x-model="confirmingExtension.note" placeholder="Reason — why is this being marked? Saved with the contract and recorded in the audit log." @required($canWrite) @readonly(! $canWrite)></textarea>
                                </div>

                                @include('partials.existing-attachments', ['stateVar' => 'confirmingExtension.attachments'])
                                @if ($canWrite)
                                    @include('partials.attachment-field', ['fieldId' => 'confirm-ext-attachment'])
                                @endif
                            </div>

                            <div class="dialog__footer">
                                <button type="button" class="btn btn--secondary" @click="confirmingExtension = null">{{ $canWrite ? 'Cancel' : 'Close' }}</button>
                                @if ($canWrite)
                                    <button type="submit" class="btn btn--default" :disabled="! confirmingExtension.status || ! confirmingExtension.note.trim()">Save</button>
                                @endif
                            </div>
                        </form>
                    </div>
                </div>
            </template>
        </div>

        {{-- Notice-served flag dialog. Same shape as the Extension dialog. --}}
        <div x-show="confirmingNotice !== null" x-cloak role="dialog" aria-modal="true" aria-labelledby="confirm-notice-title">
            <div class="dialog__overlay" @click="confirmingNotice = null" aria-hidden="true"></div>
            <template x-if="confirmingNotice !== null">
                <div class="dialog__content">
                    <div>
                        <h2 class="dialog__title" id="confirm-notice-title">Notice served</h2>
                        <p class="dialog__description">
                            <span x-text="confirmingNotice.contract_number"></span>
                            ·
                            <span x-text="confirmingNotice.route"></span>
                        </p>

                        @php $canWrite = auth()->user()->canWrite() && ! $showArchived; @endphp
                        <form method="POST"
                              :action="`{{ url('contracts') }}/${confirmingNotice.contract_id}/notice-served`"
                              enctype="multipart/form-data"
                              @submit="if (! confirmingNotice.status || ! confirmingNotice.note.trim()) { $event.preventDefault(); }">
                            @csrf
                            @method('PATCH')

                            <div class="dialog__body">
                                <div class="field">
                                    <span class="label">Has notice been served?</span>
                                    <div class="kind-row">
                                        <label class="kind-row__option" :class="{ 'is-selected': confirmingNotice.status === 'yes' }">
                                            <input type="radio" name="status" value="yes" x-model="confirmingNotice.status" @required($canWrite) @disabled(! $canWrite)>
                                            <span class="kind-row__body">
                                                <span class="kind-row__title">Yes</span>
                                                <span class="kind-row__hint">Break notice has been issued.</span>
                                            </span>
                                        </label>
                                        <label class="kind-row__option" :class="{ 'is-selected': confirmingNotice.status === 'no' }">
                                            <input type="radio" name="status" value="no" x-model="confirmingNotice.status" @required($canWrite) @disabled(! $canWrite)>
                                            <span class="kind-row__body">
                                                <span class="kind-row__title">No</span>
                                                <span class="kind-row__hint">No notice issued (yet).</span>
                                            </span>
                                        </label>
                                    </div>
                                </div>

                                <div class="field">
                                    <label class="label" for="confirm-notice-note">Note</label>
                                    <textarea id="confirm-notice-note" name="note" rows="3" maxlength="500" class="textarea" x-model="confirmingNotice.note" placeholder="Reason / context — saved with the contract and recorded in the audit log." @required($canWrite) @readonly(! $canWrite)></textarea>
                                </div>

                                @include('partials.existing-attachments', ['stateVar' => 'confirmingNotice.attachments'])
                                @if ($canWrite)
                                    @include('partials.attachment-field', ['fieldId' => 'confirm-notice-attachment'])
                                @endif
                            </div>

                            <div class="dialog__footer">
                                <button type="button" class="btn btn--secondary" @click="confirmingNotice = null">{{ $canWrite ? 'Cancel' : 'Close' }}</button>
                                @if ($canWrite)
                                    <button type="submit" class="btn btn--default" :disabled="! confirmingNotice.status || ! confirmingNotice.note.trim()">Save</button>
                                @endif
                            </div>
                        </form>
                    </div>
                </div>
            </template>
        </div>

        {{-- Tender-award dialog. Date + free-text note + attachment upload.
             Note and attachment are optional. Same audit / attachment shape
             as the flag dialogs above. --}}
        <div x-show="confirmingTender !== null" x-cloak role="dialog" aria-modal="true" aria-labelledby="confirm-tender-title">
            <div class="dialog__overlay" @click="confirmingTender = null" aria-hidden="true"></div>
            <template x-if="confirmingTender !== null">
                <div class="dialog__content">
                    <div>
                        <h2 class="dialog__title" id="confirm-tender-title">Tender award</h2>
                        <p class="dialog__description">
                            <span x-text="confirmingTender.contract_number"></span>
                            ·
                            <span x-text="confirmingTender.route"></span>
                        </p>

                        @php $canWrite = auth()->user()->canWrite() && ! $showArchived; @endphp
                        <form method="POST"
                              :action="`{{ url('contracts') }}/${confirmingTender.contract_id}/tender-award`"
                              enctype="multipart/form-data">
                            @csrf
                            @method('PATCH')

                            <div class="dialog__body">
                                <div class="field">
                                    <label class="label" for="confirm-tender-note">Tender award @if ($canWrite)<span class="is-soft">(optional)</span>@endif</label>
                                    <input id="confirm-tender-note" type="text" name="note" maxlength="500" class="input" x-model="confirmingTender.note" placeholder="e.g. Option A" @readonly(! $canWrite)>
                                    <span class="field__hint">Free-text label for what the contract was awarded as. Recorded in the audit log.</span>
                                </div>

                                @include('partials.existing-attachments', ['stateVar' => 'confirmingTender.attachments'])
                                @if ($canWrite)
                                    @include('partials.attachment-field', ['fieldId' => 'confirm-tender-attachment'])
                                @endif
                            </div>

                            <div class="dialog__footer">
                                <button type="button" class="btn btn--secondary" @click="confirmingTender = null">{{ $canWrite ? 'Cancel' : 'Close' }}</button>
                                @if ($canWrite)
                                    <button type="submit" class="btn btn--default">Save</button>
                                @endif
                            </div>
                        </form>
                    </div>
                </div>
            </template>
        </div>
    </div>
</x-app-layout>
