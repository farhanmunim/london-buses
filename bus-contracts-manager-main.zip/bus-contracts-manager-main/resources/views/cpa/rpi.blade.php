<x-app-layout :crumb="'Indices / RPI'">
    @php
        $hasAddErrors = $errors->hasAny(['month', 'rpi_index']);
        $hasImportErrors = $errors->has('csv') || session()->has('importErrors');
    @endphp
    <div x-data="{ showAddModal: {{ $hasAddErrors ? 'true' : 'false' }}, showImportModal: {{ $hasImportErrors ? 'true' : 'false' }}, editing: null }">
        <div class="page__header">
            <div>
                <h1 class="page__title">Indices</h1>
                <div class="page__subtitle">Raw <a href="https://www.ons.gov.uk/economy/inflationandpriceindices/datasets/consumerpriceinflation" target="_blank" rel="noopener" class="link">ONS Retail Prices Index</a> (CHAW, base Jan 1987 = 100). RPI is tracked alongside CPI but doesn't feed CPA derivation.</div>
                @if (auth()->user()?->canWrite())
                    <div class="page__subtitle page__subtitle--note text-soft">
                        <strong>Refresh behaviour:</strong> manual <em>overrides</em> are preserved untouched · manual <em>imports</em> and ONS-feed rows are aligned to the live ONS series.
                    </div>
                @endif
            </div>
            <div class="page__actions">
                <a href="{{ route('indices.rpi.export') }}" class="btn btn--secondary" download data-tooltip="Download as CSV" data-tooltip-side="bottom">
                    <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    Export
                </a>
                @if (auth()->user()?->canWrite())
                    <button type="button" class="btn btn--secondary" @click="showImportModal = true" data-tooltip="Bulk import from CSV" data-tooltip-side="bottom">
                        <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        Import
                    </button>
                    <button type="button" class="btn btn--default" @click="showAddModal = true">
                        <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                        Add month
                    </button>
                @endif
            </div>
        </div>

        @if (session('status'))
            <div class="alert alert--success" role="status">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5"/></svg>
                {{ session('status') }}
            </div>
        @endif

        @if (session('updateError'))
            <div class="alert alert--destructive" role="alert">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                {{ session('updateError') }}
            </div>
        @endif

        @if (session('importErrors'))
            <div class="alert alert--destructive" role="alert">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                <div>
                    <strong>Some rows could not be imported:</strong>
                    <ul class="list--inline">
                        @foreach (session('importErrors') as $err)
                            <li>{{ $err }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>
        @endif

        <nav class="tabs" aria-label="Indices views">
            <a href="{{ route('indices.cpi') }}" class="tabs__item">CPI</a>
            <a href="{{ route('indices.cpa') }}" class="tabs__item">CPA</a>
            <a href="{{ route('indices.rpi') }}" class="tabs__item is-active" aria-current="page">RPI</a>
            <a href="{{ route('indices.cebr') }}" class="tabs__item">CEBR</a>
            <a href="{{ route('indices.derv') }}" class="tabs__item">DERV</a>
        </nav>

        @php
            $rawOverrideCount = $allEntries->where('is_actual', false)->count();
        @endphp

        @include('cpa.partials.filters', [
            'route' => 'indices.rpi',
            'totalCount' => $allEntries->count(),
            'overrideCount' => $rawOverrideCount,
            'filters' => $filters,
            'sourceCounts' => $sourceCounts,
        ])

        @php
            $bulkImportCount = $allEntries->where('source_original', 'manual_import')->count();
        @endphp
        @if (($rawOverrideCount > 0 || $bulkImportCount > 0) && auth()->user()?->canWrite())
            <div class="table-actions">
                @if ($rawOverrideCount > 0)
                    <form method="POST" action="{{ route('indices.rpi.clear-overrides') }}"
                          @submit="if (! confirm('Reset every manual RPI override to its ONS value?')) $event.preventDefault();">
                        @csrf
                        <button type="submit" class="btn btn--ghost btn--sm" data-tooltip="Reset all overrides">
                            <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 12a9 9 0 0 1 15.5-6.36L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.36L3 16"/><path d="M3 21v-5h5"/></svg>
                            Reset all to ONS ({{ $rawOverrideCount }})
                        </button>
                    </form>
                @endif
                @if ($bulkImportCount > 0)
                    <form method="POST" action="{{ route('indices.rpi.clear-imports') }}"
                          @submit="if (! confirm('Delete all manually-added RPI rows ({{ $bulkImportCount }})? ONS-feed rows are kept.')) $event.preventDefault();">
                        @csrf
                        <button type="submit" class="btn btn--ghost btn--sm" data-tooltip="Delete imported rows">
                            <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-2 14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L5 6"/></svg>
                            Delete manual imports ({{ $bulkImportCount }})
                        </button>
                    </form>
                @endif
            </div>
        @endif

        <div class="table-wrap">
            <div class="table-scroll">
                <table class="table">
                    <thead>
                        <tr class="table__header-row">
                            <th scope="col">Month</th>
                            <th scope="col" class="num">RPI</th>
                            <th scope="col" class="num">YoY Change</th>
                            <th scope="col">Source</th>
                            <th scope="col" class="num"><span class="sr-only">Actions</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($entries as $entry)
                            @php
                                $monthKey = \Carbon\Carbon::parse($entry->month)->format('Y-m');
                                $yoy = $yoyByMonth[$monthKey] ?? null;
                                $yoyPositive = $yoy !== null && (float) $yoy >= 0;
                                if (! $entry->is_actual) {
                                    [$sourceLabel, $sourceModifier] = ['Manual Override', 'badge--warning'];
                                } elseif (($entry->source ?? 'manual_import') === 'ons_feed') {
                                    [$sourceLabel, $sourceModifier] = ['ONS Actual', 'badge--success'];
                                } else {
                                    [$sourceLabel, $sourceModifier] = ['Manual Import', 'badge--info'];
                                }
                            @endphp
                            <tr>
                                <td>
                                    <span class="is-medium">{{ \Carbon\Carbon::parse($entry->month)->format('F Y') }}</span>
                                    <span class="id-token">{{ \Carbon\Carbon::parse($entry->month)->format('Y-m') }}</span>
                                </td>
                                <td class="num">
                                    {{ number_format((float) $entry->rpi_index, 1) }}
                                    @unless ($entry->is_actual)
                                        <span class="override-dot" data-tooltip="Manual override" aria-label="Manually overridden"></span>
                                    @endunless
                                </td>
                                <td class="num">
                                    @if ($yoy === null)
                                        <span class="text-soft">—</span>
                                    @else
                                        <span class="trend {{ $yoyPositive ? 'trend--up' : 'trend--down' }}">
                                            <span class="trend__indicator" aria-hidden="true">{{ $yoyPositive ? '▲' : '▼' }}</span>
                                            {{ number_format(abs((float) $yoy) * 100, 4) }}%
                                        </span>
                                    @endif
                                </td>
                                <td>
                                    <span class="badge {{ $sourceModifier }} badge--with-dot">{{ $sourceLabel }}</span>
                                </td>
                                <td class="num">
                                    @if (auth()->user()?->canWrite())
                                    <button type="button" class="row-action"
                                            aria-label="Edit {{ \Carbon\Carbon::parse($entry->month)->format('F Y') }}"
                                            data-tooltip="Edit"
                                            data-id="{{ $entry->id }}"
                                            data-can-delete="{{ ($entry->source_original ?? 'manual_import') !== 'ons_feed' ? '1' : '0' }}"
                                            data-is-override="{{ ! $entry->is_actual ? '1' : '0' }}"
                                            data-month-iso="{{ \Carbon\Carbon::parse($entry->month)->format('Y-m') }}"
                                            data-month-label="{{ \Carbon\Carbon::parse($entry->month)->format('F Y') }}"
                                            data-rpi="{{ number_format((float) $entry->rpi_index, 1, '.', '') }}"
                                            @click="editing = { id: $el.dataset.id, canDelete: $el.dataset.canDelete === '1', isOverride: $el.dataset.isOverride === '1', monthIso: $el.dataset.monthIso, monthLabel: $el.dataset.monthLabel, rpi_index: $el.dataset.rpi }">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                    </button>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="5" class="table-empty">No RPI values yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if ($entries->isNotEmpty())
                <div class="table-footer">
                    <div>{{ $entries->count() }} entries · Newest first</div>
                </div>
            @endif
        </div>

        <div x-show="editing !== null" x-cloak @keydown.escape.window="editing = null" role="dialog" aria-modal="true" aria-labelledby="edit-rpi-title">
            <div class="dialog__overlay" @click="editing = null" aria-hidden="true"></div>
            <template x-if="editing !== null">
                <div class="dialog__content">
                    <h2 class="dialog__title" id="edit-rpi-title">Edit RPI</h2>
                    <p class="dialog__description" x-text="editing.monthLabel"></p>

                    <form id="rpi-edit-form" method="POST" :action="`/indices/rpi/entries/${editing.id}`"
                          @submit="if (! confirm(`Save the new RPI value for ${editing.monthLabel}?`)) $event.preventDefault();">
                        @csrf
                        @method('PATCH')
                        <div class="dialog__body">
                            <template x-if="editing.canDelete">
                                <div class="field">
                                    <label class="label">Month</label>
                                    <x-month-picker name="month" :value="null" required x-model="editing.monthIso" />
                                    <span class="field__hint">You can move this entry to a different month. ONS-feed entries are locked.</span>
                                </div>
                            </template>
                            <div class="field">
                                <label class="label" for="rpi-index">RPI</label>
                                <input id="rpi-index" type="text" class="input" name="rpi_index" :value="editing.rpi_index" pattern="\d+\.\d" required inputmode="decimal" x-data="oneDecimalInput" @input="sanitize($event)" @blur="pad($event)">
                            </div>
                            <div class="field">
                                <label class="label" for="rpi-note">Note <span class="is-soft">(optional)</span></label>
                                <textarea id="rpi-note" name="override_note" rows="2" class="textarea" placeholder="Reason for this change"></textarea>
                            </div>
                        </div>
                    </form>

                    <div class="dialog__footer dialog__footer--split">
                        <div class="flex gap-2">
                            <template x-if="editing.isOverride">
                                <form method="POST" :action="`/indices/rpi/entries/${editing.id}/reset`" @submit="if (! confirm('Reset this month to its original ONS value?')) $event.preventDefault();">
                                    @csrf
                                    <button type="submit" class="btn btn--ghost btn--sm">
                                        <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 12a9 9 0 0 1 15.5-6.36L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.36L3 16"/><path d="M3 21v-5h5"/></svg>
                                        Reset to ONS
                                    </button>
                                </form>
                            </template>
                            <template x-if="editing.canDelete">
                                <form method="POST" :action="`/indices/rpi/entries/${editing.id}`" @submit="if (! confirm(`Permanently delete ${editing.monthLabel}? The RPI value for this month will be removed.`)) $event.preventDefault();">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn--ghost btn--sm text-destructive">
                                        <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-2 14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
                                        Delete
                                    </button>
                                </form>
                            </template>
                        </div>
                        <div class="dialog__actions">
                            <button type="button" class="btn btn--secondary" @click="editing = null">Cancel</button>
                            <button type="submit" form="rpi-edit-form" class="btn btn--default">Save</button>
                        </div>
                    </div>
                </div>
            </template>
        </div>

        @include('cpa.partials.add-month-modal', [
            'storeRoute' => 'indices.rpi.store',
            'indexLabel' => 'RPI',
            'fieldName' => 'rpi_index',
            'placeholder' => 'e.g. 411.4',
            'followUpHint' => '',
        ])
        @include('cpa.partials.import-modal', [
            'importRoute' => 'indices.rpi.import',
            'templateRoute' => 'indices.rpi.import-template',
            'indexLabel' => 'RPI',
            'fieldName' => 'rpi_index',
            'followUpHint' => '',
        ])
    </div>
</x-app-layout>
