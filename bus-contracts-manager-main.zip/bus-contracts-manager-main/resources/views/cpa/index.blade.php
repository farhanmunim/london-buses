<x-app-layout :crumb="'Indices / CPA'">
    @php
        $hasAddErrors = ($errors->hasAny(['month', 'cpi_index']) && ! $errors->hasAny(['p2p_override', 'ra_override']));
        $hasImportErrors = $errors->has('csv') || session()->has('importErrors');
    @endphp
    <div x-data="{ showAddModal: {{ $hasAddErrors ? 'true' : 'false' }}, showImportModal: {{ $hasImportErrors ? 'true' : 'false' }}, editing: null }">
        <div class="page__header">
            <div>
                <h1 class="page__title">Indices</h1>
                <div class="page__subtitle">Consumer Price Adjustment (CPA) rates derived from the <a href="https://www.ons.gov.uk/economy/inflationandpriceindices/datasets/consumerpriceinflation" target="_blank" rel="noopener" class="link">ONS CPI All Items Index</a> (D7BT, base 2015 = 100).</div>
                @if (auth()->user()?->canWrite())
                    <div class="page__subtitle page__subtitle--note text-soft">
                        <strong>Refresh behaviour:</strong> CPA rates re-derive from CPI on every refresh · manual P2P / RA <em>overrides</em> on the CPA tab are preserved untouched.
                    </div>
                @endif
            </div>
            <div class="page__actions">
                <a href="{{ route('indices.export') }}" class="btn btn--secondary" download data-tooltip="Download as CSV" data-tooltip-side="bottom">
                    <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    Export
                </a>
                @if (auth()->user()?->canWrite())
                    <button type="button" class="btn btn--secondary" @click="showImportModal = true" data-tooltip="Bulk import from CSV" data-tooltip-side="bottom">
                        <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        Import
                    </button>
                    <button type="button" class="btn btn--default" @click="showAddModal = true">
                        <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                        Add month
                    </button>
                @endif
            </div>
        </div>

        @if (session('status'))
            <div class="alert alert--success" role="status">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5"/></svg>
                {{ session('status') }}
            </div>
        @endif

        @if (session('updateError'))
            <div class="alert alert--destructive" role="alert">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                {{ session('updateError') }}
            </div>
        @endif

        @if (session('importErrors'))
            <div class="alert alert--destructive" role="alert">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                <div>
                    <strong>Some rows could not be imported:</strong>
                    <ul class="list--inline">
                        @foreach (session('importErrors') as $err)
                            <li>{{ $err }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>
        @endif

        @php
            $latest = $rows->first();
            $previous = $rows->skip(1)->first();
            $latestEffectiveP2p = $latest ? ($latest->p2p_override ?? $latest->p2p_rate) : null;
            $latestEffectiveRa = $latest ? ($latest->ra_override ?? $latest->ra_rate) : null;
            $cpiDelta = ($latest && $previous) ? ((float) $latest->cpi_index - (float) $previous->cpi_index) : null;
        @endphp

        @if ($latest)
            <div class="stats">
                <div class="stat">
                    <div class="stat__label">CPI</div>
                    <div class="stat__value">
                        {{ number_format((float) $latest->cpi_index, 1) }}
                    </div>
                    <div class="stat__meta">
                        @if ($cpiDelta !== null)
                            <span class="{{ $cpiDelta < 0 ? 'stat__delta--down' : 'stat__delta--up' }}">
                                {{ $cpiDelta >= 0 ? '+' : '' }}{{ number_format($cpiDelta, 1) }}
                            </span>
                            vs prior month
                        @else
                            {{ \Carbon\Carbon::parse($latest->month)->format('F Y') }}
                        @endif
                    </div>
                </div>

                <div class="stat">
                    <div class="stat__label">YoY Change</div>
                    <div class="stat__value">{{ number_format((float) $latest->yoy_change * 100, 4) }}%</div>
                    <div class="stat__meta">vs same month last year</div>
                </div>

                <div class="stat">
                    <div class="stat__label">
                        P2P
                        @if ($latest->p2p_override !== null)
                            <span class="dot dot--override" title="Manual override"></span>
                        @endif
                    </div>
                    <div class="stat__value">{{ number_format((float) $latestEffectiveP2p * 100, 4) }}%</div>
                    <div class="stat__meta">YoY × 0.85</div>
                </div>

                <div class="stat">
                    <div class="stat__label">
                        RA
                        @if ($latest->ra_override !== null)
                            <span class="dot dot--override" title="Manual override"></span>
                        @endif
                    </div>
                    <div class="stat__value {{ $latestEffectiveRa === null ? 'muted' : '' }}">
                        {{ $latestEffectiveRa === null ? '—' : number_format((float) $latestEffectiveRa * 100, 4) . '%' }}
                    </div>
                    <div class="stat__meta">12-month rolling × 0.85</div>
                </div>
            </div>
        @endif

        <nav class="tabs" aria-label="Indices views">
            <a href="{{ route('indices.cpi') }}" class="tabs__item">CPI</a>
            <a href="{{ route('indices.cpa') }}" class="tabs__item is-active" aria-current="page">CPA</a>
            <a href="{{ route('indices.rpi') }}" class="tabs__item">RPI</a>
            <a href="{{ route('indices.cebr') }}" class="tabs__item">CEBR</a>
            <a href="{{ route('indices.derv') }}" class="tabs__item">DERV</a>
        </nav>

        @php
            $rateOverrideCount = $allRows->filter(fn ($r) => $r->p2p_override !== null || $r->ra_override !== null || $r->is_override)->count();
            $cpiOverrideCount = $entriesByMonth->where('is_actual', false)->count();
            $totalOverrideCount = $rateOverrideCount + $cpiOverrideCount;
            $sourceCounts = ['ons_feed' => 0, 'manual_import' => 0, 'manual_override' => 0];
            foreach ($allRows as $r) {
                $entry = $entriesByMonth[\Carbon\Carbon::parse($r->month)->format('Y-m')] ?? null;
                $cpiOverridden = $entry && ! $entry->is_actual;
                $isOverride = $r->is_override || $cpiOverridden;
                $key = $isOverride ? 'manual_override' : (($entry?->source ?? 'manual_import') === 'ons_feed' ? 'ons_feed' : 'manual_import');
                $sourceCounts[$key]++;
            }
        @endphp

        @include('cpa.partials.filters', [
            'route' => 'indices.cpa',
            'totalCount' => $allRows->count(),
            'overrideCount' => $totalOverrideCount,
            'filters' => $filters,
            'sourceCounts' => $sourceCounts,
        ])

        @php
            // Count every override that affects the CPA-tab display: P2P/RA
            // overrides on cpa_rates AND CPI overrides on the underlying
            // cpi_index_entries (since CPA derivations cascade from CPI).
            $cpaRateOverrideCount = $allRows->filter(fn ($r) => $r->p2p_override !== null || $r->ra_override !== null || $r->is_override)->count();
            $linkedCpiOverrideCount = $entriesByMonth->where('is_actual', false)->count();
            $cpaCombinedOverrideCount = $cpaRateOverrideCount + $linkedCpiOverrideCount;
            // Manually-added CPI rows propagate to CPA, so the "Delete manual
            // imports" action on this tab points at the CPI endpoint.
            $linkedManualImportCount = $entriesByMonth->where('source_original', 'manual_import')->count();
        @endphp
        @if (($cpaCombinedOverrideCount > 0 || $linkedManualImportCount > 0) && auth()->user()?->canWrite())
            <div class="table-actions">
                @if ($cpaCombinedOverrideCount > 0)
                    <form method="POST" action="{{ route('indices.cpa.clear-overrides') }}"
                          @submit="if (! confirm('Reset every override on this view back to ONS values? Includes P2P/RA overrides and any CPI overrides that drove derivations.')) $event.preventDefault();">
                        @csrf
                        <button type="submit" class="btn btn--ghost btn--sm" data-tooltip="Reset all overrides">
                            <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 12a9 9 0 0 1 15.5-6.36L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.36L3 16"/><path d="M3 21v-5h5"/></svg>
                            Reset all to ONS ({{ $cpaCombinedOverrideCount }})
                        </button>
                    </form>
                @endif
                @if ($linkedManualImportCount > 0)
                    <form method="POST" action="{{ route('indices.cpi.clear-imports') }}"
                          @submit="if (! confirm('Delete all manually-added CPI rows ({{ $linkedManualImportCount }})? Their derived CPA rows are removed with them. ONS-feed data is kept.')) $event.preventDefault();">
                        @csrf
                        <button type="submit" class="btn btn--ghost btn--sm" data-tooltip="Delete imported rows">
                            <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-2 14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L5 6"/></svg>
                            Delete manual imports ({{ $linkedManualImportCount }})
                        </button>
                    </form>
                @endif
            </div>
        @endif

        <div class="table-wrap">
            <div class="table-scroll">
                <table class="table table--wide">
                    <thead>
                        <tr class="table__header-row">
                            <th scope="col">Month</th>
                            <th scope="col" class="num">CPI</th>
                            <th scope="col" class="num">YoY Change</th>
                            <th scope="col" class="num">P2P</th>
                            <th scope="col" class="num">RA</th>
                            <th scope="col">Source</th>
                            <th scope="col" class="num"><span class="sr-only">Actions</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($rows as $row)
                            @php
                                $monthKey = \Carbon\Carbon::parse($row->month)->format('Y-m');
                                $entry = $entriesByMonth[$monthKey] ?? null;
                                $cpiOverridden = $entry && ! $entry->is_actual;
                                $effectiveP2p = $row->p2p_override ?? $row->p2p_rate;
                                $effectiveRa = $row->ra_override ?? $row->ra_rate;
                                $isOverride = $row->is_override || $cpiOverridden;
                                $yoyPositive = (float) $row->yoy_change >= 0;
                                if ($isOverride) {
                                    [$sourceLabel, $sourceModifier] = ['Manual Override', 'badge--warning'];
                                } elseif (($entry?->source ?? 'manual_import') === 'ons_feed') {
                                    [$sourceLabel, $sourceModifier] = ['ONS Actual', 'badge--success'];
                                } else {
                                    [$sourceLabel, $sourceModifier] = ['Manual Import', 'badge--info'];
                                }
                            @endphp
                            <tr>
                                <td>
                                    <span class="is-medium">{{ \Carbon\Carbon::parse($row->month)->format('F Y') }}</span>
                                    <span class="id-token">{{ \Carbon\Carbon::parse($row->month)->format('Y-m') }}</span>
                                </td>
                                <td class="num">
                                    {{ number_format((float) $row->cpi_index, 1) }}
                                    @if ($cpiOverridden)
                                        <span class="override-dot" data-tooltip="Manual override" aria-label="Manually overridden"></span>
                                    @endif
                                </td>
                                <td class="num">
                                    <span class="trend {{ $yoyPositive ? 'trend--up' : 'trend--down' }}">
                                        <span class="trend__indicator">{{ $yoyPositive ? '▲' : '▼' }}</span>
                                        {{ number_format(abs((float) $row->yoy_change) * 100, 4) }}%
                                    </span>
                                </td>
                                <td class="num">
                                    {{ number_format((float) $effectiveP2p * 100, 4) }}%
                                    @if ($row->p2p_override !== null)
                                        <span class="override-dot" data-tooltip="Manual override" aria-label="Manually overridden"></span>
                                    @endif
                                </td>
                                <td class="num">
                                    @if ($effectiveRa === null)
                                        <span class="text-soft">—</span>
                                    @else
                                        {{ number_format((float) $effectiveRa * 100, 4) }}%
                                        @if ($row->ra_override !== null)
                                            <span class="override-dot" data-tooltip="Manual override" aria-label="Manually overridden"></span>
                                        @endif
                                    @endif
                                </td>
                                <td>
                                    <span class="badge {{ $sourceModifier }} badge--with-dot">{{ $sourceLabel }}</span>
                                </td>
                                @php
                                    $p2pPct = $row->p2p_override !== null ? rtrim(rtrim(number_format((float) $row->p2p_override * 100, 6, '.', ''), '0'), '.') : '';
                                    $raPct = $row->ra_override !== null ? rtrim(rtrim(number_format((float) $row->ra_override * 100, 6, '.', ''), '0'), '.') : '';
                                @endphp
                                <td class="num">
                                    @if (auth()->user()?->canWrite())
                                    <button type="button" class="row-action"
                                            aria-label="Edit {{ \Carbon\Carbon::parse($row->month)->format('F Y') }}"
                                            data-tooltip="Edit"
                                            data-id="{{ $row->id }}"
                                            data-cpi-entry-id="{{ $entry?->id ?? '' }}"
                                            data-can-delete="{{ ($entry?->source_original ?? 'manual_import') !== 'ons_feed' ? '1' : '0' }}"
                                            data-month-label="{{ \Carbon\Carbon::parse($row->month)->format('F Y') }}"
                                            data-cpi="{{ number_format((float) $row->cpi_index, 1, '.', '') }}"
                                            data-p2p-pct="{{ $p2pPct }}"
                                            data-ra-pct="{{ $raPct }}"
                                            @click="editing = { id: $el.dataset.id, cpiEntryId: $el.dataset.cpiEntryId, canDelete: $el.dataset.canDelete === '1', monthLabel: $el.dataset.monthLabel, cpi_index: $el.dataset.cpi, p2p_override_pct: $el.dataset.p2pPct, ra_override_pct: $el.dataset.raPct }">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                    </button>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="7" class="table-empty">No CPA rates yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if ($rows->isNotEmpty())
                <div class="table-footer">
                    <div>{{ $rows->count() }} months · Newest first</div>
                </div>
            @endif
        </div>

        @include('cpa.partials.add-month-modal')
        @include('cpa.partials.rate-import-modal')

        <!-- Edit Rate -->
        <div x-show="editing !== null" x-cloak @keydown.escape.window="editing = null" role="dialog" aria-modal="true" aria-labelledby="edit-rate-title">
            <div class="dialog__overlay" @click="editing = null" aria-hidden="true"></div>
            <template x-if="editing !== null">
                <div class="dialog__content">
                    <h2 class="dialog__title" id="edit-rate-title">Edit CPA</h2>
                    <p class="dialog__description" x-text="editing.monthLabel"></p>

                    <form id="cpa-edit-form" method="POST" :action="`/indices/cpa/${editing.id}`"
                          @submit="if (! confirm(`Save changes to ${editing.monthLabel}? Dependent CPA rates will be recalculated.`)) $event.preventDefault();">
                        @csrf
                        @method('PATCH')
                        <div class="dialog__body">
                            <div class="field">
                                <label class="label" for="edit-cpi">CPI</label>
                                <input id="edit-cpi" type="text" class="input" name="cpi_index" :value="editing.cpi_index" pattern="\d+\.\d" required inputmode="decimal" x-data="oneDecimalInput" @input="sanitize($event)" @blur="pad($event)">
                                <span class="field__hint">One decimal place, as published by ONS.</span>
                            </div>
                            <div class="field">
                                <label class="label" for="edit-p2p">P2P override <span class="is-soft">(optional)</span></label>
                                <input id="edit-p2p" type="text" class="input" name="p2p_override" :value="editing.p2p_override_pct ?? ''" placeholder="e.g. 2.5000" inputmode="decimal">
                                <span class="field__hint">Enter as a percentage, e.g. <span class="is-mono">2.5000</span> for 2.5000%.</span>
                            </div>
                            <div class="field">
                                <label class="label" for="edit-ra">RA override <span class="is-soft">(optional)</span></label>
                                <input id="edit-ra" type="text" class="input" name="ra_override" :value="editing.ra_override_pct ?? ''" placeholder="e.g. 3.0000" inputmode="decimal">
                                <span class="field__hint">Enter as a percentage, e.g. <span class="is-mono">3.0000</span> for 3.0000%.</span>
                            </div>
                            <div class="field">
                                <label class="label" for="edit-note">Note <span class="is-soft">(optional)</span></label>
                                <textarea id="edit-note" name="override_note" rows="2" class="textarea" placeholder="Reason for this change"></textarea>
                            </div>
                        </div>
                    </form>

                    <div class="dialog__footer dialog__footer--split">
                        <div class="flex gap-2">
                            <form method="POST" :action="`/indices/cpa/${editing.id}/reset`" @submit="if (! confirm('Reset this month to the original ONS values? Any overrides will be cleared.')) $event.preventDefault();">
                                @csrf
                                <button type="submit" class="btn btn--ghost btn--sm">
                                    <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 12a9 9 0 0 1 15.5-6.36L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.36L3 16"/><path d="M3 21v-5h5"/></svg>
                                    Reset to ONS
                                </button>
                            </form>
                            <template x-if="editing.canDelete">
                                <form method="POST" :action="`/indices/cpi/entries/${editing.cpiEntryId}`" @submit="if (! confirm(`Permanently delete ${editing.monthLabel}? The CPI value and any calculated rates for this month will be removed.`)) $event.preventDefault();">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn--ghost btn--sm text-destructive">
                                        <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-2 14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
                                        Delete
                                    </button>
                                </form>
                            </template>
                        </div>
                        <div class="dialog__actions">
                            <button type="button" class="btn btn--secondary" @click="editing = null">Cancel</button>
                            <button type="submit" form="cpa-edit-form" class="btn btn--default">Save</button>
                        </div>
                    </div>
                </div>
            </template>
        </div>
    </div>
</x-app-layout>
