<div x-show="showImportModal" x-cloak @keydown.escape.window="showImportModal = false" role="dialog" aria-modal="true" aria-labelledby="rate-import-title">
    <div class="dialog__overlay" @click="showImportModal = false" aria-hidden="true"></div>
    <div class="dialog__content" x-data="{ filename: '' }">
        <h2 class="dialog__title" id="rate-import-title">Import CPA overrides</h2>
        <p class="dialog__description">CSV with <span class="is-mono">month</span>, <span class="is-mono">p2p_rate</span>, <span class="is-mono">ra_rate</span> columns. Rates are entered as percentages (e.g. <span class="is-mono">2.7683</span> for 2.7683%). <a href="{{ route('indices.cpa.import-template') }}" download class="link">Download template</a>.</p>

        <form method="POST" action="{{ route('indices.cpa.import') }}" enctype="multipart/form-data"
              @submit="if (! confirm('Import this CSV? P2P and RA rate overrides will be applied to the listed months.')) $event.preventDefault();">
            @csrf
            <div class="dialog__body">
                <label for="csv" class="dropzone" :class="filename && 'dropzone--has-file'">
                    <input id="csv" name="csv" type="file" accept=".csv,text/csv" required class="sr-only" @change="filename = $event.target.files[0]?.name ?? ''">
                    <svg class="dropzone__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true">
                        <path d="M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4"/>
                        <polyline points="17 8 12 3 7 8"/>
                        <line x1="12" y1="3" x2="12" y2="15"/>
                    </svg>
                    <span class="dropzone__text" x-text="filename || 'Click to choose a CSV file'"></span>
                    <span class="dropzone__hint">Up to 2 MB</span>
                </label>
                <x-input-error :messages="$errors->get('csv')" />
            </div>
            <div class="dialog__footer">
                <button type="button" class="btn btn--secondary" @click="showImportModal = false">Cancel</button>
                <button type="submit" class="btn btn--default">Import</button>
            </div>
        </form>
    </div>
</div>
