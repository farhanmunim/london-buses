@php
    /**
     * Reused for both CPI and RPI tabs. Override these via @include args.
     *   importRoute   — route name for POST submit
     *   templateRoute — route name for the CSV template download
     *   indexLabel    — display label, e.g. 'CPI' or 'RPI'
     *   fieldName     — CSV column name shown in the description
     *   followUpHint  — sentence appended to the confirm dialog
     */
    $importRoute = $importRoute ?? 'indices.cpi.import';
    $templateRoute = $templateRoute ?? 'indices.cpi.import-template';
    $indexLabel = $indexLabel ?? 'CPI';
    $fieldName = $fieldName ?? 'cpi_index';
    $followUpHint = $followUpHint ?? ' Dependent CPA rates will be recalculated.';
@endphp

<div x-show="showImportModal" x-cloak @keydown.escape.window="showImportModal = false" role="dialog" aria-modal="true" aria-labelledby="import-title">
    <div class="dialog__overlay" @click="showImportModal = false" aria-hidden="true"></div>
    <div class="dialog__content" x-data="{ filename: '' }">
        <h2 class="dialog__title" id="import-title">Import {{ $indexLabel }} values</h2>
        <p class="dialog__description">CSV with <span class="is-mono">month</span>, <span class="is-mono">{{ $fieldName }}</span> columns. <a href="{{ route($templateRoute) }}" download class="link">Download template</a>.</p>

        <form method="POST" action="{{ route($importRoute) }}" enctype="multipart/form-data"
              @submit="if (! confirm('Import this CSV?{{ $followUpHint }}')) $event.preventDefault();">
            @csrf
            <div class="dialog__body">
                <label for="csv" class="dropzone" :class="filename && 'dropzone--has-file'">
                    <input id="csv" name="csv" type="file" accept=".csv,text/csv" required class="sr-only" @change="filename = $event.target.files[0]?.name ?? ''">
                    <svg class="dropzone__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true">
                        <path d="M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4"/>
                        <polyline points="17 8 12 3 7 8"/>
                        <line x1="12" y1="3" x2="12" y2="15"/>
                    </svg>
                    <span class="dropzone__text" x-text="filename || 'Click to choose a CSV file'"></span>
                    @php
                        $tplKb = \App\Models\AppSetting::templateMaxKb();
                        $tplLabel = $tplKb >= 1024 ? round($tplKb / 1024, 1).' MB' : $tplKb.' KB';
                    @endphp
                    <span class="dropzone__hint">Up to {{ $tplLabel }}</span>
                </label>
                <x-input-error :messages="$errors->get('csv')" />

                <label class="checkbox-row">
                    <input type="checkbox" name="replace_overrides" value="1">
                    <span>Replace manual overrides with imported values</span>
                </label>
            </div>
            <div class="dialog__footer">
                <button type="button" class="btn btn--secondary" @click="showImportModal = false">Cancel</button>
                <button type="submit" class="btn btn--default">Import</button>
            </div>
        </form>
    </div>
</div>
