@props([
    'route',
    'totalCount',
    'overrideCount',
    'filters',
    'sourceCounts' => [],
])

@php
    $f = $filters;
    $overridesActive = $f['overrides_only'];
    $sourceActive = ! empty($f['sources']);
    $dateActive = $f['from'] !== null || $f['to'] !== null;
    $allActive = ! $overridesActive && ! $sourceActive && ! $dateActive;
    $hasAnyFilter = $overridesActive || $sourceActive || $dateActive;

    $sourceLabels = [
        'ons_feed' => 'ONS Actual',
        'manual_import' => 'Manual Import',
        'manual_override' => 'Manual Override',
    ];

    $activeSourceLabel = match (count($f['sources'])) {
        0 => null,
        1 => $sourceLabels[$f['sources'][0]] ?? 'Source',
        default => count($f['sources']).' sources',
    };

    $activeDateLabel = null;
    if ($dateActive) {
        $fromLabel = $f['from'] ? \Carbon\Carbon::createFromFormat('Y-m', $f['from'])->format('M Y') : '…';
        $toLabel = $f['to'] ? \Carbon\Carbon::createFromFormat('Y-m', $f['to'])->format('M Y') : '…';
        $activeDateLabel = $fromLabel.' → '.$toLabel;
    }
@endphp

<div class="toolbar"
     x-data="{ open: null, sources: @js($f['sources']), from: @js($f['from']), to: @js($f['to']) }"
     @keydown.escape.window="open = null">
    <div class="toolbar__group">
        <a href="{{ route($route) }}"
           class="chip {{ $allActive ? 'is-active' : '' }}">
            All <span class="chip__count">{{ $totalCount }}</span>
        </a>
        <a href="{{ route($route, array_merge(request()->except(['overrides']), ['overrides' => 1])) }}"
           class="chip {{ $overridesActive ? 'is-active' : '' }}">
            Overrides <span class="chip__count">{{ $overrideCount }}</span>
        </a>
    </div>

    <div class="toolbar__group toolbar__group--offset">
        {{-- Source popover --}}
        <div class="filter-pop" @click.outside="if (open === 'source') open = null">
            <button type="button"
                    class="chip chip--outline {{ $sourceActive ? 'is-active' : '' }}"
                    aria-haspopup="true"
                    :aria-expanded="open === 'source'"
                    @click="open = open === 'source' ? null : 'source'">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
                Source
                @if ($activeSourceLabel)
                    <span class="chip__value">{{ $activeSourceLabel }}</span>
                @endif
                <svg class="chip__chev" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
            </button>

            <form x-show="open === 'source'" x-cloak x-transition.opacity.duration.100ms
                  method="GET" action="{{ route($route) }}"
                  class="filter-pop__menu">
                @foreach (request()->except(['sources']) as $key => $val)
                    @if (is_array($val))
                        @foreach ($val as $v)
                            <input type="hidden" name="{{ $key }}[]" value="{{ $v }}">
                        @endforeach
                    @else
                        <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                    @endif
                @endforeach
                <input type="hidden" :name="sources.length ? 'sources' : null" :value="sources.join(',')">

                <div class="filter-pop__title">Filter by source</div>

                @foreach ($sourceLabels as $key => $label)
                    <label class="filter-pop__option">
                        <input type="checkbox" value="{{ $key }}" x-model="sources">
                        <span class="filter-pop__option-label">
                            <span class="dot dot--{{ $key === 'ons_feed' ? 'success' : ($key === 'manual_override' ? 'warning' : 'info') }}" aria-hidden="true"></span>
                            {{ $label }}
                        </span>
                        <span class="filter-pop__option-count">{{ $sourceCounts[$key] ?? 0 }}</span>
                    </label>
                @endforeach

                <div class="filter-pop__footer">
                    @if ($sourceActive)
                        <a href="{{ route($route, request()->except(['sources'])) }}" class="btn btn--ghost btn--sm">Clear</a>
                    @else
                        <span></span>
                    @endif
                    <button type="submit" class="btn btn--default btn--sm">Apply</button>
                </div>
            </form>
        </div>

        {{-- Date range popover --}}
        <div class="filter-pop" @click.outside="if (open === 'date') open = null">
            <button type="button"
                    class="chip chip--outline {{ $dateActive ? 'is-active' : '' }}"
                    aria-haspopup="true"
                    :aria-expanded="open === 'date'"
                    @click="open = open === 'date' ? null : 'date'">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                Date range
                @if ($activeDateLabel)
                    <span class="chip__value">{{ $activeDateLabel }}</span>
                @endif
                <svg class="chip__chev" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
            </button>

            <form x-show="open === 'date'" x-cloak x-transition.opacity.duration.100ms
                  method="GET" action="{{ route($route) }}"
                  class="filter-pop__menu filter-pop__menu--date">
                @foreach (request()->except(['from', 'to']) as $key => $val)
                    @if (is_array($val))
                        @foreach ($val as $v)
                            <input type="hidden" name="{{ $key }}[]" value="{{ $v }}">
                        @endforeach
                    @else
                        <input type="hidden" name="{{ $key }}" value="{{ $val }}">
                    @endif
                @endforeach

                <div class="filter-pop__title">Filter by date</div>

                <div class="filter-pop__row">
                    <div class="field">
                        <label class="label" for="filter-from">From</label>
                        <x-month-picker id="filter-from" name="from" :value="$f['from']" placeholder="Any" />
                    </div>
                    <div class="field">
                        <label class="label" for="filter-to">To</label>
                        <x-month-picker id="filter-to" name="to" :value="$f['to']" placeholder="Any" />
                    </div>
                </div>

                <div class="filter-pop__footer">
                    @if ($dateActive)
                        <a href="{{ route($route, request()->except(['from', 'to'])) }}" class="btn btn--ghost btn--sm">Clear</a>
                    @else
                        <span></span>
                    @endif
                    <button type="submit" class="btn btn--default btn--sm">Apply</button>
                </div>
            </form>
        </div>

        @if ($hasAnyFilter)
            <a href="{{ route($route) }}" class="chip chip--ghost" title="Reset all filters">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                Reset
            </a>
        @endif
    </div>

    <div class="toolbar__spacer"></div>
</div>
