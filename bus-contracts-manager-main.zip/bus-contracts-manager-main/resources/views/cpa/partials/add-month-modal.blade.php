@php
    /**
     * Reused for both CPI and RPI tabs. Override these via @include args.
     *   storeRoute   — route name for POST submit (default: indices.cpi.store)
     *   indexLabel   — display label, e.g. 'CPI' or 'RPI'
     *   fieldName    — request field name, e.g. 'cpi_index' or 'rpi_index'
     *   placeholder  — sample value shown inside the input
     *   followUpHint — sentence appended to descriptions explaining downstream effect
     */
    $storeRoute = $storeRoute ?? 'indices.cpi.store';
    $indexLabel = $indexLabel ?? 'CPI';
    $fieldName = $fieldName ?? 'cpi_index';
    $placeholder = $placeholder ?? 'e.g. 141.0';
    $followUpHint = $followUpHint ?? ' Dependent CPA rates auto-calculate.';
@endphp

<div x-show="showAddModal" x-cloak @keydown.escape.window="showAddModal = false" role="dialog" aria-modal="true" aria-labelledby="add-month-title">
    <div class="dialog__overlay" @click="showAddModal = false" aria-hidden="true"></div>
    <div class="dialog__content">
        <h2 class="dialog__title" id="add-month-title">Add {{ $indexLabel }} value</h2>
        <p class="dialog__description">Enter the month and ONS-published {{ $indexLabel }} value.{{ $followUpHint }}</p>
        <form method="POST" action="{{ route($storeRoute) }}"
              @submit="if (! confirm('Add this {{ $indexLabel }} value?{{ $followUpHint }}')) $event.preventDefault();">
            @csrf
            <div class="dialog__body">
                <div class="field">
                    <x-input-label for="month" value="Month" />
                    <x-month-picker id="month" name="month" required />
                    <x-input-error :messages="$errors->get('month')" />
                </div>
                <div class="field">
                    <x-input-label :for="$fieldName" :value="$indexLabel" />
                    <x-text-input :id="$fieldName" type="text" :name="$fieldName" :placeholder="$placeholder" pattern="\d+\.\d" required inputmode="decimal" x-data="oneDecimalInput" @input="sanitize($event)" @blur="pad($event)" />
                    <span class="field__hint">Exactly one decimal place, as published by ONS.</span>
                    <x-input-error :messages="$errors->get($fieldName)" />
                </div>
            </div>
            <div class="dialog__footer">
                <button type="button" class="btn btn--secondary" @click="showAddModal = false">Cancel</button>
                <button type="submit" class="btn btn--default">Save</button>
            </div>
        </form>
    </div>
</div>
