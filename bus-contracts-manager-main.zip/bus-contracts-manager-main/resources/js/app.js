import './bootstrap';

import Alpine from 'alpinejs';

import { monthPicker } from './components/month-picker';
import { datePicker } from './components/date-picker';
import { yearPicker } from './components/year-picker';
import { initAuditSearch } from './components/audit-search';
import { initScrollToHash } from './components/scroll-to-hash';
import { initThemeToggle } from './components/theme-toggle';

window.Alpine = Alpine;

Alpine.data('monthPicker', monthPicker);
Alpine.data('datePicker', datePicker);
Alpine.data('yearPicker', yearPicker);

/**
 * Constrain an <input> to a single-decimal-place number (matches ONS
 * publication precision). On every input event the value is sanitised so
 * non-digits are stripped, only one decimal point is allowed, and the
 * fractional part is truncated to 1 digit. On blur a bare integer gets
 * `.0` appended so storage and validation never see "141" (only "141.0").
 */
Alpine.data('oneDecimalInput', () => ({
    sanitize(event) {
        const el = event.target;
        let v = el.value.replace(/[^\d.]/g, '');
        const dot = v.indexOf('.');
        if (dot !== -1) {
            // Keep first dot, drop any subsequent dots, truncate fraction to 1 digit.
            v = v.slice(0, dot + 1) + v.slice(dot + 1).replace(/\./g, '').slice(0, 1);
        }
        if (v !== el.value) {
            el.value = v;
        }
    },
    pad(event) {
        const el = event.target;
        if (/^\d+$/.test(el.value)) {
            el.value = el.value + '.0';
        } else if (/^\d+\.$/.test(el.value)) {
            el.value = el.value + '0';
        }
    },
}));

Alpine.start();

document.addEventListener('DOMContentLoaded', initAuditSearch);
document.addEventListener('DOMContentLoaded', initScrollToHash);
document.addEventListener('DOMContentLoaded', initThemeToggle);

/**
 * Auto-clear filters when a search input is emptied. Triggers on either
 * the native X clear button (`search` event) or manual deletion (`input`
 * event reaching empty), but only when the page actually loaded with a
 * non-empty value — so typing a fresh query and backspacing it doesn't
 * accidentally re-submit the form.
 */
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('input[type="search"]').forEach((input) => {
        const initialValue = input.value;
        if (initialValue === '' || ! input.form) {
            return;
        }

        const submitIfCleared = () => {
            if (input.value === '') {
                input.form.submit();
            }
        };

        input.addEventListener('search', submitIfCleared);
        input.addEventListener('input', submitIfCleared);
    });
});
