/**
 * Alpine.js date picker (full date — Y-m-d).
 *
 * Mirrors the look-and-feel of the month-picker, with a 7×6 day grid and
 * Mon-first weeks (UK convention). The hidden input bound to the picker's
 * `value` always stores `YYYY-MM-DD`; the trigger label shows `dd/mm/yyyy`
 * to match the rest of the app.
 */
const MONTH_LONG = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
];

export function datePicker({ initial = null, minYear = 1990, maxYear = 2100 } = {}) {
    const today = new Date();
    const initialParsed = parseValue(initial);
    const startYear = initialParsed ? initialParsed.year : today.getFullYear();
    const startMonth = initialParsed ? initialParsed.month : today.getMonth();

    return {
        open: false,
        value: initialParsed ? formatKey(initialParsed.year, initialParsed.month, initialParsed.day) : '',
        viewYear: clamp(startYear, minYear, maxYear),
        viewMonth: startMonth,
        minYear,
        maxYear,
        panelTop: 0,
        panelLeft: 0,

        init() {
            this.$watch('value', (next) => {
                const p = parseValue(next);
                if (p) {
                    this.viewYear = clamp(p.year, this.minYear, this.maxYear);
                    this.viewMonth = p.month;
                }
            });

            this._reposition = () => this.updatePanelPosition();
            this.$watch('open', (isOpen) => {
                if (isOpen) {
                    this.$nextTick(() => this.updatePanelPosition());
                    window.addEventListener('scroll', this._reposition, true);
                    window.addEventListener('resize', this._reposition);
                } else {
                    window.removeEventListener('scroll', this._reposition, true);
                    window.removeEventListener('resize', this._reposition);
                }
            });
        },

        updatePanelPosition() {
            const trigger = this.$refs.trigger;
            if (!trigger) return;
            const panel = this.$refs.panel;
            const r = trigger.getBoundingClientRect();
            const w = panel ? panel.offsetWidth : 280;
            const h = panel ? panel.offsetHeight : 340;
            let top = r.bottom + 6;
            let left = r.left;
            if (top + h > window.innerHeight - 8) {
                const flipped = r.top - 6 - h;
                if (flipped > 8) top = flipped;
            }
            if (left + w > window.innerWidth - 8) left = window.innerWidth - w - 8;
            if (left < 8) left = 8;
            this.panelTop = top;
            this.panelLeft = left;
        },

        get display() {
            const p = parseValue(this.value);
            return p ? `${pad(p.day)}/${pad(p.month + 1)}/${p.year}` : '';
        },

        get heading() {
            return `${MONTH_LONG[this.viewMonth]} ${this.viewYear}`;
        },

        /** 42 cells: leading days from previous month, current month, trailing from next. */
        get cells() {
            const firstOfMonth = new Date(this.viewYear, this.viewMonth, 1);
            // Mon-first: shift Sunday (0) to position 6.
            const startOffset = (firstOfMonth.getDay() + 6) % 7;
            const start = new Date(this.viewYear, this.viewMonth, 1 - startOffset);
            const todayIso = formatKey(today.getFullYear(), today.getMonth(), today.getDate());

            const cells = [];
            for (let i = 0; i < 42; i++) {
                const d = new Date(start);
                d.setDate(start.getDate() + i);
                const iso = formatKey(d.getFullYear(), d.getMonth(), d.getDate());
                cells.push({
                    day: d.getDate(),
                    iso,
                    inCurrentMonth: d.getMonth() === this.viewMonth,
                    isToday: iso === todayIso,
                });
            }
            return cells;
        },

        prevMonth() {
            if (this.viewMonth === 0) {
                if (this.viewYear <= this.minYear) return;
                this.viewYear--;
                this.viewMonth = 11;
            } else {
                this.viewMonth--;
            }
        },

        nextMonth() {
            if (this.viewMonth === 11) {
                if (this.viewYear >= this.maxYear) return;
                this.viewYear++;
                this.viewMonth = 0;
            } else {
                this.viewMonth++;
            }
        },

        select(iso) {
            this.value = iso;
            this.open = false;
        },

        clear() {
            this.value = '';
            this.open = false;
        },

        goToday() {
            this.viewYear = clamp(today.getFullYear(), this.minYear, this.maxYear);
            this.viewMonth = today.getMonth();
        },

        isSelected(iso) {
            return this.value === iso;
        },
    };
}

function parseValue(raw) {
    if (!raw || typeof raw !== 'string') return null;
    const m = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (!m) return null;
    return { year: parseInt(m[1], 10), month: parseInt(m[2], 10) - 1, day: parseInt(m[3], 10) };
}

function formatKey(year, month, day) {
    return `${year}-${pad(month + 1)}-${pad(day)}`;
}

function pad(n) {
    return String(n).padStart(2, '0');
}

function clamp(n, min, max) {
    return Math.min(Math.max(n, min), max);
}
