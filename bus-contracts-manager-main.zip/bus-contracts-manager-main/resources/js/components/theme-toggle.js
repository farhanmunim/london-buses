/**
 * Theme toggle. Two states only: light ↔ dark.
 *
 * Default (nothing in localStorage) is light. Clicking the button flips
 * to dark and persists; clicking again flips back to light and clears
 * the storage entry. The pre-paint inline script in the layout reads
 * localStorage and pins `data-theme` before <body> paints so there's no
 * flash-of-light when dark is the saved choice.
 */
const STORAGE_KEY = 'theme';

function currentTheme() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored === 'dark') return 'dark';
    } catch (e) { /* storage disabled — treat as light */ }
    return 'light';
}

function apply(theme) {
    const root = document.documentElement;
    if (theme === 'dark') {
        root.setAttribute('data-theme', 'dark');
        try { localStorage.setItem(STORAGE_KEY, 'dark'); } catch (e) {}
    } else {
        root.setAttribute('data-theme', 'light');
        try { localStorage.setItem(STORAGE_KEY, 'light'); } catch (e) {}
    }
}

function paintButton(btn) {
    const theme = currentTheme();
    const next = theme === 'dark' ? 'light' : 'dark';
    btn.dataset.themeEffective = theme;
    btn.setAttribute('aria-label', `Theme: ${theme}. Switch to ${next}.`);
}

export function initThemeToggle() {
    const btn = document.querySelector('[data-theme-toggle]');
    if (! btn) return;

    paintButton(btn);

    btn.addEventListener('click', () => {
        const next = currentTheme() === 'dark' ? 'light' : 'dark';
        apply(next);
        paintButton(btn);
    });
}
