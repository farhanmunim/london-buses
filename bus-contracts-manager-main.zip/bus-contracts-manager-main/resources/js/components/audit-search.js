/**
 * Live-search wiring for the Audit log table.
 *
 * The form already POSTs nowhere — the input lives inside a GET form whose
 * action is the audit-log index route. Instead of letting that form submit
 * (which would full-page reload, reset focus, and feel laggy), we intercept
 * input/Enter, fetch the same URL with `X-Live-Search: 1`, and swap just the
 * #audit-results inner HTML. Alpine state on the surrounding page (toolbar
 * popovers, viewing-detail toggle) is preserved.
 */

const DEBOUNCE_MS = 250;
const TARGET_ID = 'audit-results';
const FORM_SELECTOR = '[data-audit-search-form]';
const INPUT_SELECTOR = '[data-audit-search-input]';

let activeRequestId = 0;
let debounceTimer;
let abortController;

export function initAuditSearch() {
    const form = document.querySelector(FORM_SELECTOR);
    const input = document.querySelector(INPUT_SELECTOR);
    if (!form || !input) return;

    input.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => liveFetch(form), DEBOUNCE_MS);
    });

    input.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter') return;
        event.preventDefault();
        clearTimeout(debounceTimer);
        liveFetch(form);
    });

    // Pagination + filter chip clicks inside the results region also flow
    // through the live-fetch path so the page never reloads.
    document.getElementById(TARGET_ID)?.addEventListener('click', (event) => {
        const link = event.target.closest('a[href]');
        if (!link) return;
        if (link.target === '_blank' || link.hasAttribute('download')) return;
        event.preventDefault();
        liveFetchUrl(link.href);
    });

    // Browser back/forward — re-render to match the URL.
    window.addEventListener('popstate', () => {
        liveFetchUrl(window.location.href, { push: false });
    });
}

function liveFetch(form) {
    const params = new URLSearchParams(new FormData(form));
    const url = new URL(form.getAttribute('action'), window.location.origin);
    // Carry over any non-form params already in the URL (filter chips set via
    // the toolbar's other forms).
    const existing = new URL(window.location.href);
    existing.searchParams.forEach((value, key) => {
        if (!params.has(key)) params.append(key, value);
    });
    url.search = params.toString();
    liveFetchUrl(url.toString());
}

async function liveFetchUrl(url, { push = true } = {}) {
    const target = document.getElementById(TARGET_ID);
    if (!target) return;

    abortController?.abort();
    abortController = new AbortController();

    const requestId = ++activeRequestId;
    target.setAttribute('aria-busy', 'true');

    try {
        const response = await fetch(url, {
            headers: {
                'X-Live-Search': '1',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'text/html',
            },
            signal: abortController.signal,
        });

        if (requestId !== activeRequestId) return;

        if (!response.ok) {
            console.error('Audit live-search failed', response.status);
            return;
        }

        const html = await response.text();
        target.innerHTML = html;

        // Re-bind Alpine directives in the new fragment so the row-level
        // detail toggle keeps working.
        if (window.Alpine?.initTree) {
            window.Alpine.initTree(target);
        }

        if (push) {
            history.pushState({}, '', url);
        }
    } catch (error) {
        if (error.name !== 'AbortError') {
            console.error('Audit live-search error', error);
        }
    } finally {
        if (requestId === activeRequestId) {
            target.removeAttribute('aria-busy');
        }
    }
}
