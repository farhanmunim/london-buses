/**
 * Alpine.js year picker — a 12-year decade grid. Stores a 4-digit year as
 * the bound `value` (string). Used for the Contracts anchor year setting
 * where months/days don't carry meaning.
 */
export function yearPicker({ initial = null, minYear = 1990, maxYear = 2100 } = {}) {
    const today = new Date();
    const seedYear = initial && /^\d{4}$/.test(initial) ? parseInt(initial, 10) : today.getFullYear();

    return {
        open: false,
        value: initial && /^\d{4}$/.test(initial) ? initial : '',
        // Top-left of the displayed 12-year window (multiples of 12, anchored
        // so the decade containing the selected year is centred-ish).
        windowStart: clamp(Math.floor(seedYear / 12) * 12, minYear, maxYear - 11),
        minYear,
        maxYear,
        panelTop: 0,
        panelLeft: 0,

        init() {
            this.$watch('value', (next) => {
                if (next && /^\d{4}$/.test(next)) {
                    const y = parseInt(next, 10);
                    this.windowStart = clamp(Math.floor(y / 12) * 12, this.minYear, this.maxYear - 11);
                }
            });

            this._reposition = () => this.updatePanelPosition();
            this.$watch('open', (isOpen) => {
                if (isOpen) {
                    this.$nextTick(() => this.updatePanelPosition());
                    window.addEventListener('scroll', this._reposition, true);
                    window.addEventListener('resize', this._reposition);
                } else {
                    window.removeEventListener('scroll', this._reposition, true);
                    window.removeEventListener('resize', this._reposition);
                }
            });
        },

        updatePanelPosition() {
            const trigger = this.$refs.trigger;
            if (!trigger) return;
            const panel = this.$refs.panel;
            const r = trigger.getBoundingClientRect();
            const w = panel ? panel.offsetWidth : 280;
            const h = panel ? panel.offsetHeight : 280;
            let top = r.bottom + 6;
            let left = r.left;
            if (top + h > window.innerHeight - 8) {
                const flipped = r.top - 6 - h;
                if (flipped > 8) top = flipped;
            }
            if (left + w > window.innerWidth - 8) left = window.innerWidth - w - 8;
            if (left < 8) left = 8;
            this.panelTop = top;
            this.panelLeft = left;
        },

        get display() {
            return this.value;
        },

        get heading() {
            return `${this.windowStart} – ${this.windowStart + 11}`;
        },

        get years() {
            const out = [];
            for (let i = 0; i < 12; i++) {
                out.push(this.windowStart + i);
            }
            return out;
        },

        prevWindow() {
            this.windowStart = Math.max(this.minYear, this.windowStart - 12);
        },

        nextWindow() {
            this.windowStart = Math.min(this.maxYear - 11, this.windowStart + 12);
        },

        select(year) {
            this.value = String(year);
            this.open = false;
        },

        clear() {
            this.value = '';
            this.open = false;
        },

        goToday() {
            const y = today.getFullYear();
            this.windowStart = clamp(Math.floor(y / 12) * 12, this.minYear, this.maxYear - 11);
        },

        isSelected(year) {
            return this.value === String(year);
        },

        isCurrent(year) {
            return year === today.getFullYear() && !this.isSelected(year);
        },
    };
}

function clamp(n, min, max) {
    return Math.min(Math.max(n, min), max);
}
