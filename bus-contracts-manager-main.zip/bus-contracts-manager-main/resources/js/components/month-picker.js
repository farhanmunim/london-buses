/**
 * Alpine.js month picker.
 *
 * `value` is the canonical YYYY-MM string bound to the underlying hidden input.
 * `viewYear` is the year currently shown in the panel — independent of the
 * selected value so users can browse without committing.
 */
const MONTH_LABELS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTH_LONG = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

export function monthPicker({ initial = null, minYear = 1990, maxYear = 2050 } = {}) {
    const today = new Date();
    const todayKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;

    const parsed = parseValue(initial);
    const startYear = parsed ? parsed.year : today.getFullYear();

    return {
        open: false,
        value: parsed ? formatKey(parsed.year, parsed.month) : '',
        viewYear: clamp(startYear, minYear, maxYear),
        months: MONTH_LABELS,
        minYear,
        maxYear,

        init() {
            // Track external value changes (e.g. via x-model) and follow the
            // selected year in the picker view.
            this.$watch('value', (next) => {
                const p = parseValue(next);
                if (p) this.viewYear = clamp(p.year, this.minYear, this.maxYear);
            });
        },

        get display() {
            const p = parseValue(this.value);
            return p ? `${MONTH_LONG[p.month]} ${p.year}` : '';
        },

        isSelected(monthIdx) {
            const p = parseValue(this.value);
            return !!p && p.year === this.viewYear && p.month === monthIdx;
        },

        isCurrent(monthIdx) {
            return formatKey(this.viewYear, monthIdx) === todayKey && !this.isSelected(monthIdx);
        },

        select(monthIdx) {
            this.value = formatKey(this.viewYear, monthIdx);
            this.open = false;
        },

        clear() {
            this.value = '';
            this.open = false;
        },

        goToday() {
            this.viewYear = clamp(today.getFullYear(), this.minYear, this.maxYear);
        },
    };
}

function parseValue(raw) {
    if (!raw || typeof raw !== 'string') return null;
    const m = raw.match(/^(\d{4})-(\d{2})/);
    if (!m) return null;
    const year = parseInt(m[1], 10);
    const month = parseInt(m[2], 10) - 1;
    if (month < 0 || month > 11) return null;
    return { year, month };
}

function formatKey(year, monthIdx) {
    return `${year}-${String(monthIdx + 1).padStart(2, '0')}`;
}

function clamp(n, min, max) {
    return Math.min(Math.max(n, min), max);
}
