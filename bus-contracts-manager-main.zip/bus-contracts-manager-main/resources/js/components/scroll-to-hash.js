/**
 * After a contract write the controller redirects to
 * /contracts#contract-{id}. The browser already handles fragment scrolling,
 * but the contracts table has a sticky thead and frozen left columns, so
 * the default jump puts the row underneath the header. This module:
 *
 *  - waits for layout (the table renders before fonts/images settle),
 *  - smooth-scrolls the matching <tr> into view with a generous block
 *    margin so the sticky thead doesn't cover it,
 *  - flashes a brief highlight so the user can spot the row that just changed.
 *
 * The highlight class is removed via animationend so the row returns to its
 * normal state without leaving stale DOM.
 */
export function initScrollToHash() {
    if (! window.location.hash) {
        return;
    }

    const id = window.location.hash.slice(1);
    if (! /^contract-\d+$/.test(id)) {
        return;
    }

    // Defer past the initial paint so frozen-pane offsets settle first.
    requestAnimationFrame(() => {
        const row = document.getElementById(id);
        if (! row) {
            return;
        }

        row.scrollIntoView({ behavior: 'smooth', block: 'center' });
        row.classList.add('row-flash');
        row.addEventListener('animationend', () => row.classList.remove('row-flash'), { once: true });
    });
}
