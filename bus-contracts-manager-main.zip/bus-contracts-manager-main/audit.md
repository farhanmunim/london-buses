# Full Project Audit & Production Readiness Prompt

You are acting as a senior staff-level web engineer, frontend architect, backend engineer, UI/UX designer, QA engineer, security reviewer, and DevOps engineer.

Your task is to fully audit, improve, fix, standardise, optimise, and productionise this entire project.

You must treat this as a real-world production audit for a live commercial platform.

You are expected to actively improve the project — not just provide feedback.

---

# Primary Goal

The entire application must feel:

- production ready
- visually cohesive
- highly polished
- responsive
- accessible
- maintainable
- scalable
- secure
- performant
- reliable
- intuitive

Every part of the project should feel intentional, consistent, and professionally engineered.

---

# General Behaviour Rules

- Work autonomously
- Continue iterating until the project reaches a high production standard
- Do not stop after identifying issues
- Implement improvements directly where appropriate
- Avoid superficial feedback
- Think holistically across the entire system
- Prioritise maintainability and consistency
- Prefer simple native solutions over unnecessary complexity
- Do not overengineer
- Keep implementations clean and scalable

---

# Full UI / Design System Audit

Audit and standardise the entire visual system.

Ensure consistency across:

- typography
- font sizing
- font weights
- line heights
- spacing
- margins
- padding
- layout rhythm
- colour palette
- contrast
- border radius
- shadows
- outlines
- transitions
- animations
- icon sizing
- hover states
- focus states
- active states
- disabled states
- button styling
- pill/tag styling
- cards
- dialogs
- tables
- forms
- dropdowns
- navigation
- badges
- alerts
- skeleton loaders
- loading indicators
- empty states
- toasts
- tooltips
- drawers
- sidebars
- tabs
- repeated layouts
- repeated components

Repeated UI patterns must share identical styling and behavioural consistency.

## User Feedback, Messaging & Communication Audit

Audit all user-facing feedback, messaging, confirmations, warnings, validation states, and system responses throughout the application.

Every user interaction must provide clear, immediate, non-technical, and context-appropriate feedback.

Verify:

- successful actions provide clear confirmation feedback
- failed actions provide clear and actionable feedback
- validation errors explain exactly what needs fixing
- upload failures explain why the upload failed
- successful uploads confirm completion clearly
- long-running actions communicate progress appropriately
- retry states are understandable
- destructive actions clearly explain consequences
- inline password reconfirmation failures explain the issue safely
- authentication failures remain secure but understandable
- permission-denied messaging remains clear without leaking sensitive information
- timeout/session-expiry messaging is understandable
- system errors avoid technical jargon where possible
- empty states guide the user helpfully
- warning states feel intentional rather than alarming
- success messaging remains concise and consistent
- feedback timing feels responsive and reliable

### Validation & Error Message Quality

Audit all validation and error messaging.

Verify:

- messages are written in plain language
- messages explain what happened
- messages explain how to fix the issue
- messages avoid raw technical/server terminology
- messages avoid exposing stack traces or sensitive internals
- field-specific validation appears near the relevant field
- validation summaries are understandable
- duplicate/conflicting messages are avoided
- required-field messaging remains consistent
- upload validation errors remain understandable
- import validation errors identify the affected row/field clearly
- API failures surface user-friendly fallback messaging

### Sensitive Action Reconfirmation UX

Audit all high-security and destructive workflows requiring reconfirmation.

Verify:

- password reconfirmation UX remains consistent
- incorrect password feedback is clear but secure
- users understand why reconfirmation is required
- repeated failures are handled safely
- destructive confirmations remain understandable
- irreversible actions are clearly communicated
- accidental confirmation is difficult
- confirmation dialogs remain concise and readable

### Toasts, Alerts & Notification Behaviour

Verify:

- toast positioning remains consistent
- alerts use consistent styling and hierarchy
- notification severity levels remain understandable
- success/warning/error/info states are visually distinct
- notifications do not overwhelm the user
- duplicate notifications are avoided
- notifications dismiss appropriately
- persistent errors remain visible until resolved
- accessibility requirements for alerts/toasts are respected
- mobile responsiveness of notifications is correct

### Audit Feedback Visibility

Verify the UI communicates clearly when actions are successfully audited.

Where appropriate, confirm users understand:

- a change was recorded
- an attachment was versioned
- a replacement occurred
- an archive action completed
- a restore action completed
- imports partially succeeded or failed
- evidence history was preserved

Ensure audit-related feedback is useful and reassuring without exposing technical implementation details.

## Cross-System Consistency Audit

Audit the project holistically to ensure identical behaviours and logic remain consistent across all areas of the platform.

Verify:

- tables behave consistently throughout the application
- filters behave consistently throughout the application
- pagination behaves consistently throughout the application
- dialogs and modals behave consistently throughout the application
- validation patterns behave consistently throughout the application
- inline error handling behaves consistently throughout the application
- loading states behave consistently throughout the application
- save/cancel actions appear in predictable locations
- destructive actions appear in predictable locations
- confirmation patterns remain consistent
- audit log rendering remains consistent
- required-field indicators remain visually consistent
- optional-field indicators remain visually consistent
- upload workflows remain consistent
- attachment handling remains consistent
- role-restricted UI behaves consistently

Ensure users do not encounter different behaviour patterns for similar workflows in different areas of the system.

### Form Layout & Required Field Behaviour

Verify:

- required fields are clearly labelled visually
- required fields use consistent indicators throughout the application
- optional fields are explicitly marked where appropriate
- validation messaging is consistent and understandable
- inline validation positioning remains consistent
- forms clearly indicate why submission failed
- keyboard navigation through forms is logical
- required amendment/change-note fields are positioned intentionally near final submission actions
- amendment reasoning fields appear directly above the save/update button where appropriate
- users cannot accidentally bypass mandatory amendment notes
- save/update actions remain visually consistent across all forms
- field ordering follows logical workflows
- labels, placeholders, help text, and validation states remain cohesive

### Import vs Manual Entry Consistency

Verify imported data and manually entered data follow identical business rules.

Audit:

- required fields
- validation rules
- formatting rules
- sanitisation rules
- permission checks
- audit logging
- duplicate handling
- date handling
- numeric parsing
- enum handling
- attachment linking
- amendment requirements

Ensure imports cannot bypass validations or business rules enforced during manual entry.

### File Collision, Versioning & Canonical Attachment Audit

Fully test attachment handling where uploaded filenames already exist.

Verify and test all collision workflows including:

1. Link the record to the existing canonical file
2. Replace the existing canonical file
3. Keep both files using automatic versioning or timestamp renaming
4. Cancel/do nothing

Audit:

- how each workflow appears in the UI
- whether the workflows are understandable to operators
- whether accidental replacement is sufficiently protected
- whether naming/versioning conventions remain clean and predictable
- whether canonical file selection is obvious
- whether historical versions remain accessible
- whether replaced files remain recoverable
- whether records linked to previous versions remain stable
- whether attachment relationships update correctly
- whether storage duplication is intentional and efficient
- whether file hashes correctly distinguish true duplicates vs same-name files
- whether rollback/recovery is possible
- whether detached or replaced files remain auditable

Verify the audit log clearly records:

- file linked
- file replaced
- canonical version changed
- file detached
- duplicate preserved
- automatic rename/version applied
- affected records
- actor identity
- timestamps
- historical version lineage

Ensure the audit log remains readable and meaningful rather than overly technical.

### Validation Stress & Test Data Audit

Validation logic must be tested aggressively across the entire application.

Generate realistic and intentionally invalid test data covering:

- text fields
- date fields
- numeric fields
- currency fields
- percentage fields
- select fields
- enum fields
- nullable fields
- required fields
- conditional fields
- uploads
- CSV imports
- bulk actions
- attachment uploads
- duplicate records
- malformed data
- edge-case values
- extremely long values
- unicode/special characters
- formula-injection payloads
- invalid MIME types
- oversized uploads

Verify:

- validation errors are accurate
- validation messages remain user-friendly
- frontend and backend validation stay aligned
- imports reject invalid rows correctly
- partial-import behaviour is intentional and documented
- failed rows are clearly explained
- successful rows remain auditable
- validation edge cases cannot corrupt state
- malformed uploads fail safely
- APIs reject invalid payloads safely
- audit logs capture validation-sensitive changes correctly

Generate and use dedicated test files during auditing to verify import, upload, parsing, validation, replacement, and audit-log behaviour end-to-end.

Do not allow fragmented or slightly different versions of the same component design to exist.

Ensure the project follows a single unified design language throughout.

---

# Layout & Responsiveness Audit

Audit every page and component across:

- mobile
- tablet
- laptop
- desktop
- ultrawide

Ensure:

- no overflow issues
- no broken responsive layouts
- no clipped text
- no awkward wrapping
- no horizontal scrolling
- no inconsistent spacing
- no tiny touch targets
- no layout shifting
- no unstable rendering
- no viewport bugs

Layouts must adapt gracefully across all screen sizes.

Mobile usability is critical.

---

# UX & Product Polish Audit

Review all UX details and improve overall usability.

Audit:

- hierarchy
- readability
- clarity
- discoverability
- interaction feedback
- navigation flow
- empty states
- loading states
- refresh states
- retry states
- error handling
- success messaging
- disabled states
- hover feedback
- focus feedback
- animation smoothness
- perceived performance
- visual noise
- friction points

Review subtle quality-of-life improvements such as:

- timestamps
- status indicators
- refresh labels
- sync states
- connection states
- tooltips
- contextual guidance
- smart defaults
- visual feedback
- confirmation handling

Polish the project to feel like a mature SaaS application.

---

# Functional Audit

Fully test all functionality throughout the entire application.

Audit and verify:

- forms
- buttons
- dialogs
- modals
- drawers
- navigation
- routing
- filters
- sorting
- searching
- pagination
- uploads
- downloads
- API requests
- API responses
- async behaviour
- data rendering
- edge cases
- fallback states
- error states
- refresh flows
- session handling
- auth flows
- notifications

Identify and fix:

- console errors
- hydration issues
- stale state
- race conditions
- duplicated logic
- invalid assumptions
- dead code
- inconsistent behaviour
- state mismatches
- brittle patterns
- poor abstractions
- unreliable flows
- verify business rules behave identically across all duplicated workflows

No partially broken experiences should remain.

---

# Per-Section End-to-End Walkthrough

Walk every major section of the app as if you were a new operator
sitting down for the first time. Don't just look at code — exercise
each page through the UI in puppeteer (or equivalent) and verify
behaviour matches expectations.

For each section, run the full matrix of scenarios:

- **happy path** — the workflow as designed
- **error path** — validation failure, permission denied, missing data
- **empty state** — no records yet
- **edge state** — exactly one record, exactly the pagination boundary, max-rows
- **destructive path** — archive/delete + confirm (verify soft-delete behaviour and recoverability), replace + confirm, cancel out
- **cross-role view** — same page as superadmin, admin, and user

Sections to walk:

- Contracts (list, +Add, Edit, per-cell CPA/Extension/Notice/Tender dialogs, Import with confirmation modal, Export, filters, search, frozen-pane scrolling)
- Indices (CPI, CPA, RPI active; CEBR, DERV stubs) — list, manual override, bulk import, ONS refresh, clear-overrides, clear-imports
- Reports — existing + coming-soon stubs
- Audit log — filters, search-and-clear behaviour, expand/collapse, attachment lifecycle indicators (Attached / Modified / Detached), per-contract history filter, pagination
- Users — list, add, edit, delete, freeze/unfreeze, password reset, login-log history
- Settings → Data control — snapshot download, clear/delete audit log, delete all data, delete all attachments, upload-limit changes (every action with its inline-password reconfirm)
- Profile — name/email change, password change, account self-deletion
- Roadmap — items render correctly, statuses sort properly, area pills colour-coded

Each section walkthrough must end with a one-line "ready / partial / broken" verdict.

---

# Audit Log Coverage & Quality Audit

Audit logging is the project's source of truth for "what happened, when,
and by whom". Every write must produce a meaningful entry, and every
entry must read cleanly in the audit log UI.

**Coverage** — for every write path in the codebase, verify:

- An `AuditLog::create()` call exists for the action
- The action key maps to one of the three high-level statuses (Added / Modified / Deleted) via `AuditActions::all()[$key]['verb']`
- The `user_id` is the **actor** (not the target)
- The `entity_type` + `entity_id` reference the affected record
- The `note` field describes WHAT happened in plain English — not just an action key
- The `old_values` / `new_values` snapshots only the fields that actually changed (no `updated_at` noise)
- **Sensitive fields are never in old/new** — passwords, raw tokens, API keys, session ids must not appear in audit columns
- The audit row is written **inside the same transaction** as the underlying write, so a rollback also rolls back the audit
- For destructive actions, the `old_values` is captured **before** the row is gone

**Per-action-key sanity check** — open audit log v4 in puppeteer for a representative example of each action key:

- `contract_added`, `contract_overridden`, `contract_varied`, `contract_confirmed`, `contract_deleted`
- `contract_cpa_confirmed`, `contract_extension_set`, `contract_notice_served_set`, `contract_tender_award_set`
- `contract_evidence_attached`, `contract_evidence_detached`
- `contracts_imported` (bulk)
- `cpi_*` family, `cpa_*` family, `rpi_*` family
- `user_created`, `user_updated`, `user_deleted`, `user_password_reset`, `user_frozen`, `user_unfrozen`
- `all_overrides_cleared`, `all_imports_cleared`
- Any `settings.*` actions

For each, verify the audit row renders cleanly:

- Status badge correctly shows Added / Modified / Deleted (no "Undefined")
- Area pill correctly colour-coded
- Record column shows a meaningful identifier (contract number, month, user name) plus `[#id]`
- Note column carries useful summary, no leaked technical prefix like `[#42 QC...]`
- Expanded panel diff table shows only the changed fields, no noise (`attachable_key`, `attachment_link_id`, etc. should be folded into the Attachment row, not displayed as raw fields)
- Attachment lifecycle indicators (Attached / Modified / Detached) fire correctly even when the parent action isn't `contract_evidence_*` (e.g. an Override that replaces a file)

**Bulk actions** — verify these produce a single summary row, not N individual rows:

- CSV imports
- ONS feed refreshes
- Clear-all-overrides / clear-all-imports
- Delete-all-data (intentionally NOT audited per policy — verify the policy is correct and documented)

---

# Form & Input Validation Audit

For every form in the app, verify both layers:

- **Client-side**: HTML5 attributes (`required`, `type`, `maxlength`, `pattern`, `min`, `max`), inline error messages, useful placeholders, accessible labels, no silent failures
- **Server-side**: Form Request class used (not ad-hoc `$request->validate()` in controller bodies), validation rules match the migration column constraints, error messages user-friendly
- **Cross-field rules**: `end_date >= start_date`, `tender_award_date >= tender_date`, etc. — server enforces, client mirrors
- verify validation logic does not diverge between client-side and server-side implementations
- **Optional vs required fields** visually marked (red asterisk for required, "(optional)" for optional)
- **Inline password re-confirmation** required for sensitive admin actions and Settings → Data control
- **Confirmation prompts** for destructive UI actions (delete, replace, bulk import)

For every file-upload feature, verify:

- Extension whitelist enforced server-side (and matched client-side via `accept` attribute)
- Size limit enforced server-side (against the configured `imports.max_kb` / equivalent)
- MIME type check (don't trust filename alone)
- No path-traversal (`../` rejected in filenames)
- Formula-injection guard on CSV cells (`= + - @ \t \r` at start of cell)
- Duplicate-name detection with Replace / Keep both / Cancel UX
- Failed-upload state handled (network error, file too large, wrong type) with clear user feedback
- Successful upload produces an audit log entry with the correct attachment lifecycle indicator
- Attachment download links survive detach (soft-detach pattern)

---

# Supporting Evidence / Attachment System Audit

Fully audit all supporting evidence, document, media, and attachment handling systems.

Verify and test:

- file uploads
- file replacements
- attachment deletion
- drag and drop uploads
- upload validation
- file type restrictions
- file size restrictions
- upload progress states
- failed upload handling
- retry handling
- preview rendering
- attachment persistence
- attachment permissions
- attachment security
- storage handling
- attachment linking
- attachment metadata
- evidence history tracking
- record update tracking
- audit logging
- timestamp recording
- version history
- change history
- update feeds
- activity logs

Ensure uploaded evidence and related records remain:

- correctly linked
- properly versioned
- securely stored
- accurately timestamped
- reliably retrievable

Ensure all update processes are stable and auditable.

---

# User Roles, Permissions & Access Control Audit

Fully audit the entire authentication and authorisation system.

Verify all roles, restrictions, and capabilities.

Audit:

- authentication flows
- login handling
- logout handling
- session expiry
- password handling
- route protection
- API protection
- middleware protection
- role-based rendering
- conditional UI visibility
- capability restrictions
- access boundaries
- admin permissions
- elevated access
- restricted actions
- secure defaults

Test every user role thoroughly.

Verify:

- users cannot access restricted pages
- users cannot access restricted APIs
- users cannot escalate privileges
- hidden UI is actually protected server-side
- permissions remain consistent across frontend and backend
- verify permission logic is not duplicated inconsistently across frontend/backend
- role changes propagate correctly
- restricted actions fail safely
- admin tooling is protected correctly

Audit all permission logic for security and consistency.

---

# Data Flow & Refreshing Audit

Audit all frontend and backend data handling systems.

Verify:

- cache handling
- invalidation logic
- refresh intervals
- stale data handling
- retry logic
- polling behaviour
- optimistic updates
- loading consistency
- background refreshes
- state synchronisation
- websocket handling
- realtime updates
- scheduled tasks
- cron behaviour

Ensure all data handling is reliable and predictable.

---

# GitHub Actions / DevOps Audit

Audit all CI/CD and automation workflows.

Review:

- GitHub Actions
- deployments
- scheduled jobs
- cron tasks
- environment variables
- secret handling
- build pipelines
- caching
- workflow efficiency
- failure handling
- deployment reliability
- rollback safety
- notifications
- logging

Ensure workflows are:

- secure
- minimal
- maintainable
- production ready
- reliable

Remove unnecessary complexity.

---

# Accessibility Audit

Ensure strong accessibility standards across the project.

Audit:

- semantic HTML
- aria labels
- keyboard navigation
- focus management
- colour contrast
- screen reader support
- accessible forms
- modal accessibility
- button accessibility
- reduced motion support
- touch accessibility

Accessibility should feel native to the product — not added afterwards.

---

# Performance Audit

Audit and optimise:

- bundle size
- rerenders
- unnecessary dependencies
- hydration cost
- lazy loading
- image optimisation
- code splitting
- caching
- expensive computations
- animation performance
- render blocking
- network usage

Optimise responsibly without overengineering.

---

# Code Quality Audit

Refactor weak implementations where necessary.

Prioritise:

- readability
- maintainability
- scalability
- consistency
- simplicity

Avoid:

- duplicated logic
- deeply nested code
- magic values
- inconsistent naming
- unnecessary abstractions
- bloated dependencies
- fragile patterns

Prefer clean and understandable code.

---

## Redundancy & Duplication Audit

Identify and eliminate unnecessary duplication across the entire codebase.

Audit for:

- duplicated business logic
- duplicated validation rules
- duplicated permission checks
- duplicated API handling
- duplicated database queries
- duplicated state logic
- duplicated UI components
- duplicated styling
- duplicated constants
- duplicated configuration
- duplicated form schemas
- duplicated transformation logic
- duplicated attachment handling
- duplicated audit logging logic
- duplicated role logic
- duplicated date formatting
- duplicated table rendering
- duplicated filtering/sorting logic
- duplicated error handling
- duplicated loading state logic
- duplicated responsive layout logic

Verify:

- shared logic is extracted appropriately
- abstractions remain simple and understandable
- helper functions are not fragmented across multiple locations
- components are reused consistently
- design tokens are centralised
- validation rules derive from a single source of truth where practical
- permissions are centrally enforced
- repeated queries are consolidated
- repeated constants are centralised
- business rules do not drift between frontend/backend implementations

Identify dangerous duplication patterns such as:

- copied-and-modified controllers
- copied form logic
- slightly different versions of the same component
- inconsistent enum definitions
- repeated raw SQL
- repeated audit logging implementations
- repeated upload handling pipelines
- duplicated role conditionals across the UI

Prefer:

- composable architecture
- shared primitives
- reusable utilities
- centralised configuration
- single-responsibility modules
- consistent patterns

Avoid over-abstraction.

Do not create generic systems that reduce clarity or maintainability.

# Security Audit

Review the project for common security issues.

Audit:

- input validation
- sanitisation
- authentication security
- authorisation logic
- API exposure
- secret leakage
- unsafe client-side trust
- upload security
- attachment security
- rate limiting
- CSRF protection
- XSS risks
- injection risks
- dependency vulnerabilities

- verify archived data cannot be accessed without proper authorisation
- verify soft-deleted records cannot be enumerated via APIs
- verify archived attachments remain permission protected
- verify restore operations are permission restricted
- verify retention-policy automation cannot be abused

Ensure the project follows safe production practices.

---

# Database & Migration Integrity Audit

Audit the database layer for correctness across both local (SQLite or
Postgres) and production (Postgres) environments.

Verify:

- Migrations are idempotent and re-runnable
- Foreign keys defined where relationships exist
- Cascade behaviour deliberate (`cascadeOnDelete` vs `nullOnDelete` vs `restrict`) — match the project's audit-log preserve-history pattern
- Soft deletes vs hard deletes documented per table
- Multi-row writes wrapped in `DB::transaction()`
- Concurrent edit handling (optimistic locking, last-write-wins) decided and documented per table
- SQL written portably — no SQLite-only syntax in production paths (e.g. `IS TRUE` / `IS FALSE` in raw `DB::statement` calls instead of `is_actual = 0`)
- Indexes on the columns hot in `WHERE` / `ORDER BY` (audit_logs.created_at, attachments.audit_log_id, etc.)
- Raw SQL audited for injection risk (parameter binding everywhere)

Verify the schema matches the production reality:

- All migrations have run on production
- No schema drift between branches
- Recently-added columns have backfill strategy if production rows exist

---

# Archival, Soft-Delete & Recoverability Audit

This platform must follow a preserve-history architecture.

In general, records should never be permanently deleted during normal application usage.

From the user's perspective, items may appear deleted in the UI, but the underlying system must preserve historical integrity unless a deliberate hard-purge workflow explicitly exists and is authorised.

Audit the entire application for destructive behaviour.

Verify that all major entities follow an intentional archival or soft-delete strategy, including:

- contracts
- attachments
- evidence files
- uploaded documents
- users
- audit records
- settings history
- overrides
- imports
- reports
- comments
- notifications
- background jobs
- related relational data

## Soft Delete & Archive Behaviour

Verify:

- destructive UI actions do not physically remove records by default
- soft-deletes or archival states are used consistently
- deleted records are excluded from normal frontend views
- archived data remains retrievable internally
- historical references do not break after archival
- foreign key integrity remains valid
- relationships still resolve correctly
- audit logs remain linked correctly after archival
- archived attachments still exist physically
- archived records preserve timestamps and ownership history
- soft-deleted users still preserve authored history
- reporting integrity is preserved after archival
- exports still handle archived references safely
- pagination/filtering excludes archived records unless intentionally requested
- search indexing respects archive visibility rules

Ensure the frontend behaves as if the record no longer exists while the backend preserves full recoverability.

## Attachment & Evidence Preservation

Attachments and supporting evidence must never become orphaned or unrecoverable.

Verify:

- deleted attachments are archived rather than physically removed
- attachment replacements preserve prior versions
- evidence version history remains accessible
- detached files remain recoverable internally
- attachment metadata is preserved
- file hashes remain stored for integrity verification
- original upload timestamps remain preserved
- uploader identity remains preserved
- storage references remain valid after archival
- download history and access history remain auditable where applicable
- attachment lifecycle events are reflected correctly in audit logs

Verify that no attachment deletion process silently destroys evidence.

## User Preservation Rules

Users should generally be:

- archived
- frozen
- disabled
- anonymised (if legally required)

rather than permanently deleted.

Verify:

- historical actions still reference the original actor
- audit logs never lose actor attribution
- deleted users cannot authenticate
- sessions revoke correctly
- ownership relationships remain stable
- permission inheritance remains safe after archival
- archived users are hidden from normal management views
- self-delete flows follow the platform's retention policy
- privileged users cannot accidentally destroy historical integrity

## Hard Delete Safety Audit

If hard deletion exists anywhere in the system:

- identify every hard-delete path explicitly
- document why hard deletion is required
- verify authorisation requirements
- verify password reconfirmation requirements
- verify irreversible-action warnings
- verify audit logging surrounding the purge action
- verify backup/recovery procedures before purge
- verify cascading behaviour intentionally preserves required history
- verify attachment cleanup jobs cannot accidentally remove active evidence
- verify scheduled cleanup jobs are safe and recoverable

Flag any accidental or uncontrolled permanent deletion behaviour as a critical issue.

## Database & ORM Enforcement

Verify archival behaviour is enforced consistently across:

- frontend UI
- backend services
- ORM models
- repositories
- policies
- API endpoints
- queued jobs
- scheduled tasks
- import/export tooling
- admin tooling

Verify:

- models correctly implement soft delete behaviour where intended
- queries consistently exclude archived records unless explicitly included
- admin tools cannot bypass archival safeguards unintentionally
- bulk operations respect archive rules
- raw SQL queries do not accidentally bypass soft-delete constraints
- unique constraints safely handle archived records
- restore operations work correctly
- archival timestamps are reliable
- restore conflicts are handled safely

## Recovery & Restore Verification

Audit the recoverability of archived data.

Verify:

- archived records can be restored safely
- restored records recover relationships correctly
- restored attachments remain valid
- restoration actions are themselves audited
- restore workflows are permission protected
- accidental deletions are realistically recoverable
- backup snapshots preserve archived data
- restore procedures include archived entities
- no data integrity corruption occurs during restore flows

Test multiple recovery scenarios end-to-end.

## Audit Log Expectations For Archival Events

Archival and deletion-related actions must always generate meaningful audit events.

Verify audit entries exist for:

- archive
- restore
- freeze
- disable
- detach
- replace
- anonymise
- purge
- scheduled cleanup
- retention-policy execution

Ensure audit logs clearly distinguish between:

- archived
- soft deleted
- detached
- hidden
- disabled
- permanently deleted

The audit log must never misleadingly imply data was destroyed when it was only archived.

---

# Backup, Restore & Disaster Recovery Audit

Verify every record in the system is recoverable.

- Snapshot schedule documented and verified (cron, manual, or Coolify)
- Backup integrity — last successful backup confirmed parseable
- Restore procedure tested end-to-end at least once recently
- Time-to-recovery measured and acceptable
- Off-host backup target (not just on the same VPS)
- Snapshot includes BLOBs (in-DB attachments) — not just metadata
- Documented "what data can be lost vs critical" matrix

For production-only failure modes:

- Postgres password rotation procedure
- App key rotation impact (encrypted columns, cookies, session table)
- Coolify rebuild from scratch — could you recreate the whole stack from this repo + a snapshot?

---

# Documentation & Onboarding Audit

Verify a brand-new contributor can:

- Stand up the project locally from a fresh clone in under 30 minutes
- Find the answer to "what is this app for" in the README within 60 seconds
- Find the engineering rules in CLAUDE.md
- Understand the deployment story without asking
- Reproduce a production issue locally

Verify:

- README accurate and current (no outdated steps, no dead links)
- CLAUDE.md guardrails reflect actual project conventions
- Local setup procedure tested on a clean machine recently
- Deployment runbook exists and is current
- Roadmap (`config/roadmap.php` + `/roadmap` page) reflects actual priorities, no stale items
- Inline code comments explain WHY (non-obvious constraints, hidden invariants), not WHAT

---

# Final Output Expectations

At the end of the audit:

1. Fix issues directly where appropriate
2. Explain major changes made
3. Identify remaining weaknesses
4. Suggest future improvements
5. Summarise production readiness
6. Highlight any risky areas requiring manual review

Be extremely detail-oriented.

Assume this project is preparing for public release and must meet a high professional standard.

Continuously search for inconsistencies, weaknesses, and opportunities to improve the entire system holistically.
