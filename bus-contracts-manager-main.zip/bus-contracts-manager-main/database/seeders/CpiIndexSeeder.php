<?php

namespace Database\Seeders;

use App\Models\CpiIndexEntry;
use App\Models\User;
use App\Services\CpiRateService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;
use RuntimeException;

class CpiIndexSeeder extends Seeder
{
    private const CSV_PATH = 'cpi_historical.csv';

    /**
     * Fallback CPI values if no CSV exists. ONS D7BT actuals, 1dp.
     *
     * @var array<string, string>
     */
    private const FALLBACK_VALUES = [
        '2023-04-01' => '131.2', '2023-05-01' => '131.4', '2023-06-01' => '131.6',
        '2023-07-01' => '131.5', '2023-08-01' => '131.9', '2023-09-01' => '131.9',
        '2023-10-01' => '132.0', '2023-11-01' => '132.0', '2023-12-01' => '132.0',
        '2024-01-01' => '131.8', '2024-02-01' => '133.0', '2024-03-01' => '133.0',
        '2024-04-01' => '133.5', '2024-05-01' => '133.9', '2024-06-01' => '134.1',
        '2024-07-01' => '133.8', '2024-08-01' => '134.3', '2024-09-01' => '134.2',
        '2024-10-01' => '135.0', '2024-11-01' => '135.1', '2024-12-01' => '135.6',
        '2025-01-01' => '135.4', '2025-02-01' => '136.0', '2025-03-01' => '136.5',
        '2025-04-01' => '138.2', '2025-05-01' => '138.4', '2025-06-01' => '138.9',
        '2025-07-01' => '139.0', '2025-08-01' => '139.3', '2025-09-01' => '139.3',
        '2025-10-01' => '139.8', '2025-11-01' => '139.5', '2025-12-01' => '140.1',
        '2026-01-01' => '139.5', '2026-02-01' => '140.1', '2026-03-01' => '141.0',
    ];

    public function run(): void
    {
        $admin = User::query()->orderBy('id')->first()
            ?? User::create([
                'name' => 'Admin',
                'email' => 'admin@example.com',
                'password' => bcrypt('password'),
            ]);

        $values = $this->loadFromCsv() ?? self::FALLBACK_VALUES;

        foreach ($values as $month => $cpi) {
            // Anything published before our automated ONS feed went live is
            // treated as a one-off historical manual import. Everything after
            // would have been picked up by the live feed.
            $source = $month < '2024-01-01' ? 'manual_import' : 'ons_feed';

            CpiIndexEntry::updateOrCreate(
                ['month' => $month],
                [
                    'cpi_index' => $cpi,
                    'cpi_index_original' => $cpi,
                    'is_actual' => true,
                    'source' => $source,
                    'source_original' => $source,
                    'override_note' => null,
                    'created_by' => $admin->id,
                ]
            );
        }

        app(CpiRateService::class)->recalculateAll();
    }

    /**
     * @return array<string, string>|null
     */
    private function loadFromCsv(): ?array
    {
        $path = base_path(self::CSV_PATH);

        if (! is_file($path)) {
            return null;
        }

        $handle = fopen($path, 'r');

        if ($handle === false) {
            throw new RuntimeException("Unable to read CSV at {$path}.");
        }

        $values = [];
        $row = 0;

        try {
            while (($cells = fgetcsv($handle, 0, ',', '"', '\\')) !== false) {
                $row++;

                if ($row === 1) {
                    continue;
                }

                if (count($cells) < 2) {
                    continue;
                }

                [$rawDate, $rawCpi] = [trim($cells[0]), trim($cells[1])];

                if ($rawDate === '' || $rawCpi === '') {
                    continue;
                }

                $month = $this->parseMonth($rawDate);
                $cpi = $this->normaliseCpi($rawCpi);

                $values[$month] = $cpi;
            }
        } finally {
            fclose($handle);
        }

        return $values;
    }

    private function parseMonth(string $raw): string
    {
        // Accept dd/mm/yyyy, yyyy-mm-dd, etc. — return first-of-month YYYY-MM-DD.
        if (preg_match('#^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$#', $raw, $m) === 1) {
            $date = Carbon::createFromDate((int) $m[3], (int) $m[2], 1);
        } else {
            $date = Carbon::parse($raw)->startOfMonth();
        }

        return $date->format('Y-m-d');
    }

    private function normaliseCpi(string $raw): string
    {
        return number_format((float) $raw, 1, '.', '');
    }
}
