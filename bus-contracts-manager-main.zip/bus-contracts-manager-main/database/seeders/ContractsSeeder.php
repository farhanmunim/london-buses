<?php

namespace Database\Seeders;

use App\Models\AppSetting;
use App\Models\Contract;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

/**
 * Seeds the contracts table from the contract-detail-example.csv shipped at
 * the repo root. The source CSV uses Excel-serial dates (e.g. 42569 →
 * 18/07/2016) so we convert via the 1899-12-30 epoch on the way in.
 *
 * Idempotent: skips rows whose (company, depot, route, contract_number,
 * start_date) tuple already exists, so re-running this never duplicates.
 *
 * Columns expected (matches the canonical spreadsheet, 0-indexed):
 *   0  Company           — string
 *   1  Depot             — string
 *   2  Route             — string
 *   3  Contract.N        — string  → contract_number
 *   4  Tender Date       — Excel serial → tender_date
 *   5  Start Date        — Excel serial → start_date
 *   6  End Date          — Excel serial → end_date
 *   7  Contract Values   — decimal → contract_value
 *   8  As of Which Year  — derived (anchor) — IGNORED
 *   9  Live.Mile         — decimal → contracted_miles
 *  10  PVR               — int → pvr
 *  11  TVR               — int → tvr
 *  12  Propulsion        — string → propulsion
 *  13  Decks             — string → decks
 *  14  Early term date   — derived — IGNORED
 *  15  Early notice date — derived — IGNORED
 *  16  Early term status — derived — IGNORED
 *  17  Notice served?    — IGNORED (now a Yes/No flag set in the UI)
 *  18  CPA % 2023        — derived — IGNORED
 *  19  CPA % 2024        — derived — IGNORED
 *  20  CPA % 2025        — derived — IGNORED
 *  21  CPA % 2026        — derived — IGNORED
 *  22  CPA confirmed 2023 — yes/no/blank → cpa_confirmations[2023]
 *  23  CPA confirmed 2024 — yes/no/blank → cpa_confirmations[2024]
 *  24  CPA confirmed 2025 — yes/no/blank → cpa_confirmations[2025]
 *  25  CPA confirmed 2026 — yes/no/blank → cpa_confirmations[2026]
 */
class ContractsSeeder extends Seeder
{
    public function run(): void
    {
        $csv = base_path('contract-detail-example.csv');

        if (! is_readable($csv)) {
            $this->command->warn("Skipping: {$csv} not readable.");

            return;
        }

        $owner = User::query()->orderBy('id')->first();

        if (! $owner) {
            $this->command->warn('Skipping: no user account exists to own the contract rows.');

            return;
        }

        $globalAnchor = AppSetting::contractsAnchorYear();

        $handle = fopen($csv, 'r');
        if ($handle === false) {
            $this->command->warn('Skipping: could not open CSV.');

            return;
        }

        fgetcsv($handle, 0, ',', '"', '\\'); // discard header row

        $inserted = 0;
        $skipped = 0;
        $errors = 0;

        try {
            while (($cells = fgetcsv($handle, 0, ',', '"', '\\')) !== false) {
                if (count($cells) < 8) {
                    continue;
                }

                $company = trim((string) ($cells[0] ?? ''));
                $depot = trim((string) ($cells[1] ?? ''));
                $route = trim((string) ($cells[2] ?? ''));
                $contractNumber = trim((string) ($cells[3] ?? ''));

                if ($company === '' || $contractNumber === '') {
                    continue;
                }

                $tender = $this->excelDate($cells[4] ?? null);
                $start = $this->excelDate($cells[5] ?? null);
                $end = $this->excelDate($cells[6] ?? null);

                if ($tender === null || $start === null || $end === null) {
                    $this->command->warn("Bad date in row for {$contractNumber}");
                    $errors++;

                    continue;
                }

                $exists = Contract::where('company', $company)
                    ->where('depot', $depot)
                    ->where('route', $route)
                    ->where('contract_number', $contractNumber)
                    ->where('start_date', $start)
                    ->exists();

                if ($exists) {
                    $skipped++;

                    continue;
                }

                $contractValue = $this->numericOrNull($cells[7] ?? null);
                $contractedMiles = $this->numericOrNull($cells[9] ?? null);
                $pvr = $this->intOrNull($cells[10] ?? null);
                $tvr = $this->intOrNull($cells[11] ?? null);
                $propulsion = trim((string) ($cells[12] ?? '')) ?: null;
                $decks = trim((string) ($cells[13] ?? '')) ?: null;

                // CPA confirmed columns (22..25 → years 2023..2026). Pre-anchor
                // years are locked to Yes by derivation, so we don't store
                // those even if the CSV has them.
                $confirmYears = [2023, 2024, 2025, 2026];
                $confirmations = [];
                foreach ($confirmYears as $i => $year) {
                    $cell = strtolower(trim((string) ($cells[22 + $i] ?? '')));
                    if ($cell === '' || ! in_array($cell, ['yes', 'no'], true)) {
                        continue;
                    }
                    if ($globalAnchor !== null && $year < $globalAnchor) {
                        continue;
                    }
                    $confirmations[(string) $year] = $cell;
                }

                Contract::create([
                    'company' => $company,
                    'depot' => $depot,
                    'route' => $route,
                    'contract_number' => $contractNumber,
                    'tender_date' => $tender,
                    'start_date' => $start,
                    'end_date' => $end,
                    'contract_value' => $contractValue ?? 0.0,
                    'contracted_miles' => $contractedMiles,
                    'pvr' => $pvr,
                    'tvr' => $tvr,
                    'propulsion' => $propulsion,
                    'decks' => $decks,
                    'cpa_confirmations' => $confirmations === [] ? null : $confirmations,
                    'created_by' => $owner->id,
                ]);

                $inserted++;
            }
        } finally {
            fclose($handle);
        }

        $this->command->info("Contracts seeded: {$inserted} inserted, {$skipped} skipped, {$errors} errors.");
    }

    /**
     * Convert an Excel-serial date (days since 1899-12-30) to YYYY-MM-DD,
     * or null if the cell isn't a positive integer.
     */
    private function excelDate(mixed $raw): ?string
    {
        $clean = trim((string) ($raw ?? ''));
        if ($clean === '' || ! ctype_digit($clean)) {
            return null;
        }

        return Carbon::create(1899, 12, 30)->addDays((int) $clean)->format('Y-m-d');
    }

    private function numericOrNull(mixed $raw): ?float
    {
        $clean = trim((string) ($raw ?? ''));
        if ($clean === '' || ! is_numeric($clean)) {
            return null;
        }

        return (float) $clean;
    }

    private function intOrNull(mixed $raw): ?int
    {
        $clean = trim((string) ($raw ?? ''));
        if ($clean === '' || ! is_numeric($clean)) {
            return null;
        }

        return (int) $clean;
    }
}
