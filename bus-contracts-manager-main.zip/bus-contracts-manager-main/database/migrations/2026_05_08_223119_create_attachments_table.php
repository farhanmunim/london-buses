<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Evidence attachments — supporting files uploaded alongside contract /
 * CPA-confirmation / extension / notice-served changes. The bytes live
 * directly in the database (BLOB column) so the existing "Download
 * snapshot" backup remains a single-file restore — no parallel storage
 * tree to keep in sync.
 *
 * Each attachment is paired 1:1 with the audit_log row that recorded
 * the change, so the audit log stays the authoritative trail and a
 * file can never be orphaned from its rationale.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('attachments', function (Blueprint $table) {
            $table->id();
            // 1:1 with the audit row that recorded the change. Soft-hidden
            // audit logs keep their attachment; if the audit row is ever
            // physically deleted the attachment goes with it (cascadeOnDelete).
            $table->foreignId('audit_log_id')
                ->unique()
                ->constrained('audit_logs')
                ->cascadeOnDelete();
            $table->string('original_filename');
            $table->string('mime_type', 100);
            $table->unsignedInteger('size_bytes');
            // Actual file bytes. SQLite stores arbitrary blobs in BLOB;
            // PostgreSQL maps `binary()` to BYTEA, which has a 1 GB cap
            // per row — well beyond our 2 MB upload limit.
            $table->binary('contents');
            // Who uploaded — survives user deletion as null so attachments
            // stay accessible (matches the planned audit_logs.user_id
            // policy in §10 of CLAUDE.md).
            $table->foreignId('uploaded_by')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attachments');
    }
};
