<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Each row is one line item of a contract: a single (company, depot,
     * route, contract_number) tuple over a date range with a contract value.
     * Contract numbers are intentionally NOT unique — the same number can
     * cover several routes (e.g. day route + night service variant) and can
     * appear on multiple rows when a contract is varied or extended into a
     * new period.
     */
    public function up(): void
    {
        Schema::create('contracts', function (Blueprint $table) {
            $table->id();
            $table->string('company', 8);
            $table->string('depot', 8);
            $table->string('route', 32);
            $table->string('contract_number', 32);
            $table->date('tender_date');
            $table->date('start_date');
            $table->date('end_date');
            $table->decimal('contract_value', 15, 4);
            $table->foreignId('created_by')->constrained('users')->cascadeOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index('contract_number');
            $table->index('company');
            $table->index('depot');
            $table->index('start_date');
            $table->index('end_date');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contracts');
    }
};
