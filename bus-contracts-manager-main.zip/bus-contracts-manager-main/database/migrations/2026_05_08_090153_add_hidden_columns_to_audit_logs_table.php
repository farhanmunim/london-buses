<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Add a soft-hide flag to audit_logs. Records flagged here are filtered
     * out of the default view but the underlying change history is never
     * mutated or deleted — the audit trail itself remains append-only.
     */
    public function up(): void
    {
        Schema::table('audit_logs', function (Blueprint $table) {
            $table->timestamp('hidden_at')->nullable()->after('ip_address');
            $table->foreignId('hidden_by')->nullable()->constrained('users')->nullOnDelete();
            $table->index('hidden_at');
        });
    }

    public function down(): void
    {
        Schema::table('audit_logs', function (Blueprint $table) {
            $table->dropForeign(['hidden_by']);
            $table->dropIndex(['hidden_at']);
            $table->dropColumn(['hidden_at', 'hidden_by']);
        });
    }
};
