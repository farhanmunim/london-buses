<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            // Per-year notes for CPA confirmations. Mirrors the shape of
            // cpa_confirmations: `{year: 'note text', ...}`. Re-opening the
            // confirmation dialog for a year that already has a note
            // pre-fills the textarea rather than starting blank — the
            // context-of-decision survives outside the audit log too.
            $table->json('cpa_confirmation_notes')->nullable()->after('cpa_confirmations');

            // Most recent override / variation note from the Edit dialog.
            // Re-opening Edit pre-fills this so the superadmin sees what was
            // said last time. Cleared when an edit is saved without a note.
            $table->string('latest_change_note', 500)->nullable()->after('cpa_confirmation_notes');
        });
    }

    public function down(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn(['cpa_confirmation_notes', 'latest_change_note']);
        });
    }
};
