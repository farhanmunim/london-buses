<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * The soft-hide feature on audit_logs has been removed in favour of the
     * hard-delete in Settings > Data control. Drop the visibility columns so
     * the schema reflects what the app actually does.
     */
    public function up(): void
    {
        Schema::table('audit_logs', function (Blueprint $table) {
            $table->dropForeign(['hidden_by']);
            $table->dropIndex(['hidden_at']);
            $table->dropColumn(['hidden_at', 'hidden_by']);
        });
    }

    public function down(): void
    {
        Schema::table('audit_logs', function (Blueprint $table) {
            $table->timestamp('hidden_at')->nullable()->after('ip_address');
            $table->foreignId('hidden_by')->nullable()->constrained('users')->nullOnDelete();
            $table->index('hidden_at');
        });
    }
};
