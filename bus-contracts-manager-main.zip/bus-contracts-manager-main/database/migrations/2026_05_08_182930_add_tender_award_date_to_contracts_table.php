<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            // Date the contract was awarded to the operator following the
            // tender process. Distinct from tender_date (the tender event
            // itself) and start_date (operations begin). Nullable because
            // legacy rows may not have this captured.
            $table->date('tender_award_date')->nullable()->after('contract_value');
        });
    }

    public function down(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn('tender_award_date');
        });
    }
};
