<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Frozen accounts cannot authenticate but their data is preserved. Used
     * for temporary lockouts (e.g. employee on leave, suspected compromise)
     * without losing audit trail or relations. The superadmin slot can never
     * be frozen — enforced at the model layer.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->timestamp('frozen_at')->nullable()->after('role');
            $table->foreignId('frozen_by')->nullable()->constrained('users')->nullOnDelete();
            $table->index('frozen_at');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropForeign(['frozen_by']);
            $table->dropIndex(['frozen_at']);
            $table->dropColumn(['frozen_at', 'frozen_by']);
        });
    }
};
