<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * ET date and Notice date are now computed from start_date / end_date /
 * tender_date / extension flag — no longer stored. Notice served goes
 * from a free-text column to a Yes/No flag with a mandatory note (mirrors
 * the CPA-confirmation pattern). A new Extension flag (Yes/No + note)
 * captures whether the contract was re-let — the ET formula treats
 * `extension_status = 'yes'` as the "re-let" branch.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn([
                'early_termination_date',
                'early_termination_notice_date',
                'notice_served',
            ]);
        });

        Schema::table('contracts', function (Blueprint $table) {
            $table->string('extension_status', 10)->nullable()->after('decks');
            $table->string('extension_note', 500)->nullable()->after('extension_status');
            $table->string('notice_served_status', 10)->nullable()->after('extension_note');
            $table->string('notice_served_note', 500)->nullable()->after('notice_served_status');
        });
    }

    public function down(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn([
                'extension_status',
                'extension_note',
                'notice_served_status',
                'notice_served_note',
            ]);
        });

        Schema::table('contracts', function (Blueprint $table) {
            $table->date('early_termination_date')->nullable()->after('decks');
            $table->date('early_termination_notice_date')->nullable()->after('early_termination_date');
            $table->string('notice_served', 60)->nullable()->after('early_termination_notice_date');
        });
    }
};
