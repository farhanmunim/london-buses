<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // The earliest months never have a lagged source (P2P uses M-4, RA uses
        // M-12..M-1) so both can legitimately be null until enough history
        // exists. yoy_change is always populated (it just needs M and M-12).
        Schema::table('cpa_rates', function (Blueprint $table) {
            $table->decimal('p2p_rate', 10, 8)->nullable()->change();
            $table->decimal('yoy_change', 10, 8)->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('cpa_rates', function (Blueprint $table) {
            $table->decimal('p2p_rate', 10, 8)->nullable(false)->change();
            $table->decimal('yoy_change', 10, 8)->nullable(false)->change();
        });
    }
};
