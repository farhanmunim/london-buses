<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('cpi_index_entries', function (Blueprint $table) {
            $table->string('source_original', 32)->nullable()->after('source');
        });

        // Backfill: for non-overridden rows, source_original mirrors current source.
        // For currently-overridden rows we don't know the original ONS/manual_import
        // distinction so we fall back to the seeder rule (pre-2024 -> manual_import,
        // 2024+ -> ons_feed).
        DB::statement("UPDATE cpi_index_entries SET source_original = source WHERE source != 'manual_override'");
        DB::statement("UPDATE cpi_index_entries SET source_original = CASE WHEN month < '2024-01-01' THEN 'manual_import' ELSE 'ons_feed' END WHERE source = 'manual_override'");
    }

    public function down(): void
    {
        Schema::table('cpi_index_entries', function (Blueprint $table) {
            $table->dropColumn('source_original');
        });
    }
};
