<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Free-text note attached to a contract's tender-award date — set via the
 * dedicated tender-award dialog (cell-click on the Tender award column).
 * Mirrors the cpa_confirmation_notes / extension_note pattern. Evidence
 * files attach to the audit row, not this column.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->string('tender_award_note', 500)->nullable()->after('tender_award_date');
        });
    }

    public function down(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn('tender_award_note');
        });
    }
};
