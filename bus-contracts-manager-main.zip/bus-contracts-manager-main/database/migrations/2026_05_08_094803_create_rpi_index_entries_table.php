<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Mirrors cpi_index_entries — the RPI All Items Index (CHAW) is published
     * monthly on the same ONS dataset and treated as a parallel index. RPI
     * doesn't currently feed CPA derivation, so it lives independently.
     */
    public function up(): void
    {
        Schema::create('rpi_index_entries', function (Blueprint $table) {
            $table->id();
            $table->date('month')->unique();
            $table->decimal('rpi_index', 8, 1);
            $table->decimal('rpi_index_original', 8, 1)->nullable();
            $table->boolean('is_actual')->default(true);
            $table->string('source', 32)->default('manual_import');
            $table->string('source_original', 32)->nullable();
            $table->string('override_note')->nullable();
            $table->foreignId('created_by')->constrained('users')->cascadeOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('rpi_index_entries');
    }
};
