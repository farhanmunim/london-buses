<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Move attachments from a strict 1:1-with-audit-log model to a "many
 * per record-item" model with soft-detach support.
 *
 *  - `attachable_key` — string slot key like `contract:333:cpa:2024` that
 *     identifies the record-item the attachment belongs to. Multiple
 *     attachments can share a key (the user can append more evidence over
 *     time). Indexed for the per-dialog lookup.
 *  - `detached_at` / `detached_by` — soft-detach. Setting these removes
 *     the attachment from the record-item's active list but preserves
 *     the row + bytes in the DB so the audit history stays intact.
 *
 * Existing attachments are backfilled by inferring the key from their
 * linked audit_log row's action + entity. CPA-confirmation rows pull
 * the year out of `old_values`/`new_values` JSON.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('attachments', function (Blueprint $table) {
            $table->string('attachable_key', 100)->nullable()->after('audit_log_id')->index();
            $table->timestamp('detached_at')->nullable()->after('uploaded_by');
            $table->foreignId('detached_by')->nullable()->constrained('users')->nullOnDelete()->after('detached_at');
        });

        // Backfill attachable_key from each row's audit_log.
        DB::table('attachments as a')
            ->join('audit_logs as l', 'l.id', '=', 'a.audit_log_id')
            ->select('a.id', 'l.action', 'l.entity_id', 'l.old_values', 'l.new_values')
            ->orderBy('a.id')
            ->chunkById(200, function ($rows) {
                foreach ($rows as $row) {
                    $key = self::deriveKey($row);
                    if ($key === null) {
                        continue;
                    }
                    DB::table('attachments')->where('id', $row->id)->update(['attachable_key' => $key]);
                }
            }, 'a.id', 'id');
    }

    public function down(): void
    {
        Schema::table('attachments', function (Blueprint $table) {
            $table->dropForeign(['detached_by']);
            $table->dropColumn(['attachable_key', 'detached_at', 'detached_by']);
        });
    }

    /**
     * Map an audit-log action + entity to the attachable_key the
     * attachment should belong to. Returns null when the action isn't
     * one of the contract evidence flows.
     */
    private static function deriveKey(object $row): ?string
    {
        $entityId = $row->entity_id;
        if (! $entityId) {
            return null;
        }

        return match ($row->action) {
            'contract_overridden', 'contract_varied', 'contract_confirmed', 'contract_added' => "contract:{$entityId}",
            'contract_extension_set' => "contract:{$entityId}:extension",
            'contract_notice_served_set' => "contract:{$entityId}:notice_served",
            'contract_tender_award_set' => "contract:{$entityId}:tender_award",
            'contract_cpa_confirmed' => self::cpaKey($entityId, $row->old_values, $row->new_values),
            default => null,
        };
    }

    private static function cpaKey(int|string $contractId, ?string $old, ?string $new): ?string
    {
        // CPA confirmation rows store the year as the JSON object's first
        // key (e.g. {"2024": "yes", "2024_note": "..."}). Pull the
        // integer-looking key.
        foreach ([$new, $old] as $payload) {
            if (! $payload) {
                continue;
            }
            $parsed = json_decode($payload, true);
            if (! is_array($parsed)) {
                continue;
            }
            foreach (array_keys($parsed) as $k) {
                if (preg_match('/^\d{4}$/', (string) $k)) {
                    return "contract:{$contractId}:cpa:{$k}";
                }
            }
        }

        return null;
    }
};
