<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            // Per-contract, per-year CPA confirmation state. Keys are 4-digit
            // year strings ("2024"); values are 'yes' | 'no' | 'blank'. Years
            // that pre-date the global anchor are derived as 'yes' and never
            // stored — so this column only carries explicit user choices.
            $table->json('cpa_confirmations')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn('cpa_confirmations');
        });
    }
};
