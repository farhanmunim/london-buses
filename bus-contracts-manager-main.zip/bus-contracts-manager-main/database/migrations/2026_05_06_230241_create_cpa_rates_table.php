<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cpa_rates', function (Blueprint $table) {
            $table->id();
            $table->date('month')->unique();
            $table->decimal('p2p_rate', 10, 8);
            $table->decimal('ra_rate', 10, 8)->nullable();
            $table->decimal('yoy_change', 10, 8);
            $table->decimal('cpi_index', 8, 1);
            $table->decimal('cpi_index_prior_year', 8, 1);
            $table->boolean('is_override')->default(false);
            $table->decimal('p2p_override', 10, 8)->nullable();
            $table->decimal('ra_override', 10, 8)->nullable();
            $table->string('override_note')->nullable();
            $table->foreignId('overridden_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('overridden_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cpa_rates');
    }
};
