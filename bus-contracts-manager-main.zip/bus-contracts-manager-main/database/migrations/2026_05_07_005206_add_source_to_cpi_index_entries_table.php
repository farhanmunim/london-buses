<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('cpi_index_entries', function (Blueprint $table) {
            $table->string('source', 32)->default('manual_import')->after('is_actual');
        });

        // Backfill: existing rows where the user has overridden the value get
        // 'manual_override'; everything else (ONS-style) is treated as a manual
        // import since the live ONS feed has not been used yet.
        // Use boolean literal instead of `= 0` so this works on Postgres
        // (which is strict about bool/int comparisons) as well as SQLite.
        DB::statement("UPDATE cpi_index_entries SET source = CASE WHEN is_actual IS FALSE THEN 'manual_override' ELSE 'manual_import' END");
    }

    public function down(): void
    {
        Schema::table('cpi_index_entries', function (Blueprint $table) {
            $table->dropColumn('source');
        });
    }
};
