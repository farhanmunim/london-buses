<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Three-tier role model: superadmin (singleton, never demotable), admin
     * (elevated), user (default). The column is a string so SQLite can store
     * it; allowed values are enforced at the model level (see User::$casts /
     * UserRole logic).
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('role', 16)->default('user')->after('password');
        });

        // Singleton superadmin: the primary login. Other accounts
        // default to 'user' and can be promoted later via the (forthcoming)
        // user-management UI.
        DB::table('users')
            ->where('email', env('SUPERADMIN_EMAIL', 'admin@example.com'))
            ->update(['role' => 'superadmin']);
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('role');
        });
    }
};
