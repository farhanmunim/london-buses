<?php

use App\Models\Attachment;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Adds a sha256 hash column on attachments. Used for:
 *  - integrity verification (snapshot restore audits)
 *  - duplicate detection in the contract evidence-upload flow (the
 *    matching uses the sanitised filename for UX intuition, but having
 *    the hash makes "different bytes, same name" cases obvious to surface)
 *
 * Existing rows are backfilled by hashing their stored contents.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('attachments', function (Blueprint $table) {
            $table->char('sha256', 64)->nullable()->after('size_bytes')->index();
        });

        // Backfill — small one-time cost. Stream-friendly in chunks so
        // we don't pull every blob into memory at once.
        Attachment::query()
            ->select(['id'])
            ->orderBy('id')
            ->chunk(50, function ($rows) {
                foreach ($rows as $row) {
                    $bytes = DB::table('attachments')->where('id', $row->id)->value('contents');
                    if ($bytes === null) {
                        continue;
                    }
                    DB::table('attachments')
                        ->where('id', $row->id)
                        ->update(['sha256' => hash('sha256', $bytes)]);
                }
            });
    }

    public function down(): void
    {
        Schema::table('attachments', function (Blueprint $table) {
            $table->dropIndex(['sha256']);
            $table->dropColumn('sha256');
        });
    }
};
