<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Stage 1 of the link-existing-evidence feature.
 *
 * Splits the slot/audit-log/detach metadata off the `attachments` row
 * (where it was 1:1 with the file bytes) onto a new `attachment_links`
 * pivot row. One Attachment can now be linked from multiple slots,
 * which lets a re-upload of the same file (matched by sha256) reuse
 * the existing bytes instead of duplicating them.
 *
 * The original columns on `attachments` are preserved as nullable for
 * now — Stage 2 of the rollout switches the read/write paths over,
 * Stage 3+ optionally drops the dead columns once we're confident.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('attachment_links', function (Blueprint $table) {
            $table->id();

            // The file the link points at. Cascade so deleting the
            // bytes also drops every link that referenced them.
            $table->foreignId('attachment_id')
                ->constrained('attachments')
                ->cascadeOnDelete();

            // Where the link is mounted (e.g. `contract:333:cpa:2024`,
            // `contract:333:tender_award`). Nullable so a row created
            // by an "unbound" upload still gets a link.
            $table->string('attachable_key')->nullable()->index();

            // The audit_log row that recorded the linking action
            // (attach / link / replace). Nullable so a backfilled
            // row from existing data — where the audit_log row may
            // have been deleted via Settings → Delete all audit log
            // — doesn't fail the FK.
            $table->foreignId('audit_log_id')
                ->nullable()
                ->constrained('audit_logs')
                ->nullOnDelete();

            // Soft-detach: hides the link from dialog listings while
            // keeping the audit history (and the bytes, if other
            // links still reference them).
            $table->timestamp('detached_at')->nullable();
            $table->foreignId('detached_by')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            $table->timestamps();
        });

        // Backfill: every existing attachment becomes a single link
        // row carrying the same metadata, so the parallel data model
        // is in sync the moment Stage 2 ships.
        if (Schema::hasTable('attachments')) {
            $rows = DB::table('attachments')
                ->select(['id', 'attachable_key', 'audit_log_id', 'detached_at', 'detached_by', 'created_at', 'updated_at'])
                ->get();

            $now = now();

            foreach ($rows as $row) {
                DB::table('attachment_links')->insert([
                    'attachment_id' => $row->id,
                    'attachable_key' => $row->attachable_key,
                    'audit_log_id' => $row->audit_log_id,
                    'detached_at' => $row->detached_at,
                    'detached_by' => $row->detached_by,
                    'created_at' => $row->created_at ?? $now,
                    'updated_at' => $row->updated_at ?? $now,
                ]);
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('attachment_links');
    }
};
