<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Closes the audit-history compliance gap flagged in CLAUDE.md §10:
 * the original audit_logs.user_id FK was set to cascadeOnDelete, so
 * a user removing their own account via Profile took every audit
 * entry they ever wrote with them — including evidence attachments
 * (which cascade off audit_logs.id).
 *
 * Switching to nullOnDelete preserves the trail. The user_id column
 * goes null on the entry, but old_values / new_values / note /
 * ip_address still hold the change snapshot, so a reviewer can still
 * see WHAT happened and WHEN, just not the now-deleted operator's id.
 *
 * Postgres can't ALTER an FK constraint in one step — we drop and
 * re-add. Same approach works on SQLite.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('audit_logs', function (Blueprint $table) {
            // user_id needs to become nullable before we can switch
            // the FK behaviour to nullOnDelete (Postgres rejects
            // SET NULL on a NOT NULL column).
            $table->unsignedBigInteger('user_id')->nullable()->change();

            $table->dropForeign(['user_id']);
            $table->foreign('user_id')
                ->references('id')->on('users')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('audit_logs', function (Blueprint $table) {
            $table->dropForeign(['user_id']);
            $table->unsignedBigInteger('user_id')->nullable(false)->change();
            $table->foreign('user_id')
                ->references('id')->on('users')
                ->cascadeOnDelete();
        });
    }
};
