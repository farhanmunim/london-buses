<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            // Operational metadata captured per contract — sourced from the
            // canonical contract spreadsheet. Everything here is nullable
            // because legacy rows pre-dating these fields don't have values
            // yet, and not every contract publishes every field.
            $table->decimal('contracted_miles', 14, 2)->nullable()->after('contract_value');
            $table->unsignedSmallInteger('pvr')->nullable()->after('contracted_miles');
            $table->unsignedSmallInteger('tvr')->nullable()->after('pvr');
            $table->string('propulsion', 40)->nullable()->after('tvr');
            $table->string('decks', 20)->nullable()->after('propulsion');
            $table->date('early_termination_date')->nullable()->after('decks');
            $table->date('early_termination_notice_date')->nullable()->after('early_termination_date');
            $table->string('notice_served', 60)->nullable()->after('early_termination_notice_date');
        });
    }

    public function down(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            $table->dropColumn([
                'contracted_miles',
                'pvr',
                'tvr',
                'propulsion',
                'decks',
                'early_termination_date',
                'early_termination_notice_date',
                'notice_served',
            ]);
        });
    }
};
