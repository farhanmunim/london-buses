<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ons_release_metadata', function (Blueprint $table) {
            $table->id();
            $table->string('dataset_key')->unique();
            $table->string('source_url');
            $table->date('release_date')->nullable();
            $table->date('next_release_date')->nullable();
            $table->string('next_release_raw')->nullable();
            $table->timestamp('fetched_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ons_release_metadata');
    }
};
