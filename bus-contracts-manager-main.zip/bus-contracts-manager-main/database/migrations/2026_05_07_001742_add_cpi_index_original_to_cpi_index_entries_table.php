<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('cpi_index_entries', function (Blueprint $table) {
            $table->decimal('cpi_index_original', 8, 1)->nullable()->after('cpi_index');
        });

        DB::table('cpi_index_entries')
            ->whereNotNull('cpi_index')
            ->update(['cpi_index_original' => DB::raw('cpi_index')]);
    }

    public function down(): void
    {
        Schema::table('cpi_index_entries', function (Blueprint $table) {
            $table->dropColumn('cpi_index_original');
        });
    }
};
