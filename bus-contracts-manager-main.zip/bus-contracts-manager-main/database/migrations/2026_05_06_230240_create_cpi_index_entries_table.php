<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cpi_index_entries', function (Blueprint $table) {
            $table->id();
            $table->date('month')->unique();
            $table->decimal('cpi_index', 8, 1);
            $table->boolean('is_actual')->default(true);
            $table->string('override_note')->nullable();
            $table->foreignId('created_by')->constrained('users')->cascadeOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cpi_index_entries');
    }
};
