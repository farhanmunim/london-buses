<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Performance indexes flagged by the §audit pass.
 *
 * - user_id: the audit-log UI filters by user (and Profile/Users flows
 *   resolve a person's history). Without an index this becomes a full
 *   scan once the table grows past a few thousand rows.
 *
 * - (created_at, id): pagination orders by `created_at DESC, id DESC`.
 *   The single-column created_at index helps the WHERE clause but not
 *   the secondary ordering, so each page becomes "index scan + filesort"
 *   on Postgres. Composite index gives a clean indexed sort.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('audit_logs', function (Blueprint $table) {
            $table->index('user_id');
            $table->index(['created_at', 'id'], 'audit_logs_created_at_id_index');
        });
    }

    public function down(): void
    {
        Schema::table('audit_logs', function (Blueprint $table) {
            $table->dropIndex(['user_id']);
            $table->dropIndex('audit_logs_created_at_id_index');
        });
    }
};
