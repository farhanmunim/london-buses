# Bus Contracts Manager

Internal web application for managing UK bus contracts. Tracks contract revenue, ONS-derived inflation indices (CPI / CPA / RPI), and produces pre-defined reports across financial years (cash forecast, accruals forecast, final claim, intermediate claim).

Designed for local use with restricted user access and a full audit trail. There is no live hosted instance; the deployment documentation below is provided for anyone self-hosting.

> **Engineering rules and AI-agent guardrails** for this codebase live in [`CLAUDE.md`](CLAUDE.md). This README is the human-facing project documentation: what the app is, how to run it, and what's planned.

---

## Stack

| Layer | Choice |
|---|---|
| Language | PHP 8.4 |
| Framework | Laravel 13 |
| Auth | Laravel Breeze (Blade stack) |
| Database | SQLite locally → PostgreSQL in production |
| Frontend | Blade · Alpine.js v3 · custom shadcn-inspired CSS (no Tailwind) |
| Testing | Pest v4 |
| Code style | Laravel Pint |
| Local server | Laravel Herd (Windows) |
| Hosting | Self-host via Docker on a Coolify VPS (documented below) |

---

## Hostnames

| Environment | URL |
|---|---|
| Local (Herd) | <https://contract-manager.test> |
| Production (example, if self-hosting on a Coolify VPS) | `https://contract-manager.example.com` |

Production `APP_URL` must be set explicitly in the Coolify env (Laravel uses it to build password-reset / email-verification / absolute redirect URLs — inheriting the `.test` value would 404 every link).

## Local development

The site is served at <https://contract-manager.test> via Laravel Herd. **Never run `php artisan serve`** — Herd serves the site automatically.

```bash
# Run migrations
php artisan migrate

# Build frontend assets
npm run build

# Run tests
php artisan test --compact

# Format PHP
vendor/bin/pint --dirty --format agent
```

### Environment

- Copy `.env.example` to `.env` and fill in any non-default values.
- Cloudflare Turnstile defaults to dev "always-pass" keys via `config/services.php`. Override `TURNSTILE_SITE_KEY` / `TURNSTILE_SECRET_KEY` in `.env` for production.
- Mail currently uses `MAIL_MAILER=log` (writes to `storage/logs`); SMTP is on the roadmap.

### First-time setup — bootstrapping a superadmin

`/register` is **always disabled** in both environments — [`routes/auth.php`](routes/auth.php) hard-codes `abort(404)` for the route. There is no first-run / no-users-exist gate; the 404 is unconditional. On a brand-new database with no users you therefore need a one-time bootstrap:

1. **Migrate** to create the schema:
   ```bash
   php artisan migrate
   ```
2. **Temporarily re-enable registration** — TWO files need editing, not one:

   a. [`routes/auth.php`](routes/auth.php) — add the `RegisteredUserController` import, comment out the `abort(404)` line, and add the Breeze register routes:
   ```php
   use App\Http\Controllers\Auth\RegisteredUserController;

   Route::get('register', [RegisteredUserController::class, 'create'])->name('register');
   Route::post('register', [RegisteredUserController::class, 'store']);
   // Route::get('register', fn () => abort(404))->name('register');
   ```

   b. [`app/Http/Controllers/Auth/RegisteredUserController.php`](app/Http/Controllers/Auth/RegisteredUserController.php) — **the controller is a tombstone**: `create()` and `store()` methods were stripped when registration was disabled, so re-enabling the route alone yields a 500. Restore the standard Breeze methods:
   ```php
   use App\Models\User;
   use Illuminate\Auth\Events\Registered;
   use Illuminate\Http\RedirectResponse;
   use Illuminate\Http\Request;
   use Illuminate\Support\Facades\Auth;
   use Illuminate\Support\Facades\Hash;
   use Illuminate\Validation\Rules;
   use Illuminate\View\View;

   public function create(): View
   {
       return view('auth.register');
   }

   public function store(Request $request): RedirectResponse
   {
       $request->validate([
           'name' => ['required', 'string', 'max:255'],
           'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:'.User::class],
           'password' => ['required', 'confirmed', Rules\Password::defaults()],
       ]);

       $user = User::create([
           'name' => $request->name,
           'email' => $request->email,
           'password' => Hash::make($request->password),
       ]);

       event(new Registered($user));
       Auth::login($user);

       return redirect(route('dashboard', absolute: false));
   }
   ```

   Commit + push both files; Coolify auto-deploys.

3. **Register your account** at `/register`. New accounts default to `role = 'user'` (per the column default in [`add_role_to_users_table`](database/migrations/2026_05_08_100455_add_role_to_users_table.php)) — promotion is a separate step.
4. **Promote to superadmin via direct SQL.** The cleanest path that works on every shell:

   **Postgres:**
   ```bash
   psql -U bcm -h 127.0.0.1 -d bcm \
     -c "UPDATE users SET role = 'superadmin' WHERE email = 'you@example.com';"
   ```
   On Windows PowerShell, set `$env:PGPASSWORD` first to skip the prompt; the binary lives at `'C:\Program Files\PostgreSQL\18\bin\psql.exe'`.

   **SQLite:**
   ```bash
   sqlite3 database/database.sqlite \
     "UPDATE users SET role = 'superadmin' WHERE email = 'you@example.com';"
   ```

   > **Why not `php artisan tinker --execute …`?** It works on bash/zsh but fails on Windows PowerShell — the `@` in the email is parsed as PHP's error-suppression operator after PowerShell strips the surrounding quotes, producing `Syntax error, unexpected '@', expecting ')'`. Direct SQL sidesteps the shell-quoting layer entirely.

   > **Note on the migration's auto-promote step.** [`add_role_to_users_table`](database/migrations/2026_05_08_100455_add_role_to_users_table.php) contains a one-shot `UPDATE … WHERE email = 'admin@example.com'` set-to-superadmin block. It runs **at migration time** — on a fresh DB no users exist yet, so it affects 0 rows and you still need the manual promotion above. The auto-promote only fires if `admin@example.com` was already in the `users` table when the migration ran (e.g. seeded, or restored from a snapshot).

5. **Log out and back in.** The role is read from the DB at login and cached on the session — your existing session still thinks you're `role = 'user'` until you re-authenticate.

6. **Re-disable registration.** Revert BOTH files: [`routes/auth.php`](routes/auth.php) back to the `abort(404)` form (and remove the `RegisteredUserController` import), and [`app/Http/Controllers/Auth/RegisteredUserController.php`](app/Http/Controllers/Auth/RegisteredUserController.php) back to the empty tombstone class. Commit + push. Every subsequent account is provisioned from **Manage users** by the superadmin.

---

## Application sections

All sections sit behind `auth` middleware. Three roles enforce access (see [Roles](#roles)).

| Section | Status | What it does |
|---|---|---|
| **Indices** | Active (CPI / CPA / RPI), placeholder (CEBR / DERV) | CPI / CPA / RPI ingestion, manual overrides, bulk CSV import, per-month audit. CEBR (forecasts) and DERV (diesel-fuel index) are stubbed in the tab nav as "Coming soon". |
| **Contracts** | Active | Add / edit (Confirmation / Override / Variation) / delete; CSV import + export; per-cell CPA confirmations + Extension / Notice-served / Tender-award click-to-edit dialogs; computed columns (Length, ET date, Notice date, ET status); file attachments per record-item with audit-log download links; frozen-pane table; Status / Company / Depot filters; "More info" toggle for operational columns; configurable anchor year + P2P/RA cutoff. |
| **Documents** | Active (Attachments) / Coming soon (Settlements) | Browseable index of every contract attachment in the system, with filename / type / uploader filters and a multi-contract drill-down modal. Settlements sub-page is the future home of TfL settlement statement PDFs that feed the claim reports. |
| **Reports** | Coming soon | Cash forecast, Accruals forecast, Final claim, Intermediate claim, Hyperion (XLSX import landing page). |
| **Audit log** | Active | Append-only ledger of every write across the app. Compact table with filter toolbar (action / user / date / search) and inline-expandable rows. Each row collapses to one line (Time · Status · Area · Record · User · Note); expand for the full before/after diff plus the attachment lifecycle indicator (Attached · Modified · Detached). Replace events merge their detach + attach pair into a single row showing both files side-by-side. |
| **Users** | Active | Manage accounts, roles (`superadmin` / `admin` / `user`), freeze / unfreeze, password reset. Per-user expandable login history with IP and user-agent. |
| **Settings** | Active | Superadmin Data control: configurable upload limits (size + extension whitelist) for attachments and CSV templates; database snapshot download; targeted data delete (single dropdown picks Audit log · Contracts · Indices · Attachments · All). Every action requires inline password re-confirmation. |
| **Profile** | Active | Self-service: name, email, password change, account deletion. Profile updates audit-log to `user_updated` with old/new diff. |

### Core feature set

Snapshot of what the app actually does today; update as features land.

**Indices (CPI / CPA / RPI)**
- Daily ONS refresh via `php artisan cpi:refresh` — refreshes CPI + RPI in one pass and cascades CPA recalculation.
- Per-month +Add / Edit / Delete / "Reset to ONS" with audit.
- Bulk CSV import with per-row sanitisation (BOM strip, formula-injection guard, range validation).
- Manual override flag preserved across feed refreshes — feed data never silently undoes a user override.
- Source filter chip (ONS Actual / Manual Import / Manual Override) and date-range filter.
- "Clear overrides" / "Clear imports" superadmin actions per index.

**Contracts**
- Full CRUD: Add, Edit (classified as **Confirmation / Override / Variation** via dropdown), Delete.
- CSV import with `import_type` codes (`1` override / `2` variation / `3` new) keyed on contract id; CSV export. Both gated to admin+.
- Per-cell **CPA confirmation** dialog (Yes / No + optional note) — note persists on the contract via `cpa_confirmation_notes` JSON; the dialog re-opens with the existing note pre-filled.
- Per-row **Extension / Notice-served** Yes/No flag dialogs with required note (drives ET-date formula's re-let branch).
- Per-row **Tender award** dialog: date + free-text note + attachment upload, click-to-edit pill in the table.
- **Computed columns**: contract Length (whole years), ET date (per-spec formula with 7-day reduction for pre-2023 tenders), Notice date (ET date − 10 months, or end-date − 10 months when length < 5), ET status (Served / Passed / Ongoing).
- **Attachments**: every dialog accepts file uploads (PDF/Word/Excel/CSV/email by default; configurable in Settings). Many-per-record-item via `attachable_key`, soft-detach (audit history preserved), filename-based duplicate detection with Link-existing / Replace-everywhere / Keep-both / Cancel.
- **Edit Contract dialog** exposes every editable field except computed ones — operational metadata (Tender award date, PVR, TVR, Propulsion, Decks) included alongside the core fields.
- Per-row **View history** link → audit log filtered by `#contract_id`.
- After save, page redirects to `#contract-{id}` and the JS scrolls + highlights the row so context isn't lost.
- Frozen left-pane (id, status, company, depot, route, contract no.) plus sticky thead while scrolling.
- Filters: Company / Depot / Status (Active / Expired / Upcoming) cascading by chip.
- "More info" toggle reveals operational columns (PVR, TVR, propulsion, decks, Extension, ET date, Notice date, Notice served, ET status, Tender award).
- 4-year CPA window (anchor−1 … anchor+2) with three rendered states: rate value, `Pending` (applicable but ONS hasn't published the underlying CPI yet), or `N/A`.
- Anchor year + P2P/RA cutoff configured via the Settings cog (admin+).
- **Read-only view for `user` role**: every dialog opens in view mode, all inputs disabled, no Save / upload / detach / Delete.

**Audit log**
- Compact table with filter toolbar (action / user / date / freetext search) and inline-expandable rows.
- Action keys collapse to three high-level statuses on display: **Added** (verb=create), **Modified** (verb=update / import), **Deleted** (verb=delete).
- Attachment lifecycle pill on each row when applicable, three states: **Attached** (green) · **Modified** (amber, paired detach+attach) · **Detached** (red). Replace events merge their two underlying audit rows into a single visual row showing both old and new files in Before / After cells.
- Expanded panel renders a 3-column diff table (Field · Before · After). Attachment-only rows suppress the technical metadata diff in favour of the dedicated Attachment row.
- Records that have since been deleted (users, contracts) still surface their original name in the Record column with a muted `(deleted)` tag, sourced from the audit row's snapshot.
- `?contract=N` URL filter narrows the list to a single contract's history; "Show only this contract's history" inside any expanded contract row jumps there.
- Hard wipes are consolidated under Settings → Data control → Delete data (single dropdown).

**Users**
- Roles: `superadmin` (singleton), `admin`, `user`.
- Freeze / unfreeze flow — frozen accounts are bounced to login on next request via `EnforceFrozenAccount` middleware.
- Per-user expandable login history (last 25 logins with IP and user-agent).
- Password reset by another user (audit-logged).

**Profile**
- Self-service name / email update with field-level diff audit (`user_updated`).
- Password change (Breeze).
- Account self-deletion. *Caveat:* `audit_logs.user_id` currently cascade-deletes with the user — see the audit-log section in [`CLAUDE.md`](CLAUDE.md).

---

## Roles

| Capability | superadmin | admin | user |
|---|:---:|:---:|:---:|
| Browse Contracts (read-only) | ✅ | ✅ | ✅ |
| Browse Indices (read-only) | ✅ | ✅ | ✅ |
| Indices export CSV | ✅ | ✅ | ✅ |
| View attachments (download) | ✅ | ✅ | ✅ |
| Open contract dialogs (read-only view of CPA / Extension / Notice / Tender / Edit) | ✅ | ✅ | ✅ |
| View Reports | ✅ | ✅ | ✅ |
| Edit own profile | ✅ | ✅ | ✅ |
| Contract write (Add / Edit / Delete / Import / Export / Settings) | ✅ | ✅ | ❌ |
| Contract attachment upload + detach | ✅ | ✅ | ❌ |
| Indices write (Add / Edit / Delete / Import / Clear) | ✅ | ✅ | ❌ |
| View Audit log | ✅ | ✅ | ❌ |
| Manage Users | ✅ | ✅ | ❌ |
| View Settings page | ✅ | ✅ | ❌ |
| See superadmin row in Users management | ✅ | ❌ | ❌ |
| See superadmin's audit-log entries | ✅ | ❌ | ❌ |
| Per-user login-log history | ✅ | ❌ | ❌ |
| Promote anyone to superadmin | ❌ (singleton) | ❌ | ❌ |
| Data control (Settings → Snapshot / Clear log / Delete log / Delete attachments / Upload limits) | ✅ | ❌ | ❌ |

**Hardening notes:**

- `superadmin` is a **singleton** — cannot be demoted, frozen, or deleted, even by themselves.
- Admin user-management writes (Add / Edit / Delete) require a fresh password confirmation via Breeze's `password.confirm` middleware.
- Every Data-control action (Settings) requires the operator to re-enter their own password inline; the server hashes-and-compares before mutating state.
- Read-only `user` role can click contract dialogs to *view* the data + linked attachments, but every write input is `disabled` / `readonly` and the Save button is hidden. Server-side, the write routes 403 for `user` regardless of UI state.

---

## CPI data pipeline

Single entry point: `php artisan cpi:refresh`.

1. **`OnsReleaseScraperService`** — scrapes `Release date` + `Next release` from the ONS dataset HTML page. Date guards reject anything outside `2015-01-01` → `now + 2 years`.
2. **`OnsCpiSeriesService`** — fetches D7BT monthly observations from the ONS time-series JSON API (<https://www.ons.gov.uk/economy/inflationandpriceindices/timeseries/d7bt/mm23/data>). HTTP retries 3× with linear back-off, 5 MB response cap, ascending-sorted output, pre-2015 entries filtered.
3. **`CpiRowSanitiser`** — every observation goes through this before persisting: BOM strip, whitespace/quote trim, formula-injection guard (`= + @ |`), CPI range check (1–1000), month range check (1990–2050), normalisation to `Y-m-d` first-of-month + 1-decimal CPI.
4. **`RefreshCpi`** — orchestrates all of the above in a single transaction. New months insert as `source = ons_feed`. Existing `manual_override` rows are **skipped**. Existing rows with a different value are treated as ONS revisions and updated. Recalculates dependent CPA rates only when something actually changed. Writes a single `cpi_refresh` audit entry. Supports `--dry-run`.

**Local schedule:** `routes/console.php` runs `cpi:refresh` daily at 08:00 Europe/London. Requires `php artisan schedule:work` running, or a Windows Task Scheduler entry hitting `php artisan schedule:run` every minute.

**CI schedule:** `.github/workflows/cpi-refresh.yml` runs `cpi:refresh` daily at 07:30 UTC. When DB changes occur it auto-commits `database/database.sqlite` with `[skip ci]`. Supports `workflow_dispatch` with `dry_run = true`.

When extending the pipeline, **reuse the sanitiser** — never persist values that have not passed through it.

---

## Business-logic gotchas

These are non-obvious rules baked into the code; changing them silently will break downstream calculations.

- **CPI index stored to exactly 1 decimal place.** Validated on input with `/^\d+\.\d$/`. Matches ONS published precision.
- **TFL P2P / RA lags.** The displayed rate at month *M* is the rate **applied to** *M* — not the rate computed from *M*'s own CPI. P2P uses a **4-month lag**, RA uses a **1-month-shifted window**:
  - `yoy_change[M]  = (CPI[M] − CPI[M-12]) / CPI[M-12]`
  - `p2p_rate[M]    = yoy_change[M-4] × 0.85`
  - `ra_rate[M]     = AVERAGE(yoy_change[M-12 … M-1]) × 0.85`
  - These match the `CPA - USED` columns in the canonical `NEW REVENUE DATA BASE` spreadsheet exactly. The unit test `tests/Unit/CpiRateServiceTest.php :: it matches the canonical Excel values for March 2026` pins this.
- **Round-half-up at 8 dp for P2P / RA / YoY** — Excel's default rounding. Implemented in `CpiRateService::roundHalfUp()`.
- **RA rate requires 25 months of CPI history** (M-24 through M-1, plus M-12 for YoY). Insufficient history → `ra_rate` is `null`, never estimated. P2P needs 16 months.
- **Period-aware MAXIFS** — when calculating which CPA rate applies to a contract in a given period, only count confirmed years whose anniversary has passed by the period end date. A future confirmation must not affect a past period.
- **Never overwrite manual overrides with feed data.** The CPI refresh skips rows with `source = manual_override`.
- **Revenue formula uses dynamic period lengths** — never hardcode 28 days. Always compute as `period_end - period_start + 1`.
- **Cross-year periods (e.g. P10, Dec–Jan)** affect the delay-CPA accrual logic. The trigger is `YEAR(period_start) ≠ YEAR(period_end)`.

---

## Useful commands

```bash
# Refresh ONS data manually (CPI + RPI, cascades CPA)
php artisan cpi:refresh

# Run a refresh in dry-run mode (no DB writes)
php artisan cpi:refresh --dry-run

# Re-seed contracts from the canonical CSV (idempotent)
php artisan db:seed --class=ContractsSeeder

# Discover all artisan commands available
php artisan list
```

---

## Production deployment (Coolify VPS)

There is no live hosted instance of this app. The notes below document how
it *was* deployed — built from `main` and auto-deployed via a
`contract-manager` GitHub App webhook — so anyone self-hosting can
reproduce the setup. Read end-to-end before deploying from scratch.

### Architecture

| Layer | Production | Local (Herd) |
|---|---|---|
| Web | Coolify → Traefik (SSL termination) → app container | Herd → `https://contract-manager.test` |
| App | Docker container, custom Dockerfile, `serversideup/php:8.4-fpm-nginx` on port 8080 | Native PHP 8.4 via Herd |
| Database | PostgreSQL 18 (Coolify managed service, internal Docker network) | SQLite (`database/database.sqlite`) |
| Build | Custom Dockerfile (multi-stage: node + PHP) | N/A — Herd serves source directly |
| Source | GitHub App ↔ private repo | Local git checkout |
| Secrets | Coolify Environment Variables | Local `.env` (gitignored) |
| Cron | Coolify Scheduled Tasks | `php artisan schedule:work` or Windows Task Scheduler |

### Why a Dockerfile and not Nixpacks

We started with Nixpacks (Coolify's default) and hit two issues that made
us switch to a hand-written Dockerfile:

1. **OOM during build.** The Nix package install phase peaks at ~1.5–2 GB
   RAM and got killed silently on a 4 GB VPS where Coolify + Postgres were
   already using ~2 GB. Worked around by adding 4 GB swap (see below).
2. **Broken nginx template.** Nixpacks' PHP nginx template renders two
   `location /` blocks for Laravel apps, so nginx fails to start with
   `nginx: [emerg] duplicate location "/" in /nginx.conf:47` and the
   container crash-loops. Setting `NIXPACKS_PHP_ROOT_DIR=/app/public` and
   `NIXPACKS_PHP_FALLBACK_PATH=/index.php?$query_string` did NOT fix it.

The handwritten [`Dockerfile`](Dockerfile) sidesteps both: smaller image
(~400 MB vs Nixpacks' ~1.5 GB), faster builds (~30s on warm cache),
predictable nginx config (`serversideup/php` ships a Laravel-tuned one).
Multi-stage layout:

- **Stage 1 (`frontend`)** — `node:22-alpine`, `npm ci`, `npm run build`
- **Stage 2 (`runtime`)** — `serversideup/php:8.4-fpm-nginx`, installs
  `pdo_pgsql` + `bcmath` PHP extensions, copies app + assets, runs
  `composer install --no-dev --optimize-autoloader`, mkdirs Laravel's
  storage subdirs, exposes port 8080.

### One-time VPS setup

```bash
# Add 4 GB swap so Docker builds (and any future memory spikes) have headroom.
sudo fallocate -l 4G /swapfile && \
sudo chmod 600 /swapfile && \
sudo mkswap /swapfile && \
sudo swapon /swapfile && \
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

(After switching to the Dockerfile this is no longer strictly required —
the build peaks at ~300 MB — but it costs nothing and provides a safety
buffer for Redis / queue workers / etc. later.)

### One-time Coolify setup

1. **Source — GitHub App.** Sources → + Add → GitHub App, install on the
   `farhanmunim/bus-contracts-manager` repo only. SSH deploy keys *also* work
   but the GitHub App provides webhook auto-deploys on push.
2. **Database — PostgreSQL 18.** Databases → + Add → PostgreSQL, accept
   defaults. Note the Postgres password (rotate later).
3. **App resource.** Create from the GitHub App source (not "Public Repository") so push-to-deploy webhooks wire up.

   On the initial **Create a new Application** form Coolify defaults to Nixpacks + port 3000. **Change both before clicking Continue:**
   - Build Pack: **Dockerfile** (not Nixpacks — see "Why a Dockerfile and not Nixpacks" above)
   - Port: **8080**

   Then on the full Configuration page:
   - Domains: `https://contract-manager.example.com`
   - Network → Ports Exposes: **8080** (verify it carried over)
   - Network → Port Mappings: **leave empty** (Traefik handles routing — the `3000:3000` you see in the field is placeholder text, not a value)

   **After changing the port or domain, click `Reset Labels to Defaults`** in the Labels section. Container labels are generated at resource-creation time and don't auto-update when you change the port/domain afterwards — without resetting, Traefik will route `contract-manager.example.com` to port 3000 inside the container and you get 502s. After resetting, verify the labels reference port 8080 (lines with `loadbalancer.server.port` and `{{upstreams ...}}`) and your real domain (`Host(`contract-manager.example.com`)` and `caddy_0=https://contract-manager.example.com`).
4. **Environment Variables (Developer view).** Paste:
   ```env
   APP_NAME="Bus Contracts Manager"
   APP_ENV=production
   APP_KEY=base64:GENERATE-FRESH-via-php-artisan-key:generate-show
   APP_DEBUG=false
   APP_URL=https://contract-manager.example.com
   APP_LOCALE=en
   APP_FALLBACK_LOCALE=en
   DB_CONNECTION=pgsql
   DB_HOST=<postgres-uuid-only>     # NOT 'postgresql-database-<uuid>'; see gotcha below
   DB_PORT=5432
   DB_DATABASE=postgres
   DB_USERNAME=postgres
   DB_PASSWORD=<from postgres service>
   SESSION_DRIVER=database
   SESSION_LIFETIME=120
   SESSION_DOMAIN=contract-manager.example.com
   SESSION_SECURE_COOKIE=true
   CACHE_STORE=database
   QUEUE_CONNECTION=database
   MAIL_MAILER=log
   MAIL_FROM_ADDRESS="no-reply@example.com"
   MAIL_FROM_NAME="${APP_NAME}"
   TURNSTILE_SITE_KEY=<real key>
   TURNSTILE_SECRET_KEY=<real key>
   ```

   - **`APP_NAME` is the display name**, not the hostname. Use `Bus Contracts Manager`, not `contract-manager.example.com` — it surfaces in page titles and the `MAIL_FROM_NAME="${APP_NAME}"` email From header.
   - **Generate a fresh `APP_KEY`** — never reuse the local one. On Windows PowerShell where `php artisan key:generate --show` may not be available (e.g. before `composer install`):
     ```powershell
     $bytes = New-Object byte[] 32; [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes); "base64:" + [Convert]::ToBase64String($bytes)
     ```
     Produces an identical-format 32-byte base64 key. Paste into the `APP_KEY=` line.
   - **Do NOT add `NIXPACKS_*` env vars.** PHP and Node versions are pinned in the Dockerfile (`serversideup/php:8.4-fpm-nginx`, `node:22-alpine`). Nixpacks vars are dead weight when you've switched build packs.
   - **Coolify's "Build-time environment variable warning: APP_ENV=production" is safe to ignore.** It's a generic Nixpacks warning. In Dockerfile builds env vars aren't passed into the build context unless declared as `ARG` (this repo's Dockerfile doesn't), so `APP_ENV` only takes effect at *runtime* — which is exactly what's wanted.

5. **First deploy** → click ▶ Deploy. Build takes ~3-5 min the first
   time (mostly composer + npm download).
6. **Migrations run automatically on container start** (commit `ea7f479`). The Dockerfile entrypoint runs `php artisan migrate --force` before nginx + php-fpm come up, so a fresh database is migrated on first boot and any new migrations run on every subsequent deploy without intervention. You do **not** need to add a post-deployment migrate command in Coolify — leave Pre/Post-deployment Commands blank. (If you ever want a belt-and-braces second run, `php artisan migrate --force` from the Terminal tab is safe and idempotent.)
7. **Bootstrap the first superadmin.** `/register` is hard-coded to
   `abort(404)` in [`routes/auth.php`](routes/auth.php) — there is
   no first-run gate. Use the same temporarily-re-enable / register /
   promote / re-disable flow documented under [First-time setup —
   bootstrapping a superadmin](#first-time-setup--bootstrapping-a-superadmin)
   above, with these production-specific tweaks:
   - Edit `routes/auth.php` on the server (Coolify Terminal tab),
     re-deploy or just clear the route cache so the change is picked up.
   - Promote via SQL from the Coolify Terminal:
     ```bash
     psql -h "$DB_HOST" -U "$DB_USERNAME" -d "$DB_DATABASE" \
       -c "UPDATE users SET role = 'superadmin' WHERE email = 'you@example.com';"
     ```
   - Revert `routes/auth.php`, commit, push — Coolify auto-deploys.
9. **Schedule CPI refresh** — Coolify → app → **Scheduled Tasks** (in the same left sidebar as General / Environment Variables) → + Add:
   - Name: `CPI refresh`
   - Command: `php artisan cpi:refresh`
   - Frequency: `0 7 * * *` (daily 07:00 UTC, after ONS publishes around 07:00 UK time)
   - Timeout: leave default (300s — `cpi:refresh` typically runs in 10–20s)
   - Container name: leave blank (runs in the default app container)
10. **Populate ONS data** once via Terminal:
    ```bash
    php artisan cpi:refresh
    ```

### Gotchas / workarounds (each one bit us at least once)

- **Start the Postgres service before deploying the app.** Coolify
  creates databases in `Exited` state — click ▶ Start on the Postgres
  resource and wait for the status badge to turn green before kicking
  off the first app deploy. If the app boots first, the entrypoint
  migration step hits `Connection refused` and the container
  crash-loops.
- **`DB_HOST` is the UUID only.** Coolify's UI shows the Postgres service
  name as `postgresql-database-<uuid>`, but the network alias inside the
  Coolify Docker network is just `<uuid>`. Use the bare UUID in `DB_HOST`
  or you'll get `could not translate host name ... Temporary failure in
  name resolution`. Confirm from inside the app container with
  `getent hosts <uuid>`.
- **Trust the proxy or HTTPS detection breaks.** Coolify fronts with
  Traefik (terminates SSL, forwards plain HTTP with `X-Forwarded-Proto:
  https`). Without `$middleware->trustProxies(at: '*')` in
  `bootstrap/app.php` Laravel sees HTTP, generates `http://` asset URLs,
  and Chrome blocks them as mixed content (CSS won't load). Already
  configured in this repo.
- **Generate a fresh `APP_KEY` for production.** Never reuse the local
  one — it's been in git history since the initial commit. Run
  `php artisan key:generate --show` locally and paste the output into
  Coolify env vars.
- **PHP extensions: `pdo_pgsql` and `bcmath`.** `serversideup/php` ships
  with sqlite/mysql but not Postgres or BCMath. The Dockerfile installs
  both. Without BCMath, `cpi:refresh` fails with `Call to undefined
  function bcsub()`.
- **Storage directories must exist in the container.** The `.dockerignore`
  excludes `storage/framework/views/*` to keep stale cache out of the
  image, which also drops the `.gitkeep` files. The Dockerfile
  `mkdir -p`s them at build time — without it Blade throws "Please
  provide a valid cache path" on first request.
- **Don't put migrations in Coolify's Pre/Post-deployment hooks.**
  Migrations run automatically from the Dockerfile entrypoint (commit
  `ea7f479`) before nginx starts. Adding them to Coolify's hooks is
  redundant and adds a second failure surface. (Historical note: an
  earlier version of these docs recommended Post-deployment because
  pre-deployment runs against the OLD container — silently skipped on
  first deploy and fails when the current container is crash-looping.
  Moving migration into the entrypoint sidesteps both problems.)
- **Postgres is strict about boolean comparisons.** SQLite accepts
  `is_actual = 0`; Postgres errors with `operator does not exist:
  boolean = integer`. Always use `IS TRUE` / `IS FALSE` in raw
  `DB::statement` calls so migrations work on both drivers. Surfaced
  in `2026_05_07_005206_add_source_to_cpi_index_entries_table` — fixed
  there.
- **CPI / RPI data is empty on a fresh DB.** The local sqlite snapshot
  came pre-seeded; production starts blank. Run `php artisan cpi:refresh`
  once after migrations to populate ONS data and recalculate CPA rates.
- **The CPA columns hide if no anchor year is set.** Defaults baked into
  `AppSetting` (`DEFAULT_CONTRACTS_ANCHOR_YEAR = 2024`,
  `DEFAULT_CONTRACTS_P2P_RA_CUTOFF = '2020-08-01'`) so they render
  immediately without forcing the operator into Settings first.

### Maintenance

- **Manual deploy** — Coolify → app → ▶ Deploy. Auto-deploy fires on
  every push to `main` via the GitHub App webhook.
- **Migrations on every deploy** — handled automatically by the
  Dockerfile entrypoint (commit `ea7f479`). Leave Pre/Post-deployment
  Commands blank.
- **Logs** — Logs tab (runtime stdout/stderr) and Deployments tab
  (build logs). For deeper diagnosis, Terminal → `tail -100
  storage/logs/laravel.log`.
- **CPI refresh** — daily via Coolify Scheduled Task, or manually from
  Terminal: `php artisan cpi:refresh`.

### Database backup & restore

The app ships an in-app **export** for both drivers; **restore** is
intentionally a manual terminal step (in-app restore is destructive
in subtle ways — see roadmap notes).

**Export — production (Postgres):**
1. Sign in as superadmin → Settings → Data control → **Download
   database snapshot** → enter your password → confirm.
2. The browser downloads
   `bus-contracts-manager-snapshot-YYYY-MM-DD-HHMMSS.sql.gz` —
   gzipped output of `pg_dump --clean --if-exists --no-owner
   --no-privileges`. The dump is portable: any same-major-version
   Postgres can replay it (16 / 17 / 18 are all fine here).
3. Store the file somewhere offline (laptop, S3, Drive — your call).

**Export — local (SQLite):**
Same Settings button. Downloads a `.sqlite` file that IS the database.
Restore = drop the file in `database/database.sqlite`.

**Restore — production (Postgres):**
1. Open Coolify → app → **Terminal**.
2. Upload the `.sql.gz` file to the container. From your laptop:
   ```
   docker cp snapshot.sql.gz <container>:/tmp/snapshot.sql.gz
   ```
   (Or paste the SQL directly into the terminal if it's small.)
3. From the container shell:
   ```
   gunzip -c /tmp/snapshot.sql.gz \
     | psql -h "$DB_HOST" -U "$DB_USERNAME" -d "$DB_DATABASE" \
            --single-transaction -v ON_ERROR_STOP=1
   ```
   `--single-transaction -v ON_ERROR_STOP=1` makes the restore atomic
   — any error rolls the whole thing back, leaving the database
   untouched.
4. After a successful restore, **sign out and back in.** Your existing
   session row was just overwritten with the snapshot's session table,
   so the cookie won't validate any more.
5. Clean up: `rm /tmp/snapshot.sql.gz`.

**Restore — local (SQLite):**
1. Stop Herd or quit anything else accessing the DB.
2. Replace `database/database.sqlite` with your snapshot file.
3. Start Herd, sign in.

**Why no in-app restore button?** Three reasons that compound:
- The restore can take seconds-to-minutes; every other request hits
  a partially-restored DB during the window.
- The current operator's session row gets overwritten mid-flight;
  they can be silently logged out into a state they can't sign back
  into (e.g. the snapshot pre-dates their account, or has a
  different password hash).
- A failed restore is destructive and there's no in-app rollback —
  the operator would need terminal access anyway to recover.
  Putting the button in the UI implies a safety net that doesn't
  exist.

---

## Roadmap

Lives at `/roadmap` in the running app (admin-only, under **Tools**). The source of truth is [`config/roadmap.php`](config/roadmap.php) — edit that file to add, change, or close out items. Status keys: `idea` · `planned` · `in_progress` · `shipped` · `paused`.
