<?php

declare(strict_types=1);

/**
 * Internal product roadmap. Rendered at /roadmap by RoadmapController.
 *
 * Status keys map 1:1 to badge variants in `resources/css/app.css`:
 *   - idea         → badge--neutral
 *   - planned      → badge--info
 *   - in_progress  → badge--warning
 *   - shipped      → badge--success
 *   - paused       → badge--destructive
 *
 * Order in the array is preserved; group items roughly by area so the
 * page reads top-to-bottom as a working backlog. Keep descriptions to
 * one short sentence — the page is a scan-and-pick view, not a spec.
 */

return [
    'statuses' => [
        'idea' => ['label' => 'Idea', 'badge' => 'badge--neutral'],
        'planned' => ['label' => 'Planned', 'badge' => 'badge--info'],
        'in_progress' => ['label' => 'In progress', 'badge' => 'badge--warning'],
        'shipped' => ['label' => 'Shipped', 'badge' => 'badge--success'],
        'paused' => ['label' => 'Paused', 'badge' => 'badge--destructive'],
    ],

    'items' => [
        // ─── Audit ───
        [
            'title' => 'Restore data / revert from audit log',
            'description' => 'Roll a record back to a chosen audit-log point. Per-row revert plus a bulk restore-to-timestamp.',
            'status' => 'idea',
            'area' => 'Audit',
        ],

        // ─── Attachments / evidence ───
        // First in `planned` because the Documents page (shipping
        // separately) gives us 90% of the picker's UI; this is the
        // natural follow-up.
        [
            'title' => 'Pick existing attachment in evidence fields',
            'description' => 'Evidence inputs gain a "select existing file" option alongside upload — links to an already-uploaded attachment via attachment_links instead of duplicating bytes. Dedup via sha256 + a search picker that reuses the Documents page query. New audit action: contract_evidence_linked.',
            'status' => 'planned',
            'area' => 'Attachments',
        ],

        // ─── Reports + Indices imports/foundations (build first) ───
        [
            'title' => 'Hyperion reports import',
            'description' => 'Upload Hyperion Excel exports (.xls / .xlsx); parse + store. Prerequisite for the cash / accruals / claim reports.',
            'status' => 'planned',
            'area' => 'Reports',
        ],
        [
            'title' => 'Settlement statements import',
            'description' => 'Upload TfL settlement statement PDFs; extract per-period figures. Prerequisite for final / intermediate claims.',
            'status' => 'planned',
            'area' => 'Documents',
        ],
        [
            'title' => 'CEBR and DERV pages',
            'description' => 'Promote the coming-soon stubs into real index pages. Prerequisite for cash / accruals forecasts that consume them.',
            'status' => 'planned',
            'area' => 'Indices',
        ],
        [
            'title' => 'Cash forecast page',
            'description' => 'Build out the coming-soon stub. Projects per-period cash by FY from contracts + CPA.',
            'status' => 'planned',
            'area' => 'Reports',
        ],
        [
            'title' => 'Accruals forecast page',
            'description' => 'Build out the coming-soon stub. Period-aware accruals incl. cross-year P10 logic.',
            'status' => 'planned',
            'area' => 'Reports',
        ],
        [
            'title' => 'Final claim page',
            'description' => 'Build out the coming-soon stub. Reconciles to settlement statements.',
            'status' => 'planned',
            'area' => 'Reports',
        ],
        [
            'title' => 'Intermediate claim page',
            'description' => 'Build out the coming-soon stub. In-period draft of the Final claim.',
            'status' => 'planned',
            'area' => 'Reports',
        ],
        [
            'title' => 'Forecast from a chosen date',
            'description' => 'Date picker on cash + accruals forecast: run as of any past date. Useful for back-testing.',
            'status' => 'idea',
            'area' => 'Reports',
        ],

        // ─── Contracts UX ───
        [
            'title' => 'Inline editing for low-stakes fields',
            'description' => 'Click-to-edit on miles / propulsion / decks. Skips the full Edit dialog for one-cell fixes.',
            'status' => 'idea',
            'area' => 'Contracts',
        ],
        [
            'title' => 'Bulk select + bulk CPA confirmation',
            'description' => 'Multi-select rows; apply a CPA confirmation to all in one dialog with a mandatory note.',
            'status' => 'idea',
            'area' => 'Contracts',
        ],
        [
            'title' => 'Mandatory note on every CPA confirmation',
            'description' => 'Make the CPA-confirmation note required so the audit trail always carries a reason.',
            'status' => 'idea',
            'area' => 'Contracts',
        ],

        // ─── Indices ───
        [
            'title' => 'Override-impact preview',
            'description' => 'Heads-up before saving a CPI override: how many dependent CPA rows will recalc.',
            'status' => 'idea',
            'area' => 'Indices',
        ],

        // ─── Settings / Data control ───
        [
            'title' => 'Targeted data delete',
            'description' => 'Dropdown: Audit · Contracts · Indices · Attachments · All. Each path transactional, password-confirmed.',
            'status' => 'shipped',
            'area' => 'Settings',
        ],
        [
            'title' => 'Section-unlock for Data control',
            'description' => 'Replace per-action password prompts with one 10-min unlock session and a manual lock-now banner.',
            'status' => 'idea',
            'area' => 'Settings',
        ],

        // ─── Attachments ───
        [
            'title' => 'Smarter attachment validation',
            'description' => 'Per-record dupe-name detection, DB-wide content-hash dedupe, and size-anomaly warnings.',
            'status' => 'idea',
            'area' => 'Attachments',
        ],

        // ─── Data lifecycle / archive pattern ───
        [
            'title' => 'Soft-delete (archive) pattern across the app',
            'description' => 'Per-record deletes (users, contracts, etc.) become soft archives — frozen + hidden from primary lists, moved to an "Archived" view. Audit history stays clean. Hard wipes only via Settings → Data control.',
            'status' => 'idea',
            'area' => 'Data lifecycle',
        ],

        // ─── Workflow / approvals ───
        [
            'title' => 'Approval workflow for writes',
            'description' => 'Gate add / edit / delete behind a reviewer sign-off. The change is staged, an approver gets notified, and only takes effect once approved. Per-section opt-in (start with Contracts).',
            'status' => 'idea',
            'area' => 'Approvals',
        ],

        // ─── Infrastructure / production hardening ───
        [
            'title' => 'SMTP / mailer wired up',
            'description' => 'Replace MAIL_MAILER=log with a real provider (Postmark / Resend / Mailgun).',
            'status' => 'planned',
            'area' => 'Infrastructure',
        ],
        [
            'title' => 'Real Cloudflare Turnstile keys',
            'description' => 'Swap dev "always-pass" Turnstile keys for real ones on the auth boundaries.',
            'status' => 'shipped',
            'area' => 'Infrastructure',
        ],
        [
            'title' => 'Rate-limit forgot-password',
            'description' => 'Per-IP + per-email throttle so the endpoint can\'t be enumerated or weaponised as a spam relay.',
            'status' => 'shipped',
            'area' => 'Infrastructure',
        ],
        [
            'title' => 'Security headers middleware',
            'description' => 'CSP / X-Frame / Referrer-Policy / Permissions-Policy on every response.',
            'status' => 'shipped',
            'area' => 'Infrastructure',
        ],

    ],
];
