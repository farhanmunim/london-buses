<?php

use App\Http\Controllers\AttachmentsController;
use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\ContractController;
use App\Http\Controllers\CpaController;
use App\Http\Controllers\DocumentsController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ReportsController;
use App\Http\Controllers\RoadmapController;
use App\Http\Controllers\RpiController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\UsersController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return auth()->check()
        ? redirect()->route('contracts.index')
        : redirect()->route('login');
});

Route::get('/dashboard', function () {
    return redirect()->route('contracts.index');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware(['auth'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::prefix('contracts')->name('contracts.')->group(function () {
        // Read paths — every authenticated user can browse contracts.
        // Export + template downloads are NOT in this group; per the
        // access matrix, the user role is read-only on contracts (no
        // export, no import). They live below under can.write.
        Route::get('/', [ContractController::class, 'index'])->name('index');

        // Write paths — gated to admin+ via the can.write alias.
        Route::middleware('can.write')->group(function () {
            Route::get('/export.csv', [ContractController::class, 'exportCsv'])->name('export');
            Route::get('/import-template.csv', [ContractController::class, 'importTemplate'])->name('import-template');
            Route::post('/import', [ContractController::class, 'importCsv'])->name('import');
            Route::post('/import-confirm', [ContractController::class, 'importConfirm'])->name('import-confirm');
            Route::post('/import-cancel', [ContractController::class, 'importCancel'])->name('import-cancel');
            Route::post('/', [ContractController::class, 'store'])->name('store');
            Route::post('/settings', [ContractController::class, 'updateSettings'])->name('settings.update');
            Route::patch('/{contract}', [ContractController::class, 'update'])->name('update');
            Route::patch('/{contract}/cpa-confirmation', [ContractController::class, 'updateCpaConfirmation'])->name('cpa-confirmation.update');
            Route::patch('/{contract}/extension', [ContractController::class, 'updateExtension'])->name('extension.update');
            Route::patch('/{contract}/notice-served', [ContractController::class, 'updateNoticeServed'])->name('notice-served.update');
            Route::patch('/{contract}/tender-award', [ContractController::class, 'updateTenderAward'])->name('tender-award.update');
            // Pre-flight check for the evidence-upload duplicate workflow.
            // Read-only; lives under the contract write group because the
            // dupe-check is only used by contract-section dialogs.
            Route::post('/check-attachment-duplicate', [AttachmentsController::class, 'checkDuplicate'])->name('check-attachment-duplicate');
            // Soft-detach an attachment LINK from its record-item slot.
            // Bytes + audit history stay; only the link's visibility
            // flag flips. The attachment itself sticks around for any
            // other slot that links to it. Replaces the legacy
            // /attachments/{attachment}/detach endpoint.
            Route::delete('/attachment-links/{link}/detach', [AttachmentsController::class, 'detachLink'])->name('attachment-links.detach');
            Route::delete('/{contract}', [ContractController::class, 'destroy'])->name('destroy');
            Route::patch('/{contract}/restore', [ContractController::class, 'restore'])->name('restore');
        });
    });

    Route::prefix('reports')->name('reports.')->group(function () {
        Route::get('/', [ReportsController::class, 'index'])->name('index');
        Route::get('/{report}', [ReportsController::class, 'show'])->name('show');
    });

    // Documents — top-level workspace section grouping every file
    // the app stores. Two sub-pages today (Attachments, Settlements
    // coming-soon). Auth-only: the data is the same set of files every
    // signed-in user can already reach by clicking through contracts.
    Route::prefix('documents')->name('documents.')->group(function () {
        Route::get('/', [DocumentsController::class, 'index'])->name('index');
        Route::get('/attachments', [DocumentsController::class, 'attachments'])->name('attachments');
        Route::get('/settlements', [DocumentsController::class, 'settlements'])->name('settlements');
    });

    // Audit log is admin-only. The user role can view contracts + indices
    // but not the underlying change log.
    // Attachment download is read-only and gated by the regular auth
    // middleware only — every signed-in user can download evidence
    // tied to contracts they can already view (user role included).
    // Admins still don't get to *act* on attachments outside their role.
    Route::get('/attachments/{attachment}/download', [AttachmentsController::class, 'download'])->name('attachments.download');

    Route::middleware('role.admin')->group(function () {
        Route::get('/audit-log', [AuditLogController::class, 'index'])->name('audit-log.index');
        Route::get('/roadmap', [RoadmapController::class, 'index'])->name('roadmap.index');

        Route::prefix('users')->name('users.')->group(function () {
            Route::get('/', [UsersController::class, 'index'])->name('index');

            // Add / edit / delete each require an inline password
            // re-confirmation (server-side via App\Support\PasswordConfirm,
            // client-side via the shared queueForPassword dialog). Same
            // pattern as Settings > Data control — replaces Breeze's
            // full-page password.confirm bounce so the user stays in
            // context.
            Route::post('/', [UsersController::class, 'store'])->name('store');
            Route::patch('/{user}', [UsersController::class, 'update'])->name('update');
            Route::delete('/{user}', [UsersController::class, 'destroy'])->name('destroy');
            Route::patch('/{user}/restore', [UsersController::class, 'restore'])->name('restore');
        });

        Route::prefix('settings')->name('settings.')->group(function () {
            Route::get('/', [SettingsController::class, 'index'])->name('index');
            // Targeted data delete — single destructive entry point.
            // Picks WHAT to wipe via a `type` param: audit_log, contracts,
            // indices, attachments, all. Superadmin only, password-
            // confirmed inline (server-side Hash::check), double-confirmed
            // in the UI. Per project policy, NOT audit-logged.
            Route::post('/delete-data', [SettingsController::class, 'deleteData'])
                ->middleware('role.superadmin')
                ->name('delete-data');
            // Configurable upload limits (file size cap + extension
            // whitelist) for evidence and template imports.
            Route::post('/upload-limits', [SettingsController::class, 'updateUploadLimits'])
                ->middleware('role.superadmin')
                ->name('upload-limits.update');
            Route::post('/upload-limits/reset', [SettingsController::class, 'resetUploadLimits'])
                ->middleware('role.superadmin')
                ->name('upload-limits.reset');
            // Database snapshot — superadmin only. Streams the live SQLite
            // file. When the app moves to PostgreSQL on Coolify this needs
            // to be reworked into a `pg_dump` SQL snapshot instead.
            // POST so a password field can be submitted alongside.
            // (See PasswordConfirm — every Data-control action gates on
            // the operator's own password.)
            Route::post('/database-snapshot', [SettingsController::class, 'downloadDatabaseSnapshot'])
                ->middleware('role.superadmin')
                ->name('database-snapshot');
        });
    });

    Route::prefix('indices')->name('indices.')->group(function () {
        // Read paths — viewable by every authenticated user (incl. role=user).
        // Exports are read-only and explicitly allowed for user role per
        // the access matrix; template downloads sit under can.write
        // because they're only useful for the import flow.
        Route::get('/', [CpaController::class, 'index'])->name('cpa');
        Route::get('/cpi', [CpaController::class, 'raw'])->name('cpi');
        Route::get('/export.csv', [CpaController::class, 'exportRates'])->name('export');
        Route::get('/rpi', [RpiController::class, 'index'])->name('rpi');
        Route::get('/rpi/export.csv', [RpiController::class, 'exportCsv'])->name('rpi.export');

        // Write paths — admin+ only. Mirrors the contracts pattern.
        Route::middleware('can.write')->group(function () {
            // Manual trigger for the same pipeline the daily scheduler runs.
            // Single endpoint covers CPI + RPI + cascaded CPA recalculation
            // — see CpaController::refreshOnsData.
            Route::post('/refresh', [CpaController::class, 'refreshOnsData'])->name('refresh');
            Route::get('/cpi/import-template.csv', [CpaController::class, 'importTemplate'])->name('cpi.import-template');
            Route::get('/cpa/import-template.csv', [CpaController::class, 'ratesImportTemplate'])->name('cpa.import-template');
            Route::get('/rpi/import-template.csv', [RpiController::class, 'importTemplate'])->name('rpi.import-template');
            // CPI tab actions
            Route::post('/cpi/import', [CpaController::class, 'importCsv'])->name('cpi.import');
            Route::post('/cpi/entries', [CpaController::class, 'storeIndexEntry'])->name('cpi.store');
            Route::patch('/cpi/entries/{cpiIndexEntry}', [CpaController::class, 'updateIndexEntry'])->name('cpi.update');
            Route::post('/cpi/entries/{cpiIndexEntry}/reset', [CpaController::class, 'resetCpiEntry'])->name('cpi.reset');
            Route::delete('/cpi/entries/{cpiIndexEntry}', [CpaController::class, 'destroyIndexEntry'])->name('cpi.destroy');
            Route::post('/cpi/clear-overrides', [CpaController::class, 'clearCpiOverrides'])->name('cpi.clear-overrides');
            Route::post('/cpi/clear-imports', [CpaController::class, 'clearCpiImports'])->name('cpi.clear-imports');

            // CPA tab actions
            Route::post('/cpa/import', [CpaController::class, 'importRates'])->name('cpa.import');
            Route::patch('/cpa/{cpaRate}', [CpaController::class, 'updateRate'])->name('cpa.update');
            Route::post('/cpa/{cpaRate}/reset', [CpaController::class, 'resetRate'])->name('cpa.reset');
            Route::post('/cpa/clear-overrides', [CpaController::class, 'clearCpaOverrides'])->name('cpa.clear-overrides');

            // RPI tab actions
            Route::post('/rpi/import', [RpiController::class, 'importCsv'])->name('rpi.import');
            Route::post('/rpi/entries', [RpiController::class, 'storeEntry'])->name('rpi.store');
            Route::patch('/rpi/entries/{rpiIndexEntry}', [RpiController::class, 'updateEntry'])->name('rpi.update');
            Route::post('/rpi/entries/{rpiIndexEntry}/reset', [RpiController::class, 'resetEntry'])->name('rpi.reset');
            Route::delete('/rpi/entries/{rpiIndexEntry}', [RpiController::class, 'destroyEntry'])->name('rpi.destroy');
            Route::post('/rpi/clear-overrides', [RpiController::class, 'clearOverrides'])->name('rpi.clear-overrides');
            Route::post('/rpi/clear-imports', [RpiController::class, 'clearImports'])->name('rpi.clear-imports');
        });

        // CEBR + DERV — coming-soon placeholders. Wired into the sidebar
        // so the future series are visible in the nav, but the views are
        // currently just the shared <x-coming-soon> component.
        Route::get('/cebr', fn () => view('indices.coming-soon', ['title' => 'CEBR', 'description' => 'Centre for Economics and Business Research forecasts.']))->name('cebr');
        Route::get('/derv', fn () => view('indices.coming-soon', ['title' => 'DERV', 'description' => 'Diesel-engined road vehicle (DERV) fuel-price index.']))->name('derv');
    });
});

require __DIR__.'/auth.php';
