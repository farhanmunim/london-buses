<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// ONS publishes CPI bulletins around 07:00 UK time on the third Wednesday
// each month, so we sweep daily at 08:00 to catch the new release shortly
// after publication. The scrape itself is idempotent — re-running on a day
// without a new release is cheap (it just confirms nothing changed).
Schedule::command('cpi:refresh')
    ->dailyAt('08:00')
    ->timezone('Europe/London')
    ->withoutOverlapping(60)
    ->onFailure(function () {
        logger()->warning('cpi:refresh schedule run failed.');
    });
