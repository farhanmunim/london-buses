/**
 * Headless screenshot of the v4 audit log: collapsed list + one expanded
 * row. Run locally with your credentials so the script can authenticate.
 *
 *   $env:APP_USER='admin@example.com'
 *   $env:APP_PASS='your-password'
 *   node scripts/review-audit-log.mjs
 *
 * Output: storage/app/screenshots/audit-log-collapsed.png
 *         storage/app/screenshots/audit-log-expanded.png
 */

import puppeteer from 'puppeteer';
import { mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const outDir = resolve(__dirname, '..', 'storage', 'app', 'screenshots');
await mkdir(outDir, { recursive: true });

const APP_BASE = process.env.APP_URL ?? 'https://bcm.test';
const APP_USER = process.env.APP_USER;
const APP_PASS = process.env.APP_PASS;

if (!APP_USER || !APP_PASS) {
    console.error('Missing APP_USER / APP_PASS env vars. Set them and re-run.');
    process.exit(1);
}

const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--ignore-certificate-errors'],
});

try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 1 });

    // Login
    await page.goto(`${APP_BASE}/login`, { waitUntil: 'networkidle2' });
    await page.type('#email', APP_USER);
    await page.type('#password', APP_PASS);
    await Promise.all([
        page.click('button[type="submit"]'),
        page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {}),
    ]);

    // v4 collapsed
    await page.goto(`${APP_BASE}/audit-log`, { waitUntil: 'networkidle2' });
    await page.screenshot({ path: `${outDir}/audit-log-collapsed.png`, fullPage: true });
    console.log('✓ audit-log-collapsed.png');

    // Expand first row that has a diff (skip Imported / Feed refresh which are usually thin)
    const expanded = await page.evaluate(() => {
        const rows = document.querySelectorAll('.audit-log-event-row');
        for (const row of rows) {
            const badge = row.querySelector('.badge');
            const label = badge ? badge.textContent.trim() : '';
            if (!['Imported', 'Feed refresh'].includes(label)) {
                row.click();
                return label;
            }
        }
        rows[0]?.click();
        return null;
    });
    await new Promise(r => setTimeout(r, 300)); // let Alpine animate
    await page.screenshot({ path: `${outDir}/audit-log-expanded.png`, fullPage: true });
    console.log(`✓ audit-log-expanded.png (expanded row action: ${expanded ?? 'first available'})`);

    await page.close();
} finally {
    await browser.close();
}

console.log(`\nScreenshots in ${outDir}`);
