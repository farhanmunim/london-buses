import puppeteer from 'puppeteer';
import { mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const outDir = resolve(__dirname, '..', 'storage', 'app', 'screenshots');
await mkdir(outDir, { recursive: true });

const APP_BASE = process.env.APP_URL ?? 'http://contract-manager.test';
const APP_LOGIN = `${APP_BASE}/login`;
const APP_USER = process.env.APP_USER ?? 'test@example.com';
const APP_PASS = process.env.APP_PASS ?? 'password';

const targets = [
    { name: 'shadcn-home', url: 'https://ui.shadcn.com/' },
    { name: 'shadcn-dashboard', url: 'https://ui.shadcn.com/blocks/dashboard' },
    { name: 'shadcn-table', url: 'https://ui.shadcn.com/docs/components/data-table' },
    { name: 'shadcn-button', url: 'https://ui.shadcn.com/docs/components/button' },
    { name: 'shadcn-card', url: 'https://ui.shadcn.com/docs/components/card' },
];

const appTargets = [
    { name: 'app-indices-cpi', path: '/indices/cpi' },
    { name: 'app-indices-cpa', path: '/indices' },
    { name: 'app-audit-log', path: '/audit-log' },
    { name: 'app-contracts', path: '/contracts' },
    { name: 'app-reports', path: '/reports' },
    { name: 'app-profile', path: '/profile' },
];

const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'] });

try {
    const ctx = await browser.createBrowserContext();

    // Public targets
    for (const t of targets) {
        const page = await ctx.newPage();
        await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 1 });
        try {
            await page.goto(t.url, { waitUntil: 'networkidle2', timeout: 30000 });
            await page.screenshot({ path: `${outDir}/${t.name}.png`, fullPage: true });
            console.log(`✓ ${t.name}`);
        } catch (e) {
            console.log(`✗ ${t.name}: ${e.message}`);
        }
        await page.close();
    }

    // Authenticate then app pages
    const page = await ctx.newPage();
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 1 });
    try {
        await page.goto(APP_LOGIN, { waitUntil: 'networkidle2', timeout: 15000 });
        await page.screenshot({ path: `${outDir}/app-login.png`, fullPage: true });
        await page.type('#email', APP_USER);
        await page.type('#password', APP_PASS);
        await Promise.all([
            page.click('button[type="submit"]'),
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {}),
        ]);
        console.log('✓ app-login (auth)');
    } catch (e) {
        console.log(`✗ app-login: ${e.message}`);
    }

    for (const t of appTargets) {
        try {
            await page.goto(`${APP_BASE}${t.path}`, { waitUntil: 'networkidle2', timeout: 15000 });
            // First-fold (above the fold) for clearer review
            await page.screenshot({ path: `${outDir}/${t.name}.png`, fullPage: false });
            await page.screenshot({ path: `${outDir}/${t.name}-full.png`, fullPage: true });
            console.log(`✓ ${t.name}`);
        } catch (e) {
            console.log(`✗ ${t.name}: ${e.message}`);
        }
    }

    await page.close();
    await ctx.close();
} finally {
    await browser.close();
}

console.log(`\nScreenshots in ${outDir}`);
