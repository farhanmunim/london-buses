/**
 * Headless screenshot of /documents.
 *
 *   $env:APP_USER='test@test.com'
 *   $env:APP_PASS='test12345'
 *   node scripts/review-documents.mjs
 */

import puppeteer from 'puppeteer';
import { mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const outDir = resolve(__dirname, '..', 'storage', 'app', 'screenshots');
await mkdir(outDir, { recursive: true });

const APP_BASE = process.env.APP_URL ?? 'https://bcm.test';
const APP_USER = process.env.APP_USER ?? 'test@test.com';
const APP_PASS = process.env.APP_PASS ?? 'test12345';

const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--ignore-certificate-errors'],
});

try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 1100, deviceScaleFactor: 1 });

    await page.goto(`${APP_BASE}/login`, { waitUntil: 'networkidle2' });
    await page.type('#email', APP_USER);
    await page.type('#password', APP_PASS);
    await Promise.all([
        page.click('button[type="submit"]'),
        page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {}),
    ]);

    await page.goto(`${APP_BASE}/documents`, { waitUntil: 'networkidle2' });
    await page.screenshot({ path: `${outDir}/documents.png`, fullPage: true });
    console.log(`Saved: ${outDir}/documents.png`);
} finally {
    await browser.close();
}
