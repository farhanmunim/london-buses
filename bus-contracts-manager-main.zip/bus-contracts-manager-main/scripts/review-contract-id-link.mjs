/**
 * Verify the #id contract search works end-to-end:
 *   1. Login
 *   2. Navigate to /contracts?q=%2342 (whatever id we pluck)
 *   3. Confirm the table renders one matching row (or "No contracts" if id absent)
 */

import puppeteer from 'puppeteer';
import { mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const outDir = resolve(__dirname, '..', 'storage', 'app', 'screenshots');
await mkdir(outDir, { recursive: true });

const APP_BASE = process.env.APP_URL ?? 'https://bcm.test';
const APP_USER = process.env.APP_USER ?? 'test@test.com';
const APP_PASS = process.env.APP_PASS ?? 'test12345';

const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--ignore-certificate-errors'],
});

try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 1100, deviceScaleFactor: 1 });

    await page.goto(`${APP_BASE}/login`, { waitUntil: 'networkidle2' });
    await page.type('#email', APP_USER);
    await page.type('#password', APP_PASS);
    await Promise.all([
        page.click('button[type="submit"]'),
        page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {}),
    ]);

    // Fetch contracts table to find a real id
    await page.goto(`${APP_BASE}/contracts`, { waitUntil: 'networkidle2' });
    const firstId = await page.evaluate(() => {
        const cell = document.querySelector('tbody tr td:first-child');
        return cell ? cell.textContent.trim() : null;
    });
    console.log(`First visible contract id: ${firstId}`);

    if (firstId) {
        await page.goto(`${APP_BASE}/contracts?q=%23${firstId}`, { waitUntil: 'networkidle2' });
        await page.screenshot({ path: `${outDir}/contracts-id-search.png`, fullPage: false });
        const rowCount = await page.evaluate(() => document.querySelectorAll('tbody tr').length);
        console.log(`Rows after q=#${firstId}: ${rowCount}`);
    }
} finally {
    await browser.close();
}
