#!/usr/bin/env bash
#
# Run any pending database migrations before nginx + php-fpm boot.
#
# serversideup/php images source every executable script in
# /etc/entrypoint.d/ (alphabetical order) before handing off to s6 to
# start the supervised processes. Putting the migrate step here means:
#
#   - if migrations succeed, the container goes healthy and Coolify
#     promotes it; the new app version + the new schema land together;
#   - if migrations fail (bad SQL, locked schema, perms), the script
#     exits non-zero, the container never reaches healthy, and Coolify
#     keeps the previous container live — no half-deployed state.
#
# `--force` is required because Laravel refuses migrations in
# production by default. `--no-interaction` is belt-and-braces.
set -e

cd /var/www/html

echo "[entrypoint] Running pending database migrations..."
php artisan migrate --force --no-interaction
echo "[entrypoint] Migrations applied."
