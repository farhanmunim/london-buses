<?php

use App\Http\Middleware\EnforceFrozenAccount;
use App\Http\Middleware\RequireAdminRole;
use App\Http\Middleware\RequireSuperadminRole;
use App\Http\Middleware\RequireWriteAccess;
use App\Http\Middleware\SecurityHeaders;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Trust Coolify's Traefik reverse proxy so Laravel honors the
        // X-Forwarded-Proto header and recognises HTTPS requests as
        // secure. Without this, the framework generates http:// asset
        // URLs while the page is served over https://, and the browser
        // blocks them as mixed content. `*` is fine here because the
        // app container is only reachable via the Coolify proxy network.
        $middleware->trustProxies(at: '*');

        // Set browser security headers (CSP, X-Frame-Options, HSTS,
        // Permissions-Policy, ...) on every response. Appended late so
        // it runs after the response has been rendered.
        $middleware->append(SecurityHeaders::class);

        // Append after authentication so a frozen user is bounced on every
        // request, even if their session was issued before the freeze.
        $middleware->appendToGroup('web', EnforceFrozenAccount::class);

        // Role-gating middleware aliases. Use `can:write` for any route
        // that mutates state, `role:admin` for admin-only sections,
        // `role:superadmin` for the strictest controls.
        $middleware->alias([
            'can.write' => RequireWriteAccess::class,
            'role.admin' => RequireAdminRole::class,
            'role.superadmin' => RequireSuperadminRole::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
