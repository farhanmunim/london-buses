<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Evidence file attached to an audit log entry. Bytes live in the
 * `contents` column so the database file is the single source of truth
 * for backups (matches the existing "Download snapshot" model).
 *
 * The `contents` column is hidden from default attribute serialisation
 * — listing rows must use `select()` to keep the blob out of memory.
 * Only the dedicated download controller pulls the bytes.
 */
#[Fillable([
    'audit_log_id',
    'attachable_key',
    'original_filename',
    'mime_type',
    'size_bytes',
    'sha256',
    'contents',
    'uploaded_by',
    'detached_at',
    'detached_by',
])]
class Attachment extends Model
{
    /**
     * Storage budget per evidence upload — kilobytes. Read from
     * app_settings `evidence.max_kb` with a 2 MB default.
     */
    public static function maxUploadKb(): int
    {
        $stored = AppSetting::get(AppSetting::ATTACHMENT_MAX_KB);

        return is_numeric($stored) ? (int) $stored : AppSetting::DEFAULT_ATTACHMENT_MAX_KB;
    }

    /**
     * Allowed file extensions for attachments. Read from
     * app_settings as a comma-separated string and split.
     *
     * @return array<int, string>
     */
    public static function allowedExtensions(): array
    {
        $stored = AppSetting::get(AppSetting::ATTACHMENT_ALLOWED_EXTENSIONS, AppSetting::DEFAULT_ATTACHMENT_EXTENSIONS);

        return array_values(array_filter(array_map(
            fn ($e) => trim((string) $e),
            explode(',', (string) $stored),
        )));
    }

    protected $hidden = ['contents'];

    protected function casts(): array
    {
        return [
            'size_bytes' => 'integer',
            'detached_at' => 'datetime',
        ];
    }

    /** Currently attached (visible to the dialog list). */
    public function scopeActive($q)
    {
        return $q->whereNull('detached_at');
    }

    public function auditLog(): BelongsTo
    {
        return $this->belongsTo(AuditLog::class);
    }

    public function uploader(): BelongsTo
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    /**
     * The slots this file is mounted on. One file can be linked from
     * many record-items via the dupe-detection "Link existing"
     * action — see AttachmentLink. Stage 2 of the rollout will move
     * read paths from `attachments.attachable_key` to `links`.
     */
    public function links(): HasMany
    {
        return $this->hasMany(AttachmentLink::class);
    }
}
