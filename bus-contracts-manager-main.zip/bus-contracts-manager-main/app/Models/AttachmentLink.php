<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Pivot row connecting an Attachment (the bytes + metadata) to a
 * record-item slot (e.g. `contract:333:cpa:2024`). One file can be
 * linked from many slots: the dupe-detection dialog offers a "Link
 * existing" option that creates a fresh link row pointing at the
 * already-uploaded bytes instead of duplicating them.
 *
 * Detach is per-link, not per-file — soft-detaching one slot leaves
 * the file intact for other slots that still reference it.
 */
#[Fillable([
    'attachment_id',
    'attachable_key',
    'audit_log_id',
    'detached_at',
    'detached_by',
])]
class AttachmentLink extends Model
{
    protected function casts(): array
    {
        return [
            'detached_at' => 'datetime',
        ];
    }

    /** Currently attached (visible to the dialog list). */
    public function scopeActive($q)
    {
        return $q->whereNull('detached_at');
    }

    public function attachment(): BelongsTo
    {
        return $this->belongsTo(Attachment::class);
    }

    public function auditLog(): BelongsTo
    {
        return $this->belongsTo(AuditLog::class);
    }

    public function detacher(): BelongsTo
    {
        return $this->belongsTo(User::class, 'detached_by');
    }
}
