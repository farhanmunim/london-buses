<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

#[Fillable([
    'user_id',
    'action',
    'entity_type',
    'entity_id',
    'old_values',
    'new_values',
    'note',
    'ip_address',
])]
class AuditLog extends Model
{
    protected function casts(): array
    {
        return [
            'old_values' => 'array',
            'new_values' => 'array',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Optional supporting evidence file uploaded with the change. Always
     * select metadata only — never eager-load the `contents` blob, which
     * is what the dedicated download endpoint streams.
     */
    public function attachment(): HasOne
    {
        return $this->hasOne(Attachment::class)
            ->select(['id', 'audit_log_id', 'original_filename', 'mime_type', 'size_bytes', 'sha256', 'uploaded_by', 'created_at']);
    }
}
