<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable(['key', 'value', 'updated_by'])]
class AppSetting extends Model
{
    /** Singleton-style key for the Contracts "anchor year" setting. */
    public const CONTRACTS_ANCHOR_YEAR = 'contracts.anchor_year';

    /**
     * Cutoff tender date that splits CPA indexation between P2P and RA.
     * Contracts tendered on or before this date use P2P; later tenders use RA.
     */
    public const CONTRACTS_P2P_RA_CUTOFF = 'contracts.p2p_ra_cutoff';

    /**
     * Soft visibility cutoff for the audit log UI. The "Delete all audit log
     * data" action sets this to the latest audit_logs id at the
     * moment it was triggered; the audit-log page filters to entries with
     * `id > cutoff`. The DB still holds every row — this is a UI-only hide
     * so the underlying audit trail is never lost.
     */
    public const AUDIT_LOG_VISIBLE_AFTER_ID = 'audit_log.visible_after_id';

    /**
     * Upload limits for attachments and template imports — surfaced
     * under Settings > Data control so a superadmin can tighten or
     * loosen them without redeploying. Defaults below kick in when no
     * row exists yet.
     *
     * The DB key strings are kept on the legacy `evidence.*` prefix —
     * an in-place rename would orphan any operator-tuned overrides
     * sitting in `app_settings`. The PHP-side constants name carries
     * the new "attachment" terminology so any new code reads cleanly.
     */
    public const ATTACHMENT_MAX_KB = 'evidence.max_kb';

    public const ATTACHMENT_ALLOWED_EXTENSIONS = 'evidence.allowed_extensions';

    public const TEMPLATE_MAX_KB = 'imports.max_kb';

    public const TEMPLATE_ALLOWED_EXTENSIONS = 'imports.allowed_extensions';

    /** Defaults applied when the corresponding row is unset. */
    public const DEFAULT_ATTACHMENT_MAX_KB = 2048;

    public const DEFAULT_ATTACHMENT_EXTENSIONS = 'eml,msg,pdf,doc,docx,xls,xlsx,csv';

    public const DEFAULT_TEMPLATE_MAX_KB = 2048;

    public const DEFAULT_TEMPLATE_EXTENSIONS = 'csv';

    /**
     * Default anchor year for the Contracts page when no setting is
     * stored. The user can override via Contracts → Settings cog.
     */
    public const DEFAULT_CONTRACTS_ANCHOR_YEAR = 2024;

    /**
     * Default P2P / RA cutoff (tender date splitting the two CPA
     * regimes). Pinned to the historical date used by the canonical
     * spreadsheet; user can override via Contracts → Settings cog.
     */
    public const DEFAULT_CONTRACTS_P2P_RA_CUTOFF = '2020-08-01';

    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $row = static::where('key', $key)->first();

        return $row?->value ?? $default;
    }

    /** Configured KB limit for CSV template imports. */
    public static function templateMaxKb(): int
    {
        $stored = self::get(self::TEMPLATE_MAX_KB);

        return is_numeric($stored) ? (int) $stored : self::DEFAULT_TEMPLATE_MAX_KB;
    }

    /** Configured allowed extensions for CSV template imports. */
    public static function templateAllowedExtensions(): array
    {
        $stored = self::get(self::TEMPLATE_ALLOWED_EXTENSIONS, self::DEFAULT_TEMPLATE_EXTENSIONS);

        return array_values(array_filter(array_map(
            fn ($e) => trim((string) $e),
            explode(',', (string) $stored),
        )));
    }

    /**
     * Validation rules for any CSV template upload — used by every
     * bulk-import controller (contracts + indices) so a single
     * setting change applies everywhere.
     */
    public static function templateUploadRules(): array
    {
        return [
            'required',
            'file',
            'mimes:'.implode(',', self::templateAllowedExtensions()),
            'mimetypes:text/csv,text/plain,application/csv,application/vnd.ms-excel',
            'max:'.self::templateMaxKb(),
        ];
    }

    /**
     * Configured Contracts anchor year, falling back to the default
     * when no row has been saved yet (fresh install or after a wipe).
     */
    public static function contractsAnchorYear(): int
    {
        $stored = self::get(self::CONTRACTS_ANCHOR_YEAR);

        return is_numeric($stored) ? (int) $stored : self::DEFAULT_CONTRACTS_ANCHOR_YEAR;
    }

    /**
     * Configured P2P/RA cutoff date (`Y-m-d` string), falling back to
     * the default when no row has been saved yet.
     */
    public static function contractsP2pRaCutoff(): string
    {
        $stored = self::get(self::CONTRACTS_P2P_RA_CUTOFF);

        return is_string($stored) && $stored !== '' ? $stored : self::DEFAULT_CONTRACTS_P2P_RA_CUTOFF;
    }

    public static function put(string $key, ?string $value, ?int $updatedBy = null): self
    {
        return static::updateOrCreate(
            ['key' => $key],
            ['value' => $value, 'updated_by' => $updatedBy],
        );
    }
}
