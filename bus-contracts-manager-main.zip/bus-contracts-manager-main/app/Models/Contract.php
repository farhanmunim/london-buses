<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use RuntimeException;

// archived_at / archived_by intentionally NOT in Fillable — only the
// archive()/unarchive() methods write them, both via forceFill, so we
// don't want a stray ::create([...]) or ->update([...]) accepting an
// archive flag from a request payload.
#[Fillable([
    'company',
    'depot',
    'route',
    'contract_number',
    'tender_date',
    'start_date',
    'end_date',
    'contract_value',
    'tender_award_note',
    'contracted_miles',
    'pvr',
    'tvr',
    'propulsion',
    'decks',
    'extension_status',
    'extension_note',
    'notice_served_status',
    'notice_served_note',
    'cpa_confirmations',
    'cpa_confirmation_notes',
    'latest_change_note',
    'created_by',
    'updated_by',
])]
class Contract extends Model
{
    /** Storable CPA confirmation states. Unset / default renders as 'blank'. */
    public const CPA_CONFIRM_STATES = ['yes', 'no'];

    /** Yes/No states accepted for the Extension and Notice-served flags. */
    public const FLAG_STATES = ['yes', 'no'];

    protected function casts(): array
    {
        return [
            'tender_date' => 'date',
            'start_date' => 'date',
            'end_date' => 'date',
            'contract_value' => 'decimal:4',
            'contracted_miles' => 'decimal:2',
            'pvr' => 'integer',
            'tvr' => 'integer',
            'cpa_confirmations' => 'array',
            'cpa_confirmation_notes' => 'array',
            'archived_at' => 'datetime',
        ];
    }

    public function isArchived(): bool
    {
        return $this->archived_at !== null;
    }

    /**
     * Soft-delete: hide from primary lists while keeping the row so the
     * audit trail still resolves historical references. Hard wipes only
     * via Settings → Data control.
     */
    public function archive(int $byUserId): void
    {
        $this->forceFill([
            'archived_at' => now(),
            'archived_by' => $byUserId,
        ])->save();
    }

    public function unarchive(): void
    {
        $this->forceFill([
            'archived_at' => null,
            'archived_by' => null,
        ])->save();
    }

    /** Default scope (explicit): hide archived rows from primary lists. */
    public function scopeActive(Builder $q): Builder
    {
        return $q->whereNull('archived_at');
    }

    public function scopeArchived(Builder $q): Builder
    {
        return $q->whereNotNull('archived_at');
    }

    /**
     * Operator note attached to a year's CPA confirmation, if one was
     * recorded. Returns null when no note exists. The dialog uses this to
     * pre-fill its textarea so the context-of-decision is visible the next
     * time someone reopens the same year for the same contract.
     */
    public function cpaConfirmationNote(int $year): ?string
    {
        $note = $this->cpa_confirmation_notes[(string) $year] ?? null;

        return is_string($note) && $note !== '' ? $note : null;
    }

    public function formatTenderDate(): string
    {
        return Carbon::parse($this->tender_date)->format('d/m/Y');
    }

    public function formatStartDate(): string
    {
        return Carbon::parse($this->start_date)->format('d/m/Y');
    }

    public function formatEndDate(): string
    {
        return Carbon::parse($this->end_date)->format('d/m/Y');
    }

    /**
     * Effective anchor year for this contract, given the global anchor year
     * configured in app_settings. If the contract's tender year is on or
     * before the global anchor, the contract is anchored TO that global year
     * (CPA indexation will roll forward from there). Otherwise the contract
     * is anchored to its own tender year (it post-dates the global anchor,
     * so its agreed value is already current).
     */
    public function anchorYear(?int $globalAnchor): ?int
    {
        if ($globalAnchor === null) {
            return null;
        }

        $tenderYear = (int) Carbon::parse($this->tender_date)->format('Y');

        return $tenderYear <= $globalAnchor ? $globalAnchor : $tenderYear;
    }

    /**
     * Which CPA flavour applies for indexing this contract: P2P (older
     * regime) or RA (rolling-average, newer regime). The split is decided
     * by tender date against the configured cutoff in app_settings.
     */
    public function cpaType(?string $cutoff): ?string
    {
        if ($cutoff === null) {
            return null;
        }

        $tender = Carbon::parse($this->tender_date)->startOfDay();
        $cutoffDate = Carbon::parse($cutoff)->startOfDay();

        return $tender->lessThanOrEqualTo($cutoffDate) ? 'P2P' : 'RA';
    }

    /**
     * Effective CPA confirmation state for a given column year.
     *
     * Returns one of:
     *   - 'yes'   — confirmed (default; locked for pre-anchor years)
     *   - 'no'    — explicitly marked unconfirmed
     *   - 'blank' — explicitly cleared, awaiting decision
     *
     * Pre-anchor years (year < global anchor) always resolve to 'yes' and are
     * not editable. Anchor-onwards years default to 'yes' until a different
     * value is stored via the inline confirmation control.
     */
    public function cpaConfirmation(int $year, ?int $globalAnchor): string
    {
        if ($globalAnchor !== null && $year < $globalAnchor) {
            return 'yes';
        }

        $stored = $this->cpa_confirmations[(string) $year] ?? null;

        return in_array($stored, self::CPA_CONFIRM_STATES, true) ? $stored : 'blank';
    }

    /**
     * Whether this year's confirmation is editable. Pre-anchor years are
     * historical and locked; anchor-onwards are editable.
     */
    public function isCpaConfirmationEditable(int $year, ?int $globalAnchor): bool
    {
        return $globalAnchor !== null && $year >= $globalAnchor;
    }

    /**
     * Operational status of this contract relative to today:
     *   - 'active'   — within [start_date, end_date]
     *   - 'expired'  — end_date already passed
     *   - 'upcoming' — start_date hasn't been reached yet
     */
    public function status(): string
    {
        $today = Carbon::today()->startOfDay();
        $start = Carbon::parse($this->start_date)->startOfDay();
        $end = Carbon::parse($this->end_date)->startOfDay();

        if ($end->lessThan($today)) {
            return 'expired';
        }
        if ($start->greaterThan($today)) {
            return 'upcoming';
        }

        return 'active';
    }

    /**
     * Contract length in whole years: ROUND((end - start) / 365, 0).
     * Per spec — uses 365 (not 365.25). Returns null if either endpoint
     * is missing.
     */
    public function contractLengthYears(): ?int
    {
        if ($this->start_date === null || $this->end_date === null) {
            return null;
        }

        $start = Carbon::parse($this->start_date)->startOfDay();
        $end = Carbon::parse($this->end_date)->startOfDay();
        $days = $start->diffInDays($end, false);

        return (int) round($days / 365);
    }

    /**
     * Whether the contract has been re-let / extended. Used by the ET
     * formula's "more than 5 years and was re-let" branch.
     */
    public function isReLet(): bool
    {
        return $this->extension_status === 'yes';
    }

    /**
     * Computed early-termination date.
     *   - tender_date null            → null (caller renders dash)
     *   - length < 5                  → null (no ET right; caller renders blank)
     *   - length === 5                → start + 3 years (−7 days if pre-2023 tender)
     *   - length  >  5 AND extension  → start + 3 years (no day reduction)
     *   - length  >  5 AND no extension → start + 4 years (−7 days if pre-2023 tender)
     */
    public function earlyTerminationDate(): ?Carbon
    {
        if ($this->tender_date === null || $this->start_date === null) {
            return null;
        }

        $length = $this->contractLengthYears();
        if ($length === null || $length < 5) {
            return null;
        }

        $start = Carbon::parse($this->start_date)->startOfDay();
        $tenderYear = (int) Carbon::parse($this->tender_date)->format('Y');
        $preReduction = $tenderYear < 2023;

        if ($length === 5) {
            $et = $start->copy()->addYears(3);

            return $preReduction ? $et->subDays(7) : $et;
        }

        // length > 5
        if ($this->isReLet()) {
            return $start->copy()->addYears(3);
        }

        $et = $start->copy()->addYears(4);

        return $preReduction ? $et->subDays(7) : $et;
    }

    /**
     * Computed notice date.
     *   - tender_date null    → null (caller renders dash)
     *   - length  <  5        → end_date − 10 months
     *   - length >= 5         → ET date − 10 months (null if ET date is null)
     */
    public function noticeDate(): ?Carbon
    {
        if ($this->tender_date === null) {
            return null;
        }

        $length = $this->contractLengthYears();
        if ($length === null) {
            return null;
        }

        if ($length < 5) {
            if ($this->end_date === null) {
                return null;
            }

            return Carbon::parse($this->end_date)->startOfDay()->subMonths(10);
        }

        $et = $this->earlyTerminationDate();

        return $et?->copy()->subMonths(10);
    }

    /**
     * Whether the dash placeholder applies (used for both ET date and
     * Notice date columns) — true when tender date is missing.
     */
    public function showsDateDash(): bool
    {
        return $this->tender_date === null;
    }

    /** Stored Extension state (yes/no/blank) — 'blank' when never set. */
    public function extensionStatus(): string
    {
        return in_array($this->extension_status, self::FLAG_STATES, true)
            ? $this->extension_status
            : 'blank';
    }

    /** Operator note attached to the Extension flag, or null. */
    public function extensionNote(): ?string
    {
        $note = $this->extension_note;

        return is_string($note) && $note !== '' ? $note : null;
    }

    /** Stored Notice-served state (yes/no/blank) — 'blank' when never set. */
    public function noticeServedStatus(): string
    {
        return in_array($this->notice_served_status, self::FLAG_STATES, true)
            ? $this->notice_served_status
            : 'blank';
    }

    /** Operator note attached to the Notice-served flag, or null. */
    public function noticeServedNoteValue(): ?string
    {
        $note = $this->notice_served_note;

        return is_string($note) && $note !== '' ? $note : null;
    }

    /** Free-text note attached to the tender-award date, or null. */
    public function tenderAwardNoteValue(): ?string
    {
        $note = $this->tender_award_note;

        return is_string($note) && $note !== '' ? $note : null;
    }

    /**
     * Stable [#id number · route X] prefix used in audit-log notes.
     * Centralised here so any controller writing audit rows for this
     * contract emits the same shape, and the audit-log search behaves
     * predictably.
     */
    public function auditRef(): string
    {
        return sprintf('[#%d %s · route %s]', $this->id, $this->contract_number, $this->route);
    }
}
