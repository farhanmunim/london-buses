<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Carbon;

#[Fillable(['month', 'cpi_index', 'cpi_index_original', 'is_actual', 'source', 'source_original', 'override_note', 'created_by', 'updated_by'])]
class CpiIndexEntry extends Model
{
    protected function casts(): array
    {
        return [
            'cpi_index' => 'decimal:1',
            'cpi_index_original' => 'decimal:1',
            'is_actual' => 'boolean',
        ];
    }

    protected function month(): Attribute
    {
        return Attribute::make(
            get: fn ($value) => $value === null ? null : Carbon::parse($value)->format('Y-m-d'),
            set: fn ($value) => Carbon::parse($value)->format('Y-m-d'),
        );
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}
