<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;

#[Fillable([
    'dataset_key',
    'source_url',
    'release_date',
    'next_release_date',
    'next_release_raw',
    'fetched_at',
])]
class OnsReleaseMetadata extends Model
{
    protected $table = 'ons_release_metadata';

    public const CPI_DATASET_KEY = 'consumerpriceinflation';

    public const CPI_DATASET_URL = 'https://www.ons.gov.uk/economy/inflationandpriceindices/datasets/consumerpriceinflation';

    protected function casts(): array
    {
        return [
            'release_date' => 'date',
            'next_release_date' => 'date',
            'fetched_at' => 'datetime',
        ];
    }
}
