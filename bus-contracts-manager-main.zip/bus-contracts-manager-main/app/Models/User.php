<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use RuntimeException;

// archived_at / archived_by intentionally NOT in Fillable — only the
// archive()/restore() methods write them, both via forceFill, so we
// don't want a stray ::create([...]) or ::update([...]) accepting an
// archive flag from request payload.
#[Fillable(['name', 'email', 'password', 'role', 'frozen_at', 'frozen_by'])]
#[Hidden(['password', 'remember_token'])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /** All recognised role values, in privilege order (highest first). */
    public const ROLES = ['superadmin', 'admin', 'user'];

    public const ROLE_SUPERADMIN = 'superadmin';

    public const ROLE_ADMIN = 'admin';

    public const ROLE_USER = 'user';

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'frozen_at' => 'datetime',
            'archived_at' => 'datetime',
        ];
    }

    public function isArchived(): bool
    {
        return $this->archived_at !== null;
    }

    /** Soft-delete: hide from primary lists, block sign-in, keep audit history. */
    public function archive(int $byUserId): void
    {
        if ($this->isSuperadmin()) {
            throw new RuntimeException('Cannot archive a superadmin account.');
        }

        $this->forceFill([
            'archived_at' => now(),
            'archived_by' => $byUserId,
            // Also freeze so the EnforceFrozenAccount middleware bounces them.
            'frozen_at' => $this->frozen_at ?? now(),
            'frozen_by' => $this->frozen_by ?? $byUserId,
        ])->save();
    }

    /** Restore an archived user — clears the archive flag. Frozen status preserved. */
    public function restore(): void
    {
        $this->forceFill([
            'archived_at' => null,
            'archived_by' => null,
        ])->save();
    }

    /** Default scope: hide archived users. Use ::withArchived() to bypass. */
    public function scopeActive(Builder $q): Builder
    {
        return $q->whereNull('archived_at');
    }

    public function scopeArchived(Builder $q): Builder
    {
        return $q->whereNotNull('archived_at');
    }

    public function isSuperadmin(): bool
    {
        return $this->role === self::ROLE_SUPERADMIN;
    }

    public function isAdmin(): bool
    {
        return in_array($this->role, [self::ROLE_SUPERADMIN, self::ROLE_ADMIN], true);
    }

    public function hasRole(string $role): bool
    {
        return $this->role === $role;
    }

    public function isFrozen(): bool
    {
        return $this->frozen_at !== null;
    }

    /**
     * Access matrix (deliberately small + readable — kept here so the rules
     * live next to the role constants):
     *
     *   superadmin  — full access everywhere; the only role that can purge
     *                 the audit log or read other users' login history.
     *   admin       — full access EXCEPT: cannot purge the audit log,
     *                 cannot promote anyone to superadmin, cannot read
     *                 login-log history for other users.
     *   user        — read-only viewer. Can view Contracts and Indices
     *                 (and any associated notes), can update their own
     *                 profile, and that is it. Cannot view Audit log,
     *                 Users, or Settings.
     */
    public function canWrite(): bool
    {
        return $this->isAdmin();
    }

    public function canManageUsers(): bool
    {
        return $this->isAdmin();
    }

    public function canViewAuditLog(): bool
    {
        return $this->isAdmin();
    }

    public function canPurgeAuditLog(): bool
    {
        return $this->isSuperadmin();
    }

    public function canViewLoginLogs(): bool
    {
        return $this->isSuperadmin();
    }

    public function canViewSettings(): bool
    {
        return $this->isAdmin();
    }

    public function freezer(): BelongsTo
    {
        return $this->belongsTo(self::class, 'frozen_by');
    }

    /**
     * Block any path that would demote a superadmin, wipe their account, or
     * freeze them out of the system. The superadmin slot is a singleton.
     */
    protected static function booted(): void
    {
        static::updating(function (User $user) {
            $original = $user->getOriginal('role');

            if ($user->isDirty('role') && $original === self::ROLE_SUPERADMIN && $user->role !== self::ROLE_SUPERADMIN) {
                throw new RuntimeException('Cannot demote the superadmin role.');
            }

            if ($user->isDirty('frozen_at') && $user->frozen_at !== null && $original === self::ROLE_SUPERADMIN) {
                throw new RuntimeException('Cannot freeze a superadmin account.');
            }
        });

        static::deleting(function (User $user) {
            if ($user->isSuperadmin()) {
                throw new RuntimeException('Cannot delete a superadmin account.');
            }
        });
    }
}
