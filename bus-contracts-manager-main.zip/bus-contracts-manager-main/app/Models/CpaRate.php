<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Carbon;

#[Fillable([
    'month',
    'p2p_rate',
    'ra_rate',
    'yoy_change',
    'cpi_index',
    'cpi_index_prior_year',
    'is_override',
    'p2p_override',
    'ra_override',
    'override_note',
    'overridden_by',
    'overridden_at',
])]
class CpaRate extends Model
{
    protected function casts(): array
    {
        return [
            'p2p_rate' => 'decimal:8',
            'ra_rate' => 'decimal:8',
            'yoy_change' => 'decimal:8',
            'cpi_index' => 'decimal:1',
            'cpi_index_prior_year' => 'decimal:1',
            'is_override' => 'boolean',
            'p2p_override' => 'decimal:8',
            'ra_override' => 'decimal:8',
            'overridden_at' => 'datetime',
        ];
    }

    protected function month(): Attribute
    {
        return Attribute::make(
            get: fn ($value) => $value === null ? null : Carbon::parse($value)->format('Y-m-d'),
            set: fn ($value) => Carbon::parse($value)->format('Y-m-d'),
        );
    }

    public function overrider(): BelongsTo
    {
        return $this->belongsTo(User::class, 'overridden_by');
    }

    public function effectiveP2pRate(): ?string
    {
        return $this->p2p_override ?? $this->p2p_rate;
    }

    public function effectiveRaRate(): ?string
    {
        return $this->ra_override ?? $this->ra_rate;
    }
}
