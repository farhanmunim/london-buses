<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Support\Facades\Http;

/**
 * Cloudflare Turnstile token validator. Posts the client-supplied token
 * to Cloudflare's siteverify endpoint along with our secret key; rejects
 * anything that doesn't come back `success: true`.
 *
 * The default secret in config/services.php is Cloudflare's "always-pass"
 * dev key, so locally every submission validates. In production, swap in
 * the real keys via TURNSTILE_SITE_KEY / TURNSTILE_SECRET_KEY.
 */
class TurnstileToken implements ValidationRule
{
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        // Bypass in tests so feature tests don't need to fake a token. The
        // browser-facing flow still validates because production env
        // returns false here.
        if (app()->environment('testing')) {
            return;
        }

        if (! is_string($value) || $value === '') {
            $fail('Please complete the verification challenge before submitting.');

            return;
        }

        try {
            $response = Http::asForm()
                ->timeout(5)
                ->post(config('services.turnstile.verify_url'), [
                    'secret' => config('services.turnstile.secret_key'),
                    'response' => $value,
                    'remoteip' => request()->ip(),
                ]);
        } catch (\Throwable $e) {
            // Network error talking to Cloudflare — fail open in dev so a
            // local developer without internet doesn't get locked out, but
            // log so the issue is visible in production.
            report($e);

            if (app()->environment('local', 'testing')) {
                return;
            }

            $fail('Could not reach the verification service — please try again.');

            return;
        }

        $body = $response->json();
        if (! is_array($body) || ($body['success'] ?? false) !== true) {
            $fail('Verification failed — please try the challenge again.');
        }
    }
}
