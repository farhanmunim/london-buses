<?php

namespace App\Services;

use DomainException;
use Illuminate\Support\Carbon;

/**
 * Sanitises and validates a single (month, cpi_index) record before it is
 * persisted. Used by the CSV bulk-import flow and any future ONS scraper that
 * pulls real CPI values. Rejecting bad input here keeps the rest of the
 * pipeline dumb — by the time data reaches the database it has already been
 * cleaned, range-checked and normalised.
 */
class CpiRowSanitiser
{
    /** Lowest plausible CPI value (the index has been base-100 since 2015). */
    public const CPI_MIN = 1.0;

    /** Highest plausible CPI value — well above any near-term ONS reading. */
    public const CPI_MAX = 1000.0;

    /** Earliest month the system will accept. */
    public const MONTH_MIN = '1990-01-01';

    /** Latest month the system will accept (guards against typos like 2206-03). */
    public const MONTH_MAX = '2050-12-01';

    /** Suspect leading characters that turn a CSV cell into an Excel formula. */
    private const INJECTION_LEADERS = ['=', '+', '-', '@', '|', "\t", "\r"];

    /**
     * @return array{month: string, cpi_index: string} normalised values
     *
     * @throws DomainException when the row cannot be cleaned into something safe
     */
    public function sanitise(string $rawMonth, string $rawCpi): array
    {
        $month = $this->clean($rawMonth);
        $cpi = $this->clean($rawCpi);

        if ($month === '' || $cpi === '') {
            throw new DomainException('Month and CPI value are both required.');
        }

        $this->guardAgainstInjection('month', $month);
        $this->guardAgainstInjection('cpi_index', $cpi);

        return [
            'month' => $this->normaliseMonth($month),
            'cpi_index' => $this->normaliseCpi($cpi),
        ];
    }

    /**
     * Strip the UTF-8 BOM from the start of a string. Useful when a file was
     * exported from Excel/Numbers and re-imported.
     */
    public static function stripBom(string $value): string
    {
        return preg_replace('/^\xEF\xBB\xBF/', '', $value) ?? $value;
    }

    /**
     * Strip BOM, surrounding whitespace, and accidental quote characters
     * picked up from spreadsheet exports.
     */
    public function clean(string $value): string
    {
        $value = self::stripBom($value);
        $value = trim($value, " \t\n\r\0\x0B\"'");

        return $value;
    }

    /**
     * Reject any cell that begins with a character Excel/Sheets would interpret
     * as a formula. Re-exporting a tainted cell would otherwise execute on the
     * next user's machine.
     */
    public function guardAgainstInjection(string $field, string $value): void
    {
        $first = mb_substr($value, 0, 1);

        if (in_array($first, self::INJECTION_LEADERS, true)) {
            throw new DomainException("Value for {$field} ('{$value}') starts with a disallowed character.");
        }
    }

    private function normaliseMonth(string $raw): string
    {
        try {
            // YYYY-MM (no day)
            if (preg_match('/^\d{4}-\d{1,2}$/', $raw) === 1) {
                $date = Carbon::createFromFormat('Y-n', $raw)->startOfMonth();
            } elseif (preg_match('#^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$#', $raw, $m) === 1) {
                $date = Carbon::createFromDate((int) $m[3], (int) $m[2], 1);
            } else {
                $date = Carbon::parse($raw)->startOfMonth();
            }
        } catch (\Throwable) {
            throw new DomainException("Could not parse month '{$raw}'.");
        }

        $value = $date->format('Y-m-d');

        if ($value < self::MONTH_MIN || $value > self::MONTH_MAX) {
            throw new DomainException("Month '{$raw}' is outside the supported range (".self::MONTH_MIN.' to '.self::MONTH_MAX.').');
        }

        return $value;
    }

    private function normaliseCpi(string $raw): string
    {
        // Allow trailing percent sign + thousands separators that crept in
        // from spreadsheet formatting.
        $cleaned = str_replace([',', ' '], '', $raw);

        if (! is_numeric($cleaned)) {
            throw new DomainException("CPI value '{$raw}' is not numeric.");
        }

        $value = (float) $cleaned;

        if ($value < self::CPI_MIN || $value > self::CPI_MAX) {
            throw new DomainException(
                'CPI '.$raw.' is outside the plausible range ('.
                self::CPI_MIN.' to '.self::CPI_MAX.').'
            );
        }

        // Always normalise to exactly one decimal place.
        return number_format($value, 1, '.', '');
    }
}
