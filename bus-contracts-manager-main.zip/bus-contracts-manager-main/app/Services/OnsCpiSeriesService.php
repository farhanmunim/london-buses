<?php

namespace App\Services;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;
use RuntimeException;

/**
 * Pulls the ONS CPI All Items Index (D7BT) monthly time series from the public
 * ONS time-series JSON endpoint. Returns parsed, normalised observations ready
 * to be fed into {@see CpiRowSanitiser} and persisted.
 *
 * The endpoint shape is:
 *   { months: [ { date: "2026 MAR", value: "141.0", ... }, ... ] }
 */
class OnsCpiSeriesService
{
    public const D7BT_TIMESERIES_URL = 'https://www.ons.gov.uk/economy/inflationandpriceindices/timeseries/d7bt/mm23/data';

    /** RPI All Items Index, monthly. Same dataset (mm23) as CPI, different series. */
    public const CHAW_TIMESERIES_URL = 'https://www.ons.gov.uk/economy/inflationandpriceindices/timeseries/chaw/mm23/data';

    /** Cap the response size to guard against runaway parsing. */
    private const MAX_RESPONSE_BYTES = 5_000_000;

    /** Retry transient HTTP failures up to this many times before giving up. */
    private const HTTP_RETRY_TIMES = 3;

    /** Wait this many milliseconds between retries (linear back-off). */
    private const HTTP_RETRY_DELAY_MS = 750;

    /**
     * Earliest observation we care about. We need ~3 years of headroom before
     * the oldest contract date so the lagged P2P (4 months back) and RA
     * (12-month window starting one month back) can be computed for the
     * earliest contract month.
     */
    private const SERIES_FROM = '2010-01-01';

    /**
     * Fetch and parse the full time series.
     *
     * @return array<int, array{month: string, raw_value: string}> sorted ascending
     *
     * @throws RuntimeException on any unrecoverable failure
     */
    public function fetchSeries(?string $url = null): array
    {
        $url ??= self::D7BT_TIMESERIES_URL;

        $response = Http::timeout(20)
            ->retry(self::HTTP_RETRY_TIMES, self::HTTP_RETRY_DELAY_MS, throw: false)
            ->withHeaders(['User-Agent' => 'Mozilla/5.0 (compatible; BusContractsManager/1.0)'])
            ->acceptJson()
            ->get($url);

        if (! $response->successful()) {
            throw new RuntimeException("ONS time-series fetch failed: HTTP {$response->status()} for {$url}");
        }

        $body = $response->body();

        if (strlen($body) > self::MAX_RESPONSE_BYTES) {
            throw new RuntimeException('ONS time-series response too large: '.strlen($body).' bytes.');
        }

        $payload = json_decode($body, true);

        if (! is_array($payload) || ! isset($payload['months']) || ! is_array($payload['months'])) {
            throw new RuntimeException('ONS time-series response is missing the expected "months" array.');
        }

        $rows = [];
        foreach ($payload['months'] as $entry) {
            $row = $this->parseEntry($entry);

            if ($row === null) {
                continue;
            }

            if ($row['month'] < self::SERIES_FROM) {
                continue;
            }

            $rows[] = $row;
        }

        // Stable ascending sort by month so callers can rely on order.
        usort($rows, fn ($a, $b) => strcmp($a['month'], $b['month']));

        return $rows;
    }

    /**
     * @param  array<string, mixed>  $entry
     * @return array{month: string, raw_value: string}|null
     */
    private function parseEntry(array $entry): ?array
    {
        $rawDate = isset($entry['date']) ? trim((string) $entry['date']) : '';
        $rawValue = isset($entry['value']) ? trim((string) $entry['value']) : '';

        if ($rawDate === '' || $rawValue === '') {
            return null;
        }

        try {
            // ONS sends dates like "2026 MAR".
            $month = Carbon::createFromFormat('Y M', $rawDate)->startOfMonth()->format('Y-m-d');
        } catch (\Throwable) {
            return null;
        }

        return [
            'month' => $month,
            'raw_value' => $rawValue,
        ];
    }
}
