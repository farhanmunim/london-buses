<?php

namespace App\Services;

use App\Models\OnsReleaseMetadata;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;
use RuntimeException;

class OnsReleaseScraperService
{
    /** Earliest acceptable scrape date — guards against malformed pages. */
    private const DATE_MIN = '2015-01-01';

    /** Latest acceptable scrape date — release dates more than two years in the future are almost certainly garbage. */
    private const DATE_MAX_OFFSET_YEARS = 2;

    /** Maximum size of an ONS HTML body we'll parse, to avoid runaway regex backtracking on a malicious response. */
    private const MAX_HTML_BYTES = 1_000_000;

    public function fetchCpiInflation(): OnsReleaseMetadata
    {
        return $this->fetch(OnsReleaseMetadata::CPI_DATASET_KEY, OnsReleaseMetadata::CPI_DATASET_URL);
    }

    public function fetch(string $datasetKey, string $url): OnsReleaseMetadata
    {
        $response = Http::timeout(20)
            ->withHeaders(['User-Agent' => 'Mozilla/5.0 (compatible; BusContractsManager/1.0; +'.config('app.url').')'])
            ->get($url);

        if (! $response->successful()) {
            throw new RuntimeException("ONS fetch failed: HTTP {$response->status()} for {$url}");
        }

        $html = $response->body();

        if (strlen($html) > self::MAX_HTML_BYTES) {
            throw new RuntimeException("ONS response too large ({$url}): ".strlen($html).' bytes.');
        }

        $releaseRaw = $this->extractLabelledValue($html, 'Release date');
        $nextRaw = $this->extractLabelledValue($html, 'Next release');

        if ($releaseRaw === null) {
            throw new RuntimeException("Could not parse 'Release date' from {$url}.");
        }

        $releaseDate = $this->parseDate($releaseRaw);

        if ($releaseDate === null) {
            throw new RuntimeException("Release date '{$releaseRaw}' from {$url} could not be parsed.");
        }

        $nextRelease = $nextRaw !== null ? $this->parseDate($nextRaw) : null;

        return OnsReleaseMetadata::updateOrCreate(
            ['dataset_key' => $datasetKey],
            [
                'source_url' => $url,
                'release_date' => $releaseDate,
                'next_release_date' => $nextRelease,
                'next_release_raw' => $nextRaw,
                'fetched_at' => now(),
            ]
        );
    }

    private function extractLabelledValue(string $html, string $label): ?string
    {
        $escaped = preg_quote($label, '/');

        // Primary pattern: ONS layout uses <div class="meta__term">Label:</div><div>VALUE</div>
        $patterns = [
            "/<(?:div|dt|span|strong|b)[^>]*>\s*{$escaped}\s*:?\s*<\/(?:div|dt|span|strong|b)>\s*<(?:div|dd|span)[^>]*>([\s\S]*?)<\/(?:div|dd|span)>/i",
            "/<(?:strong|b|dt)[^>]*>\s*{$escaped}\s*:?\s*<\/(?:strong|b|dt)>\s*([\s\S]*?)(?=<(?:strong|b|dt|h\d|table|li|ul|p)|$)/i",
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $html, $m) === 1) {
                $cleaned = trim(strip_tags($m[1]));
                $cleaned = preg_replace('/\s+/', ' ', $cleaned);
                $cleaned = trim($cleaned, " \t\n\r\0\x0B:,;.");

                if (preg_match('/(\d{1,2}\s+[A-Za-z]+\s+\d{4})/', $cleaned, $datem) === 1) {
                    return $datem[1];
                }

                if ($cleaned !== '') {
                    return $cleaned;
                }
            }
        }

        return null;
    }

    /**
     * Parse a date string and reject anything outside our sane range. Returns
     * null if the string is unparseable — callers decide whether that's fatal.
     */
    private function parseDate(string $raw): ?Carbon
    {
        try {
            $date = Carbon::parse($raw);
        } catch (\Throwable) {
            return null;
        }

        $earliest = Carbon::parse(self::DATE_MIN);
        $latest = Carbon::now()->addYears(self::DATE_MAX_OFFSET_YEARS);

        if ($date->lt($earliest) || $date->gt($latest)) {
            return null;
        }

        return $date;
    }
}
