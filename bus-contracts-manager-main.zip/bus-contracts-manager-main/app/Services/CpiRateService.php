<?php

namespace App\Services;

use App\Models\CpaRate;
use App\Models\CpiIndexEntry;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class CpiRateService
{
    private const INTERNAL_SCALE = 10;

    private const STORAGE_SCALE = 8;

    private const RA_SCALING_FACTOR = '0.85';

    /** RA averages 12 monthly YoY values. */
    private const RA_WINDOW_MONTHS = 12;

    /**
     * P2P uses the YoY change from this many months earlier — contracts apply
     * the rate with a 4-month publication-and-processing lag.
     */
    private const P2P_LAG_MONTHS = 4;

    /**
     * RA uses the 12 monthly YoY values ending at the previous month — i.e.
     * the rolling-average window is shifted back by one month.
     */
    private const RA_LAG_MONTHS = 1;

    /**
     * Calculate YoY, P2P and RA rates for a given month using stored CPI index entries.
     *
     * Formulas:
     *
     *   yoy_change[M] = (CPI[M] − CPI[M-12]) / CPI[M-12]
     *   p2p_rate[M]   = yoy_change[M-4] × 0.85
     *   ra_rate[M]    = AVERAGE(yoy_change[M-12], …, yoy_change[M-1]) × 0.85
     *
     * @return array{yoy_change: string, p2p_rate: string|null, ra_rate: string|null, cpi_index: string, cpi_index_prior_year: string}
     */
    public function calculateRatesForMonth(Carbon $month): array
    {
        $month = $month->copy()->startOfMonth();

        $current = $this->indexFor($month)
            ?? throw new RuntimeException("CPI index entry not found for {$month->format('Y-m')}.");

        $priorYearMonth = $month->copy()->subMonths(12);
        $priorYear = $this->indexFor($priorYearMonth)
            ?? throw new RuntimeException("CPI index entry not found for {$priorYearMonth->format('Y-m')} (prior year).");

        $cpiCurrent = $this->normaliseIndex($current->cpi_index);
        $cpiPriorYear = $this->normaliseIndex($priorYear->cpi_index);

        $yoy = $this->yoyChange($cpiCurrent, $cpiPriorYear);

        return [
            'yoy_change' => $this->roundHalfUp($yoy, self::STORAGE_SCALE),
            'p2p_rate' => $this->calculateLaggedP2P($month),
            'ra_rate' => $this->calculateLaggedRollingAverage($month),
            'cpi_index' => $cpiCurrent,
            'cpi_index_prior_year' => $cpiPriorYear,
        ];
    }

    /**
     * Recalculate and upsert cpa_rates for every month that has a CPI index entry.
     */
    public function recalculateAll(): void
    {
        DB::transaction(function (): void {
            CpiIndexEntry::query()->orderBy('month')->each(function (CpiIndexEntry $entry): void {
                $month = Carbon::parse($entry->month);

                try {
                    $result = $this->calculateRatesForMonth($month);
                } catch (RuntimeException) {
                    // Insufficient prior-year data for YoY — skip this month entirely.
                    return;
                }

                $existing = CpaRate::where('month', $month->toDateString())->first();

                CpaRate::updateOrCreate(
                    ['month' => $month->toDateString()],
                    [
                        'p2p_rate' => $result['p2p_rate'],
                        'ra_rate' => $result['ra_rate'],
                        'yoy_change' => $result['yoy_change'],
                        'cpi_index' => $result['cpi_index'],
                        'cpi_index_prior_year' => $result['cpi_index_prior_year'],
                        'is_override' => $existing?->is_override ?? false,
                        'p2p_override' => $existing?->p2p_override,
                        'ra_override' => $existing?->ra_override,
                        'override_note' => $existing?->override_note,
                        'overridden_by' => $existing?->overridden_by,
                        'overridden_at' => $existing?->overridden_at,
                    ]
                );
            });
        });
    }

    /**
     * P2P[M] = YoY[M − P2P_LAG_MONTHS] × 0.85. Returns null when the lagged
     * source month or its prior-year are missing.
     */
    private function calculateLaggedP2P(Carbon $month): ?string
    {
        $sourceMonth = $month->copy()->subMonths(self::P2P_LAG_MONTHS);
        $source = $this->indexFor($sourceMonth);
        $sourcePrior = $this->indexFor($sourceMonth->copy()->subMonths(12));

        if ($source === null || $sourcePrior === null) {
            return null;
        }

        $yoy = $this->yoyChange(
            $this->normaliseIndex($source->cpi_index),
            $this->normaliseIndex($sourcePrior->cpi_index),
        );

        return $this->roundHalfUp($this->scaleByFactor($yoy), self::STORAGE_SCALE);
    }

    /**
     * RA[M] = AVERAGE(YoY[M-12 … M-1]) × 0.85. Returns null when the window or
     * any of its 12-month-prior reference points are missing.
     */
    private function calculateLaggedRollingAverage(Carbon $month): ?string
    {
        $earliestNeeded = $month->copy()->subMonths(self::RA_WINDOW_MONTHS + 12);
        $latestNeeded = $month->copy()->subMonths(self::RA_LAG_MONTHS);

        $entries = CpiIndexEntry::query()
            ->whereBetween('month', [$earliestNeeded->toDateString(), $latestNeeded->toDateString()])
            ->orderBy('month')
            ->get()
            ->keyBy(fn (CpiIndexEntry $e) => Carbon::parse($e->month)->format('Y-m'));

        $sum = '0';

        for ($offset = self::RA_WINDOW_MONTHS; $offset >= self::RA_LAG_MONTHS; $offset--) {
            $windowMonth = $month->copy()->subMonths($offset);
            $windowKey = $windowMonth->format('Y-m');
            $priorKey = $windowMonth->copy()->subMonths(12)->format('Y-m');

            if (! $entries->has($windowKey) || ! $entries->has($priorKey)) {
                return null;
            }

            $cpi = $this->normaliseIndex($entries[$windowKey]->cpi_index);
            $priorCpi = $this->normaliseIndex($entries[$priorKey]->cpi_index);

            $yoy = $this->yoyChange($cpi, $priorCpi);
            $sum = bcadd($sum, $yoy, self::INTERNAL_SCALE);
        }

        $average = bcdiv($sum, (string) self::RA_WINDOW_MONTHS, self::INTERNAL_SCALE);

        return $this->roundHalfUp($this->scaleByFactor($average), self::STORAGE_SCALE);
    }

    private function yoyChange(string $current, string $priorYear): string
    {
        $diff = bcsub($current, $priorYear, self::INTERNAL_SCALE);

        return bcdiv($diff, $priorYear, self::INTERNAL_SCALE);
    }

    private function scaleByFactor(string $value): string
    {
        return bcmul($value, self::RA_SCALING_FACTOR, self::INTERNAL_SCALE);
    }

    private function indexFor(Carbon $month): ?CpiIndexEntry
    {
        return CpiIndexEntry::where('month', $month->copy()->startOfMonth()->toDateString())->first();
    }

    private function normaliseIndex(string|float $value): string
    {
        return number_format((float) $value, 1, '.', '');
    }

    /**
     * Round a bcmath string to a given scale, half-up. Matches Excel's default
     * rounding behaviour so our stored values agree with the canonical revenue
     * spreadsheet to the last decimal.
     */
    private function roundHalfUp(string $value, int $scale): string
    {
        $half = '0.'.str_repeat('0', $scale).'5';

        if (str_starts_with($value, '-')) {
            $half = '-'.$half;
        }

        return bcadd($value, $half, $scale);
    }
}
