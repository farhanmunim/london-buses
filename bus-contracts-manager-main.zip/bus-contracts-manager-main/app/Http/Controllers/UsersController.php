<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\LoginLog;
use App\Models\User;
use App\Support\PasswordConfirm;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;

/**
 * Manage users page.
 *
 * Currently superadmin-only via route gating. Full visibility (every
 * user, every login event), full edit/delete. Admin-tier filtering will
 * land later once finer-grained access controls are introduced.
 */
class UsersController extends Controller
{
    /** Recent logins shown per user in the expandable history panel. */
    private const LOGIN_HISTORY_LIMIT = 25;

    public function index(Request $request): View
    {
        $isSuperadminViewer = $request->user()->isSuperadmin();
        $showArchived = $request->boolean('archived');

        $users = User::query()
            ->when(! $isSuperadminViewer, fn ($q) => $q->where('role', '!=', User::ROLE_SUPERADMIN))
            ->when(! $showArchived, fn ($q) => $q->active())
            ->when($showArchived, fn ($q) => $q->archived())
            ->orderByRaw("CASE role WHEN 'superadmin' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END")
            ->orderBy('name')
            ->get();

        $archivedCount = User::query()
            ->when(! $isSuperadminViewer, fn ($q) => $q->where('role', '!=', User::ROLE_SUPERADMIN))
            ->archived()
            ->count();

        // Recent logins, grouped by user_id so each row can render its own
        // history. Capped per user so a noisy account doesn't blow up the
        // payload.
        $loginsByUser = LoginLog::query()
            ->whereIn('user_id', $users->pluck('id'))
            ->orderByDesc('logged_in_at')
            ->orderByDesc('id')
            ->get()
            ->groupBy('user_id')
            ->map(fn ($logs) => $logs->take(self::LOGIN_HISTORY_LIMIT));

        $lastLoginByUser = LoginLog::query()
            ->whereIn('user_id', $users->pluck('id'))
            ->selectRaw('user_id, MAX(logged_in_at) as last_login_at, MAX(id) as last_id')
            ->groupBy('user_id')
            ->get()
            ->keyBy('user_id');

        // Resolve last-login IPs in a separate batch — `MAX(id)` per user is
        // pulled above, then the IP is read from the matching row.
        $lastLoginIps = LoginLog::query()
            ->whereIn('id', $lastLoginByUser->pluck('last_id'))
            ->get()
            ->keyBy('user_id');

        return view('users.index', [
            'users' => $users,
            'loginsByUser' => $loginsByUser,
            'lastLoginIps' => $lastLoginIps,
            'roleOptions' => User::ROLES,
            'showArchived' => $showArchived,
            'archivedCount' => $archivedCount,
        ]);
    }

    /**
     * Create a new account from the Manage Users page. Superadmin only —
     * matches the existing role on the rest of this controller.
     */
    public function store(Request $request): RedirectResponse
    {
        abort_unless($request->user()->isSuperadmin(), 403);
        PasswordConfirm::check($request, 'confirm_password');

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', Rule::unique('users')],
            'role' => ['required', Rule::in(User::ROLES)],
            'password' => ['required', 'confirmed', Password::min(8)],
        ]);

        // Block creating a second superadmin — the role is a singleton.
        if ($validated['role'] === User::ROLE_SUPERADMIN) {
            return redirect()->route('users.index')
                ->with('updateError', 'The superadmin role is a singleton and cannot be assigned to a new user.');
        }

        $user = DB::transaction(function () use ($request, $validated) {
            $user = User::create([
                'name' => $validated['name'],
                'email' => $validated['email'],
                'role' => $validated['role'],
                'password' => Hash::make($validated['password']),
            ]);

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'user_created',
                'entity_type' => $user->getTable(),
                'entity_id' => $user->getKey(),
                'new_values' => [
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                ],
                'note' => 'New account created',
                'ip_address' => $request->ip(),
            ]);

            return $user;
        });

        return redirect()->route('users.index')->with('status', "Created {$user->name}.");
    }

    /**
     * Single endpoint for the edit-user dialog. Handles name /
     * email / role updates, an optional password reset, and freeze /
     * unfreeze toggling — all atomically. Each behaviour is audited under a
     * distinct action so the change history reads cleanly.
     */
    public function update(Request $request, User $user): RedirectResponse
    {
        // Archived users are immutable — restore them first if a
        // legitimate edit is needed. Same shape as the contracts
        // endpoints which already enforce this guard.
        abort_if($user->isArchived(), 404);

        $isSuperadminCaller = $request->user()->isSuperadmin();

        // Admins cannot touch the superadmin record at all — block at the
        // controller boundary so direct URL POSTs are rejected even if the
        // UI is bypassed.
        abort_if($user->isSuperadmin() && ! $isSuperadminCaller, 403);

        PasswordConfirm::check($request, 'confirm_password');

        $rules = [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', Rule::unique('users')->ignore($user->id)],
            'role' => ['required', Rule::in(User::ROLES)],
            'frozen' => ['nullable', 'boolean'],
            'password' => ['nullable', 'confirmed', Password::min(8)],
        ];

        $validated = $request->validate($rules);
        $shouldFreeze = $request->boolean('frozen');
        $newPassword = $validated['password'] ?? null;

        // Server-side rejections that the model would also throw on, surfaced
        // here as friendly flash errors.
        if ($user->isSuperadmin() && $validated['role'] !== User::ROLE_SUPERADMIN) {
            return redirect()->route('users.index')
                ->with('updateError', 'The superadmin role is a singleton and cannot be demoted.');
        }

        if ($user->isSuperadmin() && $shouldFreeze) {
            return redirect()->route('users.index')
                ->with('updateError', 'The superadmin account cannot be frozen.');
        }

        // Singleton role: nobody can be promoted *to* superadmin via this
        // endpoint (the existing superadmin already holds the slot).
        if (! $user->isSuperadmin() && $validated['role'] === User::ROLE_SUPERADMIN) {
            return redirect()->route('users.index')
                ->with('updateError', 'The superadmin role is a singleton and cannot be assigned.');
        }

        if ($newPassword !== null && ! $isSuperadminCaller) {
            return redirect()->route('users.index')
                ->with('updateError', 'Only superadmins can reset another user\'s password.');
        }

        if ($shouldFreeze && $user->id === $request->user()->id) {
            return redirect()->route('users.index')
                ->with('updateError', 'You cannot freeze your own account.');
        }

        $profileChanges = [];
        foreach (['name', 'email', 'role'] as $field) {
            if ($user->{$field} !== $validated[$field]) {
                $profileChanges[$field] = ['from' => $user->{$field}, 'to' => $validated[$field]];
            }
        }

        $freezeAction = null;
        if ($shouldFreeze && ! $user->isFrozen()) {
            $freezeAction = 'freeze';
        } elseif (! $shouldFreeze && $user->isFrozen()) {
            $freezeAction = 'unfreeze';
        }

        if (empty($profileChanges) && $newPassword === null && $freezeAction === null) {
            return redirect()->route('users.index')->with('status', 'No changes to save.');
        }

        DB::transaction(function () use ($request, $user, $validated, $profileChanges, $freezeAction, $newPassword) {
            // Profile fields
            if (! empty($profileChanges)) {
                $user->fill([
                    'name' => $validated['name'],
                    'email' => $validated['email'],
                    'role' => $validated['role'],
                ])->save();

                AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'user_updated',
                    'entity_type' => $user->getTable(),
                    'entity_id' => $user->getKey(),
                    'old_values' => array_map(fn ($c) => $c['from'], $profileChanges),
                    'new_values' => array_map(fn ($c) => $c['to'], $profileChanges),
                    'note' => 'User profile updated',
                    'ip_address' => $request->ip(),
                ]);
            }

            // Password (never logged in old/new values)
            if ($newPassword !== null) {
                $user->forceFill(['password' => Hash::make($newPassword)])->save();

                AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'user_password_reset',
                    'entity_type' => $user->getTable(),
                    'entity_id' => $user->getKey(),
                    'note' => 'Password reset by another user',
                    'ip_address' => $request->ip(),
                ]);
            }

            // Freeze toggle
            if ($freezeAction === 'freeze') {
                $user->forceFill([
                    'frozen_at' => now(),
                    'frozen_by' => $request->user()->id,
                ])->save();

                AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'user_frozen',
                    'entity_type' => $user->getTable(),
                    'entity_id' => $user->getKey(),
                    'new_values' => ['frozen_at' => $user->frozen_at?->toIso8601String()],
                    'note' => 'Account frozen — login disabled',
                    'ip_address' => $request->ip(),
                ]);
            } elseif ($freezeAction === 'unfreeze') {
                $oldFrozenAt = $user->frozen_at?->toIso8601String();

                $user->forceFill([
                    'frozen_at' => null,
                    'frozen_by' => null,
                ])->save();

                AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'user_unfrozen',
                    'entity_type' => $user->getTable(),
                    'entity_id' => $user->getKey(),
                    'old_values' => ['frozen_at' => $oldFrozenAt],
                    'note' => 'Account unfrozen — login restored',
                    'ip_address' => $request->ip(),
                ]);
            }
        });

        return redirect()->route('users.index')->with('status', "Updated {$user->name}.");
    }

    /**
     * Archive a user (soft-delete). Per project policy the row stays
     * in the database — frozen + flagged so audit history references
     * still resolve. Hard-delete only happens via Settings → Data
     * control → Delete data → All / Users.
     */
    public function destroy(Request $request, User $user): RedirectResponse
    {
        // Idempotent — already-archived users can't be archived again
        // (would write a duplicate audit row and confuse the trail).
        abort_if($user->isArchived(), 404);
        abort_if($user->isSuperadmin() && ! $request->user()->isSuperadmin(), 403);

        PasswordConfirm::check($request, 'confirm_password');

        if ($user->isSuperadmin()) {
            return redirect()->route('users.index')
                ->with('updateError', 'The superadmin account cannot be archived.');
        }

        if ($user->id === $request->user()->id) {
            return redirect()->route('users.index')
                ->with('updateError', 'You cannot archive your own account from here. Use the Profile page.');
        }

        $oldValues = ['name' => $user->name, 'email' => $user->email, 'role' => $user->role];
        $name = $user->name;

        DB::transaction(function () use ($request, $user, $oldValues) {
            $entityId = $user->getKey();
            $user->archive($request->user()->id);

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'user_deleted',
                'entity_type' => 'users',
                'entity_id' => $entityId,
                'old_values' => $oldValues,
                'new_values' => null,
                'note' => 'User account archived',
                'ip_address' => $request->ip(),
            ]);
        });

        return redirect()->route('users.index')->with('status', "Archived {$name}. The audit history is preserved.");
    }

    /**
     * Restore an archived user. Clears the archive flag; the operator
     * must separately unfreeze the account before they can sign in.
     */
    public function restore(Request $request, User $user): RedirectResponse
    {
        abort_unless($request->user()->isAdmin(), 403);
        abort_unless($user->isArchived(), 404);

        PasswordConfirm::check($request, 'confirm_password');

        DB::transaction(function () use ($request, $user) {
            $user->restore();

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'user_restored',
                'entity_type' => 'users',
                'entity_id' => $user->getKey(),
                'old_values' => ['archived' => true],
                'new_values' => ['archived' => false],
                'note' => 'User account restored from archive',
                'ip_address' => $request->ip(),
            ]);
        });

        return redirect()->route('users.index')->with('status', "Restored {$user->name}. Account remains frozen — unfreeze separately to allow sign-in.");
    }
}
