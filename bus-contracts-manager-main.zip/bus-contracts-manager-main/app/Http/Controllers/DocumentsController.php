<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Attachment;
use App\Models\AttachmentLink;
use App\Models\Contract;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\View\View;

/**
 * Documents — top-level workspace section grouping every file the
 * app stores. Currently splits two ways:
 *   - Attachments: every contract-slot attachment (the data this
 *     controller has wired up today; lives on the `attachments` /
 *     `attachment_links` tables).
 *   - Settlements: TfL settlement statements — coming-soon stub.
 *     Future home of the parsed PDF figures the claim reports
 *     consume.
 *
 * Read-only by design; mutating actions (detach, replace) still
 * happen inside the contract dialogs that own the slot.
 *
 * Auth-only (every signed-in user sees the same data they could
 * already reach by clicking through contracts). Mirrors the contracts
 * + audit-log list patterns: filter toolbar, archived-toggle for
 * detached files, paginated table.
 */
class DocumentsController extends Controller
{
    private const PER_PAGE = 50;

    /**
     * Bare /documents → land on the default sub-page (Attachments).
     * Keeps the URL stable for anyone who linked to /documents pre-split.
     */
    public function index(): \Illuminate\Http\RedirectResponse
    {
        return redirect()->route('documents.attachments');
    }

    /**
     * Coming-soon stub for the Settlements sub-page. Future home of
     * the TfL settlement-statement PDFs the claim reports will consume.
     */
    public function settlements(): View
    {
        return view('documents.settlements');
    }

    public function attachments(Request $request): View
    {
        $filters = $this->resolveFilters($request);
        $showDetached = $request->boolean('detached');

        // The `contents` BLOB column is huge — never select it on a
        // list query. Same precaution the model docblock calls out.
        $base = Attachment::query()
            ->select(['id', 'audit_log_id', 'attachable_key', 'original_filename',
                'mime_type', 'size_bytes', 'sha256', 'uploaded_by', 'detached_at', 'created_at'])
            ->with('uploader:id,name,email')
            ->when($showDetached,
                fn ($q) => $q->whereNotNull('detached_at'),
                fn ($q) => $q->whereNull('detached_at'));

        if ($filters['q'] !== null) {
            $needle = '%'.str_replace('%', '\\%', $filters['q']).'%';
            $base->where('original_filename', 'like', $needle);
        }

        if (! empty($filters['extensions'])) {
            $base->where(function ($q) use ($filters) {
                foreach ($filters['extensions'] as $ext) {
                    $q->orWhere('original_filename', 'like', "%.{$ext}");
                }
            });
        }

        if (! empty($filters['uploaders'])) {
            $base->whereIn('uploaded_by', $filters['uploaders']);
        }

        $totalCount = (clone $base)->count();
        $detachedCount = Attachment::query()->whereNotNull('detached_at')->count();

        $attachments = $base
            ->orderByDesc('created_at')
            ->orderByDesc('id')
            ->paginate(self::PER_PAGE)
            ->withQueryString();

        // Build the link lookup for the visible attachments only —
        // active links resolved to their slot label + contract context.
        $attachmentIds = $attachments->pluck('id')->all();
        $linkLookup = $this->buildLinkLookup($attachmentIds);

        // Collect every contract id any link references so we can fetch
        // them in one query and resolve the human-readable labels.
        $contractIds = $linkLookup
            ->flatten(1)
            ->pluck('contract_id')
            ->filter()
            ->unique()
            ->values()
            ->all();

        $contractLookup = Contract::query()
            ->whereIn('id', $contractIds)
            ->get(['id', 'contract_number', 'route', 'company', 'archived_at'])
            ->keyBy('id');

        // Distinct uploaders for the filter dropdown — drawn from the
        // unfiltered universe so the chip set doesn't shrink as the
        // user filters (matches the audit-log convention).
        $uploaderOptions = User::query()
            ->whereIn('id', Attachment::query()->select('uploaded_by')->distinct())
            ->orderBy('name')
            ->get(['id', 'name']);

        // Distinct extensions in the unfiltered universe, for the
        // extension filter dropdown.
        $extensionOptions = Attachment::query()
            ->select('original_filename')
            ->distinct()
            ->pluck('original_filename')
            ->map(fn ($name) => strtolower(pathinfo((string) $name, PATHINFO_EXTENSION)))
            ->filter(fn ($ext) => $ext !== '')
            ->unique()
            ->sort()
            ->values()
            ->all();

        return view('documents.attachments', [
            'attachments' => $attachments,
            'filters' => $filters,
            'showDetached' => $showDetached,
            'totalCount' => $totalCount,
            'detachedCount' => $detachedCount,
            'linkLookup' => $linkLookup,
            'contractLookup' => $contractLookup,
            'uploaderOptions' => $uploaderOptions,
            'extensionOptions' => $extensionOptions,
        ]);
    }

    /**
     * @return array{q: ?string, extensions: array<int, string>, uploaders: array<int, int>}
     */
    private function resolveFilters(Request $request): array
    {
        $q = trim((string) $request->string('q', ''));

        $extensions = collect((array) $request->input('extensions', []))
            ->map(fn ($v) => strtolower(trim((string) $v)))
            ->filter(fn ($v) => $v !== '')
            ->unique()
            ->values()
            ->all();

        $uploaders = collect((array) $request->input('uploaders', []))
            ->map(fn ($v) => (int) $v)
            ->filter(fn ($v) => $v > 0)
            ->unique()
            ->values()
            ->all();

        return [
            'q' => $q !== '' ? $q : null,
            'extensions' => $extensions,
            'uploaders' => $uploaders,
        ];
    }

    /**
     * For each attachment id, resolve the list of active link slots
     * with their parsed contract id + a friendly slot label. Returns
     * a Collection keyed by attachment id, with a list of:
     *   ['link_id' => int, 'attachable_key' => string,
     *    'contract_id' => ?int, 'slot_label' => string]
     *
     * Only ACTIVE links are returned (detached_at is null). Detached
     * attachments will have an empty entry — the view falls back to
     * "—" in the Linked-to column.
     *
     * @param  array<int, int>  $attachmentIds
     * @return Collection<int, list<array{link_id: int, attachable_key: string, contract_id: ?int, slot_label: string}>>
     */
    private function buildLinkLookup(array $attachmentIds): Collection
    {
        if ($attachmentIds === []) {
            return collect();
        }

        return AttachmentLink::query()
            ->whereIn('attachment_id', $attachmentIds)
            ->whereNull('detached_at')
            ->orderBy('id')
            ->get(['id', 'attachment_id', 'attachable_key'])
            ->groupBy('attachment_id')
            ->map(fn ($group) => $group->map(function (AttachmentLink $link) {
                [$contractId, $slotLabel] = $this->parseAttachableKey($link->attachable_key);

                return [
                    'link_id' => $link->id,
                    'attachable_key' => $link->attachable_key,
                    'contract_id' => $contractId,
                    'slot_label' => $slotLabel,
                ];
            })->values()->all());
    }

    /**
     * Parse an attachable_key into [contract_id, slot_label].
     *
     * Mirrors AttachmentsController::slotLabel but also returns the
     * contract id so the view can link to it.
     *
     * Examples:
     *   contract:406              → [406, 'Contract record']
     *   contract:406:cpa:2024     → [406, 'CPA confirmation 2024']
     *   contract:406:extension    → [406, 'Extension flag']
     *   contract:406:notice_served → [406, 'Notice-served flag']
     *   contract:406:tender_award → [406, 'Tender award']
     *
     * @return array{0: ?int, 1: string}
     */
    private function parseAttachableKey(?string $key): array
    {
        if ($key === null) {
            return [null, 'Contract record'];
        }

        $parts = explode(':', $key);
        $contractId = ($parts[0] ?? null) === 'contract' && isset($parts[1]) && ctype_digit($parts[1])
            ? (int) $parts[1]
            : null;

        if (count($parts) === 2) {
            return [$contractId, 'Contract record'];
        }

        if (count($parts) >= 4 && $parts[2] === 'cpa') {
            return [$contractId, "CPA confirmation {$parts[3]}"];
        }

        $label = match ($parts[2] ?? '') {
            'extension' => 'Extension flag',
            'notice_served' => 'Notice-served flag',
            'tender_award' => 'Tender award',
            default => 'Contract record',
        };

        return [$contractId, $label];
    }
}
