<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreContractRequest;
use App\Http\Requests\UpdateContractRequest;
use App\Models\AppSetting;
use App\Models\Attachment;
use App\Models\AttachmentLink;
use App\Models\AuditLog;
use App\Models\Contract;
use App\Models\CpaRate;
use App\Support\AttachmentUpload;
use App\Support\CsvExporter;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ContractController extends Controller
{
    /** Hard cap on import file rows so a runaway upload can't blow up memory. */
    private const IMPORT_ROW_CAP = 5000;

    public function index(Request $request): View
    {
        $filters = $this->resolveFilters($request);
        $showArchived = $request->boolean('archived');

        // Apply every active filter except the one we're computing chip
        // counts for — that way each filter dropdown shows the options that
        // are still reachable given the other selections. (Selecting EL
        // narrows the depot list to depots that exist within EL, and so on.)
        // Status is derived from start_date / end_date relative to today —
        // map each status code to a SQL predicate so the filter can run
        // server-side instead of post-filtering the result set in PHP.
        $today = Carbon::today()->toDateString();
        $statusPredicates = [
            'active' => fn ($q) => $q->where('start_date', '<=', $today)->where('end_date', '>=', $today),
            'expired' => fn ($q) => $q->where('end_date', '<', $today),
            'upcoming' => fn ($q) => $q->where('start_date', '>', $today),
        ];

        $applyFilters = function ($query, array $exclude = []) use ($filters, $statusPredicates) {
            if (! in_array('companies', $exclude, true) && ! empty($filters['companies'])) {
                $query->whereIn('company', $filters['companies']);
            }
            if (! in_array('depots', $exclude, true) && ! empty($filters['depots'])) {
                $query->whereIn('depot', $filters['depots']);
            }
            if (! in_array('statuses', $exclude, true) && ! empty($filters['statuses'])) {
                $query->where(function ($q) use ($filters, $statusPredicates) {
                    foreach ($filters['statuses'] as $status) {
                        if (isset($statusPredicates[$status])) {
                            $q->orWhere(fn ($qq) => $statusPredicates[$status]($qq));
                        }
                    }
                });
            }
            if (! in_array('q', $exclude, true) && $filters['q'] !== null) {
                // `#42` → exact lookup by primary key. Used by the
                // Documents page (and anywhere else that links to
                // "this specific contract") so a unique-id link
                // always lands on a single row, even if the same
                // number is shared across variants.
                if (preg_match('/^#(\d+)$/', $filters['q'], $m) === 1) {
                    $query->where('id', '=', (int) $m[1]);
                } else {
                    // Otherwise: substring match across the searchable
                    // columns.
                    $like = '%'.$filters['q'].'%';
                    $query->where(fn ($q) => $q
                        ->where('contract_number', 'like', $like)
                        ->orWhere('route', 'like', $like)
                        ->orWhere('company', 'like', $like)
                        ->orWhere('depot', 'like', $like));
                }
            }

            return $query;
        };

        // Archived contracts get their own view via ?archived=1 (mirrors
        // the Manage Users archive toggle). Default lists hide them.
        $archiveScope = fn ($q) => $showArchived ? $q->archived() : $q->active();

        $query = Contract::query()
            ->tap($archiveScope)
            ->orderBy('start_date')
            ->orderBy('contract_number');

        $applyFilters($query);

        $contracts = $query->get();

        $companyCounts = $applyFilters(
            Contract::query()->tap($archiveScope)->selectRaw('company, count(*) as c')->groupBy('company')->orderBy('company'),
            exclude: ['companies'],
        )->pluck('c', 'company')->all();

        $depotCounts = $applyFilters(
            Contract::query()->tap($archiveScope)->selectRaw('depot, count(*) as c')->groupBy('depot')->orderBy('depot'),
            exclude: ['depots'],
        )->pluck('c', 'depot')->all();

        // Status chip counts — apply the rest of the active filters but skip
        // status itself, then run the per-status predicate over what remains.
        $statusCounts = [];
        foreach (['active', 'expired', 'upcoming'] as $status) {
            $statusCounts[$status] = $applyFilters(Contract::query()->tap($archiveScope), exclude: ['statuses'])
                ->where(fn ($q) => $statusPredicates[$status]($q))
                ->count();
        }

        $archivedCount = Contract::query()->archived()->count();

        // Derive the four CPA-applicable year columns from the global anchor:
        // anchor-1 → anchor+2. Then bulk-load every CpaRate row in that range
        // and key it by month string ('Y-m-d') so the view can do per-cell
        // lookups in O(1) without N+1 queries.
        // Anchor falls back to the AppSetting default when no row is
        // saved yet, so the CPA columns render on a fresh install
        // without forcing the operator into Settings first.
        $globalAnchor = AppSetting::contractsAnchorYear();
        $cpaYears = range($globalAnchor - 1, $globalAnchor + 2);
        $cpaRatesByMonth = [];
        if (! empty($cpaYears)) {
            $cpaRatesByMonth = CpaRate::query()
                ->whereBetween('month', [
                    sprintf('%04d-01-01', $cpaYears[0]),
                    sprintf('%04d-12-31', end($cpaYears)),
                ])
                ->get()
                ->keyBy(fn ($r) => $r->month)
                ->all();
        }

        // Bulk-load every active attachment link for the contracts in
        // view, grouped by attachable_key. Lets each cell-click handler
        // hand the dialog a ready-made attachments list with no extra
        // round-trip. Reads via the AttachmentLink pivot (Stage 2 of the
        // link-existing rollout) so multi-slot files surface in every
        // slot they're linked from. Metadata-only — never the blob.
        $contractIds = $contracts->pluck('id')->all();
        $attachmentsByKey = [];
        if (! empty($contractIds)) {
            $keyPrefixes = array_map(fn ($id) => "contract:{$id}", $contractIds);
            $attachmentsByKey = AttachmentLink::query()
                ->select(['id', 'attachment_id', 'attachable_key', 'created_at'])
                ->whereNull('detached_at')
                ->where(function ($q) use ($keyPrefixes) {
                    foreach ($keyPrefixes as $p) {
                        $q->orWhere('attachable_key', '=', $p)
                            ->orWhere('attachable_key', 'like', $p.':%');
                    }
                })
                ->with(['attachment:id,original_filename,size_bytes,uploaded_by'])
                ->orderBy('created_at')
                ->get()
                ->groupBy('attachable_key')
                ->map(fn ($group) => $group->map(fn ($link) => [
                    'id' => $link->attachment->id,                  // download URL still uses attachment id
                    'link_id' => $link->id,                          // detach URL uses link id
                    'filename' => $link->attachment->original_filename,
                    'size_kb' => (int) round(($link->attachment->size_bytes ?? 0) / 1024),
                    'when' => $link->created_at?->format('d/m/Y H:i'),
                ])->values()->all())
                ->all();
        }

        return view('contracts.index', [
            'contracts' => $contracts,
            'filters' => $filters,
            'companyCounts' => $companyCounts,
            'depotCounts' => $depotCounts,
            'statusCounts' => $statusCounts,
            'totalCount' => Contract::query()->tap($archiveScope)->count(),
            'showArchived' => $showArchived,
            'archivedCount' => $archivedCount,
            'anchorYear' => $globalAnchor,
            'p2pRaCutoff' => AppSetting::contractsP2pRaCutoff(),
            'cpaYears' => $cpaYears,
            'cpaRatesByMonth' => $cpaRatesByMonth,
            'attachmentsByKey' => $attachmentsByKey,
        ]);
    }

    /**
     * Update the contracts settings: the anchor year (the year contract
     * values are denominated against) and the P2P/RA cutoff (the tender
     * date that splits the older P2P regime from the newer RA regime).
     * Both feed downstream indexation calculations.
     */
    public function updateSettings(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $validated = $request->validate([
            'anchor_year' => ['required', 'digits:4', 'integer', 'min:1990', 'max:2100'],
            'p2p_ra_cutoff' => ['required', 'date'],
        ]);

        $newYear = (string) $validated['anchor_year'];
        $newCutoff = Carbon::parse($validated['p2p_ra_cutoff'])->toDateString();
        $oldYear = AppSetting::get(AppSetting::CONTRACTS_ANCHOR_YEAR);
        $oldCutoff = AppSetting::get(AppSetting::CONTRACTS_P2P_RA_CUTOFF);

        $changes = [];
        if ((string) $oldYear !== $newYear) {
            $changes['anchor_year'] = ['from' => $oldYear, 'to' => $newYear];
        }
        if ((string) $oldCutoff !== $newCutoff) {
            $changes['p2p_ra_cutoff'] = ['from' => $oldCutoff, 'to' => $newCutoff];
        }

        if (empty($changes)) {
            return redirect()->route('contracts.index')->with('status', 'No settings changes to save.');
        }

        DB::transaction(function () use ($request, $newYear, $newCutoff, $changes) {
            AppSetting::put(AppSetting::CONTRACTS_ANCHOR_YEAR, $newYear, $request->user()->id);
            AppSetting::put(AppSetting::CONTRACTS_P2P_RA_CUTOFF, $newCutoff, $request->user()->id);

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'contract_settings_updated',
                'entity_type' => 'app_settings',
                'entity_id' => 0,
                'old_values' => array_map(fn ($c) => $c['from'], $changes),
                'new_values' => array_map(fn ($c) => $c['to'], $changes),
                'note' => 'Contract settings updated',
                'ip_address' => $request->ip(),
            ]);
        });

        return redirect()->route('contracts.index')->with('status', 'Contract settings saved.');
    }

    public function store(StoreContractRequest $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $contract = DB::transaction(function () use ($request) {
            $contract = Contract::create([
                ...$request->validated(),
                'created_by' => $request->user()->id,
            ]);

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'contract_added',
                'entity_type' => $contract->getTable(),
                'entity_id' => $contract->getKey(),
                'new_values' => $request->validated(),
                'note' => $this->contractRef($contract).' New contract added',
                'ip_address' => $request->ip(),
            ]);

            return $contract;
        });

        return redirect()->to(route('contracts.index')."#contract-{$contract->id}")
            ->with('status', "Added contract {$contract->contract_number} ({$contract->route}).");
    }

    /**
     * Update a contract. The user must classify the change as an
     * `override` (correcting bad data) or `variation` (a legitimate
     * contract amendment) — both paths persist the new values, but the
     * audit-log entry records which it was so a future reviewer can tell
     * a typo-fix from a renegotiation.
     */
    public function update(UpdateContractRequest $request, Contract $contract): RedirectResponse
    {
        // Archived contracts are immutable — restore them first if a
        // legitimate edit is needed. Defence-in-depth alongside the UI
        // which already hides the edit dialog's Save button.
        abort_if($contract->isArchived(), 404);

        $kind = $request->validated('change_kind');
        $note = $request->validated('change_note');
        $dupeAction = $request->validated('dupe_action');

        // Server-side guard against tampered submissions where the user
        // bypassed the client-side dupe dialog. Throws if a dupe exists
        // and no action was picked.
        AttachmentUpload::assertDupeActionIfNeeded($request->file('attachment'), $dupeAction);

        $newValues = collect($request->validated())
            ->only([
                'company', 'depot', 'route', 'contract_number',
                'tender_date', 'start_date', 'end_date',
                'contract_value', 'contracted_miles',
                'tender_award_note', 'pvr', 'tvr', 'propulsion', 'decks',
            ])
            ->all();

        // Track the "reason for change" textarea (persisted on the
        // contract as latest_change_note) so a note-only edit also
        // shows up in the audit diff. Trim+nullify so "  " == "" ==
        // null don't show as phantom changes when the note's unchanged.
        $trimmedNoteForCompare = trim((string) ($note ?? ''));
        $newValues['latest_change_note'] = $trimmedNoteForCompare !== '' ? $trimmedNoteForCompare : null;

        $changes = [];
        foreach ($newValues as $field => $value) {
            $current = $this->normaliseForCompare($contract->getAttribute($field), $field);
            $next = $this->normaliseForCompare($value, $field);

            if ($current !== $next) {
                $changes[$field] = ['from' => $current, 'to' => $next];
            }
        }

        $hasAttachment = $request->file('attachment') !== null;

        // True no-op only when nothing changed AND no attachment to upload.
        // Attachment-only saves still produce an audit row + attachment.
        if (empty($changes) && ! $hasAttachment) {
            return redirect()->route('contracts.index')->with('status', 'No changes to save.');
        }

        DB::transaction(function () use ($request, $contract, $newValues, $changes, $kind, $note, $dupeAction, $hasAttachment) {
            $contract->fill($newValues);
            // Persist the note on the contract so the Edit dialog can
            // pre-fill it next time. Empty / whitespace-only notes clear
            // the column rather than keeping a stale message from an
            // earlier change.
            $trimmedNote = trim((string) ($note ?? ''));
            $contract->latest_change_note = $trimmedNote !== '' ? $trimmedNote : null;
            $contract->updated_by = $request->user()->id;
            $contract->save();

            // Attachment-only save → distinct action key so the audit log
            // doesn't show a phantom "Override" with no diff. When real
            // field changes exist they take precedence and the upload is
            // attached to that row instead.
            if (empty($changes) && $hasAttachment) {
                $log = AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'contract_attachment_attached',
                    'entity_type' => $contract->getTable(),
                    'entity_id' => $contract->getKey(),
                    'old_values' => null,
                    'new_values' => null,
                    'note' => $this->contractRef($contract).' Attachment uploaded to contract record',
                    'ip_address' => $request->ip(),
                ]);
            } else {
                $action = match ($kind) {
                    'variation' => 'contract_varied',
                    'confirmation' => 'contract_confirmed',
                    default => 'contract_overridden',
                };
                $kindLabel = match ($kind) {
                    'variation' => 'Variation',
                    'confirmation' => 'Confirmation',
                    default => 'Override',
                };
                $combinedNote = $note ? "{$kindLabel}: {$note}" : "{$kindLabel} — no further note";

                $log = AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => $action,
                    'entity_type' => $contract->getTable(),
                    'entity_id' => $contract->getKey(),
                    'old_values' => array_map(fn ($c) => $c['from'], $changes),
                    'new_values' => array_map(fn ($c) => $c['to'], $changes),
                    'note' => $this->contractRef($contract).' '.$combinedNote,
                    'ip_address' => $request->ip(),
                ]);
            }

            AttachmentUpload::persist(
                $request->file('attachment'),
                $log,
                $request->user(),
                $dupeAction,
                "contract:{$contract->id}"
            );
        });

        $verb = $kind === 'variation' ? 'Varied' : 'Updated';

        return redirect()->to(route('contracts.index')."#contract-{$contract->id}")
            ->with('status', "{$verb} contract {$contract->contract_number} ({$contract->route}).");
    }

    /**
     * Inline CPA-confirmation update for a single (contract, year) cell from
     * the contracts table. Pre-anchor years are rejected here — they're
     * always 'yes' by derivation and must never be stored. Each save writes
     * one audit-log entry alongside the column update, so a reviewer can see
     * who flipped which year and when.
     */
    public function updateCpaConfirmation(Request $request, Contract $contract): RedirectResponse
    {
        abort_if($contract->isArchived(), 404);

        $globalAnchor = AppSetting::contractsAnchorYear();

        $validated = $request->validate([
            'year' => ['required', 'integer', 'min:1990', 'max:2100'],
            'status' => ['required', 'string', 'in:yes,no'],
            'note' => ['nullable', 'string', 'max:500'],
            'dupe_action' => AttachmentUpload::dupeActionRule(),
        ] + AttachmentUpload::rules());

        AttachmentUpload::assertDupeActionIfNeeded($request->file('attachment'), $validated['dupe_action'] ?? null);

        if (! $contract->isCpaConfirmationEditable($validated['year'], $globalAnchor)) {
            return back()->with('updateError', 'That year is locked — pre-anchor confirmations are always Yes.');
        }

        $oldStatus = $contract->cpaConfirmation($validated['year'], $globalAnchor);
        $oldNote = $contract->cpaConfirmationNote($validated['year']);
        $newNote = trim((string) ($validated['note'] ?? '')) !== ''
            ? trim($validated['note'])
            : null;

        // Skip silent re-saves: if neither status nor note changed, the
        // request is a no-op (dialog opened and Save clicked
        // without changing anything). Don't pollute the audit trail.
        $hasAttachment = $request->file('attachment') !== null;
        $unchanged = $oldStatus === $validated['status'] && $oldNote === $newNote;

        if ($unchanged && ! $hasAttachment) {
            return back();
        }

        DB::transaction(function () use ($request, $contract, $validated, $oldStatus, $oldNote, $newNote, $unchanged, $hasAttachment) {
            $confirmations = $contract->cpa_confirmations ?? [];
            $confirmations[(string) $validated['year']] = $validated['status'];
            $contract->cpa_confirmations = $confirmations;

            // Persist the note alongside the status so the next dialog
            // open can pre-fill it. Empty notes drop the year key entirely
            // rather than storing an empty string.
            $notes = $contract->cpa_confirmation_notes ?? [];
            if ($newNote !== null) {
                $notes[(string) $validated['year']] = $newNote;
            } else {
                unset($notes[(string) $validated['year']]);
            }
            $contract->cpa_confirmation_notes = $notes === [] ? null : $notes;

            $contract->updated_by = $request->user()->id;
            $contract->save();

            $statusLabel = ucfirst($validated['status']);
            $auditNote = $this->contractRef($contract)." CPA confirmation for {$validated['year']} set to {$statusLabel}";
            if ($newNote !== null) {
                $auditNote .= ' — '.$newNote;
            }

            $yearKey = (string) $validated['year'];
            $attachableKey = "contract:{$contract->id}:cpa:{$yearKey}";

            if ($unchanged && $hasAttachment) {
                $log = AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'contract_attachment_attached',
                    'entity_type' => $contract->getTable(),
                    'entity_id' => $contract->getKey(),
                    'old_values' => null,
                    'new_values' => ['attachable_key' => $attachableKey],
                    'note' => $this->contractRef($contract)." Attachment uploaded to CPA confirmation {$yearKey}",
                    'ip_address' => $request->ip(),
                ]);
            } else {
                $log = AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'contract_cpa_confirmed',
                    'entity_type' => $contract->getTable(),
                    'entity_id' => $contract->getKey(),
                    'old_values' => [$yearKey => $oldStatus, "{$yearKey}_note" => $oldNote],
                    'new_values' => [$yearKey => $validated['status'], "{$yearKey}_note" => $newNote],
                    'note' => $auditNote,
                    'ip_address' => $request->ip(),
                ]);
            }

            AttachmentUpload::persist(
                $request->file('attachment'),
                $log,
                $request->user(),
                $validated['dupe_action'] ?? null,
                $attachableKey
            );
        });

        return redirect()->to(route('contracts.index')."#contract-{$contract->id}")
            ->with('status', "CPA {$validated['year']} for {$contract->contract_number} set to ".ucfirst($validated['status']).'.');
    }

    /**
     * Set the Extension flag for a contract. The flag drives the ET-date
     * formula's "re-let" branch, so a change here can shift the ET date
     * shown elsewhere in the table. Note is mandatory (matches the
     * pattern this app is moving towards for status flags).
     */
    public function updateExtension(Request $request, Contract $contract): RedirectResponse
    {
        abort_if($contract->isArchived(), 404);

        $validated = $request->validate([
            'status' => ['required', 'string', 'in:yes,no'],
            'note' => ['nullable', 'string', 'max:500'],
            'dupe_action' => AttachmentUpload::dupeActionRule(),
        ] + AttachmentUpload::rules());

        AttachmentUpload::assertDupeActionIfNeeded($request->file('attachment'), $validated['dupe_action'] ?? null);

        $oldStatus = $contract->extensionStatus();
        $oldNote = $contract->extensionNote();
        $newNote = trim((string) ($validated['note'] ?? '')) !== '' ? trim($validated['note']) : null;
        $hasAttachment = $request->file('attachment') !== null;
        $statusChanged = $oldStatus !== $validated['status'];
        $noteChanged = $oldNote !== $newNote;

        // Note still required when the status itself is being set (matches
        // the original design intent — the note is the "why" for a flag
        // change). Evidence-only saves don't need a new note.
        if ($statusChanged && $newNote === null) {
            return back()->withErrors(['note' => 'A note is required when setting the extension flag.']);
        }

        if (! $statusChanged && ! $noteChanged && ! $hasAttachment) {
            return back();
        }

        DB::transaction(function () use ($request, $contract, $validated, $oldStatus, $oldNote, $newNote, $hasAttachment, $statusChanged, $noteChanged) {
            $attachableKey = "contract:{$contract->id}:extension";

            if (! $statusChanged && ! $noteChanged && $hasAttachment) {
                $log = AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'contract_attachment_attached',
                    'entity_type' => $contract->getTable(),
                    'entity_id' => $contract->getKey(),
                    'old_values' => null,
                    'new_values' => ['attachable_key' => $attachableKey],
                    'note' => $this->contractRef($contract).' Attachment uploaded to Extension flag',
                    'ip_address' => $request->ip(),
                ]);
            } else {
                $contract->extension_status = $validated['status'];
                $contract->extension_note = $newNote;
                $contract->updated_by = $request->user()->id;
                $contract->save();

                $statusLabel = ucfirst($validated['status']);
                $log = AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'contract_extension_set',
                    'entity_type' => $contract->getTable(),
                    'entity_id' => $contract->getKey(),
                    'old_values' => ['extension_status' => $oldStatus, 'extension_note' => $oldNote],
                    'new_values' => ['extension_status' => $validated['status'], 'extension_note' => $newNote],
                    'note' => $this->contractRef($contract)." Extension set to {$statusLabel}".($newNote ? " — {$newNote}" : ''),
                    'ip_address' => $request->ip(),
                ]);
            }

            AttachmentUpload::persist(
                $request->file('attachment'),
                $log,
                $request->user(),
                $validated['dupe_action'] ?? null,
                $attachableKey
            );
        });

        return redirect()->to(route('contracts.index')."#contract-{$contract->id}")
            ->with('status', "Extension for {$contract->contract_number} set to ".ucfirst($validated['status']).'.');
    }

    /**
     * Set the Notice-served flag. Mirrors updateExtension exactly — same
     * shape, different column. Note mandatory.
     */
    public function updateNoticeServed(Request $request, Contract $contract): RedirectResponse
    {
        abort_if($contract->isArchived(), 404);

        $validated = $request->validate([
            'status' => ['required', 'string', 'in:yes,no'],
            'note' => ['nullable', 'string', 'max:500'],
            'dupe_action' => AttachmentUpload::dupeActionRule(),
        ] + AttachmentUpload::rules());

        AttachmentUpload::assertDupeActionIfNeeded($request->file('attachment'), $validated['dupe_action'] ?? null);

        $oldStatus = $contract->noticeServedStatus();
        $oldNote = $contract->noticeServedNoteValue();
        $newNote = trim((string) ($validated['note'] ?? '')) !== '' ? trim($validated['note']) : null;
        $hasAttachment = $request->file('attachment') !== null;
        $statusChanged = $oldStatus !== $validated['status'];
        $noteChanged = $oldNote !== $newNote;

        if ($statusChanged && $newNote === null) {
            return back()->withErrors(['note' => 'A note is required when setting the notice-served flag.']);
        }

        if (! $statusChanged && ! $noteChanged && ! $hasAttachment) {
            return back();
        }

        DB::transaction(function () use ($request, $contract, $validated, $oldStatus, $oldNote, $newNote, $hasAttachment, $statusChanged, $noteChanged) {
            $attachableKey = "contract:{$contract->id}:notice_served";

            if (! $statusChanged && ! $noteChanged && $hasAttachment) {
                $log = AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'contract_attachment_attached',
                    'entity_type' => $contract->getTable(),
                    'entity_id' => $contract->getKey(),
                    'old_values' => null,
                    'new_values' => ['attachable_key' => $attachableKey],
                    'note' => $this->contractRef($contract).' Attachment uploaded to Notice-served flag',
                    'ip_address' => $request->ip(),
                ]);
            } else {
                $contract->notice_served_status = $validated['status'];
                $contract->notice_served_note = $newNote;
                $contract->updated_by = $request->user()->id;
                $contract->save();

                $statusLabel = ucfirst($validated['status']);
                $log = AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'contract_notice_served_set',
                    'entity_type' => $contract->getTable(),
                    'entity_id' => $contract->getKey(),
                    'old_values' => ['notice_served_status' => $oldStatus, 'notice_served_note' => $oldNote],
                    'new_values' => ['notice_served_status' => $validated['status'], 'notice_served_note' => $newNote],
                    'note' => $this->contractRef($contract)." Notice served set to {$statusLabel}".($newNote ? " — {$newNote}" : ''),
                    'ip_address' => $request->ip(),
                ]);
            }

            AttachmentUpload::persist(
                $request->file('attachment'),
                $log,
                $request->user(),
                $validated['dupe_action'] ?? null,
                $attachableKey
            );
        });

        return redirect()->to(route('contracts.index')."#contract-{$contract->id}")
            ->with('status', "Notice served for {$contract->contract_number} set to ".ucfirst($validated['status']).'.');
    }

    /**
     * Set the free-text "Tender award" label for a contract (e.g. "Option
     * 1", "Option 4 EV"). Same shape as the flag dialogs but with a
     * single text field plus optional evidence upload.
     */
    public function updateTenderAward(Request $request, Contract $contract): RedirectResponse
    {
        abort_if($contract->isArchived(), 404);

        $validated = $request->validate([
            'note' => ['nullable', 'string', 'max:500'],
            'dupe_action' => AttachmentUpload::dupeActionRule(),
        ] + AttachmentUpload::rules());

        AttachmentUpload::assertDupeActionIfNeeded($request->file('attachment'), $validated['dupe_action'] ?? null);

        $oldNote = $contract->tenderAwardNoteValue();
        $newNote = trim((string) ($validated['note'] ?? '')) !== ''
            ? trim($validated['note'])
            : null;

        $hasAttachment = $request->file('attachment') !== null;
        $noteChanged = $oldNote !== $newNote;

        if (! $noteChanged && ! $hasAttachment) {
            return back();
        }

        DB::transaction(function () use ($request, $contract, $newNote, $oldNote, $validated, $hasAttachment, $noteChanged) {
            $attachableKey = "contract:{$contract->id}:tender_award";

            if (! $noteChanged && $hasAttachment) {
                $log = AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'contract_attachment_attached',
                    'entity_type' => $contract->getTable(),
                    'entity_id' => $contract->getKey(),
                    'old_values' => null,
                    'new_values' => ['attachable_key' => $attachableKey],
                    'note' => $this->contractRef($contract).' Attachment uploaded to Tender award',
                    'ip_address' => $request->ip(),
                ]);
            } else {
                $contract->tender_award_note = $newNote;
                $contract->updated_by = $request->user()->id;
                $contract->save();

                $auditNote = $this->contractRef($contract).' Tender award '
                    .($newNote !== null ? "set to {$newNote}" : 'cleared');

                $log = AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'contract_tender_award_set',
                    'entity_type' => $contract->getTable(),
                    'entity_id' => $contract->getKey(),
                    'old_values' => ['tender_award_note' => $oldNote],
                    'new_values' => ['tender_award_note' => $newNote],
                    'note' => $auditNote,
                    'ip_address' => $request->ip(),
                ]);
            }

            AttachmentUpload::persist(
                $request->file('attachment'),
                $log,
                $request->user(),
                $validated['dupe_action'] ?? null,
                $attachableKey
            );
        });

        return redirect()->to(route('contracts.index')."#contract-{$contract->id}")
            ->with('status', "Tender award updated for {$contract->contract_number}.");
    }

    /**
     * Export every contract as CSV. Columns mirror the on-screen table's
     * editable inputs (Company, Depot, Route, Contract no., Tender, Start,
     * End, Value, Contracted miles). Derived columns (Anchor, CPA type,
     * CPA %, CPA Anv) are omitted — they're computed at render time and
     * re-derive cleanly on re-import. CPA confirmations are excluded too:
     * they're audited per-cell and only ever set through the in-app dialog.
     */
    public function exportCsv(): StreamedResponse
    {
        $contracts = Contract::query()->active()->orderBy('start_date')->orderBy('contract_number')->get();
        $filename = sprintf('contracts-%s.csv', now()->format('Y-m-d'));

        return response()->streamDownload(function () use ($contracts) {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['id', 'company', 'depot', 'route', 'contract_number', 'tender_date', 'start_date', 'end_date', 'contract_value', 'contracted_miles'], ',', '"', '');

            foreach ($contracts as $contract) {
                // Wrap user-controllable fields through CsvExporter::safeCell
                // to neutralise CSV / formula injection — a contract row
                // with route="=cmd|'/c calc'!A1" would otherwise execute on
                // the next reviewer's machine.
                fputcsv($out, CsvExporter::safeRow([
                    $contract->id,
                    $contract->company,
                    $contract->depot,
                    $contract->route,
                    $contract->contract_number,
                    $contract->formatTenderDate(),
                    $contract->formatStartDate(),
                    $contract->formatEndDate(),
                    number_format((float) $contract->contract_value, 2, '.', ''),
                    $contract->contracted_miles !== null
                        ? number_format((float) $contract->contracted_miles, 2, '.', '')
                        : '',
                ]), ',', '"', '');
            }

            fclose($out);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    /**
     * Empty CSV with the importable column set, plus three sample rows —
     * one per import_type value (`new`, `override`, `variation`).
     * Required columns are prefixed with `*` in the header; the parser
     * strips that prefix and column order doesn't matter. Dates accept
     * either dd/mm/yyyy or an Excel serial number.
     *
     * Optional columns: tender_award_note (free text e.g. "Option 1"),
     * pvr, tvr, propulsion, decks. CPA confirmations, extension flag,
     * notice-served flag, and tender award evidence are not importable —
     * each has its own audit-logged write path in the in-app dialogs.
     */
    public function importTemplate(): StreamedResponse
    {
        return response()->streamDownload(function () {
            $out = fopen('php://output', 'w');

            fputcsv($out, [
                'import_type', 'id',
                '*company', '*depot', '*route', '*contract_number',
                '*tender_date', '*start_date', '*end_date',
                '*contract_value', '*contracted_miles',
                'tender_award_note', 'pvr', 'tvr', 'propulsion', 'decks',
            ], ',', '"', '');

            foreach ([
                ['new', '', 'AB', 'CD', '100', 'QC12345', '01/01/2024', '01/04/2024', '31/03/2031', '1500000.00', '475000.00', 'Option A', '12', '14', 'Diesel', 'SD'],
                ['override', '42', 'AB', 'CD', '100', 'QC12345', '01/01/2024', '01/04/2024', '31/03/2031', '1525000.00', '478000.00', '', '', '', '', ''],
                ['variation', '42', 'AB', 'CD', '100', 'QC12345', '01/01/2024', '01/04/2024', '31/03/2032', '1525000.00', '480000.00', '', '', '', '', ''],
            ] as $sample) {
                fputcsv($out, $sample, ',', '"', '');
            }

            fclose($out);
        }, 'contracts-import-template.csv', [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    /**
     * Bulk-import contracts from CSV. Each row carries a Type code:
     *   1 — override an existing contract (correcting bad data)
     *   2 — variation (contractual amendment) of an existing contract
     *   3 — new contract entry
     *
     * Type 1 and 2 match against `contract_number`. If 0 or >1 contracts
     * match, the row is rejected (overrides on ambiguous matches would
     * silently mutate the wrong record). Per-row audit entries are written
     * for Types 1 and 2 with the old→new diff so the trail mirrors a manual
     * override or variation. New inserts (Type 3) are captured by a single
     * batch summary entry. The whole import runs inside one DB transaction,
     * so any audit failure rolls back every row + log together.
     */
    public function importCsv(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $request->validate([
            'csv' => AppSetting::templateUploadRules(),
        ]);

        $this->cleanupStalePendingImports();

        $content = (string) file_get_contents($request->file('csv')->getRealPath());
        $analysis = $this->analyseImport($content);

        if ($analysis['header_error'] !== null) {
            return back()->with('importErrors', [['row' => 0, 'message' => $analysis['header_error']]]);
        }

        if ($analysis['total_rows'] === 0) {
            return back()->with('importErrors', [['row' => 0, 'message' => 'No data rows found in the file.']]);
        }

        if (! empty($analysis['hard_errors'])) {
            return back()->with('importErrors', $analysis['hard_errors']);
        }

        // Stage the file for the confirmation step and let the user review
        // the pre-flight summary before committing. UUID-scoped so two
        // concurrent imports can't trample one another.
        $uuid = (string) Str::uuid();
        Storage::disk('local')->put("imports/pending/{$uuid}.csv", $content);

        return back()->with('importConfirmation', [
            'uuid' => $uuid,
            'analysis' => $analysis,
        ]);
    }

    /**
     * Final commit step — runs after the operator has reviewed the
     * pre-flight summary in the confirmation modal. The original file
     * was staged on disk by importCsv(); we read it back, apply the
     * chosen default import_type to any rows that left the cell blank,
     * and run the same insert / override / variation logic that the
     * old single-step importCsv used to.
     */
    public function importConfirm(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $validated = $request->validate([
            'uuid' => ['required', 'string', 'uuid'],
            'default_import_type' => ['nullable', Rule::in(['new', 'override', 'variation'])],
        ]);

        $path = "imports/pending/{$validated['uuid']}.csv";
        if (! Storage::disk('local')->exists($path)) {
            return redirect()->route('contracts.index')
                ->with('importErrors', [['row' => 0, 'message' => 'Pending import expired or was already applied. Please re-upload.']]);
        }

        $content = (string) Storage::disk('local')->get($path);
        $defaultType = $validated['default_import_type'] ?? null;

        $result = $this->commitImport($request, $content, $defaultType);

        Storage::disk('local')->delete($path);

        return $result;
    }

    /**
     * Operator chose Cancel in the confirmation modal — drop the staged
     * file so the temp dir doesn't grow unboundedly.
     */
    public function importCancel(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $uuid = (string) $request->input('uuid', '');
        if ($uuid !== '' && preg_match('/^[0-9a-f-]{36}$/i', $uuid) === 1) {
            Storage::disk('local')->delete("imports/pending/{$uuid}.csv");
        }

        return redirect()->route('contracts.index')->with('status', 'Import cancelled.');
    }

    /**
     * Build the import header map (canonical field name => cell index)
     * from the file's header row. Strips UTF-8 BOM, the optional `*`
     * required-marker prefix, surrounding whitespace, and lower-cases
     * the result so column ordering / casing don't matter.
     *
     * @param  array<int, mixed>  $headerCells
     * @return array<string, int>
     */
    private function buildImportHeaderMap(array $headerCells): array
    {
        $map = [];
        foreach ($headerCells as $idx => $cell) {
            $name = (string) preg_replace('/^\xEF\xBB\xBF/', '', (string) $cell);
            $name = strtolower(ltrim(trim($name), '*'));
            if ($name !== '') {
                $map[$name] = $idx;
            }
        }

        return $map;
    }

    /**
     * Pre-flight analysis. Walks the file once with no DB writes and
     * returns a structured summary the confirmation modal renders:
     *
     *   - `header_error`            string|null   missing-required-column
     *   - `total_rows`              int           non-blank data rows
     *   - `type_counts`             array         {new, override, variation}
     *   - `missing_type_rows`       array<int>    row numbers w/ blank import_type
     *   - `hard_errors`             array         per-row parse failures
     *   - `duplicate_contract_numbers` array      cn => [row#, row#, …]
     *
     * Hard errors block the import outright — the operator must fix the
     * CSV. Missing import_type is recoverable: the confirmation modal
     * lets them pick a default to apply across all blank rows.
     *
     * @return array{header_error: string|null, total_rows: int, type_counts: array<string, int>, missing_type_rows: array<int>, hard_errors: array<int, array{row: int, message: string}>, duplicate_contract_numbers: array<string, array<int>>}
     */
    private function analyseImport(string $content): array
    {
        $analysis = [
            'header_error' => null,
            'total_rows' => 0,
            'type_counts' => ['new' => 0, 'override' => 0, 'variation' => 0],
            'missing_type_rows' => [],
            'hard_errors' => [],
            'duplicate_contract_numbers' => [],
        ];

        $stream = fopen('php://temp', 'r+');
        fwrite($stream, $content);
        rewind($stream);

        try {
            $headerCells = fgetcsv($stream, 0, ',', '"', '\\');
            if ($headerCells === false || $headerCells === null) {
                $analysis['header_error'] = 'Empty file or unreadable CSV header.';

                return $analysis;
            }

            $headerMap = $this->buildImportHeaderMap($headerCells);

            $requiredHeaders = [
                'import_type', 'company', 'depot', 'route', 'contract_number',
                'tender_date', 'start_date', 'end_date',
                'contract_value', 'contracted_miles',
            ];
            $missing = array_values(array_diff($requiredHeaders, array_keys($headerMap)));
            if (! empty($missing)) {
                $analysis['header_error'] = 'CSV header is missing required column(s): '.implode(', ', $missing).'. Re-download the import template.';

                return $analysis;
            }

            $rowNumber = 1;
            $contractNumberRows = [];

            while (($cells = fgetcsv($stream, 0, ',', '"', '\\')) !== false) {
                $rowNumber++;

                if ($rowNumber > self::IMPORT_ROW_CAP + 1) {
                    $analysis['hard_errors'][] = ['row' => $rowNumber, 'message' => 'File contains more than '.self::IMPORT_ROW_CAP.' rows — refusing to import. Split the file and try again.'];
                    break;
                }

                if (count(array_filter($cells, fn ($c) => trim((string) $c) !== '')) === 0) {
                    continue;
                }

                $analysis['total_rows']++;

                $rawType = strtolower(trim((string) ($cells[$headerMap['import_type']] ?? '')));

                if ($rawType === '') {
                    // Missing import_type — recoverable. Try to parse the
                    // rest of the row with a placeholder so we can still
                    // catch other validation errors and detect duplicate
                    // contract_numbers from this row.
                    $analysis['missing_type_rows'][] = $rowNumber;
                    $cellsForParse = $cells;
                    $cellsForParse[$headerMap['import_type']] = 'new';
                    try {
                        $parsed = $this->parseImportRow($cellsForParse, $headerMap);
                        $cn = $parsed['contract_number'];
                        if ($cn !== '') {
                            $contractNumberRows[$cn][] = $rowNumber;
                        }
                    } catch (\DomainException $e) {
                        $analysis['hard_errors'][] = ['row' => $rowNumber, 'message' => $e->getMessage()];
                    }

                    continue;
                }

                try {
                    $parsed = $this->parseImportRow($cells, $headerMap);
                    $analysis['type_counts'][$parsed['type']]++;

                    // For override / variation rows, additionally verify
                    // the referenced id exists. (Doing this here, rather
                    // than at commit time, surfaces the bad-id list in
                    // the confirmation modal so the operator can fix the
                    // CSV before committing instead of after.)
                    if (in_array($parsed['type'], ['override', 'variation'], true)) {
                        $exists = Contract::query()->active()->whereKey($parsed['id'])->exists();
                        if (! $exists) {
                            $verb = $parsed['type'] === 'variation' ? 'vary' : 'override';
                            $analysis['hard_errors'][] = ['row' => $rowNumber, 'message' => "No contract with id {$parsed['id']} exists to {$verb}."];
                        }
                    }

                    $cn = $parsed['contract_number'];
                    if ($cn !== '') {
                        $contractNumberRows[$cn][] = $rowNumber;
                    }
                } catch (\DomainException $e) {
                    $analysis['hard_errors'][] = ['row' => $rowNumber, 'message' => $e->getMessage()];
                }
            }
        } finally {
            fclose($stream);
        }

        foreach ($contractNumberRows as $cn => $rows) {
            if (count($rows) > 1) {
                $analysis['duplicate_contract_numbers'][$cn] = $rows;
            }
        }

        return $analysis;
    }

    /**
     * The actual insert / override / variation work, factored out so it
     * can run after the confirmation step. Reads the staged CSV string
     * and (when supplied) applies $defaultType to any row whose
     * import_type cell is blank.
     */
    private function commitImport(Request $request, string $content, ?string $defaultType): RedirectResponse
    {
        $created = [];
        $overrideCount = 0;
        $variationCount = 0;
        $skipped = 0;
        $errors = [];

        DB::transaction(function () use ($request, $content, $defaultType, &$created, &$overrideCount, &$variationCount, &$skipped, &$errors) {
            $stream = fopen('php://temp', 'r+');
            fwrite($stream, $content);
            rewind($stream);

            $rowNumber = 0;

            try {
                $headerCells = fgetcsv($stream, 0, ',', '"', '\\');
                if ($headerCells === false || $headerCells === null) {
                    $errors[] = ['row' => 0, 'message' => 'Empty file or unreadable CSV header.'];

                    return;
                }
                $rowNumber = 1;

                $headerMap = $this->buildImportHeaderMap($headerCells);
                $typeIdx = $headerMap['import_type'] ?? null;

                while (($cells = fgetcsv($stream, 0, ',', '"', '\\')) !== false) {
                    $rowNumber++;

                    if ($rowNumber > self::IMPORT_ROW_CAP + 1) {
                        $errors[] = ['row' => $rowNumber, 'message' => 'File contains more than '.self::IMPORT_ROW_CAP.' rows.'];

                        return;
                    }

                    if (count(array_filter($cells, fn ($c) => trim((string) $c) !== '')) === 0) {
                        continue;
                    }

                    // Backfill missing import_type with the operator's
                    // chosen default before passing to the strict parser.
                    if ($defaultType !== null && $typeIdx !== null && trim((string) ($cells[$typeIdx] ?? '')) === '') {
                        $cells[$typeIdx] = $defaultType;
                    }

                    try {
                        $parsed = $this->parseImportRow($cells, $headerMap);
                    } catch (\DomainException $e) {
                        $errors[] = ['row' => $rowNumber, 'message' => $e->getMessage()];

                        continue;
                    }

                    $type = $parsed['type'];
                    unset($parsed['type']);

                    if ($type === 'new') {
                        $contract = Contract::create([
                            ...array_diff_key($parsed, ['id' => null]),
                            'created_by' => $request->user()->id,
                        ]);
                        $created[] = $contract->contract_number;

                        continue;
                    }

                    $contract = Contract::query()->active()->find($parsed['id']);
                    if ($contract === null) {
                        $verb = $type === 'variation' ? 'vary' : 'override';
                        $errors[] = ['row' => $rowNumber, 'message' => "No active contract with id {$parsed['id']} exists to {$verb}."];

                        continue;
                    }

                    $changes = [];
                    $diffFields = ['company', 'depot', 'route', 'contract_number',
                        'tender_date', 'start_date', 'end_date',
                        'contract_value', 'contracted_miles',
                        'tender_award_note', 'pvr', 'tvr', 'propulsion', 'decks'];
                    foreach ($diffFields as $field) {
                        if (! array_key_exists($field, $parsed)) {
                            continue;
                        }
                        $current = $this->normaliseForCompare($contract->getAttribute($field), $field);
                        $next = $this->normaliseForCompare($parsed[$field], $field);
                        if ($current !== $next) {
                            $changes[$field] = ['from' => $current, 'to' => $next];
                        }
                    }

                    if (empty($changes)) {
                        $skipped++;

                        continue;
                    }

                    $contract->fill(array_diff_key($parsed, ['id' => null]));
                    $contract->updated_by = $request->user()->id;
                    $contract->save();

                    $action = $type === 'variation' ? 'contract_varied' : 'contract_overridden';
                    $kindLabel = $type === 'variation' ? 'Variation' : 'Override';

                    $oldValues = array_map(fn ($c) => $c['from'], $changes);
                    $newValues = array_map(fn ($c) => $c['to'], $changes);

                    AuditLog::create([
                        'user_id' => $request->user()->id,
                        'action' => $action,
                        'entity_type' => $contract->getTable(),
                        'entity_id' => $contract->getKey(),
                        'old_values' => $oldValues,
                        'new_values' => $newValues,
                        'note' => $this->contractRef($contract)." {$kindLabel} via CSV import",
                        'ip_address' => $request->ip(),
                    ]);

                    if ($type === 'variation') {
                        $variationCount++;
                    } else {
                        $overrideCount++;
                    }
                }
            } finally {
                fclose($stream);
            }

            $totalChanged = count($created) + $overrideCount + $variationCount;
            if ($totalChanged > 0 || count($errors) > 0) {
                AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'contracts_imported',
                    'entity_type' => 'contracts',
                    'entity_id' => 0,
                    'new_values' => [
                        'new_count' => count($created),
                        'override_count' => $overrideCount,
                        'variation_count' => $variationCount,
                        'skipped_count' => $skipped,
                        'error_count' => count($errors),
                        'contract_numbers_created' => $created,
                    ],
                    'note' => sprintf(
                        'Imported via CSV: %d new, %d overrides, %d variations, %d skipped, %d rejected',
                        count($created), $overrideCount, $variationCount, $skipped, count($errors),
                    ),
                    'ip_address' => $request->ip(),
                ]);
            }
        });

        $parts = [];
        if (count($created)) {
            $parts[] = count($created).' new';
        }
        if ($overrideCount) {
            $parts[] = "{$overrideCount} overridden";
        }
        if ($variationCount) {
            $parts[] = "{$variationCount} varied";
        }
        if ($skipped) {
            $parts[] = "{$skipped} unchanged";
        }
        $errorCount = count($errors);

        $msg = empty($parts) && $errorCount === 0
            ? 'No rows applied.'
            : 'Import complete'.(empty($parts) ? '' : ': '.implode(', ', $parts)).'.';
        if ($errorCount > 0) {
            $msg .= " {$errorCount} rows rejected.";
        }

        return redirect()->route('contracts.index')
            ->with('status', $msg)
            ->with('importErrors', $errors);
    }

    /**
     * Drop staged import files older than an hour. Cheap O(N) sweep on
     * every new import — keeps the dir from growing if operators upload
     * files but never confirm or cancel.
     */
    private function cleanupStalePendingImports(): void
    {
        $cutoff = now()->subHour()->timestamp;
        foreach (Storage::disk('local')->files('imports/pending') as $file) {
            if (Storage::disk('local')->lastModified($file) < $cutoff) {
                Storage::disk('local')->delete($file);
            }
        }
    }

    /**
     * Contract-identity prefix used in audit notes so a single substring
     * query against the notes column finds entries by id, contract number,
     * or route. Format: "[#42 QC12345 · route 100]". Stable, terse, easy
     * to grep at scale.
     */
    private function contractRef(Contract $contract): string
    {
        return sprintf('[#%d %s · route %s]', $contract->id, $contract->contract_number, $contract->route);
    }

    /**
     * Parse one CSV data row into a payload usable by Contract::create()
     * (or fill() for overrides/variations). Includes the `type` code so
     * the caller knows which write path to take.
     *
     * Lookup is **header-based**: the caller passes a `$headerMap` of
     * canonical-field-name => zero-based cell index, built from the file's
     * header row. This lets the column order vary, the `*` required-field
     * markers in the template be optional, and unknown extra columns be
     * silently ignored.
     *
     * Optional fields are only included in the returned payload when the
     * column is present in the header **and** the cell is non-empty. That
     * way overrides/variations only diff on fields the operator actually
     * supplied, and a blank optional cell is "leave alone" — clearing a
     * field still has to go through the per-record edit dialog.
     *
     * Sanitisation applied to every text cell:
     *   - strip UTF-8 BOM
     *   - trim whitespace + surrounding straight/curly quotes
     *   - reject leading `=`, `+`, `-`, `@`, tab, CR (CSV-formula injection)
     *   - cap length at 100 chars (matches column types)
     *
     * Throws DomainException with a human-readable message for any field
     * that fails validation; the caller collects those into the errors
     * summary so a partial import still commits valid rows.
     *
     * @param  array<int|string, mixed>  $cells
     * @param  array<string, int>  $headerMap
     * @return array<string, mixed>
     */
    private function parseImportRow(array $cells, array $headerMap): array
    {
        $clean = function (mixed $value): string {
            if (! is_string($value)) {
                $value = (string) $value;
            }
            $value = preg_replace('/^\xEF\xBB\xBF/', '', $value) ?? $value;

            return trim($value, " \t\n\r\0\x0B\"'\u{2018}\u{2019}\u{201C}\u{201D}");
        };

        $guardInjection = function (string $field, string $value): void {
            if ($value === '') {
                return;
            }
            if (preg_match('/^[=+\-@\t\r]/', $value) === 1) {
                throw new \DomainException("{$field} starts with a forbidden character (= + - @ tab CR are CSV-injection risks).");
            }
        };

        $get = function (string $field) use ($cells, $headerMap, $clean): string {
            if (! array_key_exists($field, $headerMap)) {
                return '';
            }

            return $clean($cells[$headerMap[$field]] ?? '');
        };

        $has = fn (string $field): bool => array_key_exists($field, $headerMap);

        // import_type accepts the words `new`, `override`, `variation`
        // (case-insensitive). Anything else is rejected with a clear
        // message so a typo doesn't silently misclassify a row.
        $type = strtolower($get('import_type'));
        if (! in_array($type, ['new', 'override', 'variation'], true)) {
            throw new \DomainException("import_type must be one of: new, override, variation. Got '{$type}'.");
        }

        // id rules: required for override/variation (the lookup key);
        // rejected for new (auto-assigned on insert).
        $idRaw = $get('id');
        $id = null;
        if ($idRaw !== '') {
            if (! ctype_digit($idRaw)) {
                throw new \DomainException("id must be a positive integer. Got '{$idRaw}'.");
            }
            $id = (int) $idRaw;
        }
        if (in_array($type, ['override', 'variation'], true) && $id === null) {
            throw new \DomainException("id is required for import_type '{$type}'. Copy it from the id column on the page or from an export.");
        }
        if ($type === 'new' && $id !== null) {
            throw new \DomainException("import_type 'new' must leave id blank — ids are auto-assigned on insert.");
        }

        $textFields = [
            'company' => $get('company'),
            'depot' => $get('depot'),
            'route' => $get('route'),
            'contract_number' => $get('contract_number'),
        ];

        foreach ($textFields as $label => $value) {
            if ($value === '') {
                throw new \DomainException("{$label} is required.");
            }
            $guardInjection($label, $value);
            if (mb_strlen($value) > 100) {
                throw new \DomainException("{$label} is too long (max 100 chars).");
            }
        }

        [$company, $depot, $route, $contractNumber] = array_values($textFields);

        $tender = $this->parseDate($get('tender_date'), 'tender_date');
        $start = $this->parseDate($get('start_date'), 'start_date');
        $end = $this->parseDate($get('end_date'), 'end_date');

        if (Carbon::parse($end)->lessThan(Carbon::parse($start))) {
            throw new \DomainException('end_date must be on or after start_date.');
        }
        if (Carbon::parse($start)->lessThan(Carbon::parse($tender))) {
            throw new \DomainException('start_date must be on or after tender_date.');
        }

        // Strip currency symbols, commas, and spaces; keep digits, dot, minus.
        $valueRaw = preg_replace('/[^\d.\-]/', '', $get('contract_value')) ?? '';
        if ($valueRaw === '' || ! is_numeric($valueRaw)) {
            throw new \DomainException('contract_value must be numeric.');
        }
        $valueNum = (float) $valueRaw;
        if ($valueNum < 0) {
            throw new \DomainException('contract_value must not be negative.');
        }
        if ($valueNum > 1.0e12) {
            throw new \DomainException('contract_value is implausibly large (over £1 trillion).');
        }

        $milesRaw = preg_replace('/[^\d.\-]/', '', $get('contracted_miles')) ?? '';
        if ($milesRaw === '' || ! is_numeric($milesRaw)) {
            throw new \DomainException('contracted_miles must be numeric.');
        }
        $milesNum = (float) $milesRaw;
        if ($milesNum < 0) {
            throw new \DomainException('contracted_miles must not be negative.');
        }
        if ($milesNum > 1.0e7) {
            throw new \DomainException('contracted_miles is implausibly large (over 10 million).');
        }

        $parsed = [
            'type' => $type,
            'id' => $id,
            'company' => $company,
            'depot' => $depot,
            'route' => $route,
            'contract_number' => $contractNumber,
            'tender_date' => $tender,
            'start_date' => $start,
            'end_date' => $end,
            'contract_value' => $valueNum,
            'contracted_miles' => $milesNum,
        ];

        // Optional importable fields. Mirrors StoreContractRequest's
        // optional set; CPA confirmations / extension flags / notice flags
        // are deliberately excluded — those have per-cell write paths with
        // their own audit semantics.
        if ($has('tender_award_note') && $get('tender_award_note') !== '') {
            $val = $get('tender_award_note');
            if (mb_strlen($val) > 500) {
                throw new \DomainException('tender_award_note is too long (max 500 chars).');
            }
            $parsed['tender_award_note'] = $val;
        }

        foreach (['pvr', 'tvr'] as $intField) {
            if ($has($intField) && $get($intField) !== '') {
                $raw = $get($intField);
                if (! ctype_digit($raw)) {
                    throw new \DomainException("{$intField} must be a non-negative integer. Got '{$raw}'.");
                }
                $intVal = (int) $raw;
                if ($intVal > 9999) {
                    throw new \DomainException("{$intField} must be 9999 or less. Got '{$raw}'.");
                }
                $parsed[$intField] = $intVal;
            }
        }

        if ($has('propulsion') && $get('propulsion') !== '') {
            $val = $get('propulsion');
            $allowed = ['Diesel', 'Hybrid', 'Electric', 'Mix - Hybrid/EV'];
            if (! in_array($val, $allowed, true)) {
                throw new \DomainException('propulsion must be one of: '.implode(', ', $allowed).". Got '{$val}'.");
            }
            $parsed['propulsion'] = $val;
        }

        if ($has('decks') && $get('decks') !== '') {
            $val = $get('decks');
            $allowed = ['SD', 'DD', 'SD/DD'];
            if (! in_array($val, $allowed, true)) {
                throw new \DomainException('decks must be one of: '.implode(', ', $allowed).". Got '{$val}'.");
            }
            $parsed['decks'] = $val;
        }

        return $parsed;
    }

    /**
     * Parse a date cell from a CSV import. Accepts two encodings, since
     * spreadsheet copy-paste often emits one or the other depending on
     * whether Excel/Sheets autoformatted the cell:
     *
     *   - dd/mm/yyyy — the human-friendly UK format
     *   - bare integer — Excel's serial date (days since 1899-12-30,
     *     bounded to 1900-2099 to reject obvious typos like 12345678)
     *
     * Returns Y-m-d for downstream use. Throws DomainException for
     * empty input or anything that matches neither shape.
     */
    private function parseDate(string $raw, string $field): string
    {
        if ($raw === '') {
            throw new \DomainException("{$field} is required.");
        }

        if (ctype_digit($raw)) {
            $serial = (int) $raw;
            if ($serial < 1 || $serial > 73050) {
                throw new \DomainException("{$field} serial {$raw} is out of range (expected 1..73050, i.e. 1900..2099).");
            }

            return Carbon::create(1899, 12, 30)->addDays($serial)->format('Y-m-d');
        }

        // createFromFormat with strict mode rejects nonsense like 31/02/2024.
        $parsed = Carbon::createFromFormat('!d/m/Y', $raw);
        $errors = Carbon::getLastErrors();
        if ($parsed === false || ($errors && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))) {
            throw new \DomainException("{$field} must be dd/mm/yyyy or an Excel serial number. Got '{$raw}'.");
        }

        return $parsed->format('Y-m-d');
    }

    /**
     * Archive a contract (soft-delete). The row stays in the database
     * so the audit trail still resolves historical references; the
     * contract is hidden from primary list / reports / forecasts.
     * Hard-delete only happens via Settings → Data control.
     */
    public function destroy(Request $request, Contract $contract): RedirectResponse
    {
        // Idempotent — already-archived contracts can't be archived again
        // (would write a duplicate audit row and confuse the trail).
        abort_if($contract->isArchived(), 404);

        $oldValues = $contract->only(['company', 'depot', 'route', 'contract_number', 'tender_date', 'start_date', 'end_date', 'contract_value']);
        $oldValues['tender_date'] = $contract->formatTenderDate();
        $oldValues['start_date'] = $contract->formatStartDate();
        $oldValues['end_date'] = $contract->formatEndDate();

        $label = "{$contract->contract_number} ({$contract->route})";
        $auditNote = $this->contractRef($contract).' Contract archived';

        DB::transaction(function () use ($request, $contract, $oldValues, $auditNote) {
            $entityType = $contract->getTable();
            $entityId = $contract->getKey();
            $contract->archive($request->user()->id);

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'contract_deleted',
                'entity_type' => $entityType,
                'entity_id' => $entityId,
                'old_values' => $oldValues,
                'note' => $auditNote,
                'ip_address' => $request->ip(),
            ]);
        });

        return redirect()->route('contracts.index')->with('status', "Archived {$label}. Audit history preserved; restore from the Archived view if needed.");
    }

    /**
     * Restore an archived contract — clears the archive flag.
     */
    public function restore(Request $request, Contract $contract): RedirectResponse
    {
        abort_unless($request->user()->canWrite(), 403);
        abort_unless($contract->isArchived(), 404);

        DB::transaction(function () use ($request, $contract) {
            $contract->unarchive();

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'contract_restored',
                'entity_type' => $contract->getTable(),
                'entity_id' => $contract->getKey(),
                'old_values' => ['archived' => true],
                'new_values' => ['archived' => false],
                'note' => $this->contractRef($contract).' Contract restored from archive',
                'ip_address' => $request->ip(),
            ]);
        });

        return redirect()->route('contracts.index')->with('status', "Restored {$contract->contract_number}.");
    }

    /**
     * Compare values in a normalised form so a Carbon date object compared
     * against a 'YYYY-MM-DD' string from a form submission doesn't show as
     * a spurious change. Numeric values are compared as floats with 4dp.
     */
    private function normaliseForCompare(mixed $value, string $field): string
    {
        if ($value === null) {
            return '';
        }

        if (in_array($field, ['tender_date', 'start_date', 'end_date'], true)) {
            return Carbon::parse($value)->format('Y-m-d');
        }

        if (in_array($field, ['pvr', 'tvr'], true)) {
            return (string) (int) $value;
        }

        if ($field === 'contract_value') {
            return number_format((float) $value, 4, '.', '');
        }

        if ($field === 'contracted_miles') {
            return number_format((float) $value, 2, '.', '');
        }

        return (string) $value;
    }

    /**
     * @return array{companies: array<int, string>, depots: array<int, string>, statuses: array<int, string>, q: ?string}
     */
    private function resolveFilters(Request $request): array
    {
        $companies = $this->splitListParam($request->query('companies'));
        $depots = $this->splitListParam($request->query('depots'));
        // Restrict to the known status codes — anything else gets dropped
        // silently so a tampered query string can't push unknown predicates.
        $statuses = array_values(array_intersect(
            $this->splitListParam($request->query('statuses')),
            ['active', 'expired', 'upcoming'],
        ));

        $q = trim((string) $request->query('q', ''));
        $q = $q === '' ? null : mb_substr($q, 0, 100);

        return compact('companies', 'depots', 'statuses', 'q');
    }

    /**
     * @return array<int, string>
     */
    private function splitListParam(mixed $raw): array
    {
        if (is_string($raw)) {
            $raw = $raw === '' ? [] : explode(',', $raw);
        }

        return collect((array) ($raw ?? []))
            ->map(fn ($v) => trim((string) $v))
            ->filter(fn ($v) => $v !== '')
            ->unique()
            ->values()
            ->all();
    }
}
