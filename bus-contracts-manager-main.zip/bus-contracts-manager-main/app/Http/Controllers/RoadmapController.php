<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use Illuminate\View\View;

/**
 * Internal roadmap viewer. Reads from config/roadmap.php so adding /
 * editing items is a one-file code change (no DB / migration). Promote
 * to a DB-backed model when we want non-developers to edit it.
 */
class RoadmapController extends Controller
{
    /**
     * Status sections rendered on the page. Forward-looking only —
     * `shipped` items are kept in `config/roadmap.php` for history /
     * changelog purposes but deliberately omitted here so the page
     * stays focused on what's *next*. `paused` lands last as an
     * exception bin.
     */
    private const SECTION_ORDER = ['in_progress', 'planned', 'idea', 'paused'];

    public function index(): View
    {
        $config = config('roadmap');
        $items = $config['items'] ?? [];
        $statuses = $config['statuses'] ?? [];

        // Group items by status, preserving config order within each
        // group. Pre-seed with SECTION_ORDER so empty groups stay empty
        // (the view skips them) and out-of-scope statuses (like the
        // hidden `shipped` items) get dropped on the floor here.
        $grouped = array_fill_keys(self::SECTION_ORDER, []);
        foreach ($items as $item) {
            $key = $item['status'] ?? 'idea';
            if (! array_key_exists($key, $grouped)) {
                continue;
            }
            $grouped[$key][] = $item;
        }

        $totalCount = array_sum(array_map('count', $grouped));

        return view('roadmap.index', [
            'grouped' => $grouped,
            'sectionOrder' => self::SECTION_ORDER,
            'statuses' => $statuses,
            'totalCount' => $totalCount,
        ]);
    }
}
