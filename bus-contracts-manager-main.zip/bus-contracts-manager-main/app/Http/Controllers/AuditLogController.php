<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\AppSetting;
use App\Models\Attachment;
use App\Models\AttachmentLink;
use App\Models\AuditLog;
use App\Models\Contract;
use App\Models\CpaRate;
use App\Models\CpiIndexEntry;
use App\Models\RpiIndexEntry;
use App\Models\User;
use App\Support\AuditActions;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\View\View;

/**
 * Audit log — filter toolbar + pagination + compact-row-expand-inline
 * + two-column before / after diff. Includes explicit attachment-
 * lifecycle indicators (Added / Replaced / Removed) by pairing detach
 * + attach rows that share an attachable_key.
 *
 * Optional `?contract=N` URL param filters the list to a single
 * contract's history. The toolbar's available-action / available-user
 * counts deliberately stay unfiltered so the operator always sees the
 * unfiltered universe.
 */
class AuditLogController extends Controller
{
    private const PER_PAGE = 50;

    /** Window in seconds within which a detach + attach pair counts as a "replace". */
    private const REPLACE_WINDOW_SECONDS = 60;

    public function index(Request $request): View
    {
        $filters = $this->resolveFilters($request);
        $contractFilter = $request->integer('contract') ?: null;

        $cutoff = (int) (AppSetting::get(AppSetting::AUDIT_LOG_VISIBLE_AFTER_ID) ?? 0);
        $isSuperadminViewer = $request->user()->isSuperadmin();
        $superadminUserIds = $isSuperadminViewer
            ? []
            : User::query()->where('role', User::ROLE_SUPERADMIN)->pluck('id')->all();

        $query = AuditLog::query()
            ->with('user:id,name,email', 'attachment')
            ->where('id', '>', $cutoff)
            ->when(! $isSuperadminViewer && ! empty($superadminUserIds),
                fn ($q) => $q->whereNotIn('user_id', $superadminUserIds))
            ->orderByDesc('created_at')
            ->orderByDesc('id');

        $labelToKeys = $this->buildLabelToKeysMap();

        if (! empty($filters['actions'])) {
            $expandedKeys = [];
            foreach ($filters['actions'] as $label) {
                if (isset($labelToKeys[$label])) {
                    $expandedKeys = array_merge($expandedKeys, $labelToKeys[$label]);
                }
            }
            if (! empty($expandedKeys)) {
                $query->whereIn('action', array_values(array_unique($expandedKeys)));
            }
        }

        if (! empty($filters['users'])) {
            $query->whereIn('user_id', $filters['users']);
        }

        if ($filters['from'] !== null) {
            $query->where('created_at', '>=', Carbon::createFromFormat('Y-m', $filters['from'])->startOfMonth());
        }

        if ($filters['to'] !== null) {
            $query->where('created_at', '<=', Carbon::createFromFormat('Y-m', $filters['to'])->endOfMonth());
        }

        if ($filters['q'] !== null) {
            $like = '%'.$filters['q'].'%';
            $term = $filters['q'];
            $query->where(function ($q) use ($like, $term) {
                $q->where('note', 'like', $like)
                    ->orWhere('action', 'like', $like)
                    ->orWhere('entity_type', 'like', $like)
                    ->orWhereHas('user', fn ($u) => $u
                        ->where('name', 'like', $like)
                        ->orWhere('email', 'like', $like));

                if (ctype_digit($term)) {
                    $q->orWhere('entity_id', '=', (int) $term);
                }
            });
        }

        if ($contractFilter !== null) {
            $query->where('entity_type', 'contracts')
                ->where('entity_id', $contractFilter);
        }

        $logs = $query->paginate(self::PER_PAGE)->withQueryString();

        $monthLookup = $this->buildMonthLookup($logs->getCollection());
        $contractLookup = $this->buildContractLookup($logs->getCollection());
        $userLookup = $this->buildEntityUserLookup($logs->getCollection());
        [$attachmentEvents, $replacePairs] = $this->detectAttachmentEvents($logs->getCollection());
        $detachedAttachments = $this->buildDetachedAttachmentLookup($logs->getCollection());

        // For each attach row that's part of a replace pair, look up the
        // OLD attachment via the paired detach row's old_values.attachment_id
        // so the view can render both files (before + after) on a single
        // row. Detach rows that have a partner are suppressed in the view.
        $replaceBeforeAttachments = $this->buildReplaceBeforeAttachments($logs->getCollection(), $replacePairs);
        $suppressedDetachLogIds = array_values($replacePairs);

        $rawActionCounts = AuditLog::query()
            ->where('id', '>', $cutoff)
            ->when(! $isSuperadminViewer && ! empty($superadminUserIds),
                fn ($q) => $q->whereNotIn('user_id', $superadminUserIds))
            ->selectRaw('action, count(*) as c')
            ->groupBy('action')
            ->pluck('c', 'action')
            ->all();

        $actionGroups = collect(AuditActions::all())
            ->map(fn ($meta, $key) => [
                'key' => $key,
                'label' => $meta['label'],
                'badge' => $meta['badge'],
                'count' => $rawActionCounts[$key] ?? 0,
            ])
            ->groupBy('label')
            ->map(fn ($items, $label) => [
                'label' => $label,
                'badge' => $items->first()['badge'],
                'count' => $items->sum('count'),
            ])
            ->filter(fn ($g) => $g['count'] > 0)
            ->sortByDesc('count')
            ->values();

        $users = User::query()
            ->whereIn('id', AuditLog::query()
                ->where('id', '>', $cutoff)
                ->when(! $isSuperadminViewer && ! empty($superadminUserIds),
                    fn ($q) => $q->whereNotIn('user_id', $superadminUserIds))
                ->select('user_id')
                ->distinct())
            ->when(! $isSuperadminViewer, fn ($q) => $q->where('role', '!=', User::ROLE_SUPERADMIN))
            ->orderBy('name')
            ->get(['id', 'name']);

        $totalCount = AuditLog::query()
            ->where('id', '>', $cutoff)
            ->when(! $isSuperadminViewer && ! empty($superadminUserIds),
                fn ($q) => $q->whereNotIn('user_id', $superadminUserIds))
            ->count();

        $filteredContract = $contractFilter !== null
            ? Contract::query()->select(['id', 'contract_number', 'route', 'company'])->find($contractFilter)
            : null;

        return view('audit-log.index', [
            'logs' => $logs,
            'filters' => $filters,
            'actionGroups' => $actionGroups,
            'users' => $users,
            'monthLookup' => $monthLookup,
            'contractLookup' => $contractLookup,
            'userLookup' => $userLookup,
            'attachmentEvents' => $attachmentEvents,
            'detachedAttachments' => $detachedAttachments,
            'replaceBeforeAttachments' => $replaceBeforeAttachments,
            'suppressedDetachLogIds' => $suppressedDetachLogIds,
            'totalCount' => $totalCount,
            'contractFilter' => $contractFilter,
            'filteredContract' => $filteredContract,
        ]);
    }

    /**
     * Batch-resolve user records for any audit row whose entity_type
     * is `users` (the user being acted upon, not the actor). Lets the
     * row show "Paul Tran" rather than "Users #2".
     *
     * @return Collection<int, User>
     */
    private function buildEntityUserLookup(Collection $logs): Collection
    {
        $ids = $logs
            ->where('entity_type', 'users')
            ->pluck('entity_id')
            ->filter()
            ->unique()
            ->values();

        if ($ids->isEmpty()) {
            return collect();
        }

        return User::query()
            ->whereIn('id', $ids)
            ->get(['id', 'name', 'email'])
            ->keyBy('id');
    }

    /**
     * Detach audit rows don't carry an `attachment` relation (the
     * attachment record's audit_log_id still points at the original
     * attach row). To render the same callout card for detach events
     * we look up the referenced attachment by id from old_values.
     *
     * Returns a map keyed by audit log id → Attachment record. Falls
     * back to a plain stdClass with `original_filename` if the
     * underlying attachment was hard-deleted (e.g. via the "Delete all
     * attachments" admin action) so the card can still show the name.
     *
     * @return array<int, Attachment|object>
     */
    /** Action keys that mean "an attachment was just detached from a slot".
     *  Two keys because of the rename — the old `evidence` key still exists
     *  on every historical row written before 2026-05-12 and we never
     *  rewrite audit rows (§10 append-only). */
    private const DETACH_ACTIONS = ['contract_attachment_detached', 'contract_evidence_detached'];

    /** Same logic for "an attachment was just uploaded to a slot". */
    private const ATTACH_ACTIONS = ['contract_attachment_attached', 'contract_evidence_attached'];

    private function buildDetachedAttachmentLookup(Collection $logs): array
    {
        $idToLogIds = [];
        $logIdToFilename = [];

        foreach ($logs as $log) {
            if (! in_array($log->action, self::DETACH_ACTIONS, true)) {
                continue;
            }

            $attId = $log->old_values['attachment_id'] ?? null;
            $filename = $log->old_values['filename'] ?? null;

            if ($attId !== null && ctype_digit((string) $attId)) {
                $idToLogIds[(int) $attId][] = $log->id;
            }
            if ($filename !== null) {
                $logIdToFilename[$log->id] = (string) $filename;
            }
        }

        $loaded = empty($idToLogIds)
            ? collect()
            : Attachment::query()
                ->whereIn('id', array_keys($idToLogIds))
                ->get(['id', 'original_filename', 'mime_type', 'size_bytes', 'detached_at']);

        $lookup = [];

        foreach ($loaded as $att) {
            foreach ($idToLogIds[$att->id] ?? [] as $logId) {
                $lookup[$logId] = $att;
            }
        }

        // For any detach row whose attachment row was hard-deleted, fall
        // back to a stub object so the view can still render the name.
        foreach ($logIdToFilename as $logId => $filename) {
            if (! isset($lookup[$logId])) {
                $lookup[$logId] = (object) [
                    'id' => null,
                    'original_filename' => $filename,
                    'mime_type' => null,
                    'size_bytes' => null,
                    'detached_at' => null,
                    '_deleted' => true,
                ];
            }
        }

        return $lookup;
    }

    /**
     * Classify each audit row's relationship to its attachment, if any:
     *
     *   - 'added'    a new attachment with no recent detach for the same key
     *   - 'replaced' an attachment paired with a detach (in either direction)
     *                for the same attachable_key, within REPLACE_WINDOW_SECONDS
     *   - 'removed'  a detach with no follow-up attach in the window
     *
     * Two row shapes are considered "attached":
     *   - action = contract_attachment_attached (key in new_values)
     *   - any other action with $log->attachment set — covers files
     *     uploaded as part of a wider Override / Variation / CPA confirm
     *     / Extension / Notice / Tender award change. attachable_key
     *     for these is fetched via the attachment's link record.
     *
     * Both the new `contract_attachment_*` keys and the legacy
     * `contract_evidence_*` keys are recognised here so historical
     * audit rows continue to render correctly.
     *
     * Returns a tuple of [events, replacePairs]:
     *   - events: audit-log row id => 'added'|'replaced'|'removed' (non-attachment rows absent)
     *   - replacePairs: attachLogId => detachLogId, for the visual merge step
     *     (the detach row is suppressed in the view; the attach row carries both files)
     *
     * @return array{0: array<int, string>, 1: array<int, int>}
     */
    private function detectAttachmentEvents(Collection $logs): array
    {
        // Batch-load attachment_links so we can resolve attachable_key
        // for any audit row whose action isn't contract_attachment_*.
        $attachmentIds = $logs
            ->filter(fn ($l) => $l->attachment !== null)
            ->map(fn ($l) => $l->attachment->getKey())
            ->unique()
            ->values()
            ->all();

        $linkByAttachmentId = empty($attachmentIds)
            ? collect()
            : AttachmentLink::query()
                ->whereIn('attachment_id', $attachmentIds)
                ->get(['attachment_id', 'attachable_key'])
                ->keyBy('attachment_id');

        $byKey = [];

        foreach ($logs as $log) {
            $role = null;
            $key = null;

            if (in_array($log->action, self::DETACH_ACTIONS, true)) {
                $role = 'detached';
                $key = $log->old_values['attachable_key'] ?? null;
            } elseif (in_array($log->action, self::ATTACH_ACTIONS, true)) {
                $role = 'attached';
                $key = $log->new_values['attachable_key']
                    ?? ($log->attachment !== null
                        ? ($linkByAttachmentId[$log->attachment->getKey()]?->attachable_key ?? null)
                        : null);
            } elseif ($log->attachment !== null) {
                $role = 'attached';
                $key = $linkByAttachmentId[$log->attachment->getKey()]?->attachable_key ?? null;
            }

            if ($role === null) {
                continue;
            }

            // Orphan rows (no key) get a unique bucket so they're never
            // accidentally paired with another orphan.
            $bucket = $key ?? "_orphan_{$log->id}";
            $byKey[$bucket][] = (object) ['log' => $log, 'role' => $role];
        }

        $events = [];
        $replacePairs = [];

        foreach ($byKey as $entries) {
            usort($entries, fn ($a, $b) => $a->log->created_at <=> $b->log->created_at);

            for ($i = 0; $i < count($entries); $i++) {
                $entry = $entries[$i];
                $next = $entries[$i + 1] ?? null;
                $prev = $entries[$i - 1] ?? null;

                if ($entry->role === 'attached') {
                    $pairedWithDetach = $prev
                        && $prev->role === 'detached'
                        && abs($entry->log->created_at->diffInSeconds($prev->log->created_at)) <= self::REPLACE_WINDOW_SECONDS;
                    $events[$entry->log->id] = $pairedWithDetach ? 'replaced' : 'added';
                    if ($pairedWithDetach) {
                        $replacePairs[$entry->log->id] = $prev->log->id;
                    }
                } else {
                    $pairedWithAttach = $next
                        && $next->role === 'attached'
                        && abs($next->log->created_at->diffInSeconds($entry->log->created_at)) <= self::REPLACE_WINDOW_SECONDS;
                    $events[$entry->log->id] = $pairedWithAttach ? 'replaced' : 'removed';
                }
            }
        }

        return [$events, $replacePairs];
    }

    /**
     * For each replace pair, load the OLD attachment (referenced by the
     * detach row's old_values.attachment_id) so the merged audit-log row
     * can show "before" and "after" files side-by-side, even when they
     * share a filename. Falls back to a stub object if the attachment
     * row was hard-deleted.
     *
     * Key: attach audit log id → Attachment (or stub).
     *
     * @param  array<int, int>  $replacePairs  attachLogId => detachLogId
     * @return array<int, Attachment|object>
     */
    private function buildReplaceBeforeAttachments(Collection $logs, array $replacePairs): array
    {
        if (empty($replacePairs)) {
            return [];
        }

        // Build a quick map: log_id => log (for the detach rows we need).
        $logsById = $logs->keyBy('id');

        $idsToLoad = [];
        $attachLogIdToAttachmentId = [];
        $attachLogIdToFilename = [];

        foreach ($replacePairs as $attachLogId => $detachLogId) {
            $detachLog = $logsById->get($detachLogId);
            if (! $detachLog) {
                continue;
            }
            $attId = $detachLog->old_values['attachment_id'] ?? null;
            $filename = $detachLog->old_values['filename'] ?? null;

            if ($attId !== null && ctype_digit((string) $attId)) {
                $attId = (int) $attId;
                $idsToLoad[] = $attId;
                $attachLogIdToAttachmentId[$attachLogId] = $attId;
            }
            if ($filename !== null) {
                $attachLogIdToFilename[$attachLogId] = (string) $filename;
            }
        }

        $loaded = empty($idsToLoad)
            ? collect()
            : Attachment::query()
                ->whereIn('id', array_unique($idsToLoad))
                ->get(['id', 'original_filename', 'mime_type', 'size_bytes', 'detached_at'])
                ->keyBy('id');

        $out = [];
        foreach ($attachLogIdToAttachmentId as $attachLogId => $attId) {
            if (isset($loaded[$attId])) {
                $out[$attachLogId] = $loaded[$attId];
            }
        }

        // Stub for any attach row whose old attachment was hard-deleted.
        foreach ($attachLogIdToFilename as $attachLogId => $filename) {
            if (! isset($out[$attachLogId])) {
                $out[$attachLogId] = (object) [
                    'id' => null,
                    'original_filename' => $filename,
                    'mime_type' => null,
                    'size_bytes' => null,
                    '_deleted' => true,
                ];
            }
        }

        return $out;
    }

    /**
     * Batch-resolve contract metadata for any audit row whose
     * entity_type is `contracts`. Returns id => Contract.
     *
     * @return Collection<int, Contract>
     */
    private function buildContractLookup(Collection $logs): Collection
    {
        $ids = $logs
            ->where('entity_type', 'contracts')
            ->pluck('entity_id')
            ->filter()
            ->unique()
            ->values();

        if ($ids->isEmpty()) {
            return collect();
        }

        return Contract::query()
            ->whereIn('id', $ids)
            ->get(['id', 'contract_number', 'route', 'company'])
            ->keyBy('id');
    }

    /** @return array<string, array<int, string>> */
    private function buildLabelToKeysMap(): array
    {
        $map = [];
        foreach (AuditActions::all() as $key => $meta) {
            $map[$meta['label']][] = $key;
        }

        return $map;
    }

    /**
     * @return array{actions: array<int, string>, users: array<int, int>, from: ?string, to: ?string, q: ?string}
     */
    private function resolveFilters(Request $request): array
    {
        $actions = $this->splitListParam($request->query('actions'));
        $users = array_values(array_filter(array_map(
            fn ($v) => ctype_digit((string) $v) ? (int) $v : null,
            $this->splitListParam($request->query('users'))
        )));

        $from = $this->normaliseFilterMonth($request->query('from'));
        $to = $this->normaliseFilterMonth($request->query('to'));

        $q = trim((string) $request->query('q', ''));
        $q = $q === '' ? null : mb_substr($q, 0, 100);

        return compact('actions', 'users', 'from', 'to', 'q');
    }

    /** @return array<int, string> */
    private function splitListParam(mixed $raw): array
    {
        if (is_string($raw)) {
            $raw = $raw === '' ? [] : explode(',', $raw);
        }

        return collect((array) ($raw ?? []))
            ->map(fn ($v) => trim((string) $v))
            ->filter(fn ($v) => $v !== '')
            ->unique()
            ->values()
            ->all();
    }

    private function normaliseFilterMonth(?string $value): ?string
    {
        if ($value === null || trim($value) === '') {
            return null;
        }

        return preg_match('/^\d{4}-\d{2}$/', $value) ? $value : null;
    }

    /** @return array<string, ?string> */
    private function buildMonthLookup(Collection $logs): array
    {
        $cpiIds = [];
        $cpaIds = [];
        $rpiIds = [];

        foreach ($logs as $log) {
            if ($log->entity_id <= 0) {
                continue;
            }
            match ($log->entity_type) {
                'cpi_index_entries' => $cpiIds[] = $log->entity_id,
                'cpa_rates' => $cpaIds[] = $log->entity_id,
                'rpi_index_entries' => $rpiIds[] = $log->entity_id,
                default => null,
            };
        }

        $cpiMonths = CpiIndexEntry::whereIn('id', array_unique($cpiIds))->pluck('month', 'id');
        $cpaMonths = CpaRate::whereIn('id', array_unique($cpaIds))->pluck('month', 'id');
        $rpiMonths = RpiIndexEntry::whereIn('id', array_unique($rpiIds))->pluck('month', 'id');

        $out = [];
        foreach ($logs as $log) {
            $key = $log->entity_type.':'.$log->entity_id;

            $month = match ($log->entity_type) {
                'cpi_index_entries' => $cpiMonths[$log->entity_id] ?? null,
                'cpa_rates' => $cpaMonths[$log->entity_id] ?? null,
                'rpi_index_entries' => $rpiMonths[$log->entity_id] ?? null,
                default => null,
            };

            if ($month === null) {
                $month = $log->old_values['month'] ?? $log->new_values['month'] ?? null;
            }

            $out[$key] = $month;
        }

        return $out;
    }
}
