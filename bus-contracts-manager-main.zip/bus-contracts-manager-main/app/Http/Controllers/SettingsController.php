<?php

namespace App\Http\Controllers;

use App\Models\AppSetting;
use App\Models\Attachment;
use App\Models\AuditLog;
use App\Models\Contract;
use App\Models\CpaRate;
use App\Models\CpiIndexEntry;
use App\Models\RpiIndexEntry;
use App\Support\PasswordConfirm;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;

class SettingsController extends Controller
{
    public function index(): View
    {
        $cutoff = (int) (AppSetting::get(AppSetting::AUDIT_LOG_VISIBLE_AFTER_ID) ?? 0);

        // Snapshot availability + size depends on driver:
        //  - sqlite: file must exist on disk; size = filesize
        //  - pgsql: pg_dump streams on demand; size unknown until run
        $driver = config('database.default');
        $snapshotDriver = $driver;
        $snapshotSize = null;

        if ($driver === 'sqlite') {
            $sqlitePath = config('database.connections.sqlite.database');
            $snapshotAvailable = is_string($sqlitePath) && is_file($sqlitePath);
            if ($snapshotAvailable) {
                $snapshotSize = filesize($sqlitePath);
            }
        } else {
            // pg_dump available iff postgresql-client is installed in
            // the runtime image. Production Dockerfile installs it.
            $snapshotAvailable = $driver === 'pgsql';
        }

        return view('settings.index', [
            'auditLogCount' => AuditLog::query()->where('id', '>', $cutoff)->count(),
            'snapshotDriver' => $snapshotDriver,
            'snapshotAvailable' => $snapshotAvailable,
            'snapshotSize' => $snapshotSize,
            'attachmentCount' => Attachment::query()->count(),
            'attachmentBytes' => (int) Attachment::query()->sum('size_bytes'),
            'attachmentMaxKb' => Attachment::maxUploadKb(),
            'attachmentExtensions' => implode(',', Attachment::allowedExtensions()),
            'templateMaxKb' => AppSetting::templateMaxKb(),
            'templateExtensions' => implode(',', AppSetting::templateAllowedExtensions()),
            'contractCount' => Contract::query()->count(),
            'cpiCount' => CpiIndexEntry::query()->count(),
            'cpaCount' => CpaRate::query()->count(),
            'rpiCount' => RpiIndexEntry::query()->count(),
        ]);
    }

    /**
     * Save the configurable upload limits — file size cap and extension
     * whitelist for both evidence files and CSV template imports.
     *
     * Superadmin Data-control actions are intentionally NOT audit-logged:
     * the trail is for operator-level activity, and a superadmin tweaking
     * upload caps or wiping data is a system-administration concern, not
     * a contract-management one.
     */
    public function updateUploadLimits(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->isSuperadmin(), 403);
        PasswordConfirm::check($request);

        $validated = $request->validate([
            'attachment_max_kb' => ['required', 'integer', 'min:64', 'max:51200'],
            'attachment_extensions' => ['required', 'string', 'max:255', 'regex:/^[A-Za-z0-9,\s]+$/'],
            'template_max_kb' => ['required', 'integer', 'min:64', 'max:51200'],
            'template_extensions' => ['required', 'string', 'max:255', 'regex:/^[A-Za-z0-9,\s]+$/'],
        ], [
            'attachment_extensions.regex' => 'Use a comma-separated list of plain extensions (no dots, letters/digits only).',
            'template_extensions.regex' => 'Use a comma-separated list of plain extensions (no dots, letters/digits only).',
        ]);

        $clean = function (string $csv): string {
            $parts = array_filter(array_map(
                fn ($e) => strtolower(trim($e)),
                explode(',', $csv),
            ));

            return implode(',', array_values(array_unique($parts)));
        };

        DB::transaction(function () use ($request, $validated, $clean) {
            $newAttachmentKb = (int) $validated['attachment_max_kb'];
            $newAttachmentExts = $clean($validated['attachment_extensions']);
            $newTemplateKb = (int) $validated['template_max_kb'];
            $newTemplateExts = $clean($validated['template_extensions']);

            AppSetting::put(AppSetting::ATTACHMENT_MAX_KB, (string) $newAttachmentKb, $request->user()->id);
            AppSetting::put(AppSetting::ATTACHMENT_ALLOWED_EXTENSIONS, $newAttachmentExts, $request->user()->id);
            AppSetting::put(AppSetting::TEMPLATE_MAX_KB, (string) $newTemplateKb, $request->user()->id);
            AppSetting::put(AppSetting::TEMPLATE_ALLOWED_EXTENSIONS, $newTemplateExts, $request->user()->id);
        });

        return redirect()->route('settings.index')->with('status', 'Upload limits updated.');
    }

    /**
     * Reset every upload-limit setting back to its built-in default by
     * deleting the override rows (the getters fall through to the
     * `DEFAULT_*` constants on AppSetting). Superadmin Data-control
     * actions are not audit-logged — see updateUploadLimits().
     */
    public function resetUploadLimits(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->isSuperadmin(), 403);
        PasswordConfirm::check($request);

        // Drop the override rows entirely — the getters fall back to
        // the DEFAULT_* constants when no row exists.
        AppSetting::query()->whereIn('key', [
            AppSetting::ATTACHMENT_MAX_KB,
            AppSetting::ATTACHMENT_ALLOWED_EXTENSIONS,
            AppSetting::TEMPLATE_MAX_KB,
            AppSetting::TEMPLATE_ALLOWED_EXTENSIONS,
        ])->delete();

        return redirect()->route('settings.index')->with('status', 'Upload limits reset to defaults.');
    }

    /**
     * Stream a database snapshot as a download. Two driver paths:
     *
     *  - SQLite (local Herd): the single .sqlite file IS the backup,
     *    served directly. Restore = replace the file on disk.
     *  - PostgreSQL (production Coolify): pipe pg_dump into gzip and
     *    stream the .sql.gz to the browser. Restore = `gunzip -c file
     *    | psql -h $DB_HOST -U $DB_USERNAME $DB_DATABASE` from inside
     *    the app container's Terminal tab. The dump is portable —
     *    any same-major-version Postgres can replay it.
     *
     * Superadmin-only and password-reconfirmed; not audit-logged
     * (per the §10 carve-out for Data-control actions).
     */
    public function downloadDatabaseSnapshot(Request $request): BinaryFileResponse|StreamedResponse
    {
        abort_unless($request->user()?->isSuperadmin(), 403);
        PasswordConfirm::check($request);

        $driver = config('database.default');
        $stamp = now()->format('Y-m-d-His');

        // ── SQLite: serve the raw file ────────────────────────────────
        if ($driver === 'sqlite') {
            $path = config('database.connections.sqlite.database');

            abort_unless(is_string($path) && is_file($path), 404,
                'No SQLite database file found at the configured path.');

            return response()->download(
                $path,
                "bus-contracts-manager-snapshot-{$stamp}.sqlite",
            );
        }

        // ── Postgres: pipe pg_dump | gzip into the response ───────────
        if ($driver === 'pgsql') {
            return $this->streamPgDump($stamp);
        }

        abort(500, "Database driver '{$driver}' is not supported for snapshot downloads.");
    }

    /**
     * Spawn pg_dump and gzip its output, streaming the gzipped SQL to
     * the browser without buffering the whole dump in PHP memory.
     *
     * Flags:
     *  --clean --if-exists  drops + recreates objects on restore so a
     *                       restore into a non-empty DB just works.
     *  --no-owner --no-privileges  strip ownership/grant statements
     *                              that would only be valid for the
     *                              source DB's role.
     */
    private function streamPgDump(string $stamp): StreamedResponse
    {
        $conn = config('database.connections.pgsql');

        $cmd = sprintf(
            'pg_dump --clean --if-exists --no-owner --no-privileges --host=%s --port=%s --username=%s --dbname=%s 2>/dev/null | gzip',
            escapeshellarg((string) $conn['host']),
            escapeshellarg((string) $conn['port']),
            escapeshellarg((string) $conn['username']),
            escapeshellarg((string) $conn['database']),
        );

        return response()->streamDownload(function () use ($cmd, $conn) {
            $env = ['PGPASSWORD' => (string) $conn['password']];
            $descriptors = [
                1 => ['pipe', 'w'], // stdout = gzipped dump bytes
                2 => ['pipe', 'w'], // stderr (already redirected to /dev/null in cmd, but keep handle)
            ];

            $proc = proc_open($cmd, $descriptors, $pipes, null, $env);

            if (! is_resource($proc)) {
                // Bail with a one-line marker the user will see at the
                // top of the otherwise-empty file. Nothing else we can
                // do mid-stream — headers are already flushed.
                echo "-- ERROR: failed to spawn pg_dump\n";

                return;
            }

            // 64 KB chunks — large enough that PHP doesn't churn,
            // small enough that the browser sees progress.
            while (! feof($pipes[1])) {
                $chunk = fread($pipes[1], 65536);
                if ($chunk === false || $chunk === '') {
                    break;
                }
                echo $chunk;
                @ob_flush();
                @flush();
            }

            fclose($pipes[1]);
            fclose($pipes[2]);
            proc_close($proc);
        }, "bus-contracts-manager-snapshot-{$stamp}.sql.gz", [
            'Content-Type' => 'application/gzip',
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    /**
     * Targeted data delete — the single destructive entry point in
     * Settings → Data control. Picks WHAT to wipe from a dropdown:
     *
     *   - audit_log   → audit_logs (cascades attachments via FK)
     *   - contracts   → contracts table only (audit history preserved)
     *   - indices     → CPI + CPA + RPI tables
     *   - attachments → attachments only (audit rows + filenames preserved)
     *   - all         → contracts + indices + audit log + attachments
     *
     * Things that ALWAYS survive (regardless of which option is picked):
     *   - users + their profiles
     *   - login_logs (login history is part of the user-data trail)
     *   - app_settings (anchor year, upload limits, P2P/RA cutoff, etc.)
     *
     * The operator should be able to wipe operational data and still
     * sign in afterwards with the same credentials and the same app
     * configuration intact.
     *
     * Superadmin only, password-confirmed, double-confirmed in the UI.
     * Per project policy, Data-control actions are not audit-logged.
     */
    public function deleteData(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->isSuperadmin(), 403);

        $validated = $request->validate([
            'type' => ['required', Rule::in(['audit_log', 'contracts', 'indices', 'attachments', 'all'])],
        ]);

        PasswordConfirm::check($request);

        $type = $validated['type'];
        $message = '';

        DB::transaction(function () use ($type, $request, &$message) {
            $message = match ($type) {
                'audit_log' => $this->purgeAuditTable($request->user()->id),
                'contracts' => $this->purgeContractsTable(),
                'indices' => $this->purgeIndicesTables(),
                'attachments' => $this->purgeAttachmentsTable(),
                'all' => $this->purgeEverything($request->user()->id),
            };
        });

        return redirect()->route('settings.index')->with('status', $message);
    }

    private function purgeAuditTable(int $actorId): string
    {
        $count = AuditLog::query()->count();
        // attachments.audit_log_id cascades on delete, so attachments
        // tied to audit rows are swept here too.
        AuditLog::query()->delete();
        AppSetting::put(AppSetting::AUDIT_LOG_VISIBLE_AFTER_ID, '0', $actorId);

        return "Permanently deleted {$count} audit log {$this->plural('entry', $count)}.";
    }

    private function purgeContractsTable(): string
    {
        $count = Contract::query()->count();
        Contract::query()->delete();

        return "Permanently deleted {$count} {$this->plural('contract', $count)}. Audit history preserved.";
    }

    private function purgeIndicesTables(): string
    {
        $cpa = CpaRate::query()->count();
        $cpi = CpiIndexEntry::query()->count();
        $rpi = RpiIndexEntry::query()->count();

        CpaRate::query()->delete();
        CpiIndexEntry::query()->delete();
        RpiIndexEntry::query()->delete();

        $total = $cpa + $cpi + $rpi;

        return "Permanently deleted {$total} index {$this->plural('row', $total)} (CPI: {$cpi}, CPA: {$cpa}, RPI: {$rpi}). Audit history preserved.";
    }

    private function purgeAttachmentsTable(): string
    {
        $count = Attachment::query()->count();
        Attachment::query()->delete();

        return "Permanently deleted {$count} {$this->plural('attachment', $count)}. Audit rows referencing them are preserved (download links will 404).";
    }

    private function purgeEverything(int $actorId): string
    {
        $contracts = Contract::query()->count();
        $cpa = CpaRate::query()->count();
        $cpi = CpiIndexEntry::query()->count();
        $rpi = RpiIndexEntry::query()->count();
        $audits = AuditLog::query()->count();
        $attachments = Attachment::query()->count();

        // Delete order matters where FKs cascade. Attachments cascades
        // off audit_logs, but explicit deletion keeps the operation
        // traceable across drivers.
        //
        // login_logs is deliberately NOT wiped — it's part of the user
        // data trail (alongside the users table itself + app_settings)
        // that must survive a "wipe operational data" action.
        Attachment::query()->delete();
        AuditLog::query()->delete();
        CpaRate::query()->delete();
        CpiIndexEntry::query()->delete();
        RpiIndexEntry::query()->delete();
        Contract::query()->delete();

        AppSetting::put(AppSetting::AUDIT_LOG_VISIBLE_AFTER_ID, '0', $actorId);

        $total = $contracts + $cpa + $cpi + $rpi + $audits + $attachments;

        return "Wiped {$total} rows across data + audit + attachments. Users, login history, and app settings preserved.";
    }

    private function plural(string $singular, int $count): string
    {
        return Str::plural($singular, $count);
    }
}
