<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreRpiIndexEntryRequest;
use App\Http\Requests\UpdateRpiIndexEntryRequest;
use App\Models\AppSetting;
use App\Models\AuditLog;
use App\Models\RpiIndexEntry;
use App\Services\CpiRowSanitiser;
use App\Support\CsvExporter;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * RPI is published on the same ONS dataset as CPI but is treated as an
 * independent index here — RPI has no role in the CPA derivation, so this
 * controller deliberately doesn't reach into cpa_rates. The shape mirrors
 * the CPI handling in {@see CpaController}: same filter dimensions, same
 * source tags, same override-and-reset flow.
 */
class RpiController extends Controller
{
    /** Refuse to ingest a CSV with more than this many data rows. */
    private const IMPORT_ROW_CAP = 5000;

    /** Per-list cap for the detailed import outcome saved in the audit log. */
    private const AUDIT_DETAIL_LIMIT = 200;

    public function __construct(private readonly CpiRowSanitiser $sanitiser) {}

    public function index(Request $request): View
    {
        $filters = $this->resolveFilters($request);

        $allEntries = RpiIndexEntry::query()
            ->orderByDesc('month')
            ->get();

        $entriesById = $allEntries->keyBy(fn (RpiIndexEntry $e) => Carbon::parse($e->month)->format('Y-m'));

        $yoyByMonth = [];
        foreach ($allEntries as $entry) {
            $month = Carbon::parse($entry->month);
            $priorKey = $month->copy()->subMonths(12)->format('Y-m');

            if (! $entriesById->has($priorKey)) {
                $yoyByMonth[$month->format('Y-m')] = null;

                continue;
            }

            $current = number_format((float) $entry->rpi_index, 1, '.', '');
            $prior = number_format((float) $entriesById[$priorKey]->rpi_index, 1, '.', '');
            $diff = bcsub($current, $prior, 10);
            $yoyByMonth[$month->format('Y-m')] = bcadd(bcdiv($diff, $prior, 10), '0', 8);
        }

        $entries = $allEntries->filter(function (RpiIndexEntry $entry) use ($filters) {
            $monthKey = Carbon::parse($entry->month)->format('Y-m');
            $isOverride = ! $entry->is_actual;
            $sourceKey = match (true) {
                $isOverride => 'manual_override',
                ($entry->source ?? 'manual_import') === 'ons_feed' => 'ons_feed',
                default => 'manual_import',
            };

            return $this->matchesFilters($filters, $monthKey, $isOverride, $sourceKey);
        })->values();

        $sourceCounts = ['ons_feed' => 0, 'manual_import' => 0, 'manual_override' => 0];
        foreach ($allEntries as $e) {
            $key = ! $e->is_actual ? 'manual_override' : (($e->source ?? 'manual_import') === 'ons_feed' ? 'ons_feed' : 'manual_import');
            $sourceCounts[$key]++;
        }

        return view('cpa.rpi', [
            'entries' => $entries,
            'allEntries' => $allEntries,
            'yoyByMonth' => $yoyByMonth,
            'filters' => $filters,
            'sourceCounts' => $sourceCounts,
        ]);
    }

    public function storeEntry(StoreRpiIndexEntryRequest $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $monthDate = $request->monthDate();
        $rpi = $request->validated('rpi_index');

        DB::transaction(function () use ($request, $monthDate, $rpi) {
            $entry = RpiIndexEntry::create([
                'month' => $monthDate,
                'rpi_index' => $rpi,
                'rpi_index_original' => $rpi,
                'is_actual' => true,
                'source' => 'manual_import',
                'source_original' => 'manual_import',
                'created_by' => $request->user()->id,
            ]);

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'rpi_index_added',
                'entity_type' => $entry->getTable(),
                'entity_id' => $entry->getKey(),
                'new_values' => ['rpi_index' => $rpi, 'month' => $monthDate],
                'ip_address' => $request->ip(),
            ]);
        });

        return redirect(url()->previous())->with('status', 'RPI value added.');
    }

    public function updateEntry(UpdateRpiIndexEntryRequest $request, RpiIndexEntry $rpiIndexEntry): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $newRpi = $request->validated('rpi_index');
        $note = $request->validated('override_note');
        $newMonthDate = $request->monthDate();
        $isOnsFeed = ($rpiIndexEntry->source_original ?? 'manual_import') === 'ons_feed';

        if ($newMonthDate && $isOnsFeed && $newMonthDate !== $rpiIndexEntry->month) {
            return redirect(url()->previous())
                ->with('updateError', 'ONS-feed entries cannot be moved to a different month.');
        }

        $oldMonthDate = $rpiIndexEntry->month;
        $monthChanged = $newMonthDate && $newMonthDate !== $oldMonthDate;

        if ($monthChanged) {
            $clash = RpiIndexEntry::where('month', $newMonthDate)
                ->where('id', '!=', $rpiIndexEntry->id)
                ->exists();

            if ($clash) {
                return redirect(url()->previous())
                    ->with('updateError', 'An entry for this month already exists. Choose a different month or delete the existing one first.');
            }
        }

        DB::transaction(function () use ($request, $rpiIndexEntry, $newRpi, $note, $newMonthDate, $oldMonthDate, $monthChanged) {
            $oldRpi = $this->normaliseValue($rpiIndexEntry->rpi_index);
            $newRpiNorm = $this->normaliseValue($newRpi);

            if ($oldRpi === $newRpiNorm && ! $monthChanged) {
                return;
            }

            $changes = [];

            if ($monthChanged) {
                $rpiIndexEntry->month = $newMonthDate;
                $changes['month'] = ['from' => $oldMonthDate, 'to' => $newMonthDate];
            }

            if ($oldRpi !== $newRpiNorm) {
                $rpiIndexEntry->rpi_index = $newRpi;
                $rpiIndexEntry->is_actual = false;
                $rpiIndexEntry->source = 'manual_override';
                $changes['rpi_index'] = ['from' => $oldRpi, 'to' => $newRpiNorm];
            }

            $rpiIndexEntry->override_note = $note;
            $rpiIndexEntry->updated_by = $request->user()->id;
            $rpiIndexEntry->save();

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'rpi_index_updated',
                'entity_type' => $rpiIndexEntry->getTable(),
                'entity_id' => $rpiIndexEntry->getKey(),
                'old_values' => array_map(fn ($c) => $c['from'], $changes),
                'new_values' => array_map(fn ($c) => $c['to'], $changes),
                'note' => $note,
                'ip_address' => $request->ip(),
            ]);
        });

        return redirect(url()->previous())->with('status', 'RPI updated.');
    }

    /**
     * Per-row reset: restore a single overridden RPI entry to its original
     * ONS / imported value. RPI is independent, so nothing else recalcs.
     */
    public function resetEntry(Request $request, RpiIndexEntry $rpiIndexEntry): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        if ($rpiIndexEntry->rpi_index_original === null) {
            return redirect(url()->previous())
                ->with('updateError', 'No original ONS value recorded for this entry — nothing to reset to.');
        }

        $oldRpi = $this->normaliseValue($rpiIndexEntry->rpi_index);
        $originalRpi = $this->normaliseValue($rpiIndexEntry->rpi_index_original);

        if ($oldRpi === $originalRpi && $rpiIndexEntry->is_actual) {
            return redirect(url()->previous())->with('status', 'Already on the ONS value — nothing to reset.');
        }

        DB::transaction(function () use ($request, $rpiIndexEntry, $oldRpi, $originalRpi) {
            $rpiIndexEntry->fill([
                'rpi_index' => $originalRpi,
                'is_actual' => true,
                'source' => $rpiIndexEntry->source_original ?? 'manual_import',
                'override_note' => null,
                'updated_by' => $request->user()->id,
            ])->save();

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'rpi_index_reset',
                'entity_type' => $rpiIndexEntry->getTable(),
                'entity_id' => $rpiIndexEntry->getKey(),
                'old_values' => ['rpi_index' => $oldRpi],
                'new_values' => ['rpi_index' => $originalRpi],
                'note' => 'Reset to ONS value',
                'ip_address' => $request->ip(),
            ]);
        });

        return redirect()->route('indices.rpi')->with('status', 'Reset to ONS value.');
    }

    public function destroyEntry(Request $request, RpiIndexEntry $rpiIndexEntry): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        if (($rpiIndexEntry->source_original ?? 'manual_import') === 'ons_feed') {
            return redirect(url()->previous())
                ->with('importErrors', ['ONS-feed entries cannot be deleted — edit or reset them instead.']);
        }

        $monthLabel = Carbon::parse($rpiIndexEntry->month)->format('F Y');
        $oldValues = [
            'month' => $rpiIndexEntry->month,
            'rpi_index' => $this->normaliseValue($rpiIndexEntry->rpi_index),
            'source' => $rpiIndexEntry->source,
        ];

        DB::transaction(function () use ($request, $rpiIndexEntry, $oldValues) {
            $entityType = $rpiIndexEntry->getTable();
            $entityId = $rpiIndexEntry->getKey();
            $rpiIndexEntry->delete();

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'rpi_index_deleted',
                'entity_type' => $entityType,
                'entity_id' => $entityId,
                'old_values' => $oldValues,
                'new_values' => null,
                'note' => 'Manually deleted RPI value',
                'ip_address' => $request->ip(),
            ]);
        });

        return redirect(url()->previous())->with('status', "Deleted {$monthLabel}.");
    }

    public function clearOverrides(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $reset = 0;

        DB::transaction(function () use ($request, &$reset) {
            $overridden = RpiIndexEntry::query()
                ->where('source', 'manual_override')
                ->whereNotNull('rpi_index_original')
                ->get();

            foreach ($overridden as $entry) {
                if ($this->normaliseValue($entry->rpi_index) === $this->normaliseValue($entry->rpi_index_original)) {
                    continue;
                }

                $entry->fill([
                    'rpi_index' => $this->normaliseValue($entry->rpi_index_original),
                    'is_actual' => true,
                    'source' => $entry->source_original ?? 'manual_import',
                    'override_note' => null,
                    'updated_by' => $request->user()->id,
                ])->save();
                $reset++;
            }

            if ($reset > 0) {
                AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'rpi_overrides_cleared',
                    'entity_type' => 'rpi_index_entries',
                    'entity_id' => 0,
                    'new_values' => ['rpi_overrides_reset' => $reset],
                    'note' => 'Reset all RPI overrides to ONS values',
                    'ip_address' => $request->ip(),
                ]);
            }
        });

        $message = $reset > 0 ? "Cleared {$reset} RPI override".($reset === 1 ? '' : 's').'.' : 'No RPI overrides to clear.';

        return redirect()->route('indices.rpi')->with('status', $message);
    }

    /**
     * Delete only RPI rows that originated from a bulk import or a manual
     * +Add month entry — i.e. anything whose source_original is
     * 'manual_import'. ONS-feed rows are preserved.
     */
    public function clearImports(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $count = 0;

        DB::transaction(function () use ($request, &$count) {
            $count = RpiIndexEntry::query()
                ->where('source_original', 'manual_import')
                ->count();

            if ($count === 0) {
                return;
            }

            RpiIndexEntry::query()
                ->where('source_original', 'manual_import')
                ->delete();

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'rpi_imports_cleared',
                'entity_type' => 'rpi_index_entries',
                'entity_id' => 0,
                'new_values' => ['rpi_rows_deleted' => $count],
                'note' => 'Deleted manually-added RPI values. ONS data kept.',
                'ip_address' => $request->ip(),
            ]);
        });

        $message = $count > 0
            ? "Deleted {$count} bulk-imported RPI row".($count === 1 ? '' : 's').'. ONS-feed rows preserved.'
            : 'No bulk-imported RPI rows to delete.';

        return redirect()->route('indices.rpi')->with('status', $message);
    }

    public function importTemplate(): StreamedResponse
    {
        return response()->streamDownload(function () {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['month', 'rpi_index'], ',', '"', '');
            fputcsv($out, ['2026-03', '411.4'], ',', '"', '');
            fputcsv($out, ['2026-04', '413.1'], ',', '"', '');
            fclose($out);
        }, 'rpi-import-template.csv', [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function importCsv(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $request->validate([
            'csv' => AppSetting::templateUploadRules(),
            'replace_overrides' => ['nullable', 'boolean'],
        ]);

        $replaceOverrides = $request->boolean('replace_overrides');

        $imported = [];
        $updated = [];
        $replaced = [];
        $skipped = [];
        $errors = [];

        DB::transaction(function () use ($request, $replaceOverrides, &$imported, &$updated, &$replaced, &$skipped, &$errors) {
            $handle = fopen($request->file('csv')->getRealPath(), 'r');

            if ($handle === false) {
                $errors[] = ['row' => null, 'message' => 'Could not open uploaded file.'];

                return;
            }

            $rowNumber = 0;
            $seenMonths = [];

            try {
                while (($cells = fgetcsv($handle, 0, ',', '"', '\\')) !== false) {
                    $rowNumber++;

                    if ($rowNumber > self::IMPORT_ROW_CAP) {
                        $errors[] = ['row' => $rowNumber, 'message' => 'File contains more than '.self::IMPORT_ROW_CAP.' rows — refusing to import. Split the file and try again.'];

                        return;
                    }

                    if (count($cells) < 2) {
                        continue;
                    }

                    $rawMonth = (string) $cells[0];
                    $rawValue = (string) $cells[1];

                    if ($rowNumber === 1 && ! is_numeric(trim(CpiRowSanitiser::stripBom($rawValue)))) {
                        continue;
                    }

                    if (trim($rawMonth) === '' && trim($rawValue) === '') {
                        continue;
                    }

                    try {
                        $clean = $this->sanitiser->sanitise($rawMonth, $rawValue);
                    } catch (\DomainException $e) {
                        $errors[] = ['row' => $rowNumber, 'message' => $e->getMessage()];

                        continue;
                    }

                    $month = $clean['month'];
                    $rpi = $clean['cpi_index']; // sanitiser returns 'cpi_index' as the value key — same shape, reuse

                    if (isset($seenMonths[$month])) {
                        $errors[] = ['row' => $rowNumber, 'message' => "Duplicate month '{$month}' (already on row {$seenMonths[$month]})."];

                        continue;
                    }
                    $seenMonths[$month] = $rowNumber;

                    $existing = RpiIndexEntry::where('month', $month)->first();

                    if ($existing && $existing->source === 'manual_override' && ! $replaceOverrides) {
                        $skipped[] = [
                            'month' => $month,
                            'reason' => 'manual override — re-import without "Replace overrides" preserved the existing value',
                            'kept_rpi' => $this->normaliseValue($existing->rpi_index),
                            'csv_rpi' => $rpi,
                        ];

                        continue;
                    }

                    if ($existing) {
                        $wasOverride = $existing->source === 'manual_override';
                        $oldRpi = $this->normaliseValue($existing->rpi_index);
                        $sourceOriginal = $existing->source_original ?? $this->defaultSourceFor($month);

                        $existing->fill([
                            'rpi_index' => $rpi,
                            'rpi_index_original' => $rpi,
                            'is_actual' => true,
                            'source' => $sourceOriginal,
                            'source_original' => $sourceOriginal,
                            'override_note' => null,
                            'updated_by' => $request->user()->id,
                        ])->save();

                        $bucket = ['month' => $month, 'old_rpi' => $oldRpi, 'new_rpi' => $rpi];

                        if ($wasOverride) {
                            $replaced[] = $bucket;
                        } else {
                            $updated[] = $bucket;
                        }
                    } else {
                        $sourceOriginal = $this->defaultSourceFor($month);

                        RpiIndexEntry::create([
                            'month' => $month,
                            'rpi_index' => $rpi,
                            'rpi_index_original' => $rpi,
                            'is_actual' => true,
                            'source' => $sourceOriginal,
                            'source_original' => $sourceOriginal,
                            'created_by' => $request->user()->id,
                        ]);
                        $imported[] = ['month' => $month, 'rpi' => $rpi];
                    }
                }
            } finally {
                fclose($handle);
            }

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'rpi_index_imported',
                'entity_type' => 'rpi_index_entries',
                'entity_id' => 0,
                'old_values' => array_filter([
                    'updated' => $this->capList(array_map(fn ($r) => ['month' => $r['month'], 'rpi' => $r['old_rpi']], $updated)),
                    'replaced_overrides' => $this->capList(array_map(fn ($r) => ['month' => $r['month'], 'rpi' => $r['old_rpi']], $replaced)),
                ]),
                'new_values' => [
                    'summary' => [
                        'imported' => count($imported),
                        'updated' => count($updated),
                        'replaced_overrides' => count($replaced),
                        'skipped' => count($skipped),
                        'errors' => count($errors),
                    ],
                    'imported' => $this->capList($imported),
                    'updated' => $this->capList(array_map(fn ($r) => ['month' => $r['month'], 'rpi' => $r['new_rpi']], $updated)),
                    'replaced_overrides' => $this->capList(array_map(fn ($r) => ['month' => $r['month'], 'rpi' => $r['new_rpi']], $replaced)),
                    'skipped' => $this->capList($skipped),
                    'errors' => $this->capList($errors),
                ],
                'note' => $replaceOverrides ? 'Imported RPI values from CSV (replaced manual overrides)' : 'Imported RPI values from CSV',
                'ip_address' => $request->ip(),
            ]);
        });

        $parts = [];
        if (count($imported) > 0) {
            $parts[] = count($imported).' new';
        }
        if (count($updated) > 0) {
            $parts[] = count($updated).' updated';
        }
        if (count($replaced) > 0) {
            $parts[] = count($replaced).' overrides replaced';
        }
        if (count($skipped) > 0) {
            $parts[] = count($skipped).' skipped (overridden)';
        }
        if (count($errors) > 0) {
            $parts[] = count($errors).' errors';
        }

        $message = empty($parts) ? 'No rows imported.' : 'Imported: '.implode(', ', $parts).'.';
        $redirect = redirect(url()->previous())->with('status', $message);

        if (count($errors) > 0) {
            $redirect = $redirect->with(
                'importErrors',
                array_map(fn ($e) => $e['row'] ? "Row {$e['row']}: {$e['message']}" : $e['message'], array_slice($errors, 0, 10))
            );
        }

        return $redirect;
    }

    public function exportCsv(): StreamedResponse
    {
        $rows = RpiIndexEntry::query()->orderBy('month')->get();
        $filename = sprintf('rpi-%s.csv', now()->format('Y-m-d'));

        return response()->streamDownload(function () use ($rows) {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['month', 'rpi_index', 'source']);

            foreach ($rows as $row) {
                $source = ! $row->is_actual
                    ? 'manual_override'
                    : (($row->source ?? 'manual_import') === 'ons_feed' ? 'ons_feed' : 'manual_import');

                // safeRow neutralises CSV / formula injection on cells
                // sourced from operator overrides.
                fputcsv($out, CsvExporter::safeRow([
                    Carbon::parse($row->month)->format('Y-m-d'),
                    number_format((float) $row->rpi_index, 1, '.', ''),
                    $source,
                ]), ',', '"', '');
            }

            fclose($out);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    /* ------------------------------------------------------------------ */
    /* Helpers */
    /* ------------------------------------------------------------------ */

    /**
     * @return array{overrides_only: bool, sources: array<int, string>, from: ?string, to: ?string}
     */
    private function resolveFilters(Request $request): array
    {
        $rawSources = $request->query('sources', []);
        if (is_string($rawSources)) {
            $rawSources = $rawSources === '' ? [] : explode(',', $rawSources);
        }
        $sources = collect((array) $rawSources)
            ->map(fn ($s) => trim((string) $s))
            ->filter(fn ($s) => in_array($s, ['ons_feed', 'manual_import', 'manual_override'], true))
            ->unique()
            ->values()
            ->all();

        return [
            'overrides_only' => $request->boolean('overrides'),
            'sources' => $sources,
            'from' => $this->normaliseFilterMonth($request->query('from')),
            'to' => $this->normaliseFilterMonth($request->query('to')),
        ];
    }

    private function normaliseFilterMonth(?string $value): ?string
    {
        if ($value === null || trim($value) === '') {
            return null;
        }

        return preg_match('/^\d{4}-\d{2}$/', $value) ? $value : null;
    }

    /**
     * @param  array{overrides_only: bool, sources: array<int, string>, from: ?string, to: ?string}  $filters
     */
    private function matchesFilters(array $filters, string $monthKey, bool $isOverride, string $sourceKey): bool
    {
        if ($filters['overrides_only'] && ! $isOverride) {
            return false;
        }

        if (! empty($filters['sources']) && ! in_array($sourceKey, $filters['sources'], true)) {
            return false;
        }

        if ($filters['from'] !== null && $monthKey < $filters['from']) {
            return false;
        }

        if ($filters['to'] !== null && $monthKey > $filters['to']) {
            return false;
        }

        return true;
    }

    private function defaultSourceFor(string $monthDate): string
    {
        return $monthDate < '2024-01-01' ? 'manual_import' : 'ons_feed';
    }

    private function normaliseValue(string|float $value): string
    {
        return number_format((float) $value, 1, '.', '');
    }

    /**
     * @param  array<int, array<string, mixed>>  $items
     * @return array<int, array<string, mixed>>
     */
    private function capList(array $items): array
    {
        $limit = self::AUDIT_DETAIL_LIMIT;

        if (count($items) <= $limit) {
            return $items;
        }

        $kept = array_slice($items, 0, $limit);
        $kept[] = ['_truncated' => true, '_total' => count($items), '_shown' => $limit];

        return $kept;
    }
}
