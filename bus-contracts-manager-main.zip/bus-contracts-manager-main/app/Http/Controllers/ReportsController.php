<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\View\View;

class ReportsController extends Controller
{
    /**
     * Pre-defined reports surfaced on the Reports landing page. Each entry is
     * the single source of truth for the route slug, the card label/blurb on
     * the landing grid, and the page header on its own detail page.
     *
     * Logic for each report is deliberately stubbed for now — the Reports
     * page is a shell so the navigation and routing structure can settle
     * before we wire up the real number-crunching.
     *
     * @return array<string, array{label: string, summary: string, description: string}>
     */
    public const REPORTS = [
        'cash-forecast' => [
            'label' => 'Cash forecast',
            'summary' => 'Period-by-period projected cash receipts across upcoming financial years.',
            'description' => 'Projects when contract cash is expected to land, period by period, across the active financial years.',
        ],
        'accruals-forecast' => [
            'label' => 'Accruals forecast',
            'summary' => 'Period-by-period accruals view — earned revenue independent of when it is paid.',
            'description' => 'Models earned revenue period by period regardless of when the cash actually arrives.',
        ],
        'final-claim' => [
            'label' => 'Final claim',
            'summary' => 'End-of-year claim consolidating actuals and confirmed adjustments.',
            'description' => 'Consolidates a full year of actuals and confirmed adjustments into the final claim figure.',
        ],
        'intermediate-claim' => [
            'label' => 'Intermediate claim',
            'summary' => 'Mid-year interim claim covering year-to-date performance.',
            'description' => 'Year-to-date interim claim used between final claim cycles.',
        ],
        // Hyperion-import landing page. Hyperion is the upstream finance
        // system; this section will let an operator drop in the exported
        // Excel (.xls / .xlsx) workbooks that the cash + accruals + claim
        // reports above consume. Stubbed for now — the import pipeline
        // is on the roadmap.
        'hyperion' => [
            'label' => 'Hyperion',
            'summary' => 'Upload Hyperion Excel exports — feeds the cash, accruals, and claim reports above.',
            'description' => 'Drop in Hyperion Excel exports (.xls / .xlsx) here. The cash forecast, accruals forecast, and claim reports all consume parsed Hyperion data once this importer is wired up.',
        ],
    ];

    public function index(): View
    {
        return view('reports.index', [
            'reports' => self::REPORTS,
        ]);
    }

    public function show(string $report): View
    {
        abort_unless(array_key_exists($report, self::REPORTS), 404);

        return view('reports.show', [
            'slug' => $report,
            'meta' => self::REPORTS[$report],
        ]);
    }
}
