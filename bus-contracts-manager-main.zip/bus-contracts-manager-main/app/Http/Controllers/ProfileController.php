<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\AuditLog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\View\View;

class ProfileController extends Controller
{
    /**
     * Display the user's profile form.
     */
    public function edit(Request $request): View
    {
        return view('profile.edit', [
            'user' => $request->user(),
        ]);
    }

    /**
     * Update the user's profile information. Captures the field-level diff
     * so the audit entry shows exactly what changed (mirrors the per-record
     * edit pattern used elsewhere). Wrapped in a DB transaction so the
     * profile mutation and audit row commit or roll back together.
     */
    public function update(ProfileUpdateRequest $request): RedirectResponse
    {
        $user = $request->user();

        // Snapshot the comparable fields BEFORE filling so the diff is
        // accurate regardless of which validated keys the request carried.
        $trackedFields = ['name', 'email'];
        $oldValues = [];
        foreach ($trackedFields as $field) {
            $oldValues[$field] = $user->getAttribute($field);
        }

        $user->fill($request->validated());

        if ($user->isDirty('email')) {
            $user->email_verified_at = null;
        }

        $changes = [];
        foreach ($trackedFields as $field) {
            $next = $user->getAttribute($field);
            if ((string) ($oldValues[$field] ?? '') !== (string) ($next ?? '')) {
                $changes[$field] = ['from' => $oldValues[$field], 'to' => $next];
            }
        }

        if (empty($changes)) {
            return Redirect::route('profile.edit')->with('status', 'profile-updated');
        }

        DB::transaction(function () use ($request, $user, $changes) {
            $user->save();

            AuditLog::create([
                'user_id' => $user->id,
                'action' => 'user_updated',
                'entity_type' => $user->getTable(),
                'entity_id' => $user->id,
                'old_values' => array_map(fn ($c) => $c['from'], $changes),
                'new_values' => array_map(fn ($c) => $c['to'], $changes),
                'note' => 'Profile updated by account owner',
                'ip_address' => $request->ip(),
            ]);
        });

        return Redirect::route('profile.edit')->with('status', 'profile-updated');
    }

    /**
     * Delete the user's account.
     *
     * Writes a `user_deleted` audit entry BEFORE removing the user,
     * with a snapshot of name + email + role in old_values. The FK
     * on audit_logs.user_id is now nullOnDelete (per the migration
     * that closed the §10 compliance gap), so once the user vanishes
     * audit_logs.user_id flips to null but the rest of the row —
     * including this snapshot — survives forever.
     */
    public function destroy(Request $request): RedirectResponse
    {
        $request->validateWithBag('userDeletion', [
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        // Audit + archive must commit (or roll back) together. Doing
        // these as separate writes risks a half-applied state where
        // the audit row exists but the account is still active.
        // Logout + session teardown happens AFTER the transaction
        // commits — once the data write is durable.
        DB::transaction(function () use ($request, $user) {
            AuditLog::create([
                'user_id' => $user->id,
                'action' => 'user_deleted',
                'entity_type' => 'users',
                'entity_id' => $user->id,
                'old_values' => [
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                ],
                'new_values' => null,
                'note' => "Self-archived account: {$user->name} ({$user->email})",
                'ip_address' => $request->ip(),
            ]);

            // Soft-delete: archive instead of hard-delete so the audit
            // trail continues to resolve historical references to this
            // user.
            $user->archive($user->id);
        });

        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return Redirect::to('/');
    }
}
