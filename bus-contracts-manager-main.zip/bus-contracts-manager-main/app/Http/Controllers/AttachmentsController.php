<?php

namespace App\Http\Controllers;

use App\Models\Attachment;
use App\Models\AttachmentLink;
use App\Models\AuditLog;
use App\Models\Contract;
use App\Support\AuditActions;
use App\Support\AttachmentUpload;
use App\Support\PasswordConfirm;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\HeaderUtils;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Streams an attachment as a download. Authentication is already
 * required by the route group; here we additionally enforce:
 *
 *  - admin+ only (matches audit-log read access)
 *  - admins cannot view attachments uploaded against superadmin-authored
 *    audit entries (mirrors the AuditLogController filter)
 *
 * Always served as `Content-Disposition: attachment` per requirement —
 * no inline preview, no MIME sniffing.
 */
class AttachmentsController extends Controller
{
    /**
     * Pre-flight check fired by the attachment-field component when the
     * user picks a file. Sanitises the supplied name (matches the
     * server-side persist sanitiser exactly) and returns any existing
     * attachments using that filename so the front-end can offer the
     * replace / keep / cancel choice. Read-only — never mutates state.
     */
    public function checkDuplicate(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'filename' => ['required', 'string', 'max:300'],
        ]);

        $sanitised = AttachmentUpload::sanitiseFilename($validated['filename']);
        $duplicates = AttachmentUpload::findDuplicatesByFilename($sanitised)
            ->map(function (Attachment $a) {
                $log = $a->auditLog;

                return [
                    'id' => $a->id,
                    'filename' => $a->original_filename,
                    'size_kb' => (int) round(($a->size_bytes ?? 0) / 1024),
                    'sha256' => $a->sha256,
                    'when' => $a->created_at?->format('d/m/Y H:i'),
                    'uploader' => $log?->user?->name,
                    'context' => $log
                        ? AuditActions::label($log->action).' · '.($log->note ?? '')
                        : null,
                    // Drives the "Link existing" option in the dupe
                    // dialog — only offered when at least one active
                    // copy exists (detached files can't be linked to).
                    'is_active' => $a->detached_at === null,
                ];
            });

        return response()->json([
            'sanitised_filename' => $sanitised,
            'duplicates' => $duplicates->values()->all(),
        ]);
    }

    /**
     * Soft-detach an attachment from its record-item. Removes it from
     * the dialog list (forKey queries skip detached rows) but keeps the
     * row + bytes + audit history intact. Writes a
     * `contract_attachment_detached` audit entry recording the action.
     */

    /**
     * Soft-detach an attachment LINK from its record-item slot. The
     * attachment row + bytes + audit history all stay intact; only
     * this particular slot's binding is removed. Other slots that
     * link to the same file are unaffected.
     *
     * Replaces the previous attachment-scoped detach (which couldn't
     * disambiguate between multiple slots referencing one file once
     * the link-existing feature ships).
     */
    public function detachLink(Request $request, AttachmentLink $link): RedirectResponse|Response
    {
        $user = $request->user();
        abort_unless($user !== null && $user->canWrite(), 403);
        abort_if($link->detached_at !== null, 422, 'This link is already detached.');
        abort_if($link->attachable_key === null, 422, 'This link is not bound to a record-item.');

        $attachment = $link->attachment;
        abort_if($attachment === null, 422, 'Underlying attachment missing.');

        // Archived contracts are immutable — their attachments can't be
        // detached either. Restore the contract first if a legitimate
        // detach is needed.
        $linkOriginalLog = $link->auditLog ?? $attachment->auditLog;
        if ($linkOriginalLog && $linkOriginalLog->entity_type === 'contracts') {
            $linkContract = Contract::find($linkOriginalLog->entity_id);
            abort_if($linkContract && $linkContract->isArchived(), 404);
        }

        DB::transaction(function () use ($request, $link, $attachment) {
            $link->forceFill([
                'detached_at' => now(),
                'detached_by' => $request->user()->id,
            ])->save();

            // Mirror the legacy detached_at/detached_by columns on the
            // attachment row so any code still reading them sees the
            // change. Only mark the file fully detached when no active
            // links remain — until then, the file is still in use by
            // other slots and shouldn't be hidden globally.
            $hasActiveLinks = AttachmentLink::query()
                ->where('attachment_id', $attachment->id)
                ->whereNull('detached_at')
                ->exists();

            if (! $hasActiveLinks) {
                $attachment->forceFill([
                    'detached_at' => now(),
                    'detached_by' => $request->user()->id,
                ])->save();
            }

            // Match the framing used by `contract_attachment_attached`:
            //   [#id contract_no · route X] Attachment detached from <slot> — <filename>
            $originalLog = $link->auditLog ?? $attachment->auditLog;
            $contract = $originalLog && $originalLog->entity_type === 'contracts'
                ? Contract::find($originalLog->entity_id)
                : null;

            $prefix = $contract ? $contract->auditRef().' ' : '';
            $slotLabel = self::slotLabel($link->attachable_key);

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'contract_attachment_detached',
                'entity_type' => $originalLog?->entity_type ?? 'contracts',
                'entity_id' => $originalLog?->entity_id ?? 0,
                'old_values' => [
                    'attachable_key' => $link->attachable_key,
                    'attachment_id' => $attachment->id,
                    'attachment_link_id' => $link->id,
                    'filename' => $attachment->original_filename,
                ],
                'new_values' => null,
                'note' => $prefix."Attachment detached from {$slotLabel} — {$attachment->original_filename}",
                'ip_address' => $request->ip(),
            ]);
        });

        if ($request->expectsJson()) {
            return response()->noContent();
        }

        return back()->with('status', "Detached {$attachment->original_filename}.");
    }

    /**
     * Friendly label for an attachable_key, used in audit notes.
     * Examples:
     *   contract:406              → contract record
     *   contract:406:cpa:2024     → CPA confirmation 2024
     *   contract:406:extension    → Extension flag
     *   contract:406:notice_served → Notice-served flag
     *   contract:406:tender_award → Tender award
     */
    private static function slotLabel(?string $key): string
    {
        if ($key === null) {
            return 'contract record';
        }
        $parts = explode(':', $key);
        if (count($parts) === 2) {
            return 'contract record';
        }
        if (count($parts) >= 4 && $parts[2] === 'cpa') {
            return "CPA confirmation {$parts[3]}";
        }

        return match ($parts[2] ?? '') {
            'extension' => 'Extension flag',
            'notice_served' => 'Notice-served flag',
            'tender_award' => 'Tender award',
            default => 'contract record',
        };
    }

    public function download(Request $request, Attachment $attachment): StreamedResponse
    {
        // Any signed-in user can pull an attachment they hold a link
        // to. The admin-vs-superadmin filter that scopes the *audit log
        // listing* doesn't extend here — attachments tied to contracts
        // are content the user role is meant to read alongside the
        // dialog that points at them.
        abort_unless($request->user() !== null, 403);

        $disposition = HeaderUtils::makeDisposition(
            HeaderUtils::DISPOSITION_ATTACHMENT,
            $attachment->original_filename,
            'attachment'
        );

        // Pull the blob in a separate query (the model's default select
        // hides `contents`). Stream so we don't double-buffer in memory.
        $bytes = Attachment::query()->whereKey($attachment->id)->value('contents');

        return response()->streamDownload(function () use ($bytes) {
            echo $bytes;
        }, $attachment->original_filename, [
            'Content-Type' => $attachment->mime_type,
            'Content-Disposition' => $disposition,
            'Content-Length' => (string) $attachment->size_bytes,
            'X-Content-Type-Options' => 'nosniff',
            'Cache-Control' => 'private, no-store',
        ]);
    }
}
