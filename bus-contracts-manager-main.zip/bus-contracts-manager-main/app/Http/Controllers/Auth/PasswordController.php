<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class PasswordController extends Controller
{
    /**
     * Update the user's password.
     *
     * Wrapped in a DB transaction so the password write + audit row
     * commit or roll back together — same pattern as every other write
     * in the app per CLAUDE.md §10. Raw passwords NEVER appear in the
     * audit payload.
     */
    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validateWithBag('updatePassword', [
            'current_password' => ['required', 'current_password'],
            'password' => ['required', Password::defaults(), 'confirmed'],
        ]);

        $user = $request->user();

        DB::transaction(function () use ($user, $validated, $request) {
            $user->update([
                'password' => Hash::make($validated['password']),
            ]);

            AuditLog::create([
                'user_id' => $user->id,
                'action' => 'user_password_self_changed',
                'entity_type' => 'users',
                'entity_id' => $user->id,
                'old_values' => null,
                'new_values' => null,
                'note' => 'Password updated by account owner',
                'ip_address' => $request->ip(),
            ]);
        });

        return back()->with('status', 'password-updated');
    }
}
