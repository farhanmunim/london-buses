<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use Illuminate\Auth\Events\Verified;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;

class VerifyEmailController extends Controller
{
    /**
     * Mark the authenticated user's email address as verified.
     *
     * Wrapped in a DB transaction so the verification timestamp + audit
     * row commit together. Verification is a meaningful event for the
     * audit trail (the user proved they own the address).
     */
    public function __invoke(EmailVerificationRequest $request): RedirectResponse
    {
        $user = $request->user();

        if ($user->hasVerifiedEmail()) {
            return redirect()->intended(route('dashboard', absolute: false).'?verified=1');
        }

        $verified = false;
        DB::transaction(function () use ($user, $request, &$verified) {
            if (! $user->markEmailAsVerified()) {
                return;
            }
            $verified = true;

            AuditLog::create([
                'user_id' => $user->id,
                'action' => 'user_email_verified',
                'entity_type' => 'users',
                'entity_id' => $user->id,
                'old_values' => ['email_verified_at' => null],
                'new_values' => ['email_verified_at' => $user->email_verified_at?->toIso8601String()],
                'note' => "Email verified for {$user->email}",
                'ip_address' => $request->ip(),
            ]);
        });

        if ($verified) {
            event(new Verified($user));
        }

        return redirect()->intended(route('dashboard', absolute: false).'?verified=1');
    }
}
