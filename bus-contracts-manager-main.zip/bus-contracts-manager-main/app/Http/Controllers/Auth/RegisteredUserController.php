<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;

/**
 * Public registration is permanently disabled in this app — accounts
 * come from Manage Users only (per CLAUDE.md §1). The route bindings
 * for this controller were removed from `routes/auth.php`, but the
 * class is kept as a tombstone so a future contributor doesn't try
 * to re-enable a self-serve flow without thinking it through.
 *
 * If registration ever gets re-enabled, the previous Breeze-style
 * `create()` + `store()` implementation is in git history — but it
 * MUST be paired with: rate limiting, role assignment policy, and
 * an audit log entry for the new account (`user_created`).
 */
class RegisteredUserController extends Controller
{
}
