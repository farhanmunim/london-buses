<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCpiIndexEntryRequest;
use App\Http\Requests\UpdateCpaRateRequest;
use App\Http\Requests\UpdateCpiIndexEntryRequest;
use App\Models\AppSetting;
use App\Models\AuditLog;
use App\Models\CpaRate;
use App\Models\CpiIndexEntry;
use App\Services\CpiRateService;
use App\Services\CpiRowSanitiser;
use App\Support\CsvExporter;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class CpaController extends Controller
{
    /** Refuse to ingest a CSV with more than this many data rows. */
    private const IMPORT_ROW_CAP = 5000;

    /** Per-list cap for the detailed import outcome saved in the audit log. */
    private const AUDIT_DETAIL_LIMIT = 200;

    /** Plausibility window for any P2P/RA rate override, expressed as a fraction. */
    private const RATE_MIN = '-0.5';

    private const RATE_MAX = '0.5';

    public function __construct(
        private readonly CpiRateService $rates,
        private readonly CpiRowSanitiser $sanitiser,
    ) {}

    public function index(Request $request): View
    {
        $filters = $this->resolveFilters($request);

        $allRows = CpaRate::query()
            ->orderByDesc('month')
            ->get();

        $entriesByMonth = CpiIndexEntry::query()
            ->whereIn('month', $allRows->pluck('month'))
            ->get()
            ->keyBy(fn (CpiIndexEntry $e) => Carbon::parse($e->month)->format('Y-m'));

        $rows = $allRows->filter(function ($row) use ($filters, $entriesByMonth) {
            $monthKey = Carbon::parse($row->month)->format('Y-m');
            $entry = $entriesByMonth[$monthKey] ?? null;
            $cpiOverridden = $entry && ! $entry->is_actual;
            $isOverride = $row->is_override || $cpiOverridden;
            $sourceKey = $this->sourceKeyFor($row, $entry);

            return $this->matchesFilters($filters, $monthKey, $isOverride, $sourceKey);
        })->values();

        return view('cpa.index', [
            'rows' => $rows,
            'allRows' => $allRows,
            'entriesByMonth' => $entriesByMonth,
            'filters' => $filters,
        ]);
    }

    public function importTemplate(): StreamedResponse
    {
        return response()->streamDownload(function () {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['month', 'cpi_index'], ',', '"', '');
            fputcsv($out, ['2026-03', '141.0'], ',', '"', '');
            fputcsv($out, ['2026-04', '141.5'], ',', '"', '');
            fclose($out);
        }, 'cpi-import-template.csv', [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function ratesImportTemplate(): StreamedResponse
    {
        return response()->streamDownload(function () {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['month', 'p2p_rate', 'ra_rate'], ',', '"', '');
            fputcsv($out, ['2026-03', '2.7683', '2.8812'], ',', '"', '');
            fputcsv($out, ['2026-04', '2.8208', '2.9283'], ',', '"', '');
            fclose($out);
        }, 'cpa-rates-import-template.csv', [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    /**
     * Manual trigger for the daily ONS refresh pipeline. Runs the same
     * `cpi:refresh` artisan command the scheduler uses, synchronously,
     * so the operator sees pass/fail in the next page render.
     *
     * Manual_override rows are preserved (the command skips them — see
     * CLAUDE.md §2). Manual_import rows are aligned to ONS values like
     * any other revision. CPA rates recalculate downstream automatically
     * for any month whose CPI changed.
     */
    public function refreshOnsData(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        try {
            // Synchronous run. Captures stdout via Artisan::output().
            // Long-running but bounded — typical run ≈ 5-10s on a warm
            // network. The button is admin+ only via route middleware.
            $exitCode = Artisan::call('cpi:refresh');
        } catch (\Throwable $e) {
            report($e);

            return back()->with('updateError', 'ONS refresh failed: '.$e->getMessage());
        }

        if ($exitCode !== 0) {
            $output = trim(Artisan::output());

            return back()->with('updateError', 'ONS refresh exited with code '.$exitCode.($output ? ' — '.$output : ''));
        }

        return back()->with('status', 'ONS refresh complete. Manual overrides preserved; new / revised values stored. Dependent CPA rates recalculated.');
    }

    /**
     * Bulk-apply manual P2P / RA overrides from a CSV. Each row writes to
     * the corresponding cpa_rates row's *_override columns. Months without
     * an existing cpa_rates row are reported as errors (the user must add
     * the underlying CPI value first via the Raw Data import).
     */
    public function importRates(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $request->validate([
            'csv' => AppSetting::templateUploadRules(),
        ]);

        // Per-row outcomes captured for the audit log so reviewers can trace
        // exactly which months received which override and why each rejection
        // happened.
        $applied = [];
        $skipped = [];
        $errors = [];

        DB::transaction(function () use ($request, &$applied, &$skipped, &$errors) {
            $handle = fopen($request->file('csv')->getRealPath(), 'r');
            $rowNumber = 0;
            $seenMonths = [];

            try {
                while (($cells = fgetcsv($handle, 0, ',', '"', '\\')) !== false) {
                    $rowNumber++;

                    if ($rowNumber > self::IMPORT_ROW_CAP) {
                        $errors[] = ['row' => $rowNumber, 'message' => 'File contains more than '.self::IMPORT_ROW_CAP.' rows — refusing to import. Split the file and try again.'];

                        return;
                    }

                    if (count($cells) < 1 || trim((string) $cells[0]) === '') {
                        continue;
                    }

                    $rawMonth = (string) $cells[0];
                    $rawP2p = $this->sanitiser->clean((string) ($cells[1] ?? ''));
                    $rawRa = $this->sanitiser->clean((string) ($cells[2] ?? ''));

                    // Skip the header row — both rate cells will be non-numeric
                    if ($rowNumber === 1 && ! is_numeric($rawP2p) && ! is_numeric($rawRa)) {
                        continue;
                    }

                    try {
                        $this->sanitiser->guardAgainstInjection('p2p_rate', $rawP2p);
                        $this->sanitiser->guardAgainstInjection('ra_rate', $rawRa);
                        $month = $this->sanitiser->sanitise($rawMonth, '100')['month'];
                    } catch (\DomainException $e) {
                        $errors[] = ['row' => $rowNumber, 'message' => $e->getMessage()];

                        continue;
                    }

                    if (isset($seenMonths[$month])) {
                        $errors[] = ['row' => $rowNumber, 'message' => "Duplicate month '{$month}' (already on row {$seenMonths[$month]})."];

                        continue;
                    }
                    $seenMonths[$month] = $rowNumber;

                    $cpaRate = CpaRate::where('month', $month)->first();

                    if (! $cpaRate) {
                        $errors[] = ['row' => $rowNumber, 'message' => "No CPA row for {$month}. Add the CPI value first via the CPI tab."];

                        continue;
                    }

                    try {
                        $p2pOverride = $rawP2p === '' ? null : $this->normaliseRate('p2p_rate', $rawP2p);
                        $raOverride = $rawRa === '' ? null : $this->normaliseRate('ra_rate', $rawRa);
                    } catch (\DomainException $e) {
                        $errors[] = ['row' => $rowNumber, 'message' => $e->getMessage()];

                        continue;
                    }

                    if ($p2pOverride === null && $raOverride === null) {
                        $skipped[] = ['month' => $month, 'reason' => 'both override columns empty'];

                        continue;
                    }

                    $previous = [
                        'p2p_override' => $cpaRate->p2p_override,
                        'ra_override' => $cpaRate->ra_override,
                    ];

                    $cpaRate->fill([
                        'p2p_override' => $p2pOverride,
                        'ra_override' => $raOverride,
                        'is_override' => true,
                        'overridden_by' => $request->user()->id,
                        'overridden_at' => now(),
                    ])->save();

                    $applied[] = [
                        'month' => $month,
                        'previous' => $previous,
                        'new' => ['p2p_override' => $p2pOverride, 'ra_override' => $raOverride],
                    ];
                }
            } finally {
                fclose($handle);
            }

            if (count($applied) > 0 || count($errors) > 0) {
                AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'cpa_rates_imported',
                    'entity_type' => 'cpa_rates',
                    'entity_id' => 0,
                    'old_values' => array_filter([
                        'applied' => $this->capList(array_map(
                            fn ($a) => ['month' => $a['month']] + $a['previous'],
                            $applied
                        )),
                    ]),
                    'new_values' => [
                        'summary' => [
                            'applied' => count($applied),
                            'skipped' => count($skipped),
                            'errors' => count($errors),
                        ],
                        'applied' => $this->capList(array_map(
                            fn ($a) => ['month' => $a['month']] + $a['new'],
                            $applied
                        )),
                        'skipped' => $this->capList($skipped),
                        'errors' => $this->capList($errors),
                    ],
                    'note' => 'Imported CPA overrides from CSV',
                    'ip_address' => $request->ip(),
                ]);
            }
        });

        $parts = [];
        if (count($applied) > 0) {
            $parts[] = count($applied).' overrides applied';
        }
        if (count($skipped) > 0) {
            $parts[] = count($skipped).' skipped (empty)';
        }
        if (count($errors) > 0) {
            $parts[] = count($errors).' errors';
        }

        $message = empty($parts) ? 'No rates imported.' : 'Imported: '.implode(', ', $parts).'.';
        $redirect = redirect(url()->previous())->with('status', $message);

        if (count($errors) > 0) {
            $redirect = $redirect->with(
                'importErrors',
                array_map(fn ($e) => $e['row'] ? "Row {$e['row']}: {$e['message']}" : $e['message'], array_slice($errors, 0, 10))
            );
        }

        return $redirect;
    }

    public function importCsv(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $request->validate([
            // Use the configured upload limits so superadmin changes to
            // template_max_kb / template_extensions in Settings actually
            // apply here (not the hardcoded 2 MB / csv,txt that pre-dated
            // the limits feature).
            'csv' => AppSetting::templateUploadRules(),
            'replace_overrides' => ['nullable', 'boolean'],
        ]);

        $replaceOverrides = $request->boolean('replace_overrides');

        // Per-row outcomes tracked for the audit log so reviewers can see
        // exactly which months landed, which were rejected, and why.
        $imported = [];
        $updated = [];
        $replaced = [];
        $skipped = [];
        $errors = [];

        DB::transaction(function () use ($request, $replaceOverrides, &$imported, &$updated, &$replaced, &$skipped, &$errors) {
            $handle = fopen($request->file('csv')->getRealPath(), 'r');

            if ($handle === false) {
                $errors[] = ['row' => null, 'message' => 'Could not open uploaded file.'];

                return;
            }

            $rowNumber = 0;
            $seenMonths = [];

            try {
                while (($cells = fgetcsv($handle, 0, ',', '"', '\\')) !== false) {
                    $rowNumber++;

                    if ($rowNumber > self::IMPORT_ROW_CAP) {
                        $errors[] = ['row' => $rowNumber, 'message' => 'File contains more than '.self::IMPORT_ROW_CAP.' rows — refusing to import. Split the file and try again.'];

                        return;
                    }

                    if (count($cells) < 2) {
                        continue;
                    }

                    $rawMonth = (string) $cells[0];
                    $rawCpi = (string) $cells[1];

                    // Skip a header row (string in the CPI column on the very first row).
                    if ($rowNumber === 1 && ! is_numeric(trim(CpiRowSanitiser::stripBom($rawCpi)))) {
                        continue;
                    }

                    if (trim($rawMonth) === '' && trim($rawCpi) === '') {
                        continue;
                    }

                    try {
                        $clean = $this->sanitiser->sanitise($rawMonth, $rawCpi);
                    } catch (\DomainException $e) {
                        $errors[] = ['row' => $rowNumber, 'message' => $e->getMessage()];

                        continue;
                    }

                    $month = $clean['month'];
                    $cpi = $clean['cpi_index'];

                    if (isset($seenMonths[$month])) {
                        $errors[] = ['row' => $rowNumber, 'message' => "Duplicate month '{$month}' (already on row {$seenMonths[$month]})."];

                        continue;
                    }
                    $seenMonths[$month] = $rowNumber;

                    $existing = CpiIndexEntry::where('month', $month)->first();

                    // Skip rows with a manual override unless the user opted in
                    // to replacing them.
                    if ($existing && $existing->source === 'manual_override' && ! $replaceOverrides) {
                        $skipped[] = [
                            'month' => $month,
                            'reason' => 'manual override — re-import without "Replace overrides" preserved the existing value',
                            'kept_cpi' => $this->normaliseCpi($existing->cpi_index),
                            'csv_cpi' => $cpi,
                        ];

                        continue;
                    }

                    if ($existing) {
                        $wasOverride = $existing->source === 'manual_override';
                        $oldCpi = $this->normaliseCpi($existing->cpi_index);

                        // Preserve the row's original origin tag — re-importing
                        // shouldn't downgrade an ons_feed row to manual_import.
                        $sourceOriginal = $existing->source_original ?? $this->defaultSourceFor($month);

                        $existing->fill([
                            'cpi_index' => $cpi,
                            'cpi_index_original' => $cpi,
                            'is_actual' => true,
                            'source' => $sourceOriginal,
                            'source_original' => $sourceOriginal,
                            'override_note' => null,
                            'updated_by' => $request->user()->id,
                        ])->save();

                        $bucket = ['month' => $month, 'old_cpi' => $oldCpi, 'new_cpi' => $cpi];

                        if ($wasOverride) {
                            $replaced[] = $bucket;
                        } else {
                            $updated[] = $bucket;
                        }
                    } else {
                        // New row — apply our policy: post-2024 months would
                        // have been picked up by the live ONS feed; earlier
                        // months are catch-up imports.
                        $sourceOriginal = $this->defaultSourceFor($month);

                        CpiIndexEntry::create([
                            'month' => $month,
                            'cpi_index' => $cpi,
                            'cpi_index_original' => $cpi,
                            'is_actual' => true,
                            'source' => $sourceOriginal,
                            'source_original' => $sourceOriginal,
                            'created_by' => $request->user()->id,
                        ]);
                        $imported[] = ['month' => $month, 'cpi' => $cpi];
                    }
                }
            } finally {
                fclose($handle);
            }

            if (count($imported) > 0 || count($updated) > 0 || count($replaced) > 0) {
                $this->rates->recalculateAll();
            }

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'cpi_index_imported',
                'entity_type' => 'cpi_index_entries',
                'entity_id' => 0,
                'old_values' => array_filter([
                    'updated' => $this->capList($this->prevValuesOf($updated, 'old_cpi')),
                    'replaced_overrides' => $this->capList($this->prevValuesOf($replaced, 'old_cpi')),
                ]),
                'new_values' => [
                    'summary' => [
                        'imported' => count($imported),
                        'updated' => count($updated),
                        'replaced_overrides' => count($replaced),
                        'skipped' => count($skipped),
                        'errors' => count($errors),
                    ],
                    'imported' => $this->capList($imported),
                    'updated' => $this->capList($this->newValuesOf($updated, 'new_cpi')),
                    'replaced_overrides' => $this->capList($this->newValuesOf($replaced, 'new_cpi')),
                    'skipped' => $this->capList($skipped),
                    'errors' => $this->capList($errors),
                ],
                'note' => $replaceOverrides ? 'Imported CPI values from CSV (replaced manual overrides)' : 'Imported CPI values from CSV',
                'ip_address' => $request->ip(),
            ]);
        });

        $parts = [];
        if (count($imported) > 0) {
            $parts[] = count($imported).' new';
        }
        if (count($updated) > 0) {
            $parts[] = count($updated).' updated';
        }
        if (count($replaced) > 0) {
            $parts[] = count($replaced).' overrides replaced';
        }
        if (count($skipped) > 0) {
            $parts[] = count($skipped).' skipped (overridden)';
        }
        if (count($errors) > 0) {
            $parts[] = count($errors).' errors';
        }

        $message = empty($parts) ? 'No rows imported.' : 'Imported: '.implode(', ', $parts).'.';

        $redirect = redirect(url()->previous())->with('status', $message);

        if (count($errors) > 0) {
            $redirect = $redirect->with(
                'importErrors',
                array_map(fn ($e) => $e['row'] ? "Row {$e['row']}: {$e['message']}" : $e['message'], array_slice($errors, 0, 10))
            );
        }

        return $redirect;
    }

    /**
     * The default "origin" tag for a month — anything from January 2024 onwards
     * is assumed to come from the live ONS feed, earlier months are historical
     * catch-up data.
     */
    private function defaultSourceFor(string $monthDate): string
    {
        return $monthDate < '2024-01-01' ? 'manual_import' : 'ons_feed';
    }

    public function exportRates(): StreamedResponse
    {
        $rows = CpaRate::query()->orderBy('month')->get();

        $entriesByMonth = CpiIndexEntry::query()
            ->whereIn('month', $rows->pluck('month'))
            ->get()
            ->keyBy(fn (CpiIndexEntry $e) => Carbon::parse($e->month)->format('Y-m'));

        $filename = sprintf('cpa-rates-%s.csv', now()->format('Y-m-d'));

        return response()->streamDownload(function () use ($rows, $entriesByMonth) {
            $out = fopen('php://output', 'w');

            // Match the on-screen columns exactly. Rate values are the
            // *effective* rate (override if set, otherwise the calculated rate).
            fputcsv($out, ['month', 'cpi_index', 'yoy_change', 'p2p_rate', 'ra_rate', 'source']);

            foreach ($rows as $row) {
                $monthKey = Carbon::parse($row->month)->format('Y-m');
                $entry = $entriesByMonth[$monthKey] ?? null;
                $cpiOverridden = $entry && ! $entry->is_actual;
                $isOverride = $row->is_override || $cpiOverridden;
                $source = match (true) {
                    $isOverride => 'manual_override',
                    ($entry?->source ?? 'manual_import') === 'ons_feed' => 'ons_feed',
                    default => 'manual_import',
                };

                // safeRow neutralises CSV / formula injection on cells
                // sourced from operator overrides.
                fputcsv($out, CsvExporter::safeRow([
                    Carbon::parse($row->month)->format('Y-m-d'),
                    number_format((float) $row->cpi_index, 1, '.', ''),
                    $row->yoy_change,
                    $row->p2p_override ?? $row->p2p_rate,
                    $row->ra_override ?? $row->ra_rate,
                    $source,
                ]), ',', '"', '');
            }

            fclose($out);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function raw(Request $request): View
    {
        $filters = $this->resolveFilters($request);

        $allEntries = CpiIndexEntry::query()
            ->orderByDesc('month')
            ->get();

        $entriesById = $allEntries->keyBy(fn (CpiIndexEntry $e) => Carbon::parse($e->month)->format('Y-m'));

        $yoyByMonth = [];
        foreach ($allEntries as $entry) {
            $month = Carbon::parse($entry->month);
            $priorKey = $month->copy()->subMonths(12)->format('Y-m');

            if (! $entriesById->has($priorKey)) {
                $yoyByMonth[$month->format('Y-m')] = null;

                continue;
            }

            $current = number_format((float) $entry->cpi_index, 1, '.', '');
            $prior = number_format((float) $entriesById[$priorKey]->cpi_index, 1, '.', '');
            $diff = bcsub($current, $prior, 10);
            $yoyByMonth[$month->format('Y-m')] = bcadd(bcdiv($diff, $prior, 10), '0', 8);
        }

        $entries = $allEntries->filter(function (CpiIndexEntry $entry) use ($filters) {
            $monthKey = Carbon::parse($entry->month)->format('Y-m');
            $isOverride = ! $entry->is_actual;
            $sourceKey = match (true) {
                $isOverride => 'manual_override',
                ($entry->source ?? 'manual_import') === 'ons_feed' => 'ons_feed',
                default => 'manual_import',
            };

            return $this->matchesFilters($filters, $monthKey, $isOverride, $sourceKey);
        })->values();

        return view('cpa.raw', [
            'entries' => $entries,
            'allEntries' => $allEntries,
            'yoyByMonth' => $yoyByMonth,
            'filters' => $filters,
        ]);
    }

    /**
     * @return array{overrides_only: bool, sources: array<int, string>, from: ?string, to: ?string}
     */
    private function resolveFilters(Request $request): array
    {
        $overridesOnly = $request->boolean('overrides');

        $rawSources = $request->query('sources', []);
        if (is_string($rawSources)) {
            $rawSources = $rawSources === '' ? [] : explode(',', $rawSources);
        }
        $sources = collect((array) $rawSources)
            ->map(fn ($s) => trim((string) $s))
            ->filter(fn ($s) => in_array($s, ['ons_feed', 'manual_import', 'manual_override'], true))
            ->unique()
            ->values()
            ->all();

        $from = $this->normaliseFilterMonth($request->query('from'));
        $to = $this->normaliseFilterMonth($request->query('to'));

        return [
            'overrides_only' => $overridesOnly,
            'sources' => $sources,
            'from' => $from,
            'to' => $to,
        ];
    }

    private function normaliseFilterMonth(?string $value): ?string
    {
        if ($value === null || trim($value) === '') {
            return null;
        }

        if (! preg_match('/^\d{4}-\d{2}$/', $value)) {
            return null;
        }

        return $value;
    }

    /**
     * @param  array{overrides_only: bool, sources: array<int, string>, from: ?string, to: ?string}  $filters
     */
    private function matchesFilters(array $filters, string $monthKey, bool $isOverride, string $sourceKey): bool
    {
        if ($filters['overrides_only'] && ! $isOverride) {
            return false;
        }

        if (! empty($filters['sources']) && ! in_array($sourceKey, $filters['sources'], true)) {
            return false;
        }

        if ($filters['from'] !== null && $monthKey < $filters['from']) {
            return false;
        }

        if ($filters['to'] !== null && $monthKey > $filters['to']) {
            return false;
        }

        return true;
    }

    private function sourceKeyFor(CpaRate $row, ?CpiIndexEntry $entry): string
    {
        $cpiOverridden = $entry && ! $entry->is_actual;
        $isOverride = $row->is_override || $cpiOverridden;

        return match (true) {
            $isOverride => 'manual_override',
            ($entry?->source ?? 'manual_import') === 'ons_feed' => 'ons_feed',
            default => 'manual_import',
        };
    }

    public function storeIndexEntry(StoreCpiIndexEntryRequest $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $monthDate = $request->monthDate();
        $cpi = $request->validated('cpi_index');

        DB::transaction(function () use ($request, $monthDate, $cpi) {
            $entry = CpiIndexEntry::create([
                'month' => $monthDate,
                'cpi_index' => $cpi,
                'cpi_index_original' => $cpi,
                'is_actual' => true,
                'source' => 'manual_import',
                'source_original' => 'manual_import',
                'created_by' => $request->user()->id,
            ]);

            $this->upsertRateFor(Carbon::parse($monthDate));
            $this->recalcDownstreamFrom(Carbon::parse($monthDate));

            $this->writeAudit(
                userId: $request->user()->id,
                action: 'cpi_index_added',
                entity: $entry,
                newValues: ['cpi_index' => $cpi, 'month' => $monthDate],
                ipAddress: $request->ip(),
            );
        });

        return redirect(url()->previous())->with('status', 'CPI value added.');
    }

    public function updateRate(UpdateCpaRateRequest $request, CpaRate $cpaRate): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $month = Carbon::parse($cpaRate->month);
        $entry = CpiIndexEntry::where('month', $month->toDateString())->firstOrFail();

        $newCpi = $request->validated('cpi_index');
        $p2pOverride = $request->validated('p2p_override');
        $raOverride = $request->validated('ra_override');
        $note = $request->validated('override_note');

        DB::transaction(function () use ($request, $cpaRate, $entry, $month, $newCpi, $p2pOverride, $raOverride, $note) {
            $cpiChanged = $this->normaliseCpi($newCpi) !== $this->normaliseCpi($entry->cpi_index);

            if ($cpiChanged) {
                $oldCpi = $this->normaliseCpi($entry->cpi_index);
                $entry->fill([
                    'cpi_index' => $newCpi,
                    'is_actual' => false,
                    'source' => 'manual_override',
                    'override_note' => $note,
                    'updated_by' => $request->user()->id,
                ])->save();

                $this->upsertRateFor($month);
                $this->recalcDownstreamFrom($month);
                $cpaRate->refresh();

                $this->writeAudit(
                    userId: $request->user()->id,
                    action: 'cpi_index_updated',
                    entity: $entry,
                    oldValues: ['cpi_index' => $oldCpi],
                    newValues: ['cpi_index' => $this->normaliseCpi($newCpi)],
                    note: $note,
                    ipAddress: $request->ip(),
                );
            }

            $oldP2pOverride = $cpaRate->p2p_override;
            $oldRaOverride = $cpaRate->ra_override;

            $newP2pOverride = $this->normaliseOverride($p2pOverride);
            $newRaOverride = $this->normaliseOverride($raOverride);

            $overrideChanged = $oldP2pOverride !== $newP2pOverride || $oldRaOverride !== $newRaOverride;

            if ($overrideChanged) {
                $hasOverride = $newP2pOverride !== null || $newRaOverride !== null;

                $cpaRate->fill([
                    'p2p_override' => $newP2pOverride,
                    'ra_override' => $newRaOverride,
                    'override_note' => $note,
                    'is_override' => $hasOverride,
                    'overridden_by' => $hasOverride ? $request->user()->id : null,
                    'overridden_at' => $hasOverride ? now() : null,
                ])->save();

                $action = $hasOverride ? 'cpa_rate_overridden' : 'cpa_override_removed';

                $this->writeAudit(
                    userId: $request->user()->id,
                    action: $action,
                    entity: $cpaRate,
                    oldValues: [
                        'p2p_override' => $oldP2pOverride,
                        'ra_override' => $oldRaOverride,
                    ],
                    newValues: [
                        'p2p_override' => $newP2pOverride,
                        'ra_override' => $newRaOverride,
                    ],
                    note: $note,
                    ipAddress: $request->ip(),
                );
            }
        });

        return redirect()->route('indices.cpa')->with('status', 'CPA updated.');
    }

    /**
     * Per-row reset on the CPI tab. Restores a single overridden CPI entry
     * back to its original ONS / imported value and recalculates the
     * dependent CPA row + downstream RA window.
     */
    public function resetCpiEntry(Request $request, CpiIndexEntry $cpiIndexEntry): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        if ($cpiIndexEntry->cpi_index_original === null) {
            return redirect(url()->previous())
                ->with('updateError', 'No original ONS value recorded for this entry — nothing to reset to.');
        }

        $oldCpi = $this->normaliseCpi($cpiIndexEntry->cpi_index);
        $originalCpi = $this->normaliseCpi($cpiIndexEntry->cpi_index_original);

        if ($oldCpi === $originalCpi && $cpiIndexEntry->is_actual) {
            return redirect(url()->previous())->with('status', 'Already on the ONS value — nothing to reset.');
        }

        $month = Carbon::parse($cpiIndexEntry->month);

        DB::transaction(function () use ($request, $cpiIndexEntry, $oldCpi, $originalCpi, $month) {
            $cpiIndexEntry->fill([
                'cpi_index' => $originalCpi,
                'is_actual' => true,
                'source' => $cpiIndexEntry->source_original ?? 'manual_import',
                'override_note' => null,
                'updated_by' => $request->user()->id,
            ])->save();

            $this->upsertRateFor($month);
            $this->recalcDownstreamFrom($month);

            $this->writeAudit(
                userId: $request->user()->id,
                action: 'cpi_index_reset',
                entity: $cpiIndexEntry,
                oldValues: ['cpi_index' => $oldCpi],
                newValues: ['cpi_index' => $originalCpi],
                note: 'Reset to ONS value',
                ipAddress: $request->ip(),
            );
        });

        return redirect()->route('indices.cpi')->with('status', 'Reset to ONS value.');
    }

    public function resetRate(Request $request, CpaRate $cpaRate): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $month = Carbon::parse($cpaRate->month);
        $entry = CpiIndexEntry::where('month', $month->toDateString())->firstOrFail();

        DB::transaction(function () use ($request, $cpaRate, $entry, $month) {
            $changes = [];

            if ($entry->cpi_index_original !== null && $this->normaliseCpi($entry->cpi_index) !== $this->normaliseCpi($entry->cpi_index_original)) {
                $oldCpi = $this->normaliseCpi($entry->cpi_index);
                $entry->fill([
                    'cpi_index' => $this->normaliseCpi($entry->cpi_index_original),
                    'is_actual' => true,
                    'source' => $entry->source_original ?? 'manual_import',
                    'override_note' => null,
                    'updated_by' => $request->user()->id,
                ])->save();

                $changes['cpi_index'] = ['from' => $oldCpi, 'to' => $this->normaliseCpi($entry->cpi_index)];
            }

            $hadOverride = $cpaRate->p2p_override !== null || $cpaRate->ra_override !== null;

            if ($hadOverride) {
                $changes['p2p_override'] = ['from' => $cpaRate->p2p_override, 'to' => null];
                $changes['ra_override'] = ['from' => $cpaRate->ra_override, 'to' => null];

                $cpaRate->fill([
                    'p2p_override' => null,
                    'ra_override' => null,
                    'override_note' => null,
                    'is_override' => false,
                    'overridden_by' => null,
                    'overridden_at' => null,
                ])->save();
            }

            $this->upsertRateFor($month);
            $this->recalcDownstreamFrom($month);

            if (! empty($changes)) {
                $this->writeAudit(
                    userId: $request->user()->id,
                    action: 'cpa_rate_reset',
                    entity: $cpaRate,
                    oldValues: array_map(fn ($c) => $c['from'], $changes),
                    newValues: array_map(fn ($c) => $c['to'], $changes),
                    note: 'Reset to ONS values',
                    ipAddress: $request->ip(),
                );
            }
        });

        return redirect()->route('indices.cpa')->with('status', 'Reset to ONS values.');
    }

    public function destroyIndexEntry(Request $request, CpiIndexEntry $cpiIndexEntry): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        // ONS-feed values are authoritative — they can be edited or reset, but
        // not deleted. Anything else (manual_import / manual_override that
        // started life as a manual_import) is removable.
        if (($cpiIndexEntry->source_original ?? 'manual_import') === 'ons_feed') {
            return redirect(url()->previous())
                ->with('importErrors', ['ONS-feed entries cannot be deleted — edit or reset them instead.']);
        }

        $month = Carbon::parse($cpiIndexEntry->month);
        $monthLabel = $month->format('F Y');
        $oldValues = [
            'month' => $cpiIndexEntry->month,
            'cpi_index' => $this->normaliseCpi($cpiIndexEntry->cpi_index),
            'source' => $cpiIndexEntry->source,
        ];

        DB::transaction(function () use ($request, $cpiIndexEntry, $month, $oldValues) {
            // Snapshot the entity reference for audit before removal.
            $entityType = $cpiIndexEntry->getTable();
            $entityId = $cpiIndexEntry->getKey();

            // Drop the derived cpa_rates row first; without the underlying CPI
            // it can't be recomputed anyway.
            CpaRate::where('month', $cpiIndexEntry->month)->delete();
            $cpiIndexEntry->delete();

            // Recalculate any downstream RA values whose 12-month window
            // included the now-removed month.
            $this->recalcDownstreamFrom($month);

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'cpi_index_deleted',
                'entity_type' => $entityType,
                'entity_id' => $entityId,
                'old_values' => $oldValues,
                'new_values' => null,
                'note' => 'Manually deleted CPI value',
                'ip_address' => $request->ip(),
            ]);
        });

        return redirect(url()->previous())->with('status', "Deleted {$monthLabel}.");
    }

    /**
     * Restore every CPI manual override back to its original feed/import value.
     * Touches CPA only via the recalc afterwards (linked: when CPI changes,
     * the derived CPA rates pick up the restored values automatically).
     */
    public function clearCpiOverrides(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $reset = 0;

        DB::transaction(function () use ($request, &$reset) {
            $overriddenEntries = CpiIndexEntry::query()
                ->where('source', 'manual_override')
                ->whereNotNull('cpi_index_original')
                ->get();

            foreach ($overriddenEntries as $entry) {
                if ($this->normaliseCpi($entry->cpi_index) === $this->normaliseCpi($entry->cpi_index_original)) {
                    continue;
                }

                $entry->fill([
                    'cpi_index' => $this->normaliseCpi($entry->cpi_index_original),
                    'is_actual' => true,
                    'source' => $entry->source_original ?? 'manual_import',
                    'override_note' => null,
                    'updated_by' => $request->user()->id,
                ])->save();
                $reset++;
            }

            if ($reset > 0) {
                $this->rates->recalculateAll();

                AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'cpi_overrides_cleared',
                    'entity_type' => 'cpi_index_entries',
                    'entity_id' => 0,
                    'new_values' => ['cpi_overrides_reset' => $reset],
                    'note' => 'Reset all CPI overrides to ONS values',
                    'ip_address' => $request->ip(),
                ]);
            }
        });

        $message = $reset > 0 ? "Cleared {$reset} CPI override".($reset === 1 ? '' : 's').'.' : 'No CPI overrides to clear.';

        return redirect()->route('indices.cpi')->with('status', $message);
    }

    /**
     * Delete only CPI rows that originated from a bulk import or a manual
     * +Add month entry — i.e. anything whose source_original is
     * 'manual_import'. ONS-feed rows are preserved. Dependent cpa_rates rows
     * for the deleted months are cascaded so we don't leave derivations
     * pointing at vanished CPI months.
     */
    public function clearCpiImports(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $cpiCount = 0;
        $cpaCount = 0;

        DB::transaction(function () use ($request, &$cpiCount, &$cpaCount) {
            $deletableMonths = CpiIndexEntry::query()
                ->where('source_original', 'manual_import')
                ->pluck('month');

            $cpiCount = $deletableMonths->count();

            if ($cpiCount === 0) {
                return;
            }

            $cpaCount = CpaRate::whereIn('month', $deletableMonths)->count();
            CpaRate::whereIn('month', $deletableMonths)->delete();
            CpiIndexEntry::whereIn('month', $deletableMonths)->delete();

            AuditLog::create([
                'user_id' => $request->user()->id,
                'action' => 'cpi_imports_cleared',
                'entity_type' => 'cpi_index_entries',
                'entity_id' => 0,
                'new_values' => ['cpi_rows_deleted' => $cpiCount, 'cpa_rows_deleted' => $cpaCount],
                'note' => 'Deleted manually-added CPI values. ONS data kept.',
                'ip_address' => $request->ip(),
            ]);
        });

        $message = $cpiCount > 0
            ? "Deleted {$cpiCount} bulk-imported CPI row".($cpiCount === 1 ? '' : 's').' (and '.$cpaCount.' dependent CPA row'.($cpaCount === 1 ? '' : 's').'). ONS-feed rows preserved.'
            : 'No bulk-imported CPI rows to delete.';

        return redirect()->route('indices.cpi')->with('status', $message);
    }

    /**
     * Reset every override that affects what the CPA tab shows: P2P / RA
     * overrides on cpa_rates AND any CPI overrides on the underlying
     * cpi_index_entries (since CPA derivations cascade from CPI). Recalcs
     * the derived rates afterwards so the table reflects the restored CPI.
     */
    public function clearCpaOverrides(Request $request): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $rateReset = 0;
        $cpiReset = 0;

        DB::transaction(function () use ($request, &$rateReset, &$cpiReset) {
            // P2P / RA overrides on cpa_rates
            $overriddenRates = CpaRate::query()
                ->where(fn ($q) => $q
                    ->whereNotNull('p2p_override')
                    ->orWhereNotNull('ra_override')
                    ->orWhere('is_override', true))
                ->get();

            foreach ($overriddenRates as $rate) {
                $rate->fill([
                    'p2p_override' => null,
                    'ra_override' => null,
                    'override_note' => null,
                    'is_override' => false,
                    'overridden_by' => null,
                    'overridden_at' => null,
                ])->save();
                $rateReset++;
            }

            // CPI overrides on the underlying cpi_index_entries — these
            // propagate through to CPA derivations, so a "reset to ONS" on
            // the CPA view must also unwind them.
            $overriddenEntries = CpiIndexEntry::query()
                ->where('source', 'manual_override')
                ->whereNotNull('cpi_index_original')
                ->get();

            foreach ($overriddenEntries as $entry) {
                if ($this->normaliseCpi($entry->cpi_index) === $this->normaliseCpi($entry->cpi_index_original)) {
                    continue;
                }

                $entry->fill([
                    'cpi_index' => $this->normaliseCpi($entry->cpi_index_original),
                    'is_actual' => true,
                    'source' => $entry->source_original ?? 'manual_import',
                    'override_note' => null,
                    'updated_by' => $request->user()->id,
                ])->save();
                $cpiReset++;
            }

            // Recalculate derived rates if any CPI changed.
            if ($cpiReset > 0) {
                $this->rates->recalculateAll();
            }

            if ($rateReset > 0 || $cpiReset > 0) {
                AuditLog::create([
                    'user_id' => $request->user()->id,
                    'action' => 'cpa_overrides_cleared',
                    'entity_type' => 'cpa_rates',
                    'entity_id' => 0,
                    'new_values' => [
                        'rate_overrides_reset' => $rateReset,
                        'cpi_overrides_reset' => $cpiReset,
                    ],
                    'note' => 'Reset every override on the CPA view (P2P/RA + linked CPI)',
                    'ip_address' => $request->ip(),
                ]);
            }
        });

        $total = $rateReset + $cpiReset;
        $message = $total > 0
            ? "Reset {$rateReset} CPA P2P/RA override".($rateReset === 1 ? '' : 's').' and '.$cpiReset.' linked CPI override'.($cpiReset === 1 ? '' : 's').'.'
            : 'No overrides to reset.';

        return redirect()->route('indices.cpa')->with('status', $message);
    }

    public function updateIndexEntry(UpdateCpiIndexEntryRequest $request, CpiIndexEntry $cpiIndexEntry): RedirectResponse
    {
        abort_unless($request->user()?->canWrite(), 403);

        $newCpi = $request->validated('cpi_index');
        $note = $request->validated('override_note');
        $newMonthDate = $request->monthDate();
        $isOnsFeed = ($cpiIndexEntry->source_original ?? 'manual_import') === 'ons_feed';

        // Reject any attempt to move a month coming from the ONS feed.
        if ($newMonthDate && $isOnsFeed && $newMonthDate !== $cpiIndexEntry->month) {
            return redirect(url()->previous())
                ->with('updateError', 'ONS-feed entries cannot be moved to a different month.');
        }

        $oldMonthDate = $cpiIndexEntry->month;
        $monthChanged = $newMonthDate && $newMonthDate !== $oldMonthDate;

        // Uniqueness guard for a month change.
        if ($monthChanged) {
            $clash = CpiIndexEntry::where('month', $newMonthDate)
                ->where('id', '!=', $cpiIndexEntry->id)
                ->exists();

            if ($clash) {
                return redirect(url()->previous())
                    ->with('updateError', 'An entry for this month already exists. Choose a different month or delete the existing one first.');
            }
        }

        DB::transaction(function () use ($request, $cpiIndexEntry, $newCpi, $note, $newMonthDate, $oldMonthDate, $monthChanged) {
            $oldCpi = $this->normaliseCpi($cpiIndexEntry->cpi_index);
            $newCpiNorm = $this->normaliseCpi($newCpi);

            if ($oldCpi === $newCpiNorm && ! $monthChanged) {
                return;
            }

            $changes = [];

            if ($monthChanged) {
                // Drop the cpa_rate keyed to the old month — it'll be rebuilt
                // for the new month below.
                CpaRate::where('month', $oldMonthDate)->delete();
                $cpiIndexEntry->month = $newMonthDate;
                $changes['month'] = ['from' => $oldMonthDate, 'to' => $newMonthDate];
            }

            if ($oldCpi !== $newCpiNorm) {
                $cpiIndexEntry->cpi_index = $newCpi;
                $cpiIndexEntry->is_actual = false;
                $cpiIndexEntry->source = 'manual_override';
                $changes['cpi_index'] = ['from' => $oldCpi, 'to' => $newCpiNorm];
            }

            $cpiIndexEntry->override_note = $note;
            $cpiIndexEntry->updated_by = $request->user()->id;
            $cpiIndexEntry->save();

            // Rebuild rates: include both old and new windows so any RA values
            // that referenced either month get refreshed.
            $this->upsertRateFor(Carbon::parse($cpiIndexEntry->month));
            $this->recalcDownstreamFrom(Carbon::parse($cpiIndexEntry->month));
            if ($monthChanged) {
                $this->recalcDownstreamFrom(Carbon::parse($oldMonthDate));
            }

            $this->writeAudit(
                userId: $request->user()->id,
                action: 'cpi_index_updated',
                entity: $cpiIndexEntry,
                oldValues: array_map(fn ($c) => $c['from'], $changes),
                newValues: array_map(fn ($c) => $c['to'], $changes),
                note: $note,
                ipAddress: $request->ip(),
            );
        });

        return redirect(url()->previous())->with('status', 'CPI updated.');
    }

    private function upsertRateFor(Carbon $month): void
    {
        try {
            $result = $this->rates->calculateRatesForMonth($month);
        } catch (\RuntimeException) {
            return;
        }

        $existing = CpaRate::where('month', $month->copy()->startOfMonth()->toDateString())->first();

        CpaRate::updateOrCreate(
            ['month' => $month->copy()->startOfMonth()->toDateString()],
            [
                'p2p_rate' => $result['p2p_rate'],
                'ra_rate' => $result['ra_rate'],
                'yoy_change' => $result['yoy_change'],
                'cpi_index' => $result['cpi_index'],
                'cpi_index_prior_year' => $result['cpi_index_prior_year'],
                'is_override' => $existing?->is_override ?? false,
                'p2p_override' => $existing?->p2p_override,
                'ra_override' => $existing?->ra_override,
                'override_note' => $existing?->override_note,
                'overridden_by' => $existing?->overridden_by,
                'overridden_at' => $existing?->overridden_at,
            ]
        );
    }

    private function recalcDownstreamFrom(Carbon $month): void
    {
        $start = $month->copy()->startOfMonth()->addMonth();
        $end = $month->copy()->startOfMonth()->addMonths(12);

        $affected = CpiIndexEntry::query()
            ->whereBetween('month', [$start->toDateString(), $end->toDateString()])
            ->orderBy('month')
            ->pluck('month');

        foreach ($affected as $monthValue) {
            $this->upsertRateFor(Carbon::parse($monthValue));
        }
    }

    private function writeAudit(
        int $userId,
        string $action,
        $entity,
        ?array $oldValues = null,
        ?array $newValues = null,
        ?string $note = null,
        ?string $ipAddress = null,
    ): void {
        AuditLog::create([
            'user_id' => $userId,
            'action' => $action,
            'entity_type' => $entity->getTable(),
            'entity_id' => $entity->getKey(),
            'old_values' => $oldValues,
            'new_values' => $newValues,
            'note' => $note,
            'ip_address' => $ipAddress,
        ]);
    }

    private function normaliseCpi(string|float $value): string
    {
        return number_format((float) $value, 1, '.', '');
    }

    /**
     * Cap a per-row outcome list at AUDIT_DETAIL_LIMIT entries so a 5000-row
     * import doesn't bloat the audit_logs JSON column. When truncation happens
     * we still record the original count via a sentinel marker.
     *
     * @param  array<int, array<string, mixed>>  $items
     * @return array<int, array<string, mixed>>
     */
    private function capList(array $items): array
    {
        $limit = self::AUDIT_DETAIL_LIMIT;

        if (count($items) <= $limit) {
            return $items;
        }

        $kept = array_slice($items, 0, $limit);
        $kept[] = ['_truncated' => true, '_total' => count($items), '_shown' => $limit];

        return $kept;
    }

    /**
     * Project per-row outcomes down to the {month, cpi} shape used for the
     * audit log's old_values "before" snapshot.
     *
     * @param  array<int, array<string, mixed>>  $rows
     * @return array<int, array{month: string, cpi: string}>
     */
    private function prevValuesOf(array $rows, string $oldKey): array
    {
        return array_map(fn ($r) => ['month' => $r['month'], 'cpi' => $r[$oldKey]], $rows);
    }

    /**
     * Mirror of {@see prevValuesOf} for the "after" snapshot.
     *
     * @param  array<int, array<string, mixed>>  $rows
     * @return array<int, array{month: string, cpi: string}>
     */
    private function newValuesOf(array $rows, string $newKey): array
    {
        return array_map(fn ($r) => ['month' => $r['month'], 'cpi' => $r[$newKey]], $rows);
    }

    /**
     * Normalise an override string entry to an 8-decimal-place rate.
     * Accepts "0.028022", "2.8022", "2.8022%". Values containing % or
     * greater than or equal to 1 are treated as a percentage.
     */
    private function normaliseOverride(?string $raw): ?string
    {
        if ($raw === null || trim($raw) === '') {
            return null;
        }

        $value = trim($raw);
        $isPercent = str_ends_with($value, '%');
        $value = rtrim($value, '%');

        if ($isPercent || bccomp($value, '1', 10) >= 0) {
            $value = bcdiv($value, '100', 10);
        }

        return bcadd($value, '0', 8);
    }

    /**
     * Normalise + range-check a rate cell from the CSV import. Throws if the
     * value isn't numeric or falls outside the plausibility window. Wraps
     * normaliseOverride so callers don't need to validate themselves.
     */
    private function normaliseRate(string $field, string $raw): ?string
    {
        $candidate = rtrim(str_replace([',', ' '], '', $raw), '%');

        if (! is_numeric($candidate)) {
            throw new \DomainException("{$field} '{$raw}' is not numeric.");
        }

        $rate = $this->normaliseOverride($raw);

        if ($rate === null) {
            return null;
        }

        if (bccomp($rate, self::RATE_MIN, 8) < 0 || bccomp($rate, self::RATE_MAX, 8) > 0) {
            throw new \DomainException("{$field} '{$raw}' is outside the plausible range (±50%).");
        }

        return $rate;
    }
}
