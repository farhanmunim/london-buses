<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Gates admin-only sections (Audit log, Users, Settings). Both `admin`
 * and `superadmin` pass through; `user` → 403 with a clear message.
 * Stricter controls inside these sections (purging the audit log,
 * promoting to superadmin, viewing login logs) are enforced separately
 * via the matching User helpers.
 */
class RequireAdminRole
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user === null || ! $user->isAdmin()) {
            abort(403, 'This area is for admins and superadmins only.');
        }

        return $next($request);
    }
}
