<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Gates routes that mutate state (POST / PATCH / DELETE on contracts,
 * indices, etc.) so the read-only `user` role can browse but never write.
 * Superadmin and admin both pass through; user → 403.
 *
 * Per-action restrictions that are stricter than "needs write access" —
 * audit-log purge, promoting to superadmin, viewing login logs — are
 * enforced at the controller level using the matching User helpers.
 */
class RequireWriteAccess
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user === null || ! $user->canWrite()) {
            abort(403, 'Your account is read-only — contact a superadmin or admin to make changes.');
        }

        return $next($request);
    }
}
