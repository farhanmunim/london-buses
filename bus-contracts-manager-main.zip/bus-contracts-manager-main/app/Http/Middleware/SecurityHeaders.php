<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Sets the standard browser security headers on every response.
 *
 * Tightens the boundary against clickjacking, MIME sniffing, referrer
 * leakage and the broader injection class via CSP.
 *
 * IMPORTANT — `'unsafe-eval'` is required in script-src because
 * Alpine.js v3 evaluates every directive (`x-show`, `x-data`,
 * `x-text`, `x-bind`, ...) via the `Function()` constructor, which
 * CSP governs under `'unsafe-eval'`. Removing it silently kills
 * every Alpine binding in the app — date pickers, dialogs,
 * dropdowns, and the dupe-warning panel all stop reacting to state.
 * Tightening to a strict CSP requires switching to Alpine's CSP
 * build (npm package `@alpinejs/csp`) and rewriting expressions as
 * named methods, which is a much bigger change.
 *
 * HSTS is only emitted on real HTTPS responses so local Herd over
 * https://*.test (with a self-signed cert) doesn't lock the operator
 * out of any plain-HTTP fallbacks.
 */
class SecurityHeaders
{
    public function handle(Request $request, Closure $next): Response
    {
        /** @var Response $response */
        $response = $next($request);

        $headers = $response->headers;

        // Core hardening — universally safe defaults.
        $headers->set('X-Content-Type-Options', 'nosniff');
        $headers->set('X-Frame-Options', 'DENY');
        $headers->set('Referrer-Policy', 'strict-origin-when-cross-origin');
        $headers->set('X-Permitted-Cross-Domain-Policies', 'none');

        // Lock down sensitive browser APIs that the app does not use.
        $headers->set('Permissions-Policy', implode(', ', [
            'accelerometer=()',
            'autoplay=()',
            'camera=()',
            'cross-origin-isolated=()',
            'display-capture=()',
            'fullscreen=(self)',
            'geolocation=()',
            'gyroscope=()',
            'magnetometer=()',
            'microphone=()',
            'midi=()',
            'payment=()',
            'usb=()',
            'xr-spatial-tracking=()',
        ]));

        // CSP — pragmatic baseline for an Alpine.js + Vite + Turnstile
        // stack. `'unsafe-eval'` is mandatory for Alpine; `'unsafe-inline'`
        // covers the small theme-init script in the layouts and inline
        // style attributes scattered through some views. Tightening
        // both is a future polish item.
        $headers->set('Content-Security-Policy', implode('; ', [
            "default-src 'self'",
            "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://challenges.cloudflare.com",
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
            'img-src \'self\' data: blob:',
            "font-src 'self' data: https://fonts.gstatic.com",
            'frame-src https://challenges.cloudflare.com',
            "connect-src 'self'",
            "form-action 'self'",
            "base-uri 'self'",
            "frame-ancestors 'none'",
            "object-src 'none'",
            'upgrade-insecure-requests',
        ]));

        // HSTS — only on real HTTPS. Skip when the request itself was
        // plain HTTP (avoids accidentally pinning a misconfigured
        // local cert) or when the env explicitly opts out via
        // APP_HSTS_DISABLED=true.
        if ($request->isSecure() && ! filter_var(env('APP_HSTS_DISABLED'), FILTER_VALIDATE_BOOL)) {
            $headers->set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
        }

        return $response;
    }
}
