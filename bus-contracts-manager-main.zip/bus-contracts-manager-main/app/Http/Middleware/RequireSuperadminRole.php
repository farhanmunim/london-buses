<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Strictest gate — only the singleton superadmin passes. Used for the
 * audit-log purge and any future destructive cross-cutting actions.
 */
class RequireSuperadminRole
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user === null || ! $user->isSuperadmin()) {
            abort(403, 'This action is reserved for the superadmin.');
        }

        return $next($request);
    }
}
