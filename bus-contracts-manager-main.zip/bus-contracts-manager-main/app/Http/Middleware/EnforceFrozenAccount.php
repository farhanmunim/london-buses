<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/**
 * If the authenticated user has been frozen since their session was issued,
 * tear down the session and bounce them back to the login page with a clear
 * message. The freeze flag is checked on every request so an account can
 * be locked out in real time.
 */
class EnforceFrozenAccount
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user && $user->isFrozen()) {
            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('login')
                ->withErrors(['email' => 'Your account has been frozen. Contact an administrator to restore access.']);
        }

        return $next($request);
    }
}
