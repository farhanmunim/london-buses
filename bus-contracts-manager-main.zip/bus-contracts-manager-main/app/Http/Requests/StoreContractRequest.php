<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreContractRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'company' => ['required', 'string', 'max:8'],
            'depot' => ['required', 'string', 'max:8'],
            'route' => ['required', 'string', 'max:32'],
            'contract_number' => ['required', 'string', 'max:32'],
            'tender_date' => ['required', 'date'],
            'start_date' => ['required', 'date'],
            'end_date' => ['required', 'date', 'after_or_equal:start_date'],
            'contract_value' => ['required', 'numeric', 'min:0'],
            'contracted_miles' => ['required', 'numeric', 'min:0', 'max:10000000'],
            // Optional operational fields — same set the Edit dialog and
            // CSV import accept. Tender award is a free-text label (e.g.
            // "Option 1", "Option 4 EV"), not a date.
            'tender_award_note' => ['nullable', 'string', 'max:500'],
            'pvr' => ['nullable', 'integer', 'min:0', 'max:9999'],
            'tvr' => ['nullable', 'integer', 'min:0', 'max:9999'],
            'propulsion' => ['nullable', Rule::in(['Diesel', 'Hybrid', 'Electric', 'Mix - Hybrid/EV'])],
            'decks' => ['nullable', Rule::in(['SD', 'DD', 'SD/DD'])],
        ];
    }

    public function messages(): array
    {
        return [
            'end_date.after_or_equal' => 'The end date must be on or after the start date.',
        ];
    }
}
