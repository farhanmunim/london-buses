<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreCpiIndexEntryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'month' => [
                'required',
                'date_format:Y-m',
                Rule::unique('cpi_index_entries', 'month')->where(
                    fn ($q) => $q->where('month', $this->monthDate())
                ),
            ],
            'cpi_index' => ['required', 'regex:/^\d+\.\d$/'],
        ];
    }

    public function messages(): array
    {
        return [
            'cpi_index.regex' => 'CPI index must be a number with exactly one decimal place (e.g. 141.0).',
            'month.unique' => 'An entry for this month already exists. Edit the existing one instead.',
        ];
    }

    public function monthDate(): string
    {
        return $this->input('month').'-01';
    }
}
