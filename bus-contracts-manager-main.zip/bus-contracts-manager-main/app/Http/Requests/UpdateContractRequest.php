<?php

namespace App\Http\Requests;

use App\Support\AttachmentUpload;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateContractRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * On update, the user must classify the change as either an
     * `override` (correction of bad data — replaces the row in place) or a
     * `variation` (legitimate contract amendment — same row, but the audit
     * trail records this as a structured change rather than a fix). Both
     * paths persist the new values; the distinction only affects the audit
     * log so a future reviewer can tell the two apart.
     */
    public function rules(): array
    {
        return [
            'company' => ['required', 'string', 'max:8'],
            'depot' => ['required', 'string', 'max:8'],
            'route' => ['required', 'string', 'max:32'],
            'contract_number' => ['required', 'string', 'max:32'],
            'tender_date' => ['required', 'date'],
            'start_date' => ['required', 'date'],
            'end_date' => ['required', 'date', 'after_or_equal:start_date'],
            'contract_value' => ['required', 'numeric', 'min:0'],
            'contracted_miles' => ['required', 'numeric', 'min:0', 'max:10000000'],
            // Operational fields — all optional. Edited inline in the same
            // dialog so the user has one place to fix any non-computed,
            // non-flagged column.
            'tender_award_note' => ['nullable', 'string', 'max:500'],
            'pvr' => ['nullable', 'integer', 'min:0', 'max:9999'],
            'tvr' => ['nullable', 'integer', 'min:0', 'max:9999'],
            'propulsion' => ['nullable', Rule::in(['Diesel', 'Hybrid', 'Electric', 'Mix - Hybrid/EV'])],
            'decks' => ['nullable', Rule::in(['SD', 'DD', 'SD/DD'])],
            'change_kind' => ['required', Rule::in(['confirmation', 'override', 'variation'])],
            'change_note' => ['nullable', 'string', 'max:255'],
            'dupe_action' => AttachmentUpload::dupeActionRule(),
        ] + AttachmentUpload::rules();
    }

    public function messages(): array
    {
        return [
            'end_date.after_or_equal' => 'The end date must be on or after the start date.',
            'change_kind.required' => 'You must classify the change as a confirmation, an override (correcting bad data) or a variation (a contract amendment).',
            'change_kind.in' => 'Change kind must be one of: confirmation, override, or variation.',
        ];
    }
}
