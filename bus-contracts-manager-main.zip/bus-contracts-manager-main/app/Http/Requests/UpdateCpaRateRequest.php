<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateCpaRateRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'cpi_index' => ['required', 'regex:/^\d+\.\d$/'],
            'p2p_override' => ['nullable', 'regex:/^\d+(\.\d{1,8})?%?$/'],
            'ra_override' => ['nullable', 'regex:/^\d+(\.\d{1,8})?%?$/'],
            'override_note' => ['nullable', 'string', 'max:255'],
        ];
    }

    public function messages(): array
    {
        return [
            'cpi_index.regex' => 'CPI index must be a number with exactly one decimal place (e.g. 141.0).',
            'p2p_override.regex' => 'P2P override must be a decimal or percentage value (e.g. 0.028 or 2.8%).',
            'ra_override.regex' => 'RA override must be a decimal or percentage value (e.g. 0.029 or 2.9%).',
        ];
    }
}
