<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateCpiIndexEntryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'month' => ['nullable', 'regex:/^\d{4}-\d{1,2}$/'],
            'cpi_index' => ['required', 'regex:/^\d+\.\d$/'],
            'override_note' => ['nullable', 'string', 'max:255'],
        ];
    }

    public function messages(): array
    {
        return [
            'cpi_index.regex' => 'CPI index must be a number with exactly one decimal place (e.g. 141.0).',
            'month.regex' => 'Month must be in YYYY-MM format.',
        ];
    }

    public function monthDate(): ?string
    {
        $month = $this->input('month');

        return $month ? $month.'-01' : null;
    }
}
