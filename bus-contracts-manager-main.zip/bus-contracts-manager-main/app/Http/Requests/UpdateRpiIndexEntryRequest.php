<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateRpiIndexEntryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'month' => ['nullable', 'regex:/^\d{4}-\d{1,2}$/'],
            'rpi_index' => ['required', 'regex:/^\d+\.\d$/'],
            'override_note' => ['nullable', 'string', 'max:255'],
        ];
    }

    public function messages(): array
    {
        return [
            'rpi_index.regex' => 'RPI must be a number with exactly one decimal place (e.g. 411.4).',
            'month.regex' => 'Month must be in YYYY-MM format.',
        ];
    }

    public function monthDate(): ?string
    {
        $month = $this->input('month');

        return $month ? $month.'-01' : null;
    }
}
