<?php

namespace App\Console\Commands;

use App\Models\AuditLog;
use App\Models\CpiIndexEntry;
use App\Models\RpiIndexEntry;
use App\Models\User;
use App\Services\CpiRateService;
use App\Services\CpiRowSanitiser;
use App\Services\OnsCpiSeriesService;
use App\Services\OnsReleaseScraperService;
use DomainException;
use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use RuntimeException;

#[Signature('cpi:refresh {--dry-run : Parse + validate but do not persist any changes}')]
#[Description('Fetch the latest ONS CPI All Items Index (D7BT) values and release schedule, sanitise, persist new months, and recalculate dependent CPA rates.')]
class RefreshCpi extends Command
{
    public function handle(
        OnsReleaseScraperService $scraper,
        OnsCpiSeriesService $series,
        CpiRowSanitiser $sanitiser,
        CpiRateService $rates,
    ): int {
        $dryRun = (bool) $this->option('dry-run');

        $this->line('Refreshing CPI data from ONS'.($dryRun ? ' (dry run)' : '').'...');

        // 1. Release schedule. Failure here is non-fatal — values are the priority.
        try {
            $metadata = $scraper->fetchCpiInflation();
            $this->info(sprintf(
                '  Release metadata: %s · next release %s',
                $metadata->release_date?->toDateString() ?? 'unknown',
                $metadata->next_release_date?->toDateString() ?? $metadata->next_release_raw ?? 'unknown',
            ));
        } catch (\Throwable $e) {
            $this->warn('  Release metadata fetch failed: '.$e->getMessage());
            Log::warning('cpi:refresh release-metadata fetch failed', ['exception' => $e]);
        }

        // 2. CPI values. Failure here is fatal — this is the data the rest of
        //    the system computes against.
        try {
            $observations = $series->fetchSeries();
        } catch (RuntimeException $e) {
            $this->error('CPI series fetch failed: '.$e->getMessage());
            Log::error('cpi:refresh series fetch failed', ['exception' => $e]);

            return self::FAILURE;
        }

        $this->line(sprintf('  Fetched %d monthly observations from ONS.', count($observations)));

        $admin = User::query()->orderBy('id')->first();

        if (! $admin) {
            $this->error('No user account exists — refusing to write data without an owner.');

            return self::FAILURE;
        }

        $stats = ['inserted' => 0, 'unchanged' => 0, 'mismatch' => 0, 'skipped_override' => 0, 'errors' => 0];
        $errors = [];

        DB::beginTransaction();

        try {
            foreach ($observations as $obs) {
                try {
                    $clean = $sanitiser->sanitise($obs['month'], $obs['raw_value']);
                } catch (DomainException $e) {
                    $stats['errors']++;
                    $errors[] = $obs['month'].': '.$e->getMessage();

                    continue;
                }

                $month = $clean['month'];
                $cpi = $clean['cpi_index'];

                $existing = CpiIndexEntry::where('month', $month)->first();

                if ($existing === null) {
                    if (! $dryRun) {
                        CpiIndexEntry::create([
                            'month' => $month,
                            'cpi_index' => $cpi,
                            'cpi_index_original' => $cpi,
                            'is_actual' => true,
                            'source' => 'ons_feed',
                            'source_original' => 'ons_feed',
                            'created_by' => $admin->id,
                        ]);
                    }
                    $stats['inserted']++;

                    continue;
                }

                // Don't ever overwrite a manual override silently from a feed run.
                if ($existing->source === 'manual_override') {
                    $stats['skipped_override']++;

                    continue;
                }

                $existingCpi = number_format((float) $existing->cpi_index, 1, '.', '');

                if ($existingCpi === $cpi) {
                    // Value matches — but if the row was historically tagged
                    // as a manual import, promote it to 'ons_feed' now that
                    // the live feed has confirmed it. Without this, "Delete
                    // bulk imports" would treat ONS-confirmed history as user
                    // data and remove it.
                    if (! $dryRun && $existing->source_original !== 'ons_feed') {
                        $existing->fill([
                            'source' => 'ons_feed',
                            'source_original' => 'ons_feed',
                            'updated_by' => $admin->id,
                        ])->save();
                        $stats['promoted'] = ($stats['promoted'] ?? 0) + 1;
                    }
                    $stats['unchanged']++;

                    continue;
                }

                // ONS revised a published value — update current + original
                // snapshots so a future "reset" returns the latest authoritative figure.
                if (! $dryRun) {
                    $existing->fill([
                        'cpi_index' => $cpi,
                        'cpi_index_original' => $cpi,
                        'is_actual' => true,
                        'source' => 'ons_feed',
                        'source_original' => 'ons_feed',
                        'updated_by' => $admin->id,
                    ])->save();
                }
                $stats['mismatch']++;
            }

            // Recalculate derived rates only if anything actually changed.
            if (! $dryRun && ($stats['inserted'] > 0 || $stats['mismatch'] > 0)) {
                $rates->recalculateAll();
            }

            if (! $dryRun && ($stats['inserted'] > 0 || $stats['mismatch'] > 0 || $stats['errors'] > 0)) {
                AuditLog::create([
                    'user_id' => $admin->id,
                    'action' => 'cpi_refresh',
                    'entity_type' => 'cpi_index_entries',
                    'entity_id' => 0,
                    'new_values' => $stats,
                    'note' => 'Automated ONS feed refresh',
                ]);
            }

            if ($dryRun) {
                DB::rollBack();
            } else {
                DB::commit();
            }
        } catch (\Throwable $e) {
            DB::rollBack();
            $this->error('Unexpected failure during refresh: '.$e->getMessage());
            Log::error('cpi:refresh transaction failed', ['exception' => $e]);

            return self::FAILURE;
        }

        $this->newLine();
        $this->info(sprintf(
            'CPI: %d inserted · %d revised · %d unchanged · %d skipped (override) · %d errors',
            $stats['inserted'],
            $stats['mismatch'],
            $stats['unchanged'],
            $stats['skipped_override'],
            $stats['errors'],
        ));

        if ($stats['errors'] > 0) {
            $this->warn('CPI per-row errors:');
            foreach (array_slice($errors, 0, 10) as $err) {
                $this->line('  - '.$err);
            }
        }

        // 3. RPI series. Same dataset, different time-series ID. Failure here
        //    is non-fatal — it doesn't break CPA derivation.
        $this->newLine();
        $this->line('Refreshing RPI data from ONS...');
        $this->refreshRpi($series, $sanitiser, $admin, $dryRun);

        return self::SUCCESS;
    }

    private function refreshRpi(
        OnsCpiSeriesService $series,
        CpiRowSanitiser $sanitiser,
        User $admin,
        bool $dryRun,
    ): void {
        try {
            $observations = $series->fetchSeries(OnsCpiSeriesService::CHAW_TIMESERIES_URL);
        } catch (RuntimeException $e) {
            $this->warn('  RPI series fetch failed: '.$e->getMessage());
            Log::warning('cpi:refresh rpi series fetch failed', ['exception' => $e]);

            return;
        }

        $this->line(sprintf('  Fetched %d monthly observations from ONS.', count($observations)));

        $stats = ['inserted' => 0, 'unchanged' => 0, 'mismatch' => 0, 'skipped_override' => 0, 'errors' => 0];
        $errors = [];

        DB::beginTransaction();

        try {
            foreach ($observations as $obs) {
                try {
                    // Sanitiser is named for CPI but it's a generic month + 1-decimal
                    // numeric value validator — fine to reuse for RPI.
                    $clean = $sanitiser->sanitise($obs['month'], $obs['raw_value']);
                } catch (DomainException $e) {
                    $stats['errors']++;
                    $errors[] = $obs['month'].': '.$e->getMessage();

                    continue;
                }

                $month = $clean['month'];
                $rpi = $clean['cpi_index'];

                $existing = RpiIndexEntry::where('month', $month)->first();

                if ($existing === null) {
                    if (! $dryRun) {
                        RpiIndexEntry::create([
                            'month' => $month,
                            'rpi_index' => $rpi,
                            'rpi_index_original' => $rpi,
                            'is_actual' => true,
                            'source' => 'ons_feed',
                            'source_original' => 'ons_feed',
                            'created_by' => $admin->id,
                        ]);
                    }
                    $stats['inserted']++;

                    continue;
                }

                if ($existing->source === 'manual_override') {
                    $stats['skipped_override']++;

                    continue;
                }

                $existingRpi = number_format((float) $existing->rpi_index, 1, '.', '');

                if ($existingRpi === $rpi) {
                    // Promote a historical manual_import row to ons_feed when
                    // the live feed confirms its value (mirrors the CPI logic
                    // above so "Delete bulk imports" doesn't sweep ONS data).
                    if (! $dryRun && $existing->source_original !== 'ons_feed') {
                        $existing->fill([
                            'source' => 'ons_feed',
                            'source_original' => 'ons_feed',
                            'updated_by' => $admin->id,
                        ])->save();
                        $stats['promoted'] = ($stats['promoted'] ?? 0) + 1;
                    }
                    $stats['unchanged']++;

                    continue;
                }

                if (! $dryRun) {
                    $existing->fill([
                        'rpi_index' => $rpi,
                        'rpi_index_original' => $rpi,
                        'is_actual' => true,
                        'source' => 'ons_feed',
                        'source_original' => 'ons_feed',
                        'updated_by' => $admin->id,
                    ])->save();
                }
                $stats['mismatch']++;
            }

            if (! $dryRun && ($stats['inserted'] > 0 || $stats['mismatch'] > 0 || $stats['errors'] > 0)) {
                AuditLog::create([
                    'user_id' => $admin->id,
                    'action' => 'rpi_refresh',
                    'entity_type' => 'rpi_index_entries',
                    'entity_id' => 0,
                    'new_values' => $stats,
                    'note' => 'Automated ONS feed refresh',
                ]);
            }

            if ($dryRun) {
                DB::rollBack();
            } else {
                DB::commit();
            }
        } catch (\Throwable $e) {
            DB::rollBack();
            $this->warn('  Unexpected failure during RPI refresh: '.$e->getMessage());
            Log::error('cpi:refresh rpi transaction failed', ['exception' => $e]);

            return;
        }

        $this->info(sprintf(
            'RPI: %d inserted · %d revised · %d unchanged · %d skipped (override) · %d errors',
            $stats['inserted'],
            $stats['mismatch'],
            $stats['unchanged'],
            $stats['skipped_override'],
            $stats['errors'],
        ));

        if ($stats['errors'] > 0) {
            $this->warn('RPI per-row errors:');
            foreach (array_slice($errors, 0, 10) as $err) {
                $this->line('  - '.$err);
            }
        }
    }
}
