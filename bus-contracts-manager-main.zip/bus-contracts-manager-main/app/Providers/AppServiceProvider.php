<?php

namespace App\Providers;

use App\Models\Contract;
use App\Models\CpiIndexEntry;
use App\Models\LoginLog;
use App\Models\OnsReleaseMetadata;
use Carbon\Carbon;
use Illuminate\Auth\Events\Login;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Paginator::defaultView('vendor.pagination.default');
        Paginator::defaultSimpleView('vendor.pagination.default');

        // Make ONS release metadata available to the topbar — but only on the
        // Indices pages, where it's relevant. Other pages (Reports, Audit,
        // Manage users, Profile, Settings) don't need the CPI release schedule
        // so the topbar stays uncluttered.
        View::composer('layouts.app', function ($view) {
            $meta = null;
            $contractsMeta = null;

            if (Auth::check() && request()->routeIs('indices.*')) {
                // Always populate $meta on indices.* routes so the topbar
                // refresh button is reachable on a fresh DB — before any
                // CPI refresh has populated `ons_release_metadata`. Empty
                // fields fall through to the Blade's `?? '—'` placeholder.
                $row = OnsReleaseMetadata::where('dataset_key', OnsReleaseMetadata::CPI_DATASET_KEY)->first();
                $latestMonth = CpiIndexEntry::query()->max('month');

                $meta = [
                    'updated_at' => $row?->fetched_at?->format('d/m/Y'),
                    'data_through' => $latestMonth
                        ? Carbon::parse($latestMonth)->format('M Y')
                        : null,
                    'next_release' => $row?->next_release_date?->format('d/m/Y') ?? $row?->next_release_raw,
                ];
            }

            // Contracts pages get a slimmer counterpart: just "Updated XXX",
            // sourced from the most recent contract row update. Contracts
            // covers Add / Edit / Override / Variation / CPA confirmation /
            // Extension / Notice / Tender — all of those touch
            // contracts.updated_at. Evidence-only attachments don't, but
            // those are a minor admin action.
            if (Auth::check() && request()->routeIs('contracts.*')) {
                $latestUpdated = Contract::query()->max('updated_at');

                if ($latestUpdated) {
                    $contractsMeta = [
                        'updated_at' => Carbon::parse($latestUpdated)->format('d/m/Y'),
                    ];
                }
            }

            $view->with('topbarOnsMeta', $meta);
            $view->with('topbarContractsMeta', $contractsMeta);
        });

        // Capture every successful login so the Manage users view can show a
        // recent IP / timestamp history per account.
        Event::listen(Login::class, function (Login $event) {
            $request = request();

            LoginLog::create([
                'user_id' => $event->user->getKey(),
                'ip_address' => $request?->ip(),
                'user_agent' => mb_substr((string) $request?->userAgent(), 0, 255),
                'logged_in_at' => now(),
            ]);
        });
    }
}
