<?php

declare(strict_types=1);

namespace App\Support;

use Carbon\Carbon;

/**
 * Computes a per-field diff between an audit log row's old_values and
 * new_values, plus humanises field labels and formats raw values for
 * display. Drives the v2 audit-log card layout.
 */
class AuditDiffer
{
    /** Acronyms preserved through the snake_case → Title Case humaniser. */
    private const ACRONYMS = ['CPI', 'CPA', 'RPI', 'ONS', 'YoY', 'P2P', 'RA', 'IP', 'PVR', 'TVR', 'ET', 'TFL', 'CSV', 'ID'];

    /**
     * Field-aware overrides for keys whose snake_case → Title Case fallback
     * doesn't read naturally (e.g. `id_no` → "ID No" rather than "Id no").
     */
    private const FIELD_LABELS = [
        'cpa_confirmations' => 'CPA confirmations',
        'cpa_confirmation_notes' => 'CPA confirmation notes',
        'tender_award_note' => 'Tender award',
        'latest_change_note' => 'Reason for change',
        'notice_served' => 'Notice served',
        'change_notes' => 'Change notes',
        'attachable_key' => 'Attachable key',
    ];

    /**
     * @param  array<string, mixed>|null  $old
     * @param  array<string, mixed>|null  $new
     * @return list<array{key: string, label: string, status: 'added'|'removed'|'changed', oldFormatted: string, newFormatted: string}>
     */
    public static function diff(?array $old, ?array $new): array
    {
        $old = $old ?? [];
        $new = $new ?? [];
        // PHP auto-casts numeric string keys to int when re-reading arrays,
        // so a year-keyed payload like {"2024": "yes"} surfaces an int key
        // here. Coerce everything back to string up front so the strictly-
        // typed humanise() / array_key_exists comparisons stay happy.
        $keys = array_values(array_unique(array_map(
            'strval',
            array_merge(array_keys($old), array_keys($new))
        )));
        sort($keys);

        $diff = [];
        foreach ($keys as $key) {
            $hasOld = array_key_exists($key, $old);
            $hasNew = array_key_exists($key, $new);
            $oldVal = $old[$key] ?? null;
            $newVal = $new[$key] ?? null;

            if ($hasOld && $hasNew) {
                if (json_encode($oldVal) === json_encode($newVal)) {
                    continue;
                }
                $status = 'changed';
            } elseif ($hasNew) {
                $status = 'added';
            } else {
                $status = 'removed';
            }

            $diff[] = [
                'key' => $key,
                'label' => self::humanise($key),
                'status' => $status,
                'oldFormatted' => self::format($oldVal),
                'newFormatted' => self::format($newVal),
            ];
        }

        return $diff;
    }

    public static function humanise(string $key): string
    {
        if (isset(self::FIELD_LABELS[$key])) {
            return self::FIELD_LABELS[$key];
        }

        $label = ucfirst(str_replace('_', ' ', $key));

        foreach (self::ACRONYMS as $acronym) {
            $label = (string) preg_replace(
                '/\b'.preg_quote($acronym, '/').'\b/i',
                $acronym,
                $label
            );
        }

        return $label;
    }

    public static function format(mixed $value): string
    {
        if ($value === null || $value === '') {
            return '—';
        }

        if (is_bool($value)) {
            return $value ? 'Yes' : 'No';
        }

        if (is_string($value) && in_array(strtolower($value), ['yes', 'no'], true)) {
            return ucfirst(strtolower($value));
        }

        if (is_string($value) && preg_match('/^\d{4}-\d{2}-\d{2}/', $value)) {
            try {
                return Carbon::parse($value)->format('d/m/Y');
            } catch (\Throwable) {
                return $value;
            }
        }

        if (is_array($value)) {
            return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '—';
        }

        return (string) $value;
    }
}
