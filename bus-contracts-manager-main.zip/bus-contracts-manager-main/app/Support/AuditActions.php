<?php

namespace App\Support;

/**
 * Single source of truth for how each audit-log action key is presented in
 * the UI. Keeping this in one place means the audit table, the filter
 * dropdown, and any future export all stay aligned.
 */
class AuditActions
{
    /**
     * Action key → [label, badge modifier, verb category].
     *
     * Badge modifier maps to the `badge--*` classes already defined in app.css.
     * Verb category groups visually-related actions for the filter dropdown
     * (e.g. all "create" actions can be highlighted together).
     *
     * @var array<string, array{label: string, badge: string, verb: string}>
     */
    public const ACTIONS = [
        // Indices — entity (CPI / CPA / RPI) is shown in the Affected column,
        // so action labels stay as plain verbs.
        'cpi_index_added' => ['label' => 'Added', 'badge' => 'badge--success', 'verb' => 'create'],
        'cpi_index_updated' => ['label' => 'Updated', 'badge' => 'badge--warning', 'verb' => 'update'],
        'cpi_index_deleted' => ['label' => 'Deleted', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        'cpi_index_imported' => ['label' => 'Imported', 'badge' => 'badge--info', 'verb' => 'import'],
        'cpi_index_reset' => ['label' => 'Reset to ONS', 'badge' => 'badge--neutral', 'verb' => 'update'],
        'cpi_refresh' => ['label' => 'Feed refresh', 'badge' => 'badge--info', 'verb' => 'system'],
        'cpa_rate_overridden' => ['label' => 'Overridden', 'badge' => 'badge--warning', 'verb' => 'update'],
        'cpa_override_removed' => ['label' => 'Override removed', 'badge' => 'badge--neutral', 'verb' => 'update'],
        'cpa_rate_reset' => ['label' => 'Reset to ONS', 'badge' => 'badge--neutral', 'verb' => 'update'],
        'cpa_rates_imported' => ['label' => 'Imported', 'badge' => 'badge--info', 'verb' => 'import'],
        'cpi_overrides_cleared' => ['label' => 'Overrides reset', 'badge' => 'badge--neutral', 'verb' => 'update'],
        'cpi_imports_cleared' => ['label' => 'Imports deleted', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        'cpa_overrides_cleared' => ['label' => 'Overrides reset', 'badge' => 'badge--neutral', 'verb' => 'update'],
        // Legacy actions — kept so historical entries still render with a friendly label
        // after their live endpoints were removed or renamed.
        'cpa_imports_cleared' => ['label' => 'Imports deleted', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        'cpa_reset_all' => ['label' => 'Overrides reset', 'badge' => 'badge--destructive', 'verb' => 'update'],
        'rpi_index_added' => ['label' => 'Added', 'badge' => 'badge--success', 'verb' => 'create'],
        'rpi_index_updated' => ['label' => 'Updated', 'badge' => 'badge--warning', 'verb' => 'update'],
        'rpi_index_deleted' => ['label' => 'Deleted', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        'rpi_index_imported' => ['label' => 'Imported', 'badge' => 'badge--info', 'verb' => 'import'],
        'rpi_index_reset' => ['label' => 'Reset to ONS', 'badge' => 'badge--neutral', 'verb' => 'update'],
        'rpi_refresh' => ['label' => 'Feed refresh', 'badge' => 'badge--info', 'verb' => 'system'],
        'rpi_overrides_cleared' => ['label' => 'Overrides reset', 'badge' => 'badge--neutral', 'verb' => 'update'],
        'rpi_imports_cleared' => ['label' => 'Imports deleted', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        'rpi_reset_all' => ['label' => 'Overrides reset', 'badge' => 'badge--destructive', 'verb' => 'update'],
        // Audit log
        'audit_log_purged' => ['label' => 'Audit log purged', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        'audit_log_deleted' => ['label' => 'Audit log deleted', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        'attachments_purged' => ['label' => 'Attachments wiped', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        'data_purged' => ['label' => 'All data wiped', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        'upload_limits_updated' => ['label' => 'Upload limits updated', 'badge' => 'badge--neutral', 'verb' => 'update'],
        'upload_limits_reset' => ['label' => 'Upload limits reset', 'badge' => 'badge--neutral', 'verb' => 'update'],
        'database_snapshot_downloaded' => ['label' => 'Snapshot downloaded', 'badge' => 'badge--info', 'verb' => 'system'],
        // Users
        'user_created' => ['label' => 'Added', 'badge' => 'badge--success', 'verb' => 'create'],
        'user_updated' => ['label' => 'Updated', 'badge' => 'badge--warning', 'verb' => 'update'],
        'user_deleted' => ['label' => 'Deleted', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        // Soft-delete restore — distinct from the (now-rare) "unfrozen"
        // flag flip so the audit log shows the right verb in the UI.
        'user_restored' => ['label' => 'Restored', 'badge' => 'badge--success', 'verb' => 'create'],
        'user_password_reset' => ['label' => 'Password reset', 'badge' => 'badge--warning', 'verb' => 'update'],
        // Password / email events authored by the account owner themselves
        // (vs `user_password_reset` which is an admin acting on someone).
        'user_password_self_changed' => ['label' => 'Password changed', 'badge' => 'badge--warning', 'verb' => 'update'],
        'user_email_verified' => ['label' => 'Email verified', 'badge' => 'badge--success', 'verb' => 'update'],
        'user_frozen' => ['label' => 'Frozen', 'badge' => 'badge--destructive', 'verb' => 'update'],
        'user_unfrozen' => ['label' => 'Unfrozen', 'badge' => 'badge--success', 'verb' => 'update'],
        // Settings (cross-cutting destructive operations)
        'all_overrides_cleared' => ['label' => 'All overrides reset', 'badge' => 'badge--destructive', 'verb' => 'update'],
        'all_imports_cleared' => ['label' => 'All imports deleted', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        // Contracts
        'contract_added' => ['label' => 'Added', 'badge' => 'badge--success', 'verb' => 'create'],
        'contract_overridden' => ['label' => 'Overridden', 'badge' => 'badge--warning', 'verb' => 'update'],
        'contract_varied' => ['label' => 'Variation', 'badge' => 'badge--info', 'verb' => 'update'],
        'contract_confirmed' => ['label' => 'Confirmed', 'badge' => 'badge--success', 'verb' => 'update'],
        'contract_deleted' => ['label' => 'Deleted', 'badge' => 'badge--destructive', 'verb' => 'delete'],
        // Soft-delete restore — distinct from `contract_confirmed` (which
        // means CPA value confirmed, not "brought back from archive").
        'contract_restored' => ['label' => 'Restored', 'badge' => 'badge--success', 'verb' => 'create'],
        'contract_settings_updated' => ['label' => 'Settings updated', 'badge' => 'badge--neutral', 'verb' => 'update'],
        'contract_cpa_confirmed' => ['label' => 'CPA confirmation set', 'badge' => 'badge--info', 'verb' => 'update'],
        'contract_extension_set' => ['label' => 'Extension set', 'badge' => 'badge--info', 'verb' => 'update'],
        'contract_notice_served_set' => ['label' => 'Notice served set', 'badge' => 'badge--info', 'verb' => 'update'],
        'contract_tender_award_set' => ['label' => 'Tender award set', 'badge' => 'badge--info', 'verb' => 'update'],
        // Current keys (used for any new audit row written from
        // 2026-05-12 onward — see AttachmentUpload + ContractController).
        'contract_attachment_attached' => ['label' => 'Attachment uploaded', 'badge' => 'badge--info', 'verb' => 'create'],
        'contract_attachment_detached' => ['label' => 'Attachment detached', 'badge' => 'badge--warning', 'verb' => 'delete'],
        // Legacy keys — kept so historical rows still resolve to a
        // friendly label after the rename. Labels updated to the new
        // wording so the audit log reads consistently across old +
        // new entries; underlying action key is preserved per the
        // §10 append-only rule.
        'contract_evidence_attached' => ['label' => 'Attachment uploaded', 'badge' => 'badge--info', 'verb' => 'create'],
        'contract_evidence_detached' => ['label' => 'Attachment detached', 'badge' => 'badge--warning', 'verb' => 'delete'],
        'contracts_imported' => ['label' => 'Imported', 'badge' => 'badge--info', 'verb' => 'import'],
    ];

    /**
     * Acronyms that must keep their canonical casing if a label ever falls
     * through to the smart-case fallback below. Without this, action keys
     * containing 'cpa' / 'cpi' / etc. would render as 'Cpa', 'Cpi', etc.
     */
    private const ACRONYMS = ['CPI', 'CPA', 'RPI', 'ONS', 'YoY', 'P2P', 'RA', 'IP'];

    public static function label(string $action): string
    {
        if (isset(self::ACTIONS[$action])) {
            return self::ACTIONS[$action]['label'];
        }

        // Sentence case the slug, then restore known acronyms.
        $label = ucfirst(str_replace('_', ' ', $action));

        foreach (self::ACRONYMS as $acronym) {
            $label = preg_replace('/\b'.preg_quote($acronym, '/').'\b/i', $acronym, $label);
        }

        return $label;
    }

    public static function badge(string $action): string
    {
        return self::ACTIONS[$action]['badge'] ?? 'badge--neutral';
    }

    /**
     * @return array<string, array{label: string, badge: string, verb: string}>
     */
    public static function all(): array
    {
        return self::ACTIONS;
    }
}
