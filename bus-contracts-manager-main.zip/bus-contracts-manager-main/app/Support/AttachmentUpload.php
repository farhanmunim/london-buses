<?php

namespace App\Support;

use App\Models\Attachment;
use App\Models\AttachmentLink;
use App\Models\AuditLog;
use App\Models\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Carbon;
use Illuminate\Validation\ValidationException;

/**
 * One stop for handling attachment uploads on contract-section forms.
 * Sanitises the filename, computes a content hash, persists the
 * Attachment row in the same DB transaction as the originating action,
 * and provides the duplicate-detection helpers used by the pre-flight
 * XHR endpoint.
 *
 * Duplicate handling: the user is offered three actions when a file
 * with the same sanitised name already exists in the system —
 *   - 'replace': overwrite bytes/hash/mime/size on every existing row
 *                that shares the filename, then attach the new
 *                upload to the current audit log entry too.
 *   - 'keep'   : disambiguate the new upload's filename with a
 *                timestamp suffix, save independently.
 *   - 'cancel' : handled client-side; never reaches the server.
 *
 * If neither 'replace' nor 'keep' is supplied AND a dupe exists, the
 * controller should treat that as a validation failure (defence in
 * depth — the client should never let an unguarded submission through,
 * but a tampered request must not silently win).
 */
class AttachmentUpload
{
    /** Validation rules for the upload field itself. */
    public static function rules(): array
    {
        return [
            'attachment' => [
                'nullable',
                'file',
                'max:'.Attachment::maxUploadKb(),
                'mimes:'.implode(',', Attachment::allowedExtensions()),
            ],
        ];
    }

    /** Validation rule for the dupe-action selector. */
    public static function dupeActionRule(): array
    {
        return ['nullable', 'string', 'in:link,replace,keep'];
    }

    /**
     * Server-side guard. If the upload's sanitised name matches an
     * existing attachment AND no dupe_action was supplied, throw a
     * validation error — the client should never let an unguarded
     * submission through, but a tampered request must not silently
     * win. Caller should run this after the standard `attachment` rules
     * have validated the upload itself.
     */
    public static function assertDupeActionIfNeeded(?UploadedFile $file, ?string $dupeAction): void
    {
        if ($file === null) {
            return;
        }
        if (in_array($dupeAction, ['link', 'replace', 'keep'], true)) {
            return;
        }

        $sanitised = self::sanitiseFilename($file->getClientOriginalName());
        if (self::findDuplicatesByFilename($sanitised)->isNotEmpty()) {
            throw ValidationException::withMessages([
                'attachment' => "A file named \"{$sanitised}\" already exists in the system. Choose Link existing, Replace, or Keep both before saving.",
            ]);
        }
    }

    /**
     * Strip path components and constrain the filename to a safe set.
     * Falls back to a timestamp-named ".bin" if nothing usable remains.
     */
    public static function sanitiseFilename(string $name): string
    {
        $base = basename($name);
        $clean = preg_replace('/[^A-Za-z0-9._-]+/', '_', $base) ?? '';
        $clean = trim($clean, '._-');
        $clean = mb_substr($clean, 0, 200);

        if ($clean === '') {
            return 'attachment-'.now()->format('YmdHis').'.bin';
        }

        return $clean;
    }

    /**
     * Find existing attachments that share the sanitised filename.
     * Used by the pre-flight check XHR and the server-side guard.
     *
     * @return Collection<int, Attachment>
     */
    public static function findDuplicatesByFilename(string $sanitisedFilename): Collection
    {
        return Attachment::query()
            ->select(['id', 'audit_log_id', 'original_filename', 'mime_type', 'size_bytes', 'sha256', 'uploaded_by', 'created_at', 'detached_at'])
            ->where('original_filename', $sanitisedFilename)
            ->with(['auditLog:id,user_id,action,note,entity_type,entity_id,created_at',
                'auditLog.user:id,name'])
            ->orderByDesc('created_at')
            ->get();
    }

    /**
     * Persist the uploaded file as an Attachment row tied to $auditLog,
     * applying the chosen duplicate action.
     *
     * @param  string|null  $dupeAction  'link' | 'replace' | 'keep' | null
     */
    public static function persist(
        ?UploadedFile $file,
        AuditLog $auditLog,
        User $uploader,
        ?string $dupeAction = null,
        ?string $attachableKey = null,
    ): ?Attachment {
        if ($file === null) {
            return null;
        }

        $sanitised = self::sanitiseFilename($file->getClientOriginalName());

        // Replace / link target only ACTIVE rows. Detached attachments
        // stay frozen for audit history; replace doesn't retroactively
        // rewrite them, and link can't reuse them because they're not
        // in use anywhere.
        $activeDuplicates = self::findDuplicatesByFilename($sanitised)
            ->whereNull('detached_at');

        // ── Link existing ─────────────────────────────────────────────
        // Skip writing bytes entirely; just create a fresh link row
        // pointing at the most recent active attachment with this
        // filename. Falls through to the regular upload path if the
        // dialog somehow submitted `link` without an active dupe (the
        // UI hides the option in that case, but defence in depth).
        if ($dupeAction === 'link' && $activeDuplicates->isNotEmpty()) {
            $existing = $activeDuplicates->first();

            AttachmentLink::create([
                'attachment_id' => $existing->id,
                'attachable_key' => $attachableKey,
                'audit_log_id' => $auditLog->id,
            ]);

            return $existing;
        }

        $bytes = file_get_contents($file->getRealPath());
        $hash = hash('sha256', $bytes);
        $mime = $file->getMimeType() ?? 'application/octet-stream';
        $size = $file->getSize();

        if ($activeDuplicates->isNotEmpty() && $dupeAction === 'replace') {
            Attachment::query()
                ->whereIn('id', $activeDuplicates->pluck('id')->all())
                ->update([
                    'mime_type' => $mime,
                    'size_bytes' => $size,
                    'sha256' => $hash,
                    'contents' => $bytes,
                    'updated_at' => now(),
                ]);
        }

        $finalFilename = $sanitised;
        if ($activeDuplicates->isNotEmpty() && $dupeAction === 'keep') {
            $finalFilename = self::disambiguateFilename($sanitised);
        }

        $attachment = Attachment::create([
            'audit_log_id' => $auditLog->id,
            'attachable_key' => $attachableKey,
            'original_filename' => $finalFilename,
            'mime_type' => $mime,
            'size_bytes' => $size,
            'sha256' => $hash,
            'contents' => $bytes,
            'uploaded_by' => $uploader->id,
        ]);

        // Every persist also writes a link row alongside the attachment.
        // Legacy attachable_key on the attachments row is kept in sync
        // so any code still reading it works during the transition.
        AttachmentLink::create([
            'attachment_id' => $attachment->id,
            'attachable_key' => $attachableKey,
            'audit_log_id' => $auditLog->id,
        ]);

        return $attachment;
    }

    /**
     * List active (non-detached) attachment links for a record-item
     * slot, eager-loading the underlying file metadata. Each entry
     * comes with the bare metadata the dialog needs — never the blob.
     * Used by both the prefetch on the contracts index and the XHR
     * refresh after delete.
     *
     * @return Collection<int, AttachmentLink>
     */
    public static function forKey(string $attachableKey): Collection
    {
        return AttachmentLink::query()
            ->select(['id', 'attachment_id', 'attachable_key', 'created_at'])
            ->where('attachable_key', $attachableKey)
            ->whereNull('detached_at')
            ->with(['attachment:id,original_filename,size_bytes,uploaded_by'])
            ->orderBy('created_at')
            ->get();
    }

    /**
     * Append a timestamp before the extension so a dupe-name upload
     * gets a unique, human-readable name.
     *
     * Example: tender-award.pdf → tender-award_2026-05-08-223045.pdf
     */
    private static function disambiguateFilename(string $sanitised): string
    {
        $stamp = Carbon::now()->format('Y-m-d-His');
        $dot = strrpos($sanitised, '.');

        if ($dot === false || $dot === 0) {
            return $sanitised.'_'.$stamp;
        }

        $stem = substr($sanitised, 0, $dot);
        $ext = substr($sanitised, $dot);

        return $stem.'_'.$stamp.$ext;
    }
}
