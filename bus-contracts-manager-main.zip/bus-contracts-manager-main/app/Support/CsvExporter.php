<?php

namespace App\Support;

/**
 * Hardens CSV exports against formula-injection (CWE-1236).
 *
 * If an exported cell starts with =, +, -, @, |, \t or \r, Excel / Sheets
 * will interpret it as a formula on the next user's machine — meaning a
 * tainted contract field like `=cmd|'/c calc'!A1` becomes a remote-code-
 * execution payload for any reviewer who opens the CSV.
 *
 * Use `safeCell()` on every user-controllable value before writing it.
 * The helper prefixes a single quote so spreadsheet tools render the
 * literal text instead of evaluating it; the leading quote is invisible
 * in cell display and stripped on re-import by anything sensible.
 *
 * Hardcoded headers and template samples don't need to be wrapped — but
 * defaulting to safety has no meaningful cost, so it's fine to wrap them
 * too.
 */
class CsvExporter
{
    private const INJECTION_LEADERS = ['=', '+', '-', '@', '|', "\t", "\r"];

    public static function safeCell(int|float|string|null $value): string
    {
        if ($value === null) {
            return '';
        }

        $str = (string) $value;

        if ($str === '') {
            return '';
        }

        $first = mb_substr($str, 0, 1);

        if (in_array($first, self::INJECTION_LEADERS, true)) {
            return "'".$str;
        }

        return $str;
    }

    /**
     * Convenience: map an entire row through safeCell().
     *
     * @param  array<int|string, int|float|string|null>  $row
     * @return list<string>
     */
    public static function safeRow(array $row): array
    {
        return array_map(self::safeCell(...), array_values($row));
    }
}
