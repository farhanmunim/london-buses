<?php

namespace App\Support;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

/**
 * Inline password re-confirmation helper. Used by every action that
 * needs the operator to re-prove their identity without bouncing them
 * to a full-page Breeze confirm-password view: Settings > Data control
 * (snapshot, audit-log clear / delete, attachments delete, upload-limit
 * update / reset) and Users management (Add / Edit / Delete).
 *
 * The matching client-side flow lives in the shared `queueForPassword`
 * Alpine pattern: each form uses a modal to capture the password and
 * writes it into a hidden field before submitting.
 *
 * The default field name is `password`, but the Users controller passes
 * `confirm_password` because its forms already carry a `password` for
 * the target user's new password — using two different names avoids the
 * collision.
 */
class PasswordConfirm
{
    /**
     * Validate the supplied password against the authenticated user.
     * Throws ValidationException with a user-friendly message on
     * failure; caller doesn't need to handle the failure path.
     */
    public static function check(Request $request, string $field = 'password'): void
    {
        $user = $request->user();
        $password = (string) $request->input($field, '');

        if ($user === null) {
            abort(403);
        }

        if ($password === '') {
            throw ValidationException::withMessages([
                $field => 'Password required to confirm this action.',
            ]);
        }

        if (! Hash::check($password, $user->password)) {
            throw ValidationException::withMessages([
                $field => 'That password is incorrect.',
            ]);
        }
    }
}
