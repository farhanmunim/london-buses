# CLAUDE.md

Engineering rules and AI-agent guardrails for the Bus Contracts Manager codebase.
Project overview, stack, local-dev commands, feature inventory, deployment
checklist, and roadmap live in [`README.md`](README.md) — keep this file focused
on rules.

---

## 0. Rule Priority

1. Security & data integrity
2. Git safety
3. Architecture (data, pipelines, audit)
4. Runtime behaviour
5. UI implementation
6. Styling

---

## 1. Project Overrides

- **No Tailwind.** The project uses a custom shadcn-inspired CSS framework in `resources/css/app.css`. Do not introduce Tailwind, PostCSS, or any Tailwind utilities.
- **Database is per-environment.** Local Herd uses SQLite (`database/database.sqlite`); production runs PostgreSQL 18 on Coolify. Both share a single connection (auth + app data), wired via `DB_CONNECTION` in `.env`. **Never write SQL that only works on SQLite** — common trap is comparing booleans to integers (`is_actual = 0` errors on Postgres). Use `IS TRUE` / `IS FALSE` in raw `DB::statement` calls.
- **Never run `php artisan serve`.** Laravel Herd serves the site at `https://contract-manager.test`. Production was deployed via Docker on a Coolify VPS (no live hosted instance now) — `APP_URL` is set per-environment, never hardcoded.
- **Production runs from a Dockerfile, not Nixpacks.** The Coolify build uses [`Dockerfile`](Dockerfile) (multi-stage: node + serversideup/php). Do not switch back to Nixpacks — its PHP nginx template renders duplicate `location /` blocks and the container crash-loops. Required PHP extensions (`pdo_pgsql`, `bcmath`) are installed in the Dockerfile.
- **Public registration is disabled.** `/register` 404s in both environments; accounts come from Manage Users only. Do not re-enable the route without explicit instruction.
- **No Cloudflare Workers or CDN pipelines.** All data fetching and processing runs server-side via Laravel artisan commands and the scheduler.
- **CPI refresh pipeline** — single entry point `php artisan cpi:refresh`. See README for the full pipeline architecture.
- **Git identity** is already configured locally as `Your Name <admin@example.com>`. Do not override per-commit.
- **CI auto-commits** of `database/database.sqlite` (from the CPI refresh GitHub Action) are exempt from the normal commit approval rule.

---

## 2. Business-logic Landmines

These are non-obvious rules baked into the code; changing them silently will break downstream calculations. Treat as imperative.

- **CPI index must be stored to exactly 1 decimal place.** Validate on input with `/^\d+\.\d$/`. Never store more or fewer decimal places — this matches ONS published precision and affects downstream rate calculations.
- **TFL P2P / RA lags.** The displayed rate at month M is the rate **applied to** month M in TFL contracts, which is *not* the rate computed from M's own CPI. P2P uses a **4-month lag**, RA uses a **1-month-shifted window**:
    - `yoy_change[M]  = (CPI[M] − CPI[M-12]) / CPI[M-12]`
    - `p2p_rate[M]    = yoy_change[M-4] × 0.85`
    - `ra_rate[M]     = AVERAGE(yoy_change[M-12 … M-1]) × 0.85`
  These match the `CPA - USED` / FINAL OUTPUT columns in the canonical `NEW REVENUE DATA BASE` spreadsheet exactly. Never silently re-derive without the lag — the test `tests/Unit/CpiRateServiceTest.php :: it matches the canonical Excel values for March 2026` pins this.
- **Round-half-up at 8 dp for P2P / RA / YoY.** Excel's default rounding. Implemented in `CpiRateService::roundHalfUp()`.
- **RA rate requires 25 months of CPI history** (M-24 through M-1, plus M-12 for YoY). If sufficient history doesn't exist, `ra_rate` must be `null` — never estimated or approximated. Same for P2P needing 16 months.
- **Period-aware MAXIFS** — when calculating which CPA rate applies to a contract in a given period, only count confirmed years whose anniversary has already passed by the period end date. A future confirmation must not affect a past period.
- **Never overwrite manual overrides with feed data.** The CPI refresh command skips rows with `source = manual_override` — the feed never silently undoes a user override.
- **Audit write inside the same transaction.** If the main action rolls back, the audit entry must also roll back. Never write audit logs in a separate async step.
- **Revenue formula uses dynamic period lengths.** Never hardcode 28 days. Always compute as `period_end - period_start + 1`.
- **Cross-year periods (e.g. P10, Dec–Jan)** affect the delay CPA accrual logic. The trigger is `YEAR(period_start) ≠ YEAR(period_end)`.

---

# Git & Versioning

---

## 3. Git Identity (STRICT)

- Always use: Name `Your Name` · Email `admin@example.com`
- Verify with `git config user.name` / `git config user.email` before first commit.
- Never commit as Claude, add co-author lines, or mention AI in commits or metadata.
- Imperative commit messages: "Add CPA rate override modal".

---

## 4. Committing & Pushing (STRICT)

- Never commit or push without explicit instruction.
- State exactly what will be committed and wait for approval.
- Never batch or auto-commit at end of session.
- Never push to any remote without explicit instruction for that push.
- Exception: CI auto-commits of `database/database.sqlite` from the CPI refresh workflow are exempt.

---

## 5. .gitignore

Ignore: build artefacts, editor files, `.DS_Store`, `Thumbs.db`, logs, `changelog.md`.

---

## 6. Changelog

- Create `changelog.md` at project root if missing. Gitignore it.
- Log every meaningful change with date and short description.
- Tags: **New Feature** · **Improvement** · **Bug Fix** · **Refactor**

---

# Security & Data

---

## 7. Secrets & Environment

- All secrets in `.env` — never hardcoded. Always gitignored. Always include `.env.example` with key names, no values.

---

## 8. Security

- All routes behind `auth` middleware. Admin routes additionally behind a role middleware (`role.admin` / `role.superadmin`) **and** an inline `abort_unless` in the controller method (defence in depth — never rely on view conditionals or middleware alone).
- Rate limit all sensitive endpoints before going live.
- Security headers on all responses.
- Server-side role checks only — never trust client-supplied role claims.
- Sensitive columns (passwords, tokens) must never appear in audit log `old_values` / `new_values`.
- **Inline password re-confirmation** required for: any user-management write (Add / Edit / Delete via `password.confirm` middleware) and every Data-control action in Settings (snapshot, clear log, delete log, delete attachments, save / reset upload limits — all use the `App\Support\PasswordConfirm::check($request)` helper which `Hash::check`s a `password` request field against the current user). The matching client side is the shared dialog in `settings/index.blade.php` (`queueForPassword($event)`).
- **Read paths** (GET) are auth-only by default. The user role is read-only on contracts (no contract export / import-template) and indices (no import-template); per-section gating sits inside the route group, not the controller.
- **Attachment downloads** are auth-only — any signed-in user can pull an attachment they hold a link to (the user role needs this to view attachments on contracts they can read). Mutating attachment endpoints (`detach`, `destroyAll`) require write access or superadmin respectively.

---

## 9. Scheduled Pipelines — Core Pattern

```
Fetch → Clean → Validate → Store → Serve
                    ↓ fail at any step
          retain last known good · log error
```

- **Idempotent.** Running twice produces the same result.
- **Never overwrite good data with bad.** Validate before writing.
- **Retry max 2×** with back-off. If both fail, abort and log — never loop.
- **Credentials in env vars only.**
- **Reuse the sanitiser.** When extending the CPI pipeline, every observation must pass through `CpiRowSanitiser` — never persist values that haven't.

---

## 10. Audit logging (STRICT)

Every write action must produce an audit log entry. Build the logging layer before building any feature that uses it.

**Every entry must capture:**

```
user_id       — who did it
action        — verb: created | updated | deleted | overridden | override_removed | login | logout
entity_type   — model or resource type (e.g. 'CpiIndexEntry', 'CpaRate')
entity_id     — the ID of the affected record (nullable for non-record actions)
old_values    — JSON snapshot before the change (null for creates)
new_values    — JSON snapshot after the change (null for deletes)
note          — override reason or free-text note if provided
ip_address    — IPv4 or IPv6
created_at    — UTC timestamp
```

**Rules:**

- Audit logs are **append-only at the row level by default**. Captured change data (`action`, `entity_*`, `old_values`, `new_values`, `note`) is never mutated.
- **Soft-delete by default for record entities.** The audit trail is the source of truth for "what happened, when, and by whom" — to keep it stable, never hard-delete records (users, contracts) from regular UI flows. Per-record deletes archive instead (frozen + hidden from primary lists, surfaced in an Archived view). Hard wipes are only available via Settings → Data control (the consolidated "Delete data" dropdown). Attachments already follow this pattern via soft-detach (`detached_at`).
- **Superadmin Data-control actions are NOT audit-logged.** The audit log is for operator (user / admin) activity on contracts and indices. A superadmin tweaking upload limits, downloading a snapshot, or wiping data is a system-administration concern — and several of those actions wipe the trail itself, so a marker row would either get deleted in the same call or appear out of context. Settings → Data control writes nothing to `audit_logs`.
- A single consolidated Data-control endpoint handles every destructive wipe: `settings.delete-data` accepts a `type` of `audit_log` · `contracts` · `indices` · `attachments` · `all`. Each branch runs in its own `DB::transaction`, requires inline password reconfirm via `App\Support\PasswordConfirm::check()`, and is double-confirmed in the UI. Apply the same shape to any future destructive Data-control action.
- Other Data-control actions (`settings.upload-limits.update`, `settings.upload-limits.reset`, `settings.database-snapshot`) also require inline password reconfirm.
- Write the log **within the same database transaction** as the action. If the action rolls back, the log rolls back with it.
- Log **before** destructive actions so `old_values` is captured before the record is gone.
- Never log raw passwords, tokens, or secrets.
- **Contract action notes are enriched** with a `[#id contract_number · route X]` prefix at write time. The audit log UI strips this prefix on display (it's redundant with the dedicated Area / Record / Key columns) but search keeps matching against the raw note column, so terms like "QC56404" or "route 236" still surface entries.
- **Attachments** ride alongside audit rows: each upload creates a 1:1 `attachments` row linked by `audit_log_id`, plus an `attachable_key` for many-per-record-item grouping (e.g. `contract:333:cpa:2024`). Detach is soft (`detached_at`); the original upload audit row stays + a new `contract_attachment_detached` row records the detach with the attachment id and filename in `old_values`, so the audit log's download link survives the detach. *(Legacy: rows written before 2026-05-12 use `contract_evidence_attached` / `contract_evidence_detached`. Both key sets are registered in `AuditActions` so historical entries still render.)*
- **Attachment archive policy.** Attachments deliberately do NOT carry a separate `archived_at` column — `detached_at` on `attachment_links` (per slot) and on `attachments` (global, only flipped when no active link remains) already provides the same "hidden from active UI but preserved for audit" semantics. The lifecycle is **active → detached → hard-deleted**, with hard-delete reachable only via `settings.delete-data` (`type=attachments` or `type=all`). When a parent contract is archived, `AttachmentsController::detachLink` 404s — archived contracts are immutable, so their attachment links can't be soft-detached either; restore the contract first if a legitimate detach is needed.
- **Attachment-only saves** (no field changed, just a new file uploaded) emit a distinct `contract_attachment_attached` action so the audit row diff isn't a misleading "Override with no changes".
- **`audit_logs.user_id` is `nullOnDelete`** — self-deletion via Profile preserves the trail. `ProfileController::destroy` writes a `user_deleted` audit row before removing the account (snapshotting name/email/role into `old_values`), and the FK then nulls so the row survives the user.

### Audit log UI vocabulary

The audit log table simplifies the underlying action keys (e.g. `contract_overridden`, `contract_cpa_confirmed`, `cpi_index_added`) to **three record statuses** — derived from `AuditActions::all()[$key]['verb']`:

- `verb = create` → **Added** (green)
- `verb = update` / `import` → **Modified** (blue)
- `verb = delete` → **Deleted** (red)

Attachment events get a separate pill on the same row, with three states detected by pairing attach + detach rows that share an `attachable_key` within a 60-second window. Both the current `contract_attachment_*` keys and the legacy `contract_evidence_*` keys are recognised:

- **Attached** (green) — standalone attach
- **Modified** (amber) — paired detach+attach (the "replace" workflow); the two underlying audit rows are merged into a single visual row showing both files side-by-side in Before / After
- **Detached** (red) — standalone detach

For non-attachment actions that ALSO carry an attachment (Override / CPA confirm / etc. with a file upload), the attachment lifecycle pill still fires — `attachable_key` is resolved via the `attachment_links` table.

Attachment-only audit rows (`contract_attachment_attached` / `contract_attachment_detached`, plus the legacy `contract_evidence_*` keys) suppress the field-by-field diff because the `attachable_key` / `attachment_id` / `filename` rows in old/new_values are pure technical noise; the dedicated Attachment row carries the meaningful information instead.

---

## 11. User Roles

Three roles: `superadmin` (singleton), `admin`, `user`. The full role matrix lives in the README. Engineering rules:

- Roles stored in the database, not hardcoded.
- Role checks always server-side. Never trust client-supplied role claims.
- The `superadmin` account cannot be demoted, deleted, frozen, or have its role changed — enforce at controller and model level.
- Admin cannot promote anyone to superadmin (singleton). Admin cannot view the superadmin's audit-log entries, login-log history, or the superadmin row in user management.
- Three middleware aliases gate routes: `can.write` (admin+), `role.admin`, `role.superadmin`. User-level capability checks via `User::canWrite()` / `canManageUsers()` / `canViewAuditLog()` / `canPurgeAuditLog()` / `canViewLoginLogs()` / `canViewSettings()`.
- **`user` role is read-only across the app:**
  - Can browse Contracts and Indices and any associated notes; can download attachments tied to contracts they can see.
  - Click-to-view: cell-pill triggers and the Edit-contract pencil ALWAYS render. The dialogs detect `canWrite()` and degrade to read-only — every input `disabled`/`readonly`, attachment-upload field hidden, attachment-detach buttons hidden, Save / Delete / Reset buttons hidden, Cancel button reads "Close".
  - Server-side enforcement matches: every mutating route is gated by `can.write` / `role.admin` / `role.superadmin` middleware; the dialog's read-only UI is purely UX (a tampered submission still 403s).
  - `user` role does NOT have access to: contract export / contract import-template / indices import-templates / audit log / users management / settings.

When adding a new write feature: route it under the appropriate middleware group (`can.write` for admin+ writes, `role.admin` for admin-only, `role.superadmin` for purges/snapshots), gate the matching UI button with `auth()->user()->can*()`, and call `abort_unless(...)` inside the controller method as defence in depth.

---

# Laravel Conventions

---

## 12. Do Things the Laravel Way

- Use `php artisan make:` commands for all new files (migrations, controllers, models, etc.).
- Use `php artisan make:class` for generic PHP classes.
- Pass `--no-interaction` to all Artisan commands.
- Use named routes and the `route()` function for all URL generation.
- Use Eloquent models, resource controllers, and Form Requests for validation.
- Use `php artisan make:test --pest {name}` for all tests. Most tests should be feature tests.
- After modifying any PHP files, run `vendor/bin/pint --dirty --format agent`.

---

## 13. Herd & Tooling

- Use `herd` CLI to manage services and PHP versions (`herd list` to discover commands).
- Use `database-query` MCP tool for read-only database queries instead of raw SQL in tinker.
- Use `database-schema` MCP tool to inspect table structure before writing migrations.
- Use `get-absolute-url` MCP tool to resolve correct URLs — always use this before sharing a URL.
- Use `search-docs` MCP tool before making code changes — do not skip this step.
- Use `browser-logs` MCP tool to read browser errors and exceptions.
- Run Artisan commands directly via CLI. Use `php artisan list` to discover commands.

---

## 14. Code Quality

- One responsibility per file. If a function does more than one thing, split it.
- Use PHP 8 constructor property promotion.
- Use explicit return type declarations and type hints for all method parameters.
- Use descriptive names: `isRegisteredForDiscounts`, not `discount()`.
- No dead code, unused functions, or commented-out blocks.
- Check for existing components to reuse before writing new ones.
- Do not create verification scripts or tinker when tests cover that functionality.
- Do not create documentation files unless explicitly requested.

---

## 15. Modularity & Scalability

The app is built feature-by-feature (Indices → Contracts → Reports → Audit log). Each feature must be self-contained so it can be built, tested, changed, or removed without touching unrelated code.

### Directory structure — one folder per feature

```
app/
  Indices/
    Controllers/
    Services/
      CpiRateService.php
      OnsReleaseScraperService.php
      OnsCpiSeriesService.php
    Models/
      CpiIndexEntry.php
      CpaRate.php
    Requests/
    Actions/
      UpdateCpiIndexAction.php
      OverrideCpaRateAction.php
  Contracts/
    Controllers/
    Services/
    Models/
    Requests/
    Actions/
  Reports/
    Controllers/
    Services/
  Audit/
    Controllers/
    Models/
      AuditLog.php

routes/
  web.php        — requires the feature route files only
  indices.php
  contracts.php
  reports.php
  audit.php
```

### Rules

- **One service class, one responsibility.** `CpiRateService` calculates rates. `OnsReleaseScraperService` scrapes ONS. They do not know about each other — the Artisan command orchestrates them.
- **Actions for all write operations.** Any operation that writes to the database and the audit log in a single transaction goes in an Action class. Controllers call Actions — they never contain business logic themselves. Example: `UpdateCpiIndexAction` handles the DB write, rate recalculation, and audit entry atomically.
- **No cross-feature model imports.** If the Reports feature needs a CPA rate, it calls a service method or queries `cpa_rates` directly — it does not import `App\Indices\Models\CpaRate`. Use service contracts or repository interfaces for cross-feature dependencies.
- **Feature routes in separate files.** Each feature has its own route file, included from `routes/web.php` via `require`. Route names are prefixed by feature: `indices.cpa`, `indices.cpi`, `contracts.index`, `reports.index`.
- **Shared infrastructure is not a feature.** The `AuditLog` model, the `AuditService`, base controllers, and shared Blade components (layout, nav, cards) live in `app/Shared/` or the default Laravel locations — not inside any feature folder.
- **Migrations stay flat.** All migrations in `database/migrations/` regardless of feature — Laravel requires this. Use descriptive names: `create_cpi_index_entries_table`, `create_cpa_rates_table`.
- **Config per feature if needed.** If a feature has configurable constants (e.g. the 0.85 RA/P2P scaling factor), store them in `config/indices.php` — not hardcoded in the service class.
- **Test per feature.** Feature tests live in `tests/Feature/Indices/`, `tests/Feature/Contracts/` etc. Unit tests for services in `tests/Unit/Indices/`. Each feature's tests are fully independent — no shared state between feature test suites.

### Adding a new feature

Before starting any new feature (e.g. Contracts), create the folder structure, the route file, and a "coming soon" controller first. Wire it into the nav. Then build the feature incrementally behind that shell. This keeps the app always in a working state.

---

# UI & Frontend

---

## 16. Frontend Design — shadcn-Inspired CSS

This project uses a custom shadcn-inspired CSS framework at `resources/css/app.css` (Geist font, HSL/CSS-variable tokens, BEM-style component classes). **No Tailwind — ever.**

Follow these rules for all Blade and CSS work:

1. **Semantic HTML.** Use the right element — `nav`, `main`, `button` (never `<div onclick>`), `<a href>` for navigation, `<form>` with `<label>` + `<input>`. Tables use `<thead>`/`<tbody>`/`<th scope="col">`.
2. **Accessibility (WCAG AA).** Every interactive element must be keyboard-reachable with visible `:focus-visible`. Provide `aria-label` for icon-only buttons, `aria-current="page"` for active nav, `role="dialog" aria-modal="true"` for modals. Form inputs always have an associated `<label>`. Colour contrast ≥ 4.5:1.
3. **BEM class naming.** `block__element--modifier`. State classes: `.is-active`, `.is-open`, `.is-loading`.
4. **Responsive by default.** Mobile-first media queries. Sidebar collapses below ~900px. Tables get horizontal scroll wrappers. Dialogs are `max-width` capped.
5. **Component-first.** Before adding a one-off styled `div`, check whether `.card`, `.btn`, `.input`, `.badge`, `.tabs`, `.dialog-content`, `.timeline` etc. already exist in `app.css`. Extend the framework rather than scattering inline styles.
6. **No Tailwind.** Do not reintroduce `tailwindcss`, `@tailwindcss/forms`, `postcss`, or any Tailwind utility classes.

**Button variants (five only — never invent new ones):**

- `.btn--default` — filled primary (black on white in light mode); the page-level main CTA
- `.btn--secondary` — bordered, white fill; export/import-style actions in `page__actions`
- `.btn--ghost` — no border or fill; subtle row actions and dialog tertiary buttons (e.g. "Reset to ONS")
- `.btn--destructive` — red; only for irreversible actions (e.g. account deletion)
- `.btn--link` — text-only with subtle underline; used inside auth views ("Forgot password?", "Sign up")

**Size modifiers:** `.btn--sm` (28 px height), default (32 px). Combine with `.btn--block` for full-width (auth submits).

**Header actions pattern:** the right side of `page__header` (`page__actions`) takes the page-level CTAs. Convention from the design reference: secondary buttons (Export, Import) followed by the primary action (Add month / New contract / Recalculate) on the far right. Each carries an SVG `.btn__icon` plus a label — never icon-only at this level.

**Alpine.js** is acceptable for small UI interactions (modals, tab switching, disclosure). No other JavaScript frameworks.

---

## 17. CSS Architecture

- BEM (`block__element--modifier`) for all project-specific class names.
- No inline styles. All styling through the token and class system.
- Flat, predictable selectors. Never style based on DOM position or descendant chains.
- Use `color-mix()` for hover/active/disabled states — never create a new token for a one-off.

---

## 18. Responsive

- Mobile-first. Base styles target smallest viewport; breakpoints add or override.
- Flex and grid for layout. `gap` for spacing. `clamp()` for fluid type and spacing.
- Respect `prefers-reduced-motion` and `prefers-color-scheme`.
- Use `dvh` / safe-area-inset for full-viewport surfaces (sidebar, dialogs) so OS taskbars don't overlap content.

---

# Shipping

---

## 19. Pre-Commit Checks

- No console errors.
- All tests pass: `php artisan test --compact`.
- PHP formatted: `vendor/bin/pint --dirty --format agent`.

===

<laravel-boost-guidelines>
=== foundation rules ===

# Laravel Boost Guidelines

The Laravel Boost guidelines are specifically curated by Laravel maintainers for this application. These guidelines should be followed closely to ensure the best experience when building Laravel applications.

## Foundational Context

This application is a Laravel application and its main Laravel ecosystems package & versions are below. You are an expert with them all. Ensure you abide by these specific packages & versions.

- php - 8.4
- laravel/framework (LARAVEL) - v13
- laravel/prompts (PROMPTS) - v0
- laravel/boost (BOOST) - v2
- laravel/breeze (BREEZE) - v2
- laravel/mcp (MCP) - v0
- laravel/pail (PAIL) - v1
- laravel/pint (PINT) - v1
- pestphp/pest (PEST) - v4
- phpunit/phpunit (PHPUNIT) - v12
- alpinejs (ALPINEJS) - v3

## Skills Activation

This project has domain-specific skills available in `**/skills/**`. You MUST activate the relevant skill whenever you work in that domain—don't wait until you're stuck.

## Conventions

- You must follow all existing code conventions used in this application. When creating or editing a file, check sibling files for the correct structure, approach, and naming.
- Use descriptive names for variables and methods. For example, `isRegisteredForDiscounts`, not `discount()`.
- Check for existing components to reuse before writing a new one.

## Verification Scripts

- Do not create verification scripts or tinker when tests cover that functionality and prove they work. Unit and feature tests are more important.

## Application Structure & Architecture

- Stick to existing directory structure; don't create new base folders without approval.
- Do not change the application's dependencies without approval.

## Frontend Bundling

- If the user doesn't see a frontend change reflected in the UI, it could mean they need to run `npm run build`, `npm run dev`, or `composer run dev`. Ask them.

## Documentation Files

- You must only create documentation files if explicitly requested by the user.

## Replies

- Be concise in your explanations - focus on what's important rather than explaining obvious details.

=== boost rules ===

# Laravel Boost

## Tools

- Laravel Boost is an MCP server with tools designed specifically for this application. Prefer Boost tools over manual alternatives like shell commands or file reads.
- Use `database-query` to run read-only queries against the database instead of writing raw SQL in tinker.
- Use `database-schema` to inspect table structure before writing migrations or models.
- Use `get-absolute-url` to resolve the correct scheme, domain, and port for project URLs. Always use this before sharing a URL with the user.
- Use `browser-logs` to read browser logs, errors, and exceptions. Only recent logs are useful, ignore old entries.

## Searching Documentation (IMPORTANT)

- Always use `search-docs` before making code changes. Do not skip this step. It returns version-specific docs based on installed packages automatically.
- Pass a `packages` array to scope results when you know which packages are relevant.
- Use multiple broad, topic-based queries: `['rate limiting', 'routing rate limiting', 'routing']`. Expect the most relevant results first.
- Do not add package names to queries because package info is already shared. Use `test resource table`, not `filament 4 test resource table`.

### Search Syntax

1. Use words for auto-stemmed AND logic: `rate limit` matches both "rate" AND "limit".
2. Use `"quoted phrases"` for exact position matching: `"infinite scroll"` requires adjacent words in order.
3. Combine words and phrases for mixed queries: `middleware "rate limit"`.
4. Use multiple queries for OR logic: `queries=["authentication", "middleware"]`.

## Artisan

- Run Artisan commands directly via the command line (e.g., `php artisan route:list`). Use `php artisan list` to discover available commands and `php artisan [command] --help` to check parameters.
- Inspect routes with `php artisan route:list`. Filter with: `--method=GET`, `--name=users`, `--path=api`, `--except-vendor`, `--only-vendor`.
- Read configuration values using dot notation: `php artisan config:show app.name`, `php artisan config:show database.default`. Or read config files directly from the `config/` directory.
- To check environment variables, read the `.env` file directly.

## Tinker

- Execute PHP in app context for debugging and testing code. Do not create models without user approval, prefer tests with factories instead. Prefer existing Artisan commands over custom tinker code.
- Always use single quotes to prevent shell expansion: `php artisan tinker --execute 'Your::code();'`
  - Double quotes for PHP strings inside: `php artisan tinker --execute 'User::where("active", true)->count();'`

=== php rules ===

# PHP

- Always use curly braces for control structures, even for single-line bodies.
- Use PHP 8 constructor property promotion: `public function __construct(public GitHub $github) { }`. Do not leave empty zero-parameter `__construct()` methods unless the constructor is private.
- Use explicit return type declarations and type hints for all method parameters: `function isAccessible(User $user, ?string $path = null): bool`
- Use TitleCase for Enum keys: `FavoritePerson`, `BestLake`, `Monthly`.
- Prefer PHPDoc blocks over inline comments. Only add inline comments for exceptionally complex logic.
- Use array shape type definitions in PHPDoc blocks.

=== deployments rules ===

# Deployment

- Laravel can be deployed using [Laravel Cloud](https://cloud.laravel.com/), which is the fastest way to deploy and scale production Laravel applications.

=== herd rules ===

# Laravel Herd

- The application is served by Laravel Herd at `https?://[kebab-case-project-dir].test`. Use the `get-absolute-url` tool to generate valid URLs. Never run commands to serve the site. It is always available.
- Use the `herd` CLI to manage services, PHP versions, and sites (e.g. `herd sites`, `herd services:start <service>`, `herd php:list`). Run `herd list` to discover all available commands.

=== tests rules ===

# Test Enforcement

- Every change must be programmatically tested. Write a new test or update an existing test, then run the affected tests to make sure they pass.
- Run the minimum number of tests needed to ensure code quality and speed. Use `php artisan test --compact` with a specific filename or filter.

=== laravel/core rules ===

# Do Things the Laravel Way

- Use `php artisan make:` commands to create new files (i.e. migrations, controllers, models, etc.). You can list available Artisan commands using `php artisan list` and check their parameters with `php artisan [command] --help`.
- If you're creating a generic PHP class, use `php artisan make:class`.
- Pass `--no-interaction` to all Artisan commands to ensure they work without user input. You should also pass the correct `--options` to ensure correct behavior.

### Model Creation

- When creating new models, create useful factories and seeders for them too. Ask the user if they need any other things, using `php artisan make:model --help` to check the available options.

## APIs & Eloquent Resources

- For APIs, default to using Eloquent API Resources and API versioning unless existing API routes do not, then you should follow existing application convention.

## URL Generation

- When generating links to other pages, prefer named routes and the `route()` function.

## Testing

- When creating models for tests, use the factories for the models. Check if the factory has custom states that can be used before manually setting up the model.
- Faker: Use methods such as `$this->faker->word()` or `fake()->randomDigit()`. Follow existing conventions whether to use `$this->faker` or `fake()`.
- When creating tests, make use of `php artisan make:test [options] {name}` to create a feature test, and pass `--unit` to create a unit test. Most tests should be feature tests.

## Vite Error

- If you receive an "Illuminate\Foundation\ViteException: Unable to locate file in Vite manifest" error, you can run `npm run build` or ask the user to run `npm run dev` or `composer run dev`.

=== pint/core rules ===

# Laravel Pint Code Formatter

- If you have modified any PHP files, you must run `vendor/bin/pint --dirty --format agent` before finalizing changes to ensure your code matches the project's expected style.
- Do not run `vendor/bin/pint --test --format agent`, simply run `vendor/bin/pint --format agent` to fix any formatting issues.

=== pest/core rules ===

## Pest

- This project uses Pest for testing. Create tests: `php artisan make:test --pest {name}`.
- The `{name}` argument should not include the test suite directory. Use `php artisan make:test --pest SomeFeatureTest` instead of `php artisan make:test --pest Feature/SomeFeatureTest`.
- Run tests: `php artisan test --compact` or filter: `php artisan test --compact --filter=testName`.
- Do NOT delete tests without approval.

</laravel-boost-guidelines>
