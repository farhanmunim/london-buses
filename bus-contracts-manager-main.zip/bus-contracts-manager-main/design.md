# Design Language — shadcn / SaaS-inspired CSS Framework

A portable, framework-agnostic design system distilled from the Bus Contracts Manager app. **No Tailwind.** Pure CSS with custom properties (tokens) and strict BEM naming. Light + dark theme via `data-theme="dark"` on `<html>`. Geist font. Fluid, responsive, accessible (WCAG AA).

This document is the spec — copy the token block verbatim, then implement components against the rules below.

---

## 1. Core principles

1. **Tokens first.** Every colour, radius, spacing, shadow, and font-size is a CSS variable on `:root`. Components reference tokens, never raw values. Dark mode is a token flip — components don't change.
2. **BEM naming.** `.block`, `.block__element`, `.block--modifier`, `.is-state`. Flat selectors. Never style by DOM position or descendant chains.
3. **No utility-first CSS.** No Tailwind. A small set of helper classes (`.flex`, `.gap-2`, `.mt-2`, `.text-muted`) is allowed, but layout belongs in components.
4. **Semantic HTML.** Real `<button>`, `<a href>`, `<nav>`, `<main>`, `<th scope="col">`. Never `<div onclick>`.
5. **Accessibility is non-negotiable.** Visible `:focus-visible` rings, `aria-label` on icon-only buttons, `aria-current="page"` on active nav, `role="dialog" aria-modal="true"` on modals, contrast ≥ 4.5:1.
6. **Mobile-first, fluid.** `clamp()` for type and spacing, `auto-fit minmax()` for grids, `dvh` over `vh`, respect `prefers-reduced-motion` and `prefers-color-scheme`.
7. **Five button variants only.** `default`, `secondary`, `ghost`, `destructive`, `link`. Never invent new ones.
8. **Subtle elevation, generous whitespace.** Hairline borders (1 px), shadows are nearly imperceptible. Rely on `--color-surface` / `--color-surface-2` tiering rather than heavy shadows.

---

## 2. Tokens (copy verbatim)

```css
:root {
    /* -- colour -- */
    --color-bg: #ffffff;
    --color-surface: #ffffff;
    --color-surface-2: #f7f7f8;
    --color-surface-3: #f2f2f3;

    --color-border: #ececee;
    --color-border-strong: #dcdce0;

    --color-text: #0a0a0a;
    --color-text-muted: #5f5f63;
    --color-text-soft: #8a8a90;

    --color-accent: #0a0a0a;          /* primary CTA fill */
    --color-accent-hover: #1f1f1f;
    --color-on-accent: #ffffff;

    --color-blue: #2563eb;
    --color-blue-soft: #eff4ff;
    --color-green: #16a34a;
    --color-green-soft: #f0fdf4;
    --color-amber: #d97706;
    --color-amber-soft: #fef9ec;
    --color-red: #dc2626;
    --color-red-soft: #fef2f2;

    /* focus ring (faint, theme-aware) */
    --ring: rgba(0, 0, 0, 0.06);
    --ring-soft: rgba(0, 0, 0, 0.04);

    /* -- elevation -- */
    --shadow-xs: 0 1px 2px rgba(0, 0, 0, 0.04);
    --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.06), 0 1px 2px rgba(0, 0, 0, 0.04);
    --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1);

    /* -- radius -- */
    --radius-xs: 4px;
    --radius-sm: 6px;
    --radius-md: 8px;
    --radius-lg: 10px;
    --radius-pill: 9999px;

    /* -- spacing (4-px base) -- */
    --space-0: 0;
    --space-1: 4px;
    --space-2: 8px;
    --space-3: 12px;
    --space-4: 16px;
    --space-5: 20px;
    --space-6: 24px;
    --space-8: 32px;
    --space-10: 40px;
    --space-12: 48px;
    --space-16: 64px;

    /* -- fluid type (clamp: min, preferred, max) -- */
    --text-xs:   clamp(11px,    0.6875rem + 0.1vw,  12px);
    --text-sm:   clamp(12.5px,  0.78rem   + 0.1vw,  13.5px);
    --text-base: clamp(13.5px,  0.84rem   + 0.1vw,  14.5px);
    --text-md:   clamp(14px,    0.875rem  + 0.15vw, 15px);
    --text-lg:   clamp(15px,    0.9375rem + 0.2vw,  16.5px);
    --text-xl:   clamp(17px,    1.05rem   + 0.2vw,  18px);
    --text-2xl:  clamp(20px,    1.1rem    + 0.6vw,  24px);
    --text-3xl:  clamp(24px,    1.4rem    + 0.8vw,  30px);

    /* -- layout -- */
    --sidebar-width: clamp(208px, 18vw, 240px);
    --topbar-height: 52px;
    --page-max: 1400px;
    --page-pad: clamp(var(--space-3), 1.5vw + 8px, var(--space-6));

    /* -- motion -- */
    --transition-fast: 0.12s ease;
    --transition-base: 0.18s ease;

    /* -- typography -- */
    --font-sans: 'Geist', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    --font-mono: 'Geist Mono', ui-monospace, 'SF Mono', Menlo, monospace;
}

:root[data-theme="dark"] {
    --color-bg: #0a0a0a;
    --color-surface: #0f0f10;
    --color-surface-2: #161618;
    --color-surface-3: #1f1f23;

    --color-border: #262629;
    --color-border-strong: #38383d;

    --color-text: #fafafa;
    --color-text-muted: #d4d4d8;
    --color-text-soft: #a1a1aa;

    --color-accent: #fafafa;          /* flipped: white CTA on dark */
    --color-accent-hover: #e4e4e7;
    --color-on-accent: #0a0a0a;

    --color-blue: #60a5fa;   --color-blue-soft: #172554;
    --color-green: #4ade80;  --color-green-soft: #14532d;
    --color-amber: #fbbf24;  --color-amber-soft: #451a03;
    --color-red: #dc2626;    --color-red-soft: #450a0a;   /* red kept dark-mode-safe for AA */

    --ring: rgba(255, 255, 255, 0.12);
    --ring-soft: rgba(255, 255, 255, 0.08);

    --shadow-xs: 0 1px 2px rgba(0, 0, 0, 0.4);
    --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.5), 0 1px 2px rgba(0, 0, 0, 0.3);
    --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.5);
    --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.6);
}
```

### Token usage rules

- **Surface tiering.** `--color-bg` is the page canvas. `--color-surface` is cards / inputs / dialogs. `--color-surface-2` is hover and table header tints. `--color-surface-3` is the deepest tier (sidebar hover, ghost button hover).
- **Borders.** Default to `--color-border` (hairline). Step up to `--color-border-strong` on hover/focus.
- **Text.** Three tiers: `--color-text` (primary), `--color-text-muted` (secondary, labels, hints), `--color-text-soft` (tertiary, placeholders, meta).
- **Brand hues.** Always pair the bright `--color-X` with `--color-X-soft` (foreground on background). Used in badges, alerts, status pills.
- **Hover via `color-mix`.** For one-off shaded states, write `color-mix(in oklab, var(--color-red) 85%, black)` rather than introducing a new token.
- **Never hardcode hex values inside components.** Only inside `:root` / `:root[data-theme="dark"]`.

---

## 3. Reset & base

```css
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
    background: var(--color-bg);
    color: var(--color-text);
    font-family: var(--font-sans);
    font-size: var(--text-base);
    line-height: 1.5;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    min-height: 100dvh;
}

a { color: inherit; text-decoration: none; }
button { font: inherit; cursor: pointer; border: 0; background: none; color: inherit; padding: 0; }
ul, ol { list-style: none; }
table { border-collapse: collapse; border-spacing: 0; }
img, svg { display: block; max-width: 100%; }

@media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
        animation-duration: 0.01ms !important;
        transition-duration: 0.01ms !important;
        scroll-behavior: auto !important;
    }
}

/* Universal keyboard-only focus */
:where(a, button, [role='button'], input, select, textarea, [tabindex]):focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
    border-radius: var(--radius-sm);
}
```

Inline pre-paint script in `<head>` to avoid flash-of-light-theme:

```html
<script>
  (function() {
    var t = localStorage.getItem('theme');
    if (t === 'dark' || (!t && matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.setAttribute('data-theme', 'dark');
    }
  })();
</script>
```

---

## 4. Typography

- **Family:** Geist (sans) + Geist Mono. Load via `@font-face` or a CDN. System fallback stack already in the token.
- **Scale:** use the `--text-*` clamp tokens; never write raw `px` for font-size.
- **Weight:** body 400, UI controls 500, headings 600. Avoid 700.
- **Letter-spacing:** `-0.015em` on `--text-2xl` and up, `-0.01em` on titles, `0.04em` uppercased eyebrows (sidebar section labels).
- **Tabular numerals:** `font-variant-numeric: tabular-nums` on any column of numbers — stats values, table `.num` cells, pagination, meta.
- **Monospace:** ID tokens (`.id-token`), code chips (`.code-token`), `chip__count`.

```css
.page__title  { font-size: var(--text-2xl); font-weight: 600; letter-spacing: -0.015em; line-height: 1.2; }
.card__title  { font-size: var(--text-base); font-weight: 600; letter-spacing: -0.01em; }
.dialog__title{ font-size: var(--text-lg);  font-weight: 600; letter-spacing: -0.01em; line-height: 1.4; }
```

---

## 5. Layout primitives

### App shell

A two-column CSS grid: sticky sidebar + scrollable main.

```css
.app {
    display: grid;
    grid-template-columns: var(--sidebar-width) minmax(0, 1fr);
    min-height: 100dvh;
}
.app--guest { grid-template-columns: 1fr; }  /* auth pages */

.main { min-width: 0; display: flex; flex-direction: column; }
```

### Topbar

Sticky, translucent, backdrop-blurred. Contains breadcrumbs + meta.

```css
.topbar {
    display: flex; align-items: center; gap: var(--space-3);
    padding: 10px var(--space-6);
    border-bottom: 1px solid var(--color-border);
    background: color-mix(in oklab, var(--color-bg) 85%, transparent);
    position: sticky; top: 0; z-index: 10;
    backdrop-filter: blur(8px);
    height: var(--topbar-height);
}
```

### Page

```css
.page {
    padding: var(--page-pad);
    max-width: var(--page-max);
    width: 100%;
    margin-inline: auto;
}
.page__header {
    display: flex; align-items: flex-start; justify-content: space-between;
    gap: var(--space-6); margin-bottom: var(--space-8); flex-wrap: wrap;
}
.page__actions { display: flex; gap: var(--space-2); flex-wrap: wrap; align-items: center; }
```

**Header actions pattern:** secondary buttons (Export, Import) on the left of `page__actions`, primary CTA on the far right. Each carries an SVG `.btn__icon` plus a label — never icon-only at page level.

---

## 6. Buttons

**Five variants only. Never invent new ones.**

| Variant | Purpose |
|---|---|
| `.btn--default` | Filled primary. Page main CTA (one per page). |
| `.btn--secondary` | Bordered, white fill. Export/Import-style actions. |
| `.btn--ghost` | No border or fill. Subtle row actions, dialog tertiary buttons. |
| `.btn--destructive` | Red fill. Irreversible actions only. |
| `.btn--link` | Underlined text. Inside auth views and inline prose. |

Sizes: default 32 px, `.btn--sm` 28 px. `.btn--block` for full-width (auth submits).

```css
.btn {
    display: inline-flex; align-items: center; justify-content: center;
    gap: 6px;
    padding: 7px 12px;
    border-radius: var(--radius-sm);
    font-size: 13px; font-weight: 500;
    transition: all var(--transition-fast);
    border: 1px solid transparent;
    white-space: nowrap;
    height: 32px;
    background: transparent;
    color: var(--color-text);
}
.btn:disabled, .btn[aria-disabled='true'] { opacity: 0.5; pointer-events: none; }
.btn__icon { width: 14px; height: 14px; stroke-width: 2; }

.btn--default    { background: var(--color-accent); color: var(--color-on-accent); box-shadow: var(--shadow-xs); }
.btn--default:hover { background: var(--color-accent-hover); }

.btn--secondary  { background: var(--color-surface); border-color: var(--color-border); box-shadow: var(--shadow-xs); }
.btn--secondary:hover { background: var(--color-surface-2); border-color: var(--color-border-strong); }

.btn--ghost      { color: var(--color-text-muted); }
.btn--ghost:hover{ background: var(--color-surface-2); color: var(--color-text); }

.btn--destructive{ background: var(--color-red); color: white; }
.btn--destructive:hover { background: color-mix(in oklab, var(--color-red) 85%, black); }

.btn--link {
    height: auto; padding: 0;
    text-decoration: underline; text-underline-offset: 0.25em;
    text-decoration-color: var(--color-border-strong);
    color: var(--color-text);
}
.btn--link:hover { text-decoration-color: var(--color-text); }

.btn--sm { height: 28px; padding: 4px 10px; font-size: 12.5px; }
```

---

## 7. Inputs & forms

```css
.input, .select, .textarea {
    display: block; width: 100%;
    height: 32px; padding: 0 10px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--color-border);
    background: var(--color-surface);
    color: var(--color-text);
    font-size: 13px;
    transition: all var(--transition-fast);
    outline: 0;
}
.textarea { height: auto; padding: var(--space-2) 10px; line-height: 1.5; resize: vertical; min-height: 64px; }
.input:focus, .select:focus, .textarea:focus {
    border-color: var(--color-border-strong);
    box-shadow: 0 0 0 3px var(--ring-soft);
}
.input::placeholder, .textarea::placeholder { color: var(--color-text-soft); }
.input:disabled, .select:disabled, .textarea:disabled { opacity: 0.5; cursor: not-allowed; }

.label   { display: inline-block; font-size: 13px; font-weight: 500; line-height: 1; margin-bottom: 6px; }
.field   { display: flex; flex-direction: column; }
.field__hint  { font-size: 12px; color: var(--color-text-soft); margin-top: var(--space-1); }
.field__error { font-size: 12px; color: var(--color-red); margin-top: var(--space-1); }
```

Auto-mark required fields with a red asterisk:

```css
.field:has(input[required], select[required], textarea[required]) > .label::after {
    content: ' *'; color: var(--color-red); font-weight: 600;
}
```

### Dropzone (file upload)

Dashed border on a subtly tinted surface. The native `<input type="file">` is `.sr-only` but still keyboard-focusable.

```css
.dropzone {
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    gap: 4px;
    padding: 20px var(--space-4);
    border: 1.5px dashed var(--color-border-strong);
    border-radius: var(--radius-md);
    background: var(--color-surface-2);
    color: var(--color-text-muted);
    cursor: pointer; text-align: center;
    transition: background var(--transition-fast), border-color var(--transition-fast);
}
.dropzone:hover { background: var(--color-surface-3); border-color: var(--color-text-soft); }
.dropzone:focus-within { border-color: var(--color-text); background: var(--color-surface); }
.dropzone--has-file { border-color: var(--color-green); background: var(--color-green-soft); }
```

---

## 8. Sidebar

A vertical, sticky column. Brand mark on top, grouped nav sections, user card pinned to bottom.

```css
.sidebar {
    background: var(--color-surface-2);
    border-right: 1px solid var(--color-border);
    padding: var(--space-4) var(--space-3) calc(var(--space-4) + env(safe-area-inset-bottom, 0px));
    display: flex; flex-direction: column;
    position: sticky; top: 0;
    height: 100dvh;
    gap: var(--space-1);
    overflow-y: auto;
    overscroll-behavior: contain;
}

.sidebar__brand-mark {
    width: 28px; height: 28px;
    background: var(--color-accent); color: var(--color-on-accent);
    border-radius: var(--radius-sm);
    display: flex; align-items: center; justify-content: center;
    font-weight: 600; font-size: 11px; letter-spacing: -0.02em;
}

.sidebar__section-label {
    font-size: 11px; font-weight: 500; color: var(--color-text-soft);
    padding: var(--space-2) 10px var(--space-1);
    text-transform: uppercase; letter-spacing: 0.04em;
}

.sidebar__nav-item {
    display: flex; align-items: center; gap: 10px;
    padding: 6px 10px;
    border-radius: var(--radius-sm);
    font-size: 13px; font-weight: 500;
    color: var(--color-text-muted);
    transition: all var(--transition-fast);
    width: 100%; text-align: left;
}
.sidebar__nav-item:hover { background: var(--color-surface-3); color: var(--color-text); }
.sidebar__nav-item.is-active {
    background: var(--color-surface);
    color: var(--color-text);
    box-shadow: var(--shadow-xs);
}
.sidebar__nav-icon { width: 15px; height: 15px; flex-shrink: 0; stroke-width: 1.75; }
```

Sub-nav: indent 24 px with a 1 px left border that doubles as a hierarchy rail.

---

## 9. Cards

```css
.card {
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    overflow: hidden;
}
.card__header {
    padding: 14px var(--space-4);
    border-bottom: 1px solid var(--color-border);
    display: flex; align-items: center; justify-content: space-between;
    gap: var(--space-4); flex-wrap: wrap;
}
.card__title    { font-size: var(--text-base); font-weight: 600; letter-spacing: -0.01em; }
.card__subtitle { font-size: 12.5px; color: var(--color-text-muted); margin-top: 2px; }
.card__body     { padding: var(--space-4); }
.card__footer   { padding: var(--space-3) var(--space-4); border-top: 1px solid var(--color-border); }
.card__footer--split { display: flex; align-items: center; justify-content: space-between; gap: var(--space-3); flex-wrap: wrap; }
.card__footer--end   { display: flex; justify-content: flex-end; }
```

Destructive variant (subtle red ring around a card housing an irreversible action):

```css
.card--destructive { border-color: color-mix(in srgb, var(--color-red) 35%, var(--color-border)); }
.card--destructive .card__header { border-bottom-color: color-mix(in srgb, var(--color-red) 18%, var(--color-border)); }
.card--destructive .card__footer {
    border-top-color: color-mix(in srgb, var(--color-red) 18%, var(--color-border));
    background: color-mix(in srgb, var(--color-red) 4%, var(--color-surface));
}
```

---

## 10. Stats

Auto-fit grid of compact metric cards.

```css
.stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: var(--space-3);
    margin-bottom: var(--space-8);
}
.stat {
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    padding: 14px var(--space-4);
}
.stat__label { font-size: 12.5px; color: var(--color-text-muted); margin-bottom: 6px; font-weight: 500; }
.stat__value {
    font-size: var(--text-2xl); font-weight: 600;
    letter-spacing: -0.02em; line-height: 1.1;
    font-variant-numeric: tabular-nums;
}
.stat__meta  { font-size: 12px; color: var(--color-text-soft); margin-top: var(--space-1); }
.stat__delta--up   { color: var(--color-green); font-weight: 500; }
.stat__delta--down { color: var(--color-red);   font-weight: 500; }
```

---

## 11. Tables

Toolbar on top, table inside `.table-wrap`, optional footer. Numeric columns get `.num` (right-aligned tabular).

```css
.toolbar {
    display: flex; align-items: center; gap: var(--space-2);
    padding: 10px var(--space-3);
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-bottom: 0;
    border-radius: var(--radius-md) var(--radius-md) 0 0;
    flex-wrap: wrap;
}
.table-wrap {
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: 0 0 var(--radius-md) var(--radius-md);
    overflow: hidden;
    width: 100%;
}
.table-scroll { overflow-x: auto; width: 100%; }
.table { width: 100%; font-size: 13px; }

.table thead th {
    text-align: left; padding: var(--space-2) 14px;
    font-size: 12px; font-weight: 500;
    color: var(--color-text-muted);
    border-bottom: 1px solid var(--color-border);
    background: var(--color-surface-2);
    white-space: nowrap; height: 36px;
}
.table th.num, .table td.num { text-align: right; font-variant-numeric: tabular-nums; }
.table tbody tr        { transition: background var(--transition-fast); }
.table tbody tr:hover  { background: var(--color-surface-2); }
.table tbody tr + tr td{ border-top: 1px solid var(--color-border); }
.table tbody td        { padding: var(--space-3) 14px; vertical-align: middle; white-space: nowrap; }

.table-footer {
    display: flex; align-items: center; justify-content: space-between;
    padding: 10px 14px;
    border-top: 1px solid var(--color-border);
    background: var(--color-surface);
    font-size: 12.5px; color: var(--color-text-muted);
    gap: var(--space-3); flex-wrap: wrap;
}
```

For sticky-header tall tables, use `overflow-y: auto; max-height: clamp(420px, 65dvh, 720px);` on the scroller and `position: sticky; top: 0; z-index: 2; background: var(--color-surface);` on `thead th`.

---

## 12. Badges

Pill-shaped, soft background + bright foreground. Optional dot prefix.

```css
.badge {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 2px var(--space-2);
    border-radius: var(--radius-pill);
    font-size: 11.5px; font-weight: 500;
    border: 1px solid transparent;
    line-height: 1.4;
}
.badge--with-dot::before {
    content: ''; width: 5px; height: 5px;
    border-radius: 50%; background: currentColor;
    flex-shrink: 0;
}
.badge--success    { background: var(--color-green-soft); color: var(--color-green); }
.badge--warning    { background: var(--color-amber-soft); color: var(--color-amber); }
.badge--info       { background: var(--color-blue-soft);  color: var(--color-blue); }
.badge--destructive{ background: var(--color-red-soft);   color: var(--color-red); }
.badge--neutral    { background: var(--color-surface-2);  color: var(--color-text-muted); border-color: var(--color-border); }
.badge--sm         { padding: 1px 6px; font-size: 10.5px; }
```

### Chips (filter/segmented controls)

```css
.chip {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 5px 10px;
    border-radius: var(--radius-sm);
    font-size: 12.5px; font-weight: 500;
    color: var(--color-text-muted);
    transition: all var(--transition-fast);
    height: 28px;
    border: 1px solid transparent;
}
.chip:hover, .chip.is-active { background: var(--color-surface-2); color: var(--color-text); }
.chip__count { color: var(--color-text-soft); font-family: var(--font-mono); font-size: 11px; }
.chip--outline { border-color: var(--color-border); background: var(--color-surface); }
.chip--outline:hover { border-color: var(--color-border-strong); }
```

---

## 13. Tabs

Bottom-bordered, 2 px active underline in the accent colour.

```css
.tabs {
    display: flex; gap: 0;
    border-bottom: 1px solid var(--color-border);
    margin-bottom: var(--space-6);
    flex-wrap: wrap;
}
.tabs__item {
    padding: var(--space-2) var(--space-3);
    font-size: 13px; font-weight: 500;
    color: var(--color-text-muted);
    border-bottom: 2px solid transparent;
    margin-bottom: -1px;
    transition: all var(--transition-fast);
    white-space: nowrap;
    background: transparent; cursor: pointer;
}
.tabs__item:hover { color: var(--color-text); }
.tabs__item.is-active { color: var(--color-text); border-bottom-color: var(--color-accent); }
```

---

## 14. Dialog / modal

Fixed-center, 480 px default, scrollable body, dimmed + blurred overlay.

```css
.dialog__overlay {
    position: fixed; inset: 0; z-index: 50;
    background: rgba(0, 0, 0, 0.4);
    backdrop-filter: blur(2px);
}
.dialog__content {
    position: fixed; z-index: 51;
    left: 50%; top: 50%; transform: translate(-50%, -50%);
    width: min(calc(100% - 2rem), 480px);
    background: var(--color-surface); color: var(--color-text);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-lg);
    padding: var(--space-5);
    max-height: calc(100dvh - 2rem - env(safe-area-inset-bottom, 0px));
    overflow-y: auto;
}
.dialog__content--lg { width: min(calc(100% - 2rem), 560px); }

.dialog__title       { font-size: var(--text-lg); font-weight: 600; letter-spacing: -0.01em; line-height: 1.4; }
.dialog__description { font-size: 12.5px; color: var(--color-text-muted); margin-top: var(--space-1); }
.dialog__body        { margin-top: var(--space-4); display: flex; flex-direction: column; gap: var(--space-3); }
.dialog__footer      { margin-top: var(--space-5); display: flex; gap: var(--space-2); justify-content: flex-end; flex-wrap: wrap; }
.dialog__footer--split { justify-content: space-between; }
```

A11y: `role="dialog" aria-modal="true" aria-labelledby="dialog-title-id"`. Trap focus, restore on close, close on `Escape`.

---

## 15. Dropdown menu

Lightweight popover. Anchored under (or above with `--up`) its trigger.

```css
.dropdown { position: relative; }
.dropdown__menu {
    position: absolute; z-index: 30;
    min-width: 180px;
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    padding: var(--space-1);
    box-shadow: var(--shadow-md);
    margin-top: var(--space-1);
}
.dropdown__menu--up   { bottom: calc(100% + var(--space-1)); margin-top: 0; }
.dropdown__menu--full { left: 0; right: 0; min-width: 0; }

.dropdown__item {
    display: flex; align-items: center; gap: var(--space-2);
    padding: 6px var(--space-2);
    border-radius: var(--radius-xs);
    font-size: 13px; color: var(--color-text);
    width: 100%; text-align: left;
    background: transparent;
}
.dropdown__item:hover { background: var(--color-surface-2); }
.dropdown__separator  { height: 1px; margin: var(--space-1) calc(-1 * var(--space-1)); background: var(--color-border); }
```

---

## 16. Alerts

```css
.alert {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 14px;
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    background: var(--color-surface);
    font-size: 13px;
    margin-bottom: var(--space-4);
}
.alert--success     { background: var(--color-green-soft); border-color: rgba(22,163,74,0.2); color: var(--color-green); }
.alert--destructive { background: var(--color-red-soft);   border-color: rgba(220,38,38,0.2); color: var(--color-red); }
.alert--warning {
    background: color-mix(in oklab, var(--color-amber) 12%, var(--color-surface));
    border-color: color-mix(in oklab, var(--color-amber) 30%, var(--color-border));
    color: var(--color-amber);
}
```

---

## 17. Empty state

```css
.empty-state {
    border: 1px dashed var(--color-border);
    border-radius: var(--radius-md);
    padding: var(--space-16) var(--space-8);
    text-align: center;
    background: var(--color-surface);
}
.empty-state__icon  { height: 36px; width: 36px; margin: 0 auto var(--space-3); color: var(--color-text-soft); }
.empty-state__title { font-size: var(--text-base); font-weight: 600; }
.empty-state__description { color: var(--color-text-muted); margin-top: var(--space-1); font-size: 13px; }
```

---

## 18. Pagination

```css
.pagination { display: flex; gap: 2px; align-items: center; }
.pagination a, .pagination span {
    min-width: 26px; height: 26px; padding: 0 6px;
    display: inline-flex; align-items: center; justify-content: center;
    border-radius: var(--radius-xs);
    color: var(--color-text-muted);
    font-size: 12px; font-weight: 500;
}
.pagination a:hover { background: var(--color-surface-2); }
.pagination .is-active { background: var(--color-surface-2); color: var(--color-text); }
```

---

## 19. Helper / utility classes

Keep this set small. Anything bigger belongs in a component.

```css
.sr-only       { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0; }

.is-tabular, .num    { font-variant-numeric: tabular-nums; }
.is-mono             { font-family: var(--font-mono); }
.text-muted, .muted  { color: var(--color-text-muted); }
.text-soft           { color: var(--color-text-soft); }
.text-success        { color: var(--color-green); }
.text-destructive    { color: var(--color-red); }

.text-xs   { font-size: var(--text-xs); }
.text-sm   { font-size: var(--text-sm); }
.text-base { font-size: var(--text-base); }
.text-lg   { font-size: var(--text-lg); }
.text-xl   { font-size: var(--text-xl); }

.flex        { display: flex; }
.inline-flex { display: inline-flex; }
.items-center{ align-items: center; }
.gap-2 { gap: var(--space-2); }
.gap-3 { gap: var(--space-3); }
.mt-1  { margin-top: var(--space-1); }
.mt-2  { margin-top: var(--space-2); }
.mb-2  { margin-bottom: var(--space-2); }
.mb-4  { margin-bottom: var(--space-4); }
.space-y-3 > * + * { margin-top: var(--space-3); }
.space-y-4 > * + * { margin-top: var(--space-4); }
```

### Code/ID tokens

```css
.id-token   { font-family: var(--font-mono); font-size: 11.5px; color: var(--color-text-soft); margin-left: var(--space-2); }
.code-token { font-family: var(--font-mono); font-size: 11.5px; background: var(--color-surface-2); padding: 1px 6px; border-radius: var(--radius-xs); border: 1px solid var(--color-border); }
```

---

## 20. Responsive rules

- Mobile-first: base styles target the smallest viewport; media queries add or override.
- Sidebar collapses below ~900 px (slide-over drawer).
- Tables get a horizontal scroll wrapper rather than reflowing.
- Dialogs use `width: min(calc(100% - 2rem), 480px)` so they never touch viewport edges.
- Use `dvh` not `vh` on full-viewport surfaces (sidebar, dialogs) so OS chrome doesn't overlap content.
- Honour `safe-area-inset-bottom` on bottom-anchored elements.

---

## 21. Motion

- Transitions: `--transition-fast` (120 ms ease) for hover tints, `--transition-base` (180 ms ease) for opacity/transform.
- No bouncy springs, no decorative animation. UI feedback only.
- Always respect `prefers-reduced-motion: reduce` — collapse to ~0 ms.

---

## 22. Iconography

- Line icons, **1.75 stroke-width** by default (Lucide / Heroicons outline). Bump to 2 inside `.btn__icon`.
- Sizes: 14 px in buttons, 15 px in sidebar nav, 18 px in role displays, 22 px in dropzones, 36 px in empty-states.
- Icon-only buttons need `aria-label`.

---

## 23. Accessibility checklist (every component)

- Keyboard reachable, visible `:focus-visible` ring (the universal `outline: 2px solid var(--color-accent); outline-offset: 2px;` rule covers this — don't suppress it).
- Icon-only controls have `aria-label`.
- Active nav has `aria-current="page"`.
- Modals: `role="dialog" aria-modal="true"`, focus trapped, focus restored on close, `Escape` closes.
- Form inputs always have a matching `<label>` (visible or `.sr-only`).
- Colour contrast ≥ 4.5:1 — already validated for every brand pair in this token set.
- Hit targets ≥ 24 × 24 px (sub-nav links use 7 px vertical padding to clear this).

---

## 24. Component checklist (when adding a new component)

Before writing CSS:

1. Can an existing component (`.card`, `.btn`, `.input`, `.badge`, `.tabs`, `.chip`, `.dialog-content`, `.empty-state`) be reused or extended with a `--modifier`?
2. Does it use only token values, never raw hex or px font sizes?
3. Is it BEM, with flat selectors?
4. Does it work in both themes without per-component dark overrides?
5. Does it have a `:hover`, `:focus-visible`, `:disabled` state?
6. Does it survive `prefers-reduced-motion`?
7. Is the markup semantic? (`<button>`, not `<div role="button">`.)

If you answer "no" to (1), justify it in a comment above the component block.

---

## 25. Filters (chip-trigger popovers)

The toolbar pattern is a **row of `.chip` triggers**, each opening a `.filter-pop__menu` popover. A chip with a current value shows the value inside a small inline pill (`.chip__value`) followed by a chevron (`.chip__chev`). Active chips bump their border + background a tier so it's obvious which filters are applied.

```css
.filter-pop { position: relative; }

.chip__value {
    margin-left: 4px;
    padding: 1px 6px;
    border-radius: var(--radius-sm);
    background: var(--color-surface-2);
    color: var(--color-text);
    font-size: 11.5px; font-weight: 500; line-height: 1.4;
    max-width: 170px;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.chip__chev    { color: var(--color-text-soft); margin-left: 2px; }
.chip.is-active{ border-color: var(--color-border-strong); background: var(--color-surface-2); color: var(--color-text); }
.chip--ghost   { color: var(--color-text-soft); background: transparent; }
.chip--ghost:hover { color: var(--color-text); background: var(--color-surface-2); }

.filter-pop__menu {
    position: absolute;
    top: calc(100% + 6px);
    left: 0;
    z-index: 40;
    min-width: 240px;
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-md);
    padding: var(--space-2);
    display: flex; flex-direction: column; gap: var(--space-1);
}
.filter-pop__menu--date  { min-width: 320px; }

.filter-pop__title {
    font-size: 11px; font-weight: 600;
    text-transform: uppercase; letter-spacing: 0.04em;
    color: var(--color-text-soft);
    padding: 6px var(--space-2) 4px;
}
.filter-pop__option {
    display: flex; align-items: center; gap: var(--space-2);
    padding: 6px var(--space-2);
    border-radius: var(--radius-sm);
    font-size: 13px; color: var(--color-text);
    cursor: pointer; transition: background var(--transition-fast);
}
.filter-pop__option:hover { background: var(--color-surface-2); }
.filter-pop__option input[type='checkbox'] { width: 14px; height: 14px; accent-color: var(--color-accent); }
.filter-pop__option-label { display: inline-flex; align-items: center; gap: 6px; flex: 1; }
.filter-pop__option-count { font-family: var(--font-mono); font-size: 11px; color: var(--color-text-soft); }

.filter-pop__row {
    display: grid; grid-template-columns: 1fr 1fr;
    gap: var(--space-2);
    padding: 4px var(--space-1) 0;
}
.filter-pop__footer {
    display: flex; justify-content: space-between; align-items: center;
    gap: var(--space-2);
    padding-top: var(--space-2); margin-top: 4px;
    border-top: 1px solid var(--color-border);
}
.filter-pop__empty { padding: var(--space-3); color: var(--color-text-muted); font-size: 12px; }
```

**Anatomy of a filter popover:**
1. Optional `.filter-pop__title` (uppercase eyebrow — e.g. "Filter by status").
2. List of `.filter-pop__option` rows: checkbox + label + count.
3. Optional `.filter-pop__row` for two-column inputs (from / to dates, min / max).
4. `.filter-pop__footer` with a left-aligned "Clear" ghost button and right-aligned "Apply" default button.

Show count in monospace (`.filter-pop__option-count`) so digit columns align across rows.

---

## 26. Search input (with leading icon)

A 30 px input with an absolutely-positioned icon inside the left padding.

```css
.audit-search {
    position: relative;
    display: flex; align-items: center;
}
.audit-search__icon {
    position: absolute;
    left: 10px;
    width: 14px; height: 14px;
    color: var(--color-text-soft);
    pointer-events: none;
}
.audit-search__input {
    height: 30px;
    padding: 0 var(--space-3) 0 30px;     /* leave room for the icon */
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    font-size: 12.5px;
    width: 220px;
    transition: border-color var(--transition-fast);
}
.audit-search__input:focus {
    outline: none;
    border-color: var(--color-text);
    box-shadow: 0 0 0 3px var(--ring);
}
```

This is the canonical "search box that lives in a toolbar" treatment. Generalise the class names if reusing outside the audit log.

---

## 27. Date / month / year pickers

A trigger styled as a regular `.input` opens a popover panel. Same trigger shape for date, month, and year — only the panel grid changes.

### Trigger

```css
.date-picker { position: relative; }
.date-picker__trigger {
    /* compose with .input so it inherits height, border, font, focus ring */
    display: inline-flex; align-items: center; justify-content: space-between;
    gap: var(--space-2);
    width: 100%; text-align: left;
    cursor: pointer; user-select: none;
}
.date-picker__trigger:hover    { border-color: var(--color-border-strong); }
.date-picker__trigger.is-open  { border-color: var(--color-text); box-shadow: 0 0 0 3px var(--ring); }
.date-picker__trigger--empty .date-picker__value { color: var(--color-text-soft); }
.date-picker__icon { width: 14px; height: 14px; color: var(--color-text-soft); flex-shrink: 0; }
```

### Panel

```css
.date-picker__panel {
    position: absolute;       /* or fixed when used inside an overflow:hidden parent */
    top: calc(100% + 6px); left: 0;
    z-index: 50;
    width: 280px;
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-md);
    padding: var(--space-2);
}

.date-picker__nav {
    display: flex; align-items: center; justify-content: space-between;
    gap: var(--space-1);
    padding: 4px var(--space-1);
    margin-bottom: var(--space-1);
}
.date-picker__nav-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px;
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--color-text-muted);
    transition: all var(--transition-fast);
}
.date-picker__nav-btn:hover:not(:disabled) { background: var(--color-surface-2); color: var(--color-text); }
.date-picker__nav-btn:disabled { opacity: 0.4; cursor: not-allowed; }
.date-picker__heading { font-weight: 600; font-size: 13.5px; font-variant-numeric: tabular-nums; }
```

### Grids

- **Day grid** — 7 columns × 6 rows. Weekday header uses uppercase 10.5 px labels with 0.04 em letter-spacing.
- **Month grid** — 3 columns × 4 rows (`.month-picker__grid`). Cell height 36 px.
- **Year grid** — 3 columns × 4 rows (`.date-picker__year-grid`). Cell height 38 px.

```css
.date-picker__weekdays {
    display: grid; grid-template-columns: repeat(7, 1fr);
    gap: 2px; padding: 0 2px; margin-bottom: 2px;
}
.date-picker__weekdays span {
    text-align: center;
    font-size: 10.5px; font-weight: 600;
    text-transform: uppercase; letter-spacing: 0.04em;
    color: var(--color-text-soft);
    padding: 4px 0;
}

.date-picker__grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 2px; }
.date-picker__cell {
    height: 32px;
    border-radius: var(--radius-sm);
    background: transparent; border: 1px solid transparent;
    font-size: 12.5px; font-weight: 500;
    font-variant-numeric: tabular-nums;
    transition: all var(--transition-fast);
}
.date-picker__cell:hover            { background: var(--color-surface-2); }
.date-picker__cell.is-outside       { color: var(--color-text-soft); opacity: 0.55; }
.date-picker__cell.is-today         { border-color: var(--color-border-strong); }
.date-picker__cell.is-selected      { background: var(--color-accent); color: var(--color-on-accent); border-color: var(--color-accent); }
.date-picker__cell.is-selected:hover{ background: var(--color-accent-hover); }
```

The month picker reuses the same nav header + footer layout, just swaps in a 3-column `repeat(3, 1fr)` grid with 36 px cells.

---

## 28. Tooltips (pure CSS)

Replace native `title=""` (slow, unstyled, inconsistent) with a styled popover keyed off `data-tooltip="..."`. Pure CSS — no JS — so it works on any element without wiring.

```css
[data-tooltip] { position: relative; }

[data-tooltip]::after,
[data-tooltip]::before {
    position: absolute;
    pointer-events: none;
    opacity: 0;
    transition: opacity 120ms ease, transform 120ms ease;
    z-index: 1000;
}

[data-tooltip]::after {
    content: attr(data-tooltip);
    bottom: calc(100% + 8px);
    left: 50%;
    transform: translate(-50%, 4px);
    background: var(--color-text);
    color: var(--color-bg);
    padding: var(--space-1) var(--space-2);
    border-radius: var(--radius-sm);
    font-size: 12px; font-weight: 500; line-height: 1.4;
    white-space: normal; text-align: center;
    width: max-content;
    max-width: min(220px, 90vw);
    box-shadow: var(--shadow-md);
}

[data-tooltip]::before {  /* caret */
    content: '';
    bottom: calc(100% + 4px);
    left: 50%;
    transform: translate(-50%, 4px);
    width: 0; height: 0;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 4px solid var(--color-text);
}

@media (hover: hover) {
    [data-tooltip]:hover::after,
    [data-tooltip]:hover::before { opacity: 1; transform: translate(-50%, 0); }
}
[data-tooltip]:focus-visible::after,
[data-tooltip]:focus-visible::before { opacity: 1; transform: translate(-50%, 0); }

/* Optional: data-tooltip-side="bottom" flips it below the trigger. */
[data-tooltip-side="bottom"]::after  { bottom: auto; top: calc(100% + 8px); }
[data-tooltip-side="bottom"]::before {
    bottom: auto; top: calc(100% + 4px);
    border-top: none;
    border-bottom: 4px solid var(--color-text);
}
```

Important: the trigger element should still have an `aria-label` or visible text — `data-tooltip` is visual sugar, not a substitute for accessible naming. Tooltips appear on `:hover` (pointer devices) and `:focus-visible` (keyboard).

---

## 29. Auth shell

Centered single-column layout on a tinted surface, max 380 px wide.

```css
.auth-shell {
    min-height: 100dvh;
    display: grid; place-items: center;
    padding: var(--space-6);
    background: var(--color-surface-2);
}
.auth-shell__panel { width: 100%; max-width: 380px; }

.auth-card { width: 100%; overflow: hidden; }  /* compose with .card */
.auth-card__header { padding: var(--space-6) var(--space-6) var(--space-2); text-align: left; }
.auth-card__title  { font-size: 22px; font-weight: 600; letter-spacing: -0.015em; line-height: 1.2; }
.auth-card__description { margin-top: 6px; color: var(--color-text-muted); font-size: 13.5px; }
.auth-card__body   { padding: var(--space-4) var(--space-6) var(--space-6); display: flex; flex-direction: column; gap: var(--space-4); }
.auth-card__footer {
    padding: var(--space-3) var(--space-6) var(--space-5);
    text-align: center; font-size: 13px;
    color: var(--color-text-muted);
    border-top: 1px solid var(--color-border);
}

.btn--block { width: 100%; }

/* Label flush-left, helper link flush-right (e.g. password + Forgot?) */
.field__label-row {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 6px;
}
.field__label-row .label { margin-bottom: 0; }
```

---

## 30. Checkbox row & toggle row

Two interaction patterns for boolean form fields.

### Checkbox row — minimal, inline

```css
.checkbox-row {
    display: inline-flex; align-items: flex-start;
    gap: var(--space-2);
    font-size: 13px; color: var(--color-text-muted);
    cursor: pointer; line-height: 1.4;
}
.checkbox-row input[type='checkbox'] {
    width: 14px; height: 14px;
    margin-top: 2px;
    accent-color: var(--color-accent);
    flex-shrink: 0;
}
.checkbox-row > span { color: var(--color-text); display: flex; flex-direction: column; gap: 2px; }
```

### Toggle row — bordered card with title + hint

Used inside forms for settings (e.g. "Freeze account", "Set new password"). Reads as a labelled control with a description.

```css
.toggle-row {
    display: flex; align-items: flex-start;
    gap: var(--space-3);
    padding: 10px 12px;
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    background: var(--color-surface);
    cursor: pointer;
    transition: border-color var(--transition-fast), background var(--transition-fast);
}
.toggle-row:hover { border-color: var(--color-border-strong); }
.toggle-row input[type='checkbox'] {
    width: 14px; height: 14px; margin-top: 3px;
    accent-color: var(--color-accent);
    flex-shrink: 0;
}
.toggle-row__body  { display: flex; flex-direction: column; gap: 2px; flex: 1; }
.toggle-row__title { font-size: 13px; font-weight: 500; color: var(--color-text); }
.toggle-row__hint  { font-size: 12px; color: var(--color-text-muted); line-height: 1.45; }
```

---

## 31. Selectable option cards (kind-row)

Two side-by-side selectable cards driven by `<input type="radio">`. Selected state is a `--is-selected` modifier (or `:has(input:checked)`) that bumps border and tints background.

```css
.kind-row {
    display: grid; grid-template-columns: 1fr 1fr;
    gap: var(--space-2);
}
.kind-row__option {
    display: flex; gap: var(--space-2);
    padding: 10px 12px;
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    cursor: pointer;
    transition: border-color var(--transition-fast), background var(--transition-fast);
}
.kind-row__option:hover                { border-color: var(--color-border-strong); }
.kind-row__option.is-selected,
.kind-row__option:has(input:checked)   { border-color: var(--color-text); background: var(--color-surface-2); }
.kind-row__option input[type='radio']  { accent-color: var(--color-accent); margin-top: 3px; }
.kind-row__title { font-size: 13px; font-weight: 600; }
.kind-row__hint  { font-size: 12px; color: var(--color-text-muted); line-height: 1.4; }
```

---

## 32. Row actions (hover-revealed icon buttons)

Icon-only square buttons that only appear when their parent row is hovered or the button itself is focused. Lives inside table rows.

```css
.row-action {
    display: inline-flex; align-items: center; justify-content: center;
    height: 28px; width: 28px;          /* clears WCAG 24×24 minimum */
    border: 1px solid transparent;
    border-radius: var(--radius-sm);
    color: var(--color-text-soft);
    background: transparent;
    cursor: pointer;
    transition: background var(--transition-fast), color var(--transition-fast), opacity var(--transition-fast);
    opacity: 0;                          /* hidden by default */
}
.row-action:hover         { background: var(--color-surface-2); color: var(--color-text); }
.row-action:focus-visible { outline: none; border-color: var(--color-text); box-shadow: 0 0 0 3px var(--ring); background: var(--color-surface-2); color: var(--color-text); }
.row-action[disabled]     { opacity: 0.4 !important; cursor: not-allowed; pointer-events: none; }
.row-action svg           { width: 14px; height: 14px; stroke-width: 1.75; }

/* Reveal on row hover / focus */
tr:hover .row-action,
.row-action:focus-visible,
.row-action.is-active { opacity: 1; }

.row-action.is-active {
    background: var(--color-surface-2);
    color: var(--color-text);
    border-color: var(--color-border-strong);
}
```

Pair with `data-tooltip="Edit"` to label the icon without taking up row space.

---

## 33. Override dot & status dots

Tiny coloured circles for inline annotations.

```css
/* Standalone dot used in toolbars, sidebar status, etc. */
.dot {
    display: inline-block;
    width: 6px; height: 6px;
    border-radius: 50%;
    background: currentColor;
    flex-shrink: 0;
}
.dot--success { background: var(--color-green); }
.dot--warning { background: var(--color-amber); }
.dot--info    { background: var(--color-blue); }
.dot--muted   { background: var(--color-text-soft); }

/* Inline annotation: a small amber dot rendered next to a cell value
   to flag "this is a manual override". Quieter than a badge. */
.override-dot {
    display: inline-block;
    width: 5px; height: 5px;
    border-radius: 50%;
    background: var(--color-amber);
    margin-left: 6px;
    vertical-align: middle;
    opacity: 0.85;
}
.override-dot--leading { margin-left: 0; margin-right: 6px; }
```

---

## 34. Trend indicator

Inline up/down value (e.g. "+ 2.3 %" or "- 1.1 %") used in stats and tables.

```css
.trend {
    display: inline-flex; align-items: center; gap: var(--space-1);
    font-variant-numeric: tabular-nums; font-weight: 500;
}
.trend--up   { color: var(--color-green); }
.trend--down { color: var(--color-red); }
.trend__indicator { font-size: 9px; line-height: 1; }
```

---

## 35. Pager (alternative to pagination)

A compact prev/next + position pair, smaller than the numbered `.pagination`. Used in audit-log-style listings.

```css
.pager { display: inline-flex; align-items: center; gap: var(--space-1); }
.pager__btn {
    display: inline-flex; align-items: center; gap: 4px;
    height: 28px; padding: 0 10px;
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    background: var(--color-surface);
    font-size: 12.5px; font-weight: 500;
    transition: all var(--transition-fast);
}
.pager__btn:hover           { border-color: var(--color-border-strong); background: var(--color-surface-2); }
.pager__btn--disabled       { opacity: 0.45; cursor: not-allowed; }
.pager__btn--disabled:hover { border-color: var(--color-border); background: var(--color-surface); }
.pager__pos {
    padding: 0 var(--space-2);
    font-size: 12px;
    color: var(--color-text-soft);
    font-variant-numeric: tabular-nums;
}
```

---

## 36. Layout primitives: cluster, stack

Used everywhere inside dialogs, cards, and page bodies.

```css
.cluster {
    display: flex; flex-wrap: wrap; align-items: center;
    gap: var(--space-2);
}
.cluster--split { justify-content: space-between; }

.stack {
    display: flex; flex-direction: column;
    gap: var(--space-3);
}
.stack--sm     { gap: var(--space-2); }
.stack--lg     { gap: var(--space-5); }
.stack--narrow { max-width: 640px; }
.stack--medium { max-width: 720px; }
```

Combine with `<form>` / `<section>` to constrain narrow forms (profile, settings) without inline `max-width`.

---

## 37. Diff layouts (3-column Field / Before / After)

Used for audit-log row expansions and any side-by-side change comparison. CSS-grid based — not a `<table>` — so the three columns flex predictably and rows can carry status tints.

```css
.diff-table {
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    overflow: hidden;
}
.diff-table__head,
.diff-table__row {
    display: grid;
    grid-template-columns: minmax(160px, 220px) 1fr 1fr;
}
.diff-table__head {
    background: var(--color-surface-2);
    border-bottom: 1px solid var(--color-border);
}
.diff-table__head .diff-table__cell {
    padding: 8px var(--space-3);
    font-size: 11px; font-weight: 600;
    text-transform: uppercase; letter-spacing: 0.04em;
    color: var(--color-text-soft);
}
.diff-table__head .diff-table__cell--before { color: var(--color-red); }
.diff-table__head .diff-table__cell--after  { color: var(--color-green); }

.diff-table__row { border-bottom: 1px solid var(--color-border); }
.diff-table__row:last-child { border-bottom: 0; }

.diff-table__cell {
    padding: 8px var(--space-3);
    font-size: var(--text-sm);
    word-break: break-word; overflow-wrap: anywhere;
}

/* Row state tints */
.diff-table__row--added   { background: color-mix(in oklab, var(--color-green-soft) 45%, transparent); }
.diff-table__row--removed { background: color-mix(in oklab, var(--color-red-soft)   45%, transparent); }
.diff-table__row--changed { background: color-mix(in oklab, var(--color-amber-soft) 35%, transparent); }

.diff-table__cell--field { font-weight: 500; color: var(--color-text-muted); }
.diff-table__value       { font-family: var(--font-mono); font-size: 12px; }
.diff-table__value--old  { color: var(--color-red);   text-decoration: line-through; text-decoration-thickness: 1px; text-decoration-color: color-mix(in oklab, var(--color-red) 50%, transparent); }
.diff-table__value--new  { color: var(--color-green); font-weight: 500; }
.diff-table__empty       { color: var(--color-text-soft); font-family: var(--font-mono); font-size: 12px; opacity: 0.55; }
```

---

## 38. Categorical / area pills

Like badges but compact, uppercase, used to tag the "area" of an event (Contracts / CPI / Users etc.). Per-area accent variants.

```css
.area-pill {
    display: inline-flex; align-items: center;
    padding: 2px 8px;
    border-radius: var(--radius-pill);
    border: 1px solid var(--color-border);
    background: var(--color-surface-2);
    color: var(--color-text-muted);
    font-size: 10px; font-weight: 600;
    text-transform: uppercase; letter-spacing: 0.04em;
    line-height: 1.4; white-space: nowrap;
}
.area-pill--blue  { background: var(--color-blue-soft);  color: var(--color-blue);  border-color: color-mix(in oklab, var(--color-blue)  25%, transparent); }
.area-pill--amber { background: var(--color-amber-soft); color: var(--color-amber); border-color: color-mix(in oklab, var(--color-amber) 25%, transparent); }
.area-pill--green { background: var(--color-green-soft); color: var(--color-green); border-color: color-mix(in oklab, var(--color-green) 25%, transparent); }
.area-pill--red   { background: var(--color-red-soft);   color: var(--color-red);   border-color: color-mix(in oklab, var(--color-red)   25%, transparent); }
```

**Lifecycle pills** (Attached / Modified / Detached, Added / Replaced / Removed) follow the exact same shape — only the colour pair changes (green / amber / red). Reuse one base class with three modifiers; don't proliferate names.

---

## 39. Linked card grids

Used for "report tile" and "roadmap card" navigation grids. Auto-fill grid of clickable cards with subtle hover lift.

```css
.tile-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    gap: var(--space-4);
}
.tile-card {
    display: flex; flex-direction: column;
    gap: var(--space-2);
    padding: var(--space-5);
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    color: var(--color-text);
    text-decoration: none;
    transition: border-color var(--transition-fast),
                box-shadow var(--transition-fast),
                transform var(--transition-fast);
}
.tile-card:hover {
    border-color: var(--color-border-strong);
    box-shadow: var(--shadow-sm);
    transform: translateY(-1px);              /* 1 px lift, never more */
}
.tile-card:focus-visible {
    outline: none;
    border-color: var(--color-text);
    box-shadow: 0 0 0 3px var(--ring);
}
.tile-card__head    { display: flex; align-items: center; justify-content: space-between; gap: var(--space-2); }
.tile-card__label   { font-size: var(--text-md); font-weight: 600; }
.tile-card__chev    { width: 16px; height: 16px; color: var(--color-text-soft); transition: transform var(--transition-fast), color var(--transition-fast); }
.tile-card:hover .tile-card__chev { color: var(--color-text); transform: translateX(2px); }
.tile-card__summary { font-size: 13px; color: var(--color-text-muted); line-height: 1.5; flex: 1; }
.tile-card__status  { display: inline-flex; align-items: center; gap: 6px; margin-top: var(--space-2); font-size: 11.5px; color: var(--color-text-soft); }
```

Status variants on the card itself (use sparingly — accent the *outcome*, not the card):
- `--shipped`: subtle green-tinted background, leading `✓` on title.
- `--in_progress`: 3 px amber left border (use `padding-left: calc(var(--space-4) - 2px);` to compensate so content doesn't shift).
- `--paused`: `background: var(--color-surface-2); opacity: 0.85;`.

---

## 40. Counts panel (summary block)

Pre-flight import summaries, dashboard totals, etc. — small auto-fit grid of count tiles.

```css
.counts-panel {
    background: var(--color-surface-2);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    padding: var(--space-4);
}
.counts-panel__grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    gap: var(--space-3);
}
.counts-panel__item {
    text-align: center;
    padding: var(--space-2);
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
}
.counts-panel__item--warn {
    background: var(--color-amber-soft);
    border-color: color-mix(in oklab, var(--color-amber) 30%, var(--color-border));
}
.counts-panel__num   { font-size: var(--text-2xl); font-weight: 600; line-height: 1; }
.counts-panel__item--warn .counts-panel__num { color: var(--color-amber); }
.counts-panel__label {
    margin-top: 4px;
    font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em;
    color: var(--color-text-muted);
}
```

---

## 41. Theme toggle

Inline dark/light switcher driven by `data-theme-effective` on the button. Renders the icon and label for the *current* theme so the click target reads "switch from light → dark" (or vice versa).

```css
.theme-toggle {
    width: 100%; text-align: left; cursor: pointer;
    background: transparent; border: 0; color: inherit; font: inherit;
}
.theme-toggle__icon,
.theme-toggle__label > span { display: none; }

.theme-toggle[data-theme-effective="light"] .theme-toggle__icon--light,
.theme-toggle[data-theme-effective="light"] .theme-toggle__label--light,
.theme-toggle[data-theme-effective="dark"]  .theme-toggle__icon--dark,
.theme-toggle[data-theme-effective="dark"]  .theme-toggle__label--dark { display: inline-block; }
```

Wire-up: a tiny JS reads `localStorage.getItem('theme')` (or `prefers-color-scheme`), sets `data-theme` on `<html>` and `data-theme-effective` on every `.theme-toggle`. The pre-paint script in §3 prevents the flash of light.

---

## 42. Row flash (just-changed highlight)

After a redirect that lands the user on a list page, briefly tint the row that just received a write so the eye lands on it.

```css
@keyframes row-flash {
    0%   { background-color: color-mix(in oklab, var(--color-accent) 18%, transparent); }
    100% { background-color: transparent; }
}
.row-flash > td,
.row-flash > td.table-frozen {
    animation: row-flash 1.6s ease-out 1;
}
```

Apply `.row-flash` via JS after scrolling the target row into view. Frozen-pane cells need the rule explicitly so the stripe stays continuous.

---

## 43. Emphasis & small text helpers

```css
.is-emphasis {
    text-decoration: underline;
    text-decoration-thickness: 1px;
    text-underline-offset: 2px;
    color: var(--color-text);
}

.is-medium { font-weight: 500; }
.is-hidden { display: none !important; }   /* keep in DOM, hide visually + a11y */
```

Combine `.is-emphasis` with `.is-mono` when the emphasised token is a code value (e.g. a CSV column name inside a dialog description).

---

## 44. Desktop-only gate (optional)

For apps that target laptop/desktop only — hide the entire UI below 900 px and show a single message via a pseudo-element. No JS, no markup; purely a CSS override.

```css
@media (max-width: 899px) {
    body > * { display: none !important; }
    body {
        display: grid; place-content: center;
        min-height: 100dvh;
        padding: var(--space-6);
        background: var(--color-bg);
    }
    body::before {
        content: 'This application is designed for laptop and desktop displays. Please open it on a screen at least 900 pixels wide.';
        max-width: 32rem;
        text-align: center;
        color: var(--color-text);
        font: 500 var(--text-md)/1.6 var(--font-sans);
    }
}
```

Skip this block if the project needs to be fully responsive on phones.

---

## 45. Patterns to internalise (cheat sheet)

| Pattern | Implementation |
|---|---|
| **Status pill (success/warn/info/danger/neutral)** | `.badge--success` etc. + `.badge--with-dot` for emphasis. |
| **Categorical tag** | `.area-pill--{colour}`, smaller, uppercase, 10 px. |
| **Filter chip with value** | `.chip + .chip__value + .chip__chev`, opens `.filter-pop__menu`. |
| **Picker (date/month/year)** | Trigger composes with `.input`. Panel anchored `top: calc(100% + 6px)`. Selected cell uses `--color-accent`. |
| **Icon-only row action** | `.row-action`, `opacity: 0` by default, revealed on `tr:hover` or `:focus-visible`. Paired with `data-tooltip`. |
| **Inline annotation dot** | `.override-dot` (5 px amber). |
| **Hover-lift card** | `transform: translateY(-1px); box-shadow: var(--shadow-sm); border-color: var(--color-border-strong);` |
| **Card destructive ring** | Tinted border + footer via `color-mix(in srgb, var(--color-red) X%, ...)`. |
| **Diff layout** | CSS-grid `minmax(160px, 220px) 1fr 1fr`. Row tints via `color-mix` of soft colours. |
| **Just-changed row** | `@keyframes row-flash` 1.6 s once. |
| **Floating panel (popover, dropdown, picker)** | `position: absolute; top: calc(100% + 6px); z-index: 30–50; box-shadow: var(--shadow-md); border-radius: var(--radius-md);`. |
| **Subtle eyebrow label** | `font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; color: var(--color-text-soft);`. |
| **Numeric column** | `.num` class → `text-align: right; font-variant-numeric: tabular-nums;`. |
| **Translucent sticky bar** | `background: color-mix(in oklab, var(--color-bg) 85%, transparent); backdrop-filter: blur(8px);`. |

---

## 46. Anti-patterns (forbidden)

- ❌ Tailwind / PostCSS utility classes.
- ❌ Inline `style="..."` attributes.
- ❌ New button variants beyond the five listed.
- ❌ Raw hex colours inside components (always use tokens).
- ❌ Descendant chain styling (`.card .button .icon span`).
- ❌ `100vh` (use `100dvh`).
- ❌ Suppressing `:focus-visible` without a replacement focus indicator.
- ❌ Hardcoded font sizes in `px` (use `--text-*` clamp tokens).
- ❌ JavaScript frameworks beyond Alpine.js for view layer; no React/Vue unless the project explicitly needs SPA-grade reactivity.
