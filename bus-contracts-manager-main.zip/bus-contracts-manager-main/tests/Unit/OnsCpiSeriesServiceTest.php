<?php

use App\Services\OnsCpiSeriesService;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

uses(TestCase::class);

beforeEach(function () {
    $this->service = new OnsCpiSeriesService;
});

it('parses ONS-shaped time-series JSON into normalised rows', function () {
    Http::fake([
        OnsCpiSeriesService::D7BT_TIMESERIES_URL => Http::response([
            'months' => [
                ['date' => '2026 MAR', 'value' => '141.0'],
                ['date' => '2026 FEB', 'value' => '140.1'],
                ['date' => '2026 JAN', 'value' => '139.5'],
            ],
        ], 200),
    ]);

    $rows = $this->service->fetchSeries();

    // Sorted ascending
    expect($rows)->toBe([
        ['month' => '2026-01-01', 'raw_value' => '139.5'],
        ['month' => '2026-02-01', 'raw_value' => '140.1'],
        ['month' => '2026-03-01', 'raw_value' => '141.0'],
    ]);
});

it('filters out observations earlier than 2010', function () {
    Http::fake([
        OnsCpiSeriesService::D7BT_TIMESERIES_URL => Http::response([
            'months' => [
                ['date' => '1988 JAN', 'value' => '48.4'],
                ['date' => '2009 DEC', 'value' => '89.0'],
                ['date' => '2010 JAN', 'value' => '88.4'],
                ['date' => '2026 MAR', 'value' => '141.0'],
            ],
        ], 200),
    ]);

    $rows = $this->service->fetchSeries();

    expect($rows)->toHaveCount(2)
        ->and($rows[0]['month'])->toBe('2010-01-01')
        ->and($rows[1]['month'])->toBe('2026-03-01');
});

it('skips entries with malformed dates rather than aborting the whole feed', function () {
    Http::fake([
        OnsCpiSeriesService::D7BT_TIMESERIES_URL => Http::response([
            'months' => [
                ['date' => 'wat', 'value' => '141.0'],
                ['date' => '2026 MAR', 'value' => '141.0'],
            ],
        ], 200),
    ]);

    $rows = $this->service->fetchSeries();

    expect($rows)->toHaveCount(1)
        ->and($rows[0]['month'])->toBe('2026-03-01');
});

it('skips entries missing date or value', function () {
    Http::fake([
        OnsCpiSeriesService::D7BT_TIMESERIES_URL => Http::response([
            'months' => [
                ['date' => '2026 MAR'],
                ['value' => '141.0'],
                ['date' => '', 'value' => ''],
                ['date' => '2026 APR', 'value' => '141.5'],
            ],
        ], 200),
    ]);

    $rows = $this->service->fetchSeries();

    expect($rows)->toHaveCount(1);
});

it('throws on HTTP failure', function () {
    Http::fake([
        OnsCpiSeriesService::D7BT_TIMESERIES_URL => Http::response('', 503),
    ]);

    $this->service->fetchSeries();
})->throws(RuntimeException::class, 'HTTP 503');

it('throws on missing months key', function () {
    Http::fake([
        OnsCpiSeriesService::D7BT_TIMESERIES_URL => Http::response(['years' => []], 200),
    ]);

    $this->service->fetchSeries();
})->throws(RuntimeException::class, 'months');
