<?php

use App\Models\CpiIndexEntry;
use App\Models\User;
use App\Services\CpiRateService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Tests\TestCase;

uses(TestCase::class, RefreshDatabase::class);

beforeEach(function () {
    $this->service = app(CpiRateService::class);
    $this->user = User::factory()->create();
});

/** Helper for inserting a fixture row. */
function seedCpi(array $cpi, int $userId): void
{
    foreach ($cpi as $month => $value) {
        CpiIndexEntry::create([
            'month' => $month,
            'cpi_index' => $value,
            'cpi_index_original' => $value,
            'is_actual' => true,
            'source' => 'manual_import',
            'source_original' => 'manual_import',
            'created_by' => $userId,
        ]);
    }
}

/**
 * Pin the canonical TFL CPA spreadsheet values for March 2026. These match
 * the "CPA - USED" / FINAL OUTPUT columns of the revenue spreadsheet exactly:
 *
 *   yoy[Mar 26]  = (141.0 − 136.5) / 136.5         = 0.03296703
 *   p2p[Mar 26]  = yoy[Nov 25] × 0.85              = 0.02768320 (4-month lag)
 *   ra[Mar 26]   = AVG(yoy[Mar 25 … Feb 26]) × 0.85 = 0.02881201 (1-month-shifted window)
 *
 * Drift on this test means the service has stopped agreeing with the
 * canonical TFL values.
 */
it('matches the canonical Excel values for March 2026', function () {
    seedCpi([
        // Mar 2024 — prior year for the earliest RA window month (Mar 25)
        '2024-03-01' => '133.0',
        // Apr 2024 → Mar 2025 — priors for the rest of the RA window months
        '2024-04-01' => '133.5', '2024-05-01' => '133.9', '2024-06-01' => '134.1',
        '2024-07-01' => '133.8', '2024-08-01' => '134.3', '2024-09-01' => '134.2',
        '2024-10-01' => '135.0', '2024-11-01' => '135.1', '2024-12-01' => '135.6',
        '2025-01-01' => '135.4', '2025-02-01' => '136.0', '2025-03-01' => '136.5',
        // Apr 2025 → Mar 2026 — the RA window months themselves (Mar 25 … Feb 26)
        // plus the current month (Mar 26) and its prior year (already above)
        '2025-04-01' => '138.2', '2025-05-01' => '138.4', '2025-06-01' => '138.9',
        '2025-07-01' => '139.0', '2025-08-01' => '139.3', '2025-09-01' => '139.3',
        '2025-10-01' => '139.8', '2025-11-01' => '139.5', '2025-12-01' => '140.1',
        '2026-01-01' => '139.5', '2026-02-01' => '140.1', '2026-03-01' => '141.0',
    ], $this->user->id);

    $result = $this->service->calculateRatesForMonth(Carbon::parse('2026-03-01'));

    expect($result)->toMatchArray([
        'cpi_index' => '141.0',
        'cpi_index_prior_year' => '136.5',
        'yoy_change' => '0.03296703',
        'p2p_rate' => '0.02768320',
        'ra_rate' => '0.02881201',
    ]);
});

it('returns null P2P when the lagged source month is missing', function () {
    // Only the current month + prior year — no Nov 2025 / Nov 2024 for P2P,
    // and no RA window either.
    seedCpi([
        '2025-03-01' => '136.5',
        '2026-03-01' => '141.0',
    ], $this->user->id);

    $result = $this->service->calculateRatesForMonth(Carbon::parse('2026-03-01'));

    expect($result['yoy_change'])->toBe('0.03296703')
        ->and($result['p2p_rate'])->toBeNull()
        ->and($result['ra_rate'])->toBeNull();
});

it('throws when the prior-year CPI for the current month is missing', function () {
    seedCpi(['2026-03-01' => '141.0'], $this->user->id);

    $this->service->calculateRatesForMonth(Carbon::parse('2026-03-01'));
})->throws(RuntimeException::class);
