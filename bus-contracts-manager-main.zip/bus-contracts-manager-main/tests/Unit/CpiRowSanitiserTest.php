<?php

use App\Services\CpiRowSanitiser;

beforeEach(function () {
    $this->sanitiser = new CpiRowSanitiser;
});

describe('happy paths', function () {
    it('normalises ISO month + 1dp CPI', function () {
        expect($this->sanitiser->sanitise('2026-03', '141.0'))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.0']);
    });

    it('promotes integer CPI to 1dp', function () {
        expect($this->sanitiser->sanitise('2026-03', '141'))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.0']);
    });

    it('rounds extra decimals to 1dp', function () {
        expect($this->sanitiser->sanitise('2026-03', '141.04'))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.0']);

        expect($this->sanitiser->sanitise('2026-03', '141.05'))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.1']);
    });

    it('strips thousands separators and stray spaces', function () {
        expect($this->sanitiser->sanitise('2026-03', '1 41.5'))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.5']);
    });

    it('strips a UTF-8 BOM', function () {
        $bom = "\u{FEFF}";

        expect($this->sanitiser->sanitise($bom.'2026-03', '141.0'))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.0']);
    });

    it('trims surrounding whitespace and quotes', function () {
        expect($this->sanitiser->sanitise('  "2026-03" ', "  '141.5'  "))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.5']);
    });

    it('accepts dd/mm/yyyy and dd-mm-yyyy', function () {
        expect($this->sanitiser->sanitise('01/03/2026', '141.0'))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.0']);

        expect($this->sanitiser->sanitise('15-03-2026', '141.0'))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.0']);
    });

    it('accepts long-form month names', function () {
        expect($this->sanitiser->sanitise('March 2026', '141.0'))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.0']);

        expect($this->sanitiser->sanitise('Mar 2026', '141.0'))
            ->toBe(['month' => '2026-03-01', 'cpi_index' => '141.0']);
    });
});

describe('rejected input', function () {
    it('rejects empty values', function () {
        $this->sanitiser->sanitise('', '141.0');
    })->throws(DomainException::class);

    it('rejects unparseable months', function () {
        $this->sanitiser->sanitise('not-a-month', '141.0');
    })->throws(DomainException::class);

    it('rejects months before the supported range', function () {
        $this->sanitiser->sanitise('1989-12', '141.0');
    })->throws(DomainException::class, 'outside the supported range');

    it('rejects months after the supported range', function () {
        $this->sanitiser->sanitise('2051-01', '141.0');
    })->throws(DomainException::class, 'outside the supported range');

    it('rejects non-numeric CPI', function () {
        $this->sanitiser->sanitise('2026-03', 'abc');
    })->throws(DomainException::class, 'not numeric');

    it('rejects negative CPI', function () {
        // The sanitiser's injection guard catches the leading `-`
        // before the numeric range check ever sees it. Both rejections
        // are correct; the injection one fires first (and is more
        // defensive — `-` can lead an Excel formula too).
        $this->sanitiser->sanitise('2026-03', '-1');
    })->throws(DomainException::class, 'disallowed character');

    it('rejects CPI below the floor', function () {
        $this->sanitiser->sanitise('2026-03', '0.5');
    })->throws(DomainException::class, 'plausible range');

    it('rejects CPI above the ceiling', function () {
        $this->sanitiser->sanitise('2026-03', '1500');
    })->throws(DomainException::class, 'plausible range');

    it('blocks formula injection in the month cell', function () {
        $this->sanitiser->sanitise('=cmd|"/c calc"!A1', '141.0');
    })->throws(DomainException::class, 'disallowed character');

    it('blocks formula injection in the CPI cell', function () {
        $this->sanitiser->sanitise('2026-03', '=SUM(A1:A2)');
    })->throws(DomainException::class, 'disallowed character');

    it('blocks @-prefixed cells (Excel function call)', function () {
        $this->sanitiser->sanitise('@2026-03', '141.0');
    })->throws(DomainException::class);
});

describe('utility', function () {
    it('strips a UTF-8 BOM via static helper', function () {
        $bom = "\u{FEFF}";
        expect(CpiRowSanitiser::stripBom($bom.'hello'))->toBe('hello');
        expect(CpiRowSanitiser::stripBom('hello'))->toBe('hello');
    });
});
