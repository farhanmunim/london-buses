<?php

use App\Models\AppSetting;
use App\Models\AuditLog;
use App\Models\Contract;
use App\Models\User;
use Illuminate\Http\UploadedFile;

beforeEach(function () {
    // Imports are write actions, so the actor needs the admin role to
    // pass the can.write middleware. Default factory role is 'user'.
    $this->user = User::factory()->create(['role' => User::ROLE_ADMIN]);

    AppSetting::put(AppSetting::CONTRACTS_ANCHOR_YEAR, '2024', $this->user->id);
    AppSetting::put(AppSetting::CONTRACTS_P2P_RA_CUTOFF, '2018-08-01', $this->user->id);
    AuditLog::query()->delete();
});

const HEADER_LINE = "import_type,id,company,depot,route,contract_number,tender_date,start_date,end_date,contract_value,contracted_miles\n";

function makeCsv(string $body): UploadedFile
{
    $path = tempnam(sys_get_temp_dir(), 'contracts-test-').'.csv';
    file_put_contents($path, $body);

    return new UploadedFile($path, 'contracts.csv', 'text/csv', null, true);
}

/**
 * The import is now a two-step flow: POST /contracts/import stages the
 * file and returns a confirmation flash; POST /contracts/import-confirm
 * actually commits. Tests that expected the old single-step behaviour
 * use this helper to chain both. Hard-error / preflight-rejection paths
 * never reach step two (no `importConfirmation` flash) — the helper
 * returns the first response unchanged so the existing assertions work.
 */
function importAndConfirm($test, $user, string $csv, ?string $defaultType = null)
{
    $resp = $test->actingAs($user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $confirmation = $resp->getSession()->get('importConfirmation');
    if (! $confirmation) {
        return $resp;
    }

    return $test->actingAs($user)->post('/contracts/import-confirm', [
        'uuid' => $confirmation['uuid'],
        'default_import_type' => $defaultType,
    ]);
}

/**
 * Build a single CSV row matching the import template's column order.
 * Defaults satisfy every mandatory field; pass overrides as a map.
 */
function row(array $overrides = []): string
{
    $defaults = [
        'import_type' => 'new',
        'id' => '',
        'company' => 'AB',
        'depot' => 'CD',
        'route' => '100',
        'contract_number' => 'QC'.random_int(10000, 99999),
        'tender_date' => '01/01/2024',
        'start_date' => '01/04/2024',
        'end_date' => '31/03/2031',
        'contract_value' => '1500000.00',
        'contracted_miles' => '500000.00',
    ];

    return implode(',', array_values(array_merge($defaults, $overrides)))."\n";
}

function makeContract(int $userId, array $overrides = []): Contract
{
    return Contract::create(array_merge([
        'company' => 'AB', 'depot' => 'CD', 'route' => '100',
        'contract_number' => 'QC'.fake()->numerify('#####'),
        'tender_date' => '2024-01-01',
        'start_date' => '2024-04-01',
        'end_date' => '2031-03-31',
        'contract_value' => 1500000.00,
        'contracted_miles' => 500000.00,
        'created_by' => $userId,
    ], $overrides));
}

it('imports an import_type=new row as a new contract with a summary audit', function () {
    $csv = HEADER_LINE.row(['contract_number' => 'QC11111']);

    $response = importAndConfirm($this, $this->user, $csv);

    $response->assertRedirect(route('contracts.index'));

    $contract = Contract::firstWhere('contract_number', 'QC11111');
    expect($contract)->not->toBeNull()
        ->and($contract->company)->toBe('AB')
        ->and((float) $contract->contract_value)->toBe(1500000.0)
        ->and((float) $contract->contracted_miles)->toBe(500000.0)
        // CPA confirmations are intentionally not part of the import payload —
        // they're only ever set per-cell via the in-app dialog.
        ->and($contract->cpa_confirmations)->toBeNull();

    expect(AuditLog::where('action', 'contracts_imported')->count())->toBe(1);
});

it('imports an import_type=override row matched by ID, with diff audit', function () {
    $existing = makeContract($this->user->id, ['contract_number' => 'QC22222']);

    $csv = HEADER_LINE.row([
        'import_type' => 'override',
        'id' => (string) $existing->id,
        'contract_number' => 'QC22222',
        'contract_value' => '1525000.00',
    ]);

    importAndConfirm($this, $this->user, $csv);

    $existing->refresh();
    expect((float) $existing->contract_value)->toBe(1525000.0);

    $entry = AuditLog::where('action', 'contract_overridden')->first();
    expect($entry)->not->toBeNull()
        ->and($entry->old_values['contract_value'])->toBe('1500000.0000')
        ->and($entry->new_values['contract_value'])->toBe('1525000.0000');
});

it('imports an import_type=variation row matched by ID', function () {
    $existing = makeContract($this->user->id, ['contract_number' => 'QC33333']);

    $csv = HEADER_LINE.row([
        'import_type' => 'variation',
        'id' => (string) $existing->id,
        'contract_number' => 'QC33333',
        'end_date' => '31/03/2032',
    ]);

    importAndConfirm($this, $this->user, $csv);

    expect(AuditLog::where('action', 'contract_varied')->count())->toBe(1);
});

it('overrides the correct row when two contracts share the same contract_number', function () {
    $first = makeContract($this->user->id, ['contract_number' => 'QC_DUP', 'route' => 'A']);
    $second = makeContract($this->user->id, ['contract_number' => 'QC_DUP', 'route' => 'B']);

    $csv = HEADER_LINE.row([
        'import_type' => 'override',
        'id' => (string) $second->id,
        'route' => 'B',
        'contract_number' => 'QC_DUP',
        'contract_value' => '2000000.00',
    ]);

    importAndConfirm($this, $this->user, $csv);

    $first->refresh();
    $second->refresh();
    expect((float) $first->contract_value)->toBe(1500000.0)
        ->and((float) $second->contract_value)->toBe(2000000.0);
});

it('rejects import_type=override when the ID does not exist', function () {
    $csv = HEADER_LINE.row([
        'import_type' => 'override',
        'id' => '99999',
        'contract_number' => 'QC44444',
    ]);

    $response = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $response->assertSessionHas('importErrors', fn ($e) => count($e) === 1 && str_contains($e[0]['message'], 'No contract with id 99999'));
    expect(Contract::count())->toBe(0);
});

it('rejects import_type=override when the ID is blank', function () {
    $csv = HEADER_LINE.row([
        'import_type' => 'override',
        'contract_number' => 'QC55555',
    ]);

    $response = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $response->assertSessionHas('importErrors', fn ($e) => count($e) === 1 && str_contains($e[0]['message'], 'id is required'));
});

it('rejects import_type=new when an ID is provided', function () {
    $csv = HEADER_LINE.row([
        'id' => '123',
        'contract_number' => 'QC66666',
    ]);

    $response = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $response->assertSessionHas('importErrors', fn ($e) => count($e) === 1 && str_contains($e[0]['message'], 'must leave id blank'));
    expect(Contract::count())->toBe(0);
});

it('rejects a non-numeric ID', function () {
    $csv = HEADER_LINE.row([
        'import_type' => 'override',
        'id' => 'abc',
        'contract_number' => 'QC77777',
    ]);

    $response = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $response->assertSessionHas('importErrors', fn ($e) => count($e) === 1 && str_contains($e[0]['message'], 'id must be a positive integer'));
});

it('rejects an invalid import_type value', function () {
    $csv = HEADER_LINE.row([
        'import_type' => 'bogus',
        'contract_number' => 'QC88888',
    ]);

    $response = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $response->assertSessionHas('importErrors', fn ($e) => count($e) === 1 && str_contains($e[0]['message'], 'import_type must be one of'));
});

it('blocks a CSV-formula-injection attempt in a text cell', function () {
    $csv = HEADER_LINE.row([
        'company' => '=cmd|" /C calc"',
        'contract_number' => 'QC99999',
    ]);

    $response = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $response->assertSessionHas('importErrors', fn ($e) => count($e) === 1 && str_contains($e[0]['message'], 'forbidden character'));
    expect(Contract::count())->toBe(0);
});

it('rejects an impossible date like 31/02/2024', function () {
    $csv = HEADER_LINE.row([
        'tender_date' => '31/02/2024',
        'contract_number' => 'QC10001',
    ]);

    $response = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $response->assertSessionHas('importErrors', fn ($e) => count($e) === 1 && str_contains($e[0]['message'], 'tender_date must be dd/mm/yyyy'));
});

it('parses Excel serial-date integers as dates', function () {
    // 44197 = 2021-01-01, 44562 = 2022-01-01, 46022 = 2025-12-31. These
    // are verifiable from the canonical Excel epoch (1899-12-30 + N days).
    $csv = HEADER_LINE.row([
        'contract_number' => 'QCSERIAL',
        'tender_date' => '44197',
        'start_date' => '44562',
        'end_date' => '46022',
    ]);

    importAndConfirm($this, $this->user, $csv);

    $contract = Contract::firstWhere('contract_number', 'QCSERIAL');
    expect($contract)->not->toBeNull()
        ->and($contract->tender_date->format('Y-m-d'))->toBe('2021-01-01')
        ->and($contract->start_date->format('Y-m-d'))->toBe('2022-01-01')
        ->and($contract->end_date->format('Y-m-d'))->toBe('2025-12-31');
});

it('rejects negative or implausibly-large values', function () {
    $csv = HEADER_LINE
        .row(['contract_number' => 'QC10002', 'contract_value' => '-100'])
        .row(['contract_number' => 'QC10003', 'contract_value' => '9999999999999']);

    $response = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $response->assertSessionHas('importErrors', fn ($e) => count($e) === 2);
    expect(Contract::count())->toBe(0);
});

it('rejects a row missing the mandatory contracted_miles', function () {
    $csv = HEADER_LINE.row([
        'contract_number' => 'QC10006',
        'contracted_miles' => '',
    ]);

    $response = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $response->assertSessionHas('importErrors', fn ($e) => count($e) === 1 && str_contains($e[0]['message'], 'contracted_miles must be numeric'));
    expect(Contract::count())->toBe(0);
});

it('strips a UTF-8 BOM from the first cell of the header row', function () {
    $csv = "\xEF\xBB\xBF".HEADER_LINE.row([
        'contract_number' => 'QC10004',
    ]);

    importAndConfirm($this, $this->user, $csv);

    expect(Contract::firstWhere('contract_number', 'QC10004'))->not->toBeNull();
});

it('marks an import_type=override import as unchanged when nothing differs', function () {
    $existing = makeContract($this->user->id, ['contract_number' => 'QC10005']);

    $csv = HEADER_LINE.row([
        'import_type' => 'override',
        'id' => (string) $existing->id,
        'contract_number' => 'QC10005',
    ]);

    importAndConfirm($this, $this->user, $csv);

    expect(AuditLog::where('action', 'contract_overridden')->count())->toBe(0);
});

it('preflight: returns importConfirmation flash with type counts and missing-type rows', function () {
    $csv = HEADER_LINE
        .row(['contract_number' => 'QC20001'])
        .row(['contract_number' => 'QC20002', 'import_type' => ''])
        .row(['contract_number' => 'QC20003', 'import_type' => ''])
        .row(['contract_number' => 'QC20004']);

    $resp = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $conf = $resp->getSession()->get('importConfirmation');
    expect($conf)->not->toBeNull()
        ->and($conf['analysis']['total_rows'])->toBe(4)
        ->and($conf['analysis']['type_counts']['new'])->toBe(2)
        ->and(count($conf['analysis']['missing_type_rows']))->toBe(2)
        ->and(Contract::count())->toBe(0);
});

it('preflight: catches a bad override id without committing anything', function () {
    $csv = HEADER_LINE.row([
        'import_type' => 'override',
        'id' => '99998',
        'contract_number' => 'QC20010',
    ]);

    $resp = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $resp->assertSessionHas('importErrors', fn ($e) => count($e) === 1 && str_contains($e[0]['message'], 'No contract with id 99998'));
    $resp->assertSessionMissing('importConfirmation');
    expect(Contract::count())->toBe(0);
});

it('confirm: applies default_import_type to rows missing import_type', function () {
    $csv = HEADER_LINE
        .row(['contract_number' => 'QC30001', 'import_type' => ''])
        .row(['contract_number' => 'QC30002', 'import_type' => '']);

    importAndConfirm($this, $this->user, $csv, defaultType: 'new');

    expect(Contract::firstWhere('contract_number', 'QC30001'))->not->toBeNull()
        ->and(Contract::firstWhere('contract_number', 'QC30002'))->not->toBeNull();
});

it('preflight: flags duplicate contract_numbers within the file as a warning', function () {
    $csv = HEADER_LINE
        .row(['contract_number' => 'QC_SAME'])
        .row(['contract_number' => 'QC_SAME']);

    $resp = $this->actingAs($this->user)->post('/contracts/import', ['csv' => makeCsv($csv)]);

    $conf = $resp->getSession()->get('importConfirmation');
    expect($conf)->not->toBeNull()
        ->and($conf['analysis']['duplicate_contract_numbers'])->toHaveKey('QC_SAME')
        ->and($conf['analysis']['duplicate_contract_numbers']['QC_SAME'])->toBe([2, 3]);
});
