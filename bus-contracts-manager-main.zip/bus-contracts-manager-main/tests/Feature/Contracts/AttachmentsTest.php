<?php

use App\Models\AppSetting;
use App\Models\Attachment;
use App\Models\AuditLog;
use App\Models\Contract;
use App\Models\User;
use App\Support\AttachmentUpload;
use Illuminate\Http\UploadedFile;

beforeEach(function () {
    // Every contract write path is gated by `can.write` (admin+), so the
    // actor needs the admin role.
    $this->user = User::factory()->create(['role' => User::ROLE_ADMIN]);

    // CPA confirmation paths require a configured anchor year so the
    // controller can determine which years are editable (year >= anchor).
    AppSetting::put(AppSetting::CONTRACTS_ANCHOR_YEAR, '2024', $this->user->id);

    $this->contract = Contract::create([
        'company' => 'TST',
        'depot' => 'D1',
        'route' => '99',
        'contract_number' => 'TEST-001',
        'tender_date' => '2024-01-01',
        'start_date' => '2024-06-01',
        'end_date' => '2031-05-31',
        'contract_value' => 1000000,
        'created_by' => $this->user->id,
    ]);
    AuditLog::query()->delete();
    Attachment::query()->delete();
});

/**
 * Write a tiny real PDF on disk and return an UploadedFile pointing at
 * it. UploadedFile::fake()->create() writes 0 bytes, which causes
 * Laravel's `mimes:` rule (Symfony's MIME guesser sniffs the bytes) to
 * fail on an "empty" file. The PDF magic header below is enough to make
 * the guesser report `application/pdf`. The `$kb` parameter pads the
 * file out so size-based assertions and dupe-replace tests can produce
 * different file lengths.
 */
function attachmentFile(string $name = 'attachment.pdf', int $kb = 4): UploadedFile
{
    $path = tempnam(sys_get_temp_dir(), 'attachment-test-').'.pdf';
    $padding = str_repeat('A', max(0, $kb * 1024 - 32));
    file_put_contents($path, "%PDF-1.4\n%test\n".$padding);

    return new UploadedFile($path, $name, 'application/pdf', null, true);
}

it('saves an attachment alongside a CPA confirmation update', function () {
    $resp = $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'note' => 'Confirmed via TFL email',
            'attachment' => attachmentFile('cpa-2026.pdf'),
        ]);

    $resp->assertRedirect();
    expect(Attachment::count())->toBe(1);

    $att = Attachment::first();
    expect($att->original_filename)->toBe('cpa-2026.pdf');
    expect($att->attachable_key)->toBe("contract:{$this->contract->id}:cpa:2026");
    expect($att->mime_type)->toBe('application/pdf');
    expect($att->detached_at)->toBeNull();
    expect($att->sha256)->toHaveLength(64);

    $log = $att->auditLog;
    expect($log->action)->toBe('contract_cpa_confirmed');
});

it('treats an attachment-only save as a non-no-op and writes a dedicated audit action', function () {
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'note' => 'Initial confirm',
        ]);

    AuditLog::query()->delete();
    Attachment::query()->delete();

    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'note' => 'Initial confirm',
            'attachment' => attachmentFile('proof.pdf'),
        ]);

    expect(Attachment::count())->toBe(1);
    expect(AuditLog::where('action', 'contract_attachment_attached')->count())->toBe(1);
});

it('blocks an upload with a duplicate filename when no dupe_action is supplied', function () {
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'attachment' => attachmentFile('shared.pdf'),
        ]);

    $resp = $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2025,
            'status' => 'yes',
            'attachment' => attachmentFile('shared.pdf'),
        ]);

    $resp->assertSessionHasErrors('attachment');
    expect(Attachment::count())->toBe(1);
});

it('saves a second copy with disambiguated filename when dupe_action is "keep"', function () {
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'attachment' => attachmentFile('shared.pdf'),
        ]);

    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2025,
            'status' => 'yes',
            'attachment' => attachmentFile('shared.pdf'),
            'dupe_action' => 'keep',
        ]);

    expect(Attachment::count())->toBe(2);
    $names = Attachment::pluck('original_filename')->all();
    expect($names)->toContain('shared.pdf');
    expect(collect($names)->filter(fn ($n) => str_starts_with($n, 'shared_') && str_ends_with($n, '.pdf')))->toHaveCount(1);
});

it('updates bytes everywhere when dupe_action is "replace"', function () {
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'attachment' => attachmentFile('shared.pdf', 4),
        ]);

    $original = Attachment::first();
    $originalHash = $original->sha256;

    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2025,
            'status' => 'yes',
            'attachment' => attachmentFile('shared.pdf', 8),
            'dupe_action' => 'replace',
        ]);

    expect(Attachment::count())->toBe(2);

    $original->refresh();
    expect($original->sha256)->not->toBe($originalHash);
});

it('soft-detaches an attachment link and writes a dedicated audit row', function () {
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'attachment' => attachmentFile('detach-me.pdf'),
        ]);

    $att = Attachment::first();
    $link = \App\Models\AttachmentLink::where('attachment_id', $att->id)->firstOrFail();
    expect($link->detached_at)->toBeNull();
    expect($att->detached_at)->toBeNull();

    $this->actingAs($this->user)
        ->delete("/contracts/attachment-links/{$link->id}/detach");

    $link->refresh();
    expect($link->detached_at)->not->toBeNull();
    expect($link->detached_by)->toBe($this->user->id);

    // The single-link case mirrors the legacy attachment.detached_at,
    // so any code still reading that column sees the change too.
    $att->refresh();
    expect($att->detached_at)->not->toBeNull();
    expect($att->detached_by)->toBe($this->user->id);

    expect(AuditLog::where('action', 'contract_attachment_detached')->count())->toBe(1);
    $detachLog = AuditLog::where('action', 'contract_attachment_detached')->first();
    expect($detachLog->old_values['attachment_id'])->toBe($att->id);
    expect($detachLog->old_values['attachment_link_id'])->toBe($link->id);
});

it('hides detached attachments from the dialog list but keeps them downloadable', function () {
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'attachment' => attachmentFile('still-here.pdf'),
        ]);
    $att = Attachment::first();
    $link = \App\Models\AttachmentLink::where('attachment_id', $att->id)->firstOrFail();

    $this->actingAs($this->user)->delete("/contracts/attachment-links/{$link->id}/detach");

    expect(AttachmentUpload::forKey($link->attachable_key))->toHaveCount(0);

    $this->actingAs($this->user)
        ->get("/attachments/{$att->id}/download")
        ->assertOk();
});

it('superadmin can wipe all attachments via the bulk delete endpoint', function () {
    $superadmin = User::factory()->create(['role' => User::ROLE_SUPERADMIN, 'password' => bcrypt('correct-horse')]);

    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'attachment' => attachmentFile('a.pdf'),
        ]);
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2025,
            'status' => 'no',
            'attachment' => attachmentFile('b.pdf'),
        ]);

    expect(Attachment::count())->toBe(2);

    $resp = $this->actingAs($superadmin)
        ->post('/settings/delete-data', [
            'type' => 'attachments',
            'password' => 'correct-horse',
        ]);

    $resp->assertRedirect('/settings');
    expect(Attachment::count())->toBe(0);
    expect(AuditLog::where('action', 'contract_cpa_confirmed')->count())->toBe(2);
    // Superadmin Data-control actions are not audit-logged.
    expect(AuditLog::where('action', 'attachments_purged')->count())->toBe(0);
});

it('link-existing reuses the existing attachment instead of writing new bytes', function () {
    // Upload once — creates attachment + link.
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'attachment' => attachmentFile('shared.pdf'),
        ]);

    expect(Attachment::count())->toBe(1);
    expect(\App\Models\AttachmentLink::count())->toBe(1);
    $original = Attachment::first();
    $originalHash = $original->sha256;

    // Upload again to a different slot with the same filename + 'link' action.
    // Must include a real attachment file so server-side validation passes —
    // server discards the bytes and just creates a fresh link row.
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2025,
            'status' => 'no',
            'attachment' => attachmentFile('shared.pdf'),
            'dupe_action' => 'link',
        ]);

    // Still only ONE attachment row — bytes weren't duplicated.
    expect(Attachment::count())->toBe(1);
    // But TWO link rows now point at it (one per slot).
    expect(\App\Models\AttachmentLink::count())->toBe(2);

    $original->refresh();
    expect($original->sha256)->toBe($originalHash);

    $links = \App\Models\AttachmentLink::all();
    expect($links->pluck('attachment_id')->unique())->toHaveCount(1);
    expect($links->pluck('attachable_key')->sort()->values()->all())
        ->toBe([
            "contract:{$this->contract->id}:cpa:2025",
            "contract:{$this->contract->id}:cpa:2026",
        ]);
});

it('detaching one slot leaves the file linked from the other slot', function () {
    // Two slots linked to the same file (one upload + one link).
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'attachment' => attachmentFile('shared.pdf'),
        ]);
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2025,
            'status' => 'no',
            'attachment' => attachmentFile('shared.pdf'),
            'dupe_action' => 'link',
        ]);

    $att = Attachment::first();
    $links = \App\Models\AttachmentLink::orderBy('id')->get();
    expect($links)->toHaveCount(2);

    // Detach the first slot (2026).
    $this->actingAs($this->user)
        ->delete("/contracts/attachment-links/{$links[0]->id}/detach");

    // First link is detached, second is still active.
    $links[0]->refresh();
    $links[1]->refresh();
    expect($links[0]->detached_at)->not->toBeNull();
    expect($links[1]->detached_at)->toBeNull();

    // Crucially: the attachment row itself stays ACTIVE because at
    // least one link still points at it. (Legacy detached_at column
    // mirrors only when the LAST active link goes away.)
    $att->refresh();
    expect($att->detached_at)->toBeNull();

    // forKey() for the still-active slot returns the file.
    $stillActive = AttachmentUpload::forKey("contract:{$this->contract->id}:cpa:2025");
    expect($stillActive)->toHaveCount(1);
    expect($stillActive->first()->attachment->id)->toBe($att->id);

    // forKey() for the detached slot returns nothing.
    expect(AttachmentUpload::forKey("contract:{$this->contract->id}:cpa:2026"))->toHaveCount(0);
});

it('detaching the last link also marks the attachment row as detached', function () {
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'attachment' => attachmentFile('only.pdf'),
        ]);

    $att = Attachment::first();
    $link = \App\Models\AttachmentLink::firstOrFail();
    expect($att->detached_at)->toBeNull();

    $this->actingAs($this->user)
        ->delete("/contracts/attachment-links/{$link->id}/detach");

    $att->refresh();
    $link->refresh();
    expect($link->detached_at)->not->toBeNull();
    expect($att->detached_at)->not->toBeNull();
});

it('rejects bulk delete without the correct password', function () {
    $superadmin = User::factory()->create(['role' => User::ROLE_SUPERADMIN, 'password' => bcrypt('correct-horse')]);

    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
            'attachment' => attachmentFile('a.pdf'),
        ]);

    $this->actingAs($superadmin)
        ->post('/settings/delete-data', [
            'type' => 'attachments',
            'password' => 'wrong-password',
        ])
        ->assertSessionHasErrors('password');

    expect(Attachment::count())->toBe(1);
});
