<?php

// Public registration is disabled — accounts are provisioned only by
// a superadmin via the Manage users page. The /register route still
// resolves so Breeze internals don't break, but always 404s.

test('GET /register 404s', function () {
    $this->get('/register')->assertNotFound();
});

test('POST /register cannot create a user', function () {
    // 405 (method not allowed) since only the GET route is defined for
    // registration — but the user-facing outcome is the same: no account
    // is created and the request stays unauthenticated.
    $response = $this->post('/register', [
        'name' => 'Test User',
        'email' => 'test@example.com',
        'password' => 'password',
        'password_confirmation' => 'password',
    ]);

    expect($response->status())->toBeIn([404, 405]);
    $this->assertGuest();
});
