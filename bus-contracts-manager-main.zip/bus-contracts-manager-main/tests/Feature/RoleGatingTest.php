<?php

use App\Models\AppSetting;
use App\Models\Attachment;
use App\Models\AuditLog;
use App\Models\Contract;
use App\Models\User;

beforeEach(function () {
    $this->superadmin = User::factory()->create(['role' => User::ROLE_SUPERADMIN]);
    $this->admin = User::factory()->create(['role' => User::ROLE_ADMIN]);
    $this->user = User::factory()->create(['role' => User::ROLE_USER]);

    $this->contract = Contract::create([
        'company' => 'TST',
        'depot' => 'D1',
        'route' => '99',
        'contract_number' => 'TEST-001',
        'tender_date' => '2024-01-01',
        'start_date' => '2024-06-01',
        'end_date' => '2031-05-31',
        'contract_value' => 1000000,
        'created_by' => $this->admin->id,
    ]);
});

// ── user role: read-only ──────────────────────────────────────────────

it('user role can browse the contracts page', function () {
    $this->actingAs($this->user)->get('/contracts')->assertOk();
});

it('user role cannot export contracts', function () {
    $this->actingAs($this->user)->get('/contracts/export.csv')->assertForbidden();
});

it('user role cannot download the contract import template', function () {
    $this->actingAs($this->user)->get('/contracts/import-template.csv')->assertForbidden();
});

it('user role cannot create a contract', function () {
    $this->actingAs($this->user)->post('/contracts', [])->assertForbidden();
});

it('user role cannot update a contract', function () {
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}", ['change_kind' => 'override'])
        ->assertForbidden();
});

it('user role cannot delete a contract', function () {
    $this->actingAs($this->user)
        ->delete("/contracts/{$this->contract->id}")
        ->assertForbidden();
});

it('user role cannot update a CPA confirmation', function () {
    $this->actingAs($this->user)
        ->patch("/contracts/{$this->contract->id}/cpa-confirmation", [
            'year' => 2026,
            'status' => 'yes',
        ])
        ->assertForbidden();
});

it('user role cannot view the audit log page', function () {
    $this->actingAs($this->user)->get('/audit-log')->assertForbidden();
});

it('user role cannot view the users page', function () {
    $this->actingAs($this->user)->get('/users')->assertForbidden();
});

it('user role cannot view the settings page', function () {
    $this->actingAs($this->user)->get('/settings')->assertForbidden();
});

it('user role can browse indices and export', function () {
    $this->actingAs($this->user)->get('/indices')->assertOk();
    $this->actingAs($this->user)->get('/indices/export.csv')->assertOk();
});

it('user role cannot download index import templates', function () {
    $this->actingAs($this->user)
        ->get('/indices/cpi/import-template.csv')
        ->assertForbidden();
});

// ── admin vs superadmin separation ────────────────────────────────────

it('admin cannot freeze the superadmin', function () {
    $resp = $this->actingAs($this->admin)
        ->patch("/users/{$this->superadmin->id}", [
            'name' => $this->superadmin->name,
            'email' => $this->superadmin->email,
            'role' => User::ROLE_SUPERADMIN,
            'frozen' => 1,
            'password' => 'password',
        ]);

    // Either 403 from the inline guard or a redirect with no state change.
    $this->superadmin->refresh();
    expect($this->superadmin->frozen_at)->toBeNull();
});

it('admin cannot promote anyone to superadmin', function () {
    $regular = User::factory()->create(['role' => User::ROLE_USER, 'password' => bcrypt('xxx')]);

    $this->actingAs($this->admin)
        ->patch("/users/{$regular->id}", [
            'name' => $regular->name,
            'email' => $regular->email,
            'role' => User::ROLE_SUPERADMIN,
            'password' => 'admin-pw',
        ]);

    $regular->refresh();
    expect($regular->role)->not->toBe(User::ROLE_SUPERADMIN);
});

it('admin user list excludes the superadmin row', function () {
    $resp = $this->actingAs($this->admin)->get('/users')->assertOk();
    expect($resp->getContent())->not->toContain($this->superadmin->email);
});

it('superadmin user list includes every user', function () {
    $resp = $this->actingAs($this->superadmin)->get('/users')->assertOk();
    $body = $resp->getContent();
    expect($body)->toContain($this->superadmin->email)
        ->and($body)->toContain($this->admin->email);
});

it('admin cannot see audit-log entries authored by the superadmin', function () {
    AuditLog::create([
        'user_id' => $this->superadmin->id,
        'action' => 'contract_added',
        'entity_type' => 'contracts',
        'entity_id' => $this->contract->id,
        'note' => 'Action by superadmin — should not be visible to admin',
        'ip_address' => '127.0.0.1',
    ]);
    AuditLog::create([
        'user_id' => $this->admin->id,
        'action' => 'contract_added',
        'entity_type' => 'contracts',
        'entity_id' => $this->contract->id,
        'note' => 'Action by admin — visible to admin',
        'ip_address' => '127.0.0.1',
    ]);

    $body = $this->actingAs($this->admin)->get('/audit-log')->getContent();
    expect($body)->toContain('Action by admin — visible to admin')
        ->and($body)->not->toContain('Action by superadmin — should not be visible to admin');
});

// ── superadmin-only Data control ──────────────────────────────────────

it('admin cannot trigger data-control destructive actions', function () {
    $this->actingAs($this->admin)
        ->post('/settings/delete-data', ['type' => 'audit_log', 'password' => 'whatever'])
        ->assertForbidden();

    $this->actingAs($this->admin)
        ->post('/settings/delete-data', ['type' => 'attachments', 'password' => 'whatever'])
        ->assertForbidden();

    $this->actingAs($this->admin)
        ->post('/settings/delete-data', ['type' => 'all', 'password' => 'whatever'])
        ->assertForbidden();
});

it('superadmin can trigger data-control actions with the correct password', function () {
    $superadmin = User::factory()->create(['role' => User::ROLE_SUPERADMIN, 'password' => bcrypt('right-pw')]);

    $this->actingAs($superadmin)
        ->post('/settings/delete-data', ['type' => 'audit_log', 'password' => 'right-pw'])
        ->assertRedirect();
});

it('superadmin gets a 422 with wrong password', function () {
    $superadmin = User::factory()->create(['role' => User::ROLE_SUPERADMIN, 'password' => bcrypt('right-pw')]);

    $this->actingAs($superadmin)
        ->post('/settings/delete-data', ['type' => 'audit_log', 'password' => 'wrong-pw'])
        ->assertSessionHasErrors('password');
});

// ── upload limits writes ──────────────────────────────────────────────

it('admin cannot edit upload limits', function () {
    $this->actingAs($this->admin)
        ->post('/settings/upload-limits', [
            'password' => 'whatever',
            'attachment_max_kb' => 1024,
            'attachment_extensions' => 'pdf',
            'template_max_kb' => 1024,
            'template_extensions' => 'csv',
        ])
        ->assertForbidden();
});

it('reset upload limits drops the override rows so getters return defaults', function () {
    $superadmin = User::factory()->create(['role' => User::ROLE_SUPERADMIN, 'password' => bcrypt('reset-pw')]);

    AppSetting::put(AppSetting::ATTACHMENT_MAX_KB, '4096', $superadmin->id);
    AppSetting::put(AppSetting::ATTACHMENT_ALLOWED_EXTENSIONS, 'pdf', $superadmin->id);
    AppSetting::put(AppSetting::TEMPLATE_MAX_KB, '512', $superadmin->id);
    AppSetting::put(AppSetting::TEMPLATE_ALLOWED_EXTENSIONS, 'csv', $superadmin->id);

    $this->actingAs($superadmin)
        ->post('/settings/upload-limits/reset', ['password' => 'reset-pw'])
        ->assertRedirect();

    expect(AppSetting::query()->whereIn('key', [
        AppSetting::ATTACHMENT_MAX_KB,
        AppSetting::ATTACHMENT_ALLOWED_EXTENSIONS,
        AppSetting::TEMPLATE_MAX_KB,
        AppSetting::TEMPLATE_ALLOWED_EXTENSIONS,
    ])->count())->toBe(0);

    expect(Attachment::maxUploadKb())->toBe(AppSetting::DEFAULT_ATTACHMENT_MAX_KB);
});
